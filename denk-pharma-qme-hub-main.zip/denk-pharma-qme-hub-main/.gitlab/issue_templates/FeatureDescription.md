### Ziel

Kurze Beschreibung von Ziel und Mehrwert.

:sparkles: [**Figma Prototyp**](url)    
:rainbow: [**Figma Design System**](url)    

</br>
<details>
<summary><h3>Briefing Kunde</h3></summary>

Kommunizierte Aufwandsschätzung: XX PT

- ...
- ...

</details>

### Acceptance Criteria

* [ ] AC 1
* [ ] AC 2

### Offen

* [ ] ...

### To Dos

* [ ] ...

#### Review

* [ ] ...

### Livegang
Timing: Live Deploy bis XX.XX.XX

* [ ] ...
* [ ] ggf. wichtigste Dokumentation anlegen (README.md / Notion / ...)
* [ ] ggf. Regressiontests um neue Funktionalität erweitern  @cl-format-d