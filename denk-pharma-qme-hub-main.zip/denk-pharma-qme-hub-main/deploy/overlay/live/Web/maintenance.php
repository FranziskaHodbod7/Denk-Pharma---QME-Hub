<?php

/*
 * This Script replaces the index.php during a deployment to prevent caches from being partially build
 */

// Throw 404 if script is not in use
if (basename($_SERVER['SCRIPT_NAME']) !== 'index.php') {
    http_response_code(404);
    die('Page not Found!');
}

# Enable this feature if needed
#    // disable maintenance page for requests from Format D
#    if ($_SERVER['REMOTE_ADDR'] == '212.36.166.138') {
#        require_once('disabled_index.php');
#    }

// Throw 503 if script is active and display maintenance message
http_response_code(503);
header('Retry-After: 10');
?>
<!doctype html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Maintenance</title>
    <style>
        @keyframes rotate {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(-360deg);
            }
        }
    </style>
</head>

<body style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100vh; margin: 0;">
    <div style="text-align: center; font-family: sans-serif; line-height: 1.5; padding: 20px;">
        <svg style=" animation: rotate 5s infinite; width: 48px; height: 48px;" width="24" height="24"
            viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M14.5728 18H9.43225M12 12L9.2 14.1C7.18555 15.6108 6 17.9819 6 20.5V21H18V20.5C18 17.9819 16.8144 15.6108 14.8 14.1L12 12ZM12 12L9.2 9.9C7.18555 8.38916 6 6.01806 6 3.5V3H18V3.5C18 6.01806 16.8144 8.38916 14.8 9.9L12 12Z"
                stroke="#1F2937" stroke-width="1.5" />
        </svg>
        <h1>Maintenance</h1>
        <h4>Our application is currently under reconstruction. <br> Thank you for your understanding!</h4>

        <!-- Here you have to actively leave links and fill in the imprint and privacy policy with customer data (address, contact, commercial register, etc.).
       <p style="margin: 0;">
           Until then, you can reach us by email at
           <a href="mailto:test@abc.de" style="color: black;">[EMAIL]</a>
           or by
           <a href="tel:0123456789" style="color: black;">[PHONE]</a>
           .
       </p>
       <br>
       <p>
           <a href="maintenance-imprint.html" style="color: black;" rel="noopener noreferrer">Imprint</a> | <a href="maintenance-privacy-policy.html" style="color: black;" rel="noopener noreferrer">Privacy Policy</a>
       </p>
       -->

    </div>
</body>

</html>