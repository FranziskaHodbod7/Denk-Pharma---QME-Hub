<?php

/*
 * This Script clears the opcodecache after deployment
 */

if ($_GET['reset'] === 'vn873Rhao86ALdftgvnwom') {
	opcache_reset();
} // Throw 404 if command is not provided
else {
	http_response_code(404);
	die('Page not Found!');
}

?>
<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>OPcache</title>
</head>

<body>
<p style="font-family: sans-serif;">Cache has been cleared...</p>
</body>
</html>
