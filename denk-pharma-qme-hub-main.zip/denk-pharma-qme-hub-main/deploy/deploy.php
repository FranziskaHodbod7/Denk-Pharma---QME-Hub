<?php

namespace Deployer;

require '/var/deployer/recipies/neos-cms.php';

task('deploy')->desc('Deploy App');




set('application', 'DenkPharma QME Hub');
set('bin/php', '/usr/bin/php8.4');


task('deploy:clean_code_cache', function () {
	run('cluster-control login --pa_token="' . getenv('MAXCLUSTER_PAT') . '"');
	run('cluster-control php:restart C-2666 srv-a');
	run('cluster-control logout');
})->desc('MaxCluster clear PHP code cache');

host('live')
	->setHostname('109.71.72.205')
	->setRemoteUser('web-user')
	->setPort(22)
	->set('labels', ['stage' => 'live'])
	->setForwardAgent(false)
	->set('deploy_path', '/var/www/share/default')
	->set('flow_context', 'Production/MaxClusterLive')
	->set('symlink_configuration_paths', [
		'Configuration/Production/MaxClusterLive/Caches.yaml',
		'Configuration/Production/MaxClusterLive/Settings.yaml',
	]);
