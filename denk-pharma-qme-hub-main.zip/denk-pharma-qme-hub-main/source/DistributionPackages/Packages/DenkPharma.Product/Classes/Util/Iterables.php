<?php

declare(strict_types=1);

namespace DenkPharma\Product\Util;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final class Iterables
{
	/**
	 * Generic n-level groupBy. Each key extractor receives the current item and
	 * the previous row's key at this level *within the current group path*: if
	 * any higher-level key changed compared to the previous row, this level's
	 * previous key is null (no previous in this group). Lets cascading-fallback
	 * rules be expressed declaratively at the call site (e.g. `$f['x'] ?: ($prev ?? '')`).
	 *
	 * @template T
	 * @param iterable<T> $items
	 * @param callable(T, ?string): string ...$keyFns
	 * @return array<string, mixed> nested N levels deep (N = count($keyFns));
	 *         intermediate levels are array<string, ...>, leaves are list<T>
	 */
	public static function groupBy(iterable $items, callable ...$keyFns): array
	{
		$result = [];
		/** @var list<?string> $previousKeys */
		$previousKeys = array_fill(0, count($keyFns), null);

		foreach ($items as $item) {
			$currentKeys = [];
			$stillMatching = true;
			foreach ($keyFns as $level => $keyFn) {
				$previous = $stillMatching ? $previousKeys[$level] : null;
				$key = $keyFn($item, $previous);
				$currentKeys[] = $key;
				if ($stillMatching && $key !== $previousKeys[$level]) {
					$stillMatching = false;
				}
			}

			$cursor = &$result;
			foreach ($currentKeys as $key) {
				$cursor[$key] ??= [];
				$cursor = &$cursor[$key];
			}
			$cursor[] = $item;
			unset($cursor);

			$previousKeys = $currentKeys;
		}

		return $result;
	}
}
