<?php

declare(strict_types=1);

namespace DenkPharma\Product\Eel;

use DenkPharma\Product\Presentation\AdministrationTable\AdministrationGroup;
use DenkPharma\Product\Presentation\Downloads\DownloadEntry;
use DenkPharma\Product\Service\AdministrationTableFactory;
use DenkPharma\Product\Service\IngredientLabeler;
use Neos\ContentRepository\Core\NodeType\NodeTypeNames;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\NodeType\NodeTypeCriteria;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\NodePath;
use Neos\ContentRepository\Core\Projection\ContentGraph\Nodes;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class CachingHelper implements ProtectedContextAwareInterface
{

	#[Flow\Inject(lazy: false)]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	/**
	 * Returns a list of NodeTypeNames (string) relevant for caching 
	 * @return string[]
	 */
	public function cacheRelevantNodeTypes(): array {
		return [
			"DenkPharma.Product:Abstract.Product",
			"DenkPharma.Product:Abstract.Formulation",
			"DenkPharma.Product:Abstract.Ingredient",
			"Sitegeist.Taxonomy:Taxonomy"
		];
	}

    public function accumulatedTaxonomiesTags(Node $productNode): array {
		$accumulatedTaxonomies = Nodes::createEmpty();

		$subgraph = $this->contentRepositoryRegistry->subgraphForNode($productNode);

		$accumulatedTaxonomies = $this->resolveReferenceNodes($subgraph, $productNode, "medications");
		
		$administrationsCollection = $subgraph->findNodeByPath(NodePath::fromString("administrations"), $productNode->aggregateId);
		if($administrationsCollection === null) {
			return [...$accumulatedTaxonomies];
		}

		$administrations = $subgraph->findChildNodes($administrationsCollection->aggregateId, FindChildNodesFilter::create());

		foreach($administrations as $administrationNode) {
			$accumulatedTaxonomies = $accumulatedTaxonomies->merge($this->resolveReferenceNodes($subgraph, $administrationNode, "administrationForm"));

			$formulations = $subgraph->findChildNodes($administrationNode->aggregateId, FindChildNodesFilter::create(nodeTypes: "DenkPharma.Product:Abstract.Formulation"));

			foreach($formulations as $formulationNode) {
				$accumulatedTaxonomies = $accumulatedTaxonomies->merge($this->resolveReferenceNodes($subgraph, $formulationNode, "packageQuantity"));

				$ingredients = $subgraph->findChildNodes($formulationNode->aggregateId, FindChildNodesFilter::create(nodeTypes: "DenkPharma.Product:Abstract.Ingredient"));

				foreach($ingredients as $ingredientNode) {
					$accumulatedTaxonomies = $accumulatedTaxonomies->merge($this->resolveReferenceNodes($subgraph, $ingredientNode, "substance"));
					$accumulatedTaxonomies = $accumulatedTaxonomies->merge($this->resolveReferenceNodes($subgraph, $ingredientNode, "substance-unit"));
				}
			}
		}

        return [...$accumulatedTaxonomies];
    }

	protected function resolveReferenceNodes(ContentSubgraphInterface $subgraph, Node $node, string $referenceName): Nodes
	{
		$substanceReferences = $subgraph->findReferences($node->aggregateId, FindReferencesFilter::create(referenceName:$referenceName));
		$nodes = Nodes::createEmpty();
		
		foreach($substanceReferences as $substanceReference) {
			$nodes = $nodes->append($substanceReference->node);
		}

		return $nodes;
	}

	public function allowsCallOfMethod($methodName): bool
	{
		return true;
	}
}