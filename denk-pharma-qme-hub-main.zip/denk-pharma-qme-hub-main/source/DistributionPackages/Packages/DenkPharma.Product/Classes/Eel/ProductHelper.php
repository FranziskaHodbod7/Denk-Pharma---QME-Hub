<?php

declare(strict_types=1);

namespace DenkPharma\Product\Eel;

use DenkPharma\Product\Presentation\AdministrationTable\AdministrationTableData;
use DenkPharma\Product\Presentation\Downloads\DownloadEntry;
use DenkPharma\Product\Service\AdministrationTableFactory;
use DenkPharma\Product\Service\IngredientLabeler;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class ProductHelper implements ProtectedContextAwareInterface
{
	#[Flow\Inject]
	protected AdministrationTableFactory $administrationTableFactory;

	#[Flow\Inject]
	protected IngredientLabeler $ingredientLabeler;

	/**
	 * @param list<Node> $administrations
	 */
	public function administrationTable(array $administrations): AdministrationTableData
	{
		return $this->administrationTableFactory->administrationGroups($administrations);
	}

	/**
	 * @param list<Node> $administrations
	 * @return list<DownloadEntry>
	 */
	public function downloads(array $administrations): array
	{
		$entries = [];
		foreach ($administrations as $admin) {
			$nodeContextPath = NodeAddress::fromNode($admin)->toJson();
			foreach ($admin->getProperty('downloads') ?? [] as $download) {
				$entries[] = new DownloadEntry(
					asset: $download,
					nodeContextPath: $nodeContextPath,
				);
			}
		}
		return $entries;
	}

	public function ingredientLabel(?Node $ingredient): string
	{
		return $ingredient === null ? '' : $this->ingredientLabeler->forIngredient($ingredient);
	}

	public function formulationLabel(?Node $formulation): string
	{
		return $formulation === null ? '' : $this->ingredientLabeler->forFormulation($formulation);
	}

	public function allowsCallOfMethod($methodName): bool
	{
		return true;
	}
}
