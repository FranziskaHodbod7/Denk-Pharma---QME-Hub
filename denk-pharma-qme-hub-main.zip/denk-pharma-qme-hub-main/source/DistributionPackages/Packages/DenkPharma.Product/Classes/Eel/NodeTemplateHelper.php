<?php

declare(strict_types=1);

namespace DenkPharma\Product\Eel;

use Neos\ContentRepository\Core\Projection\ContentGraph\AbsoluteNodePath;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;
use Sitegeist\Taxonomy\Service\TaxonomyService;

class NodeTemplateHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected TaxonomyService $taxonomyService;

    /**
     * Returns the nth (1-based) child taxonomy node under the given absolute path,
     * e.g. taxonomy(1, "/<Sitegeist.Taxonomy:Root>/administration-form")
     */
    public function taxonomy(int $index, string $absolutePath): ?Node
    {
        $subgraph = $this->taxonomyService->getDefaultSubgraph();
        $parent = $subgraph->findNodeByAbsolutePath(AbsoluteNodePath::fromString($absolutePath));
        if ($parent === null) {
            return null;
        }
        $i = 0;
        foreach ($subgraph->findChildNodes($parent->aggregateId, FindChildNodesFilter::create()) as $child) {
            if (++$i === $index) {
                return $child;
            }
        }
        return null;
    }

    /**
     * Returns the taxonomy node at the given absolute path directly.
     */
    public function taxonomyByPath(string $absolutePath): ?Node
    {
        $subgraph = $this->taxonomyService->getDefaultSubgraph();
        return $subgraph->findNodeByAbsolutePath(AbsoluteNodePath::fromString($absolutePath));
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
