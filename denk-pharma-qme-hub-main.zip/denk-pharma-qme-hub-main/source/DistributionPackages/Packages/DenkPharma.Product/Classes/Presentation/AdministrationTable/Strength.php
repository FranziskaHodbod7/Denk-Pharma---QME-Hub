<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class Strength
{
	public function __construct(
		public ?float $quantity,
		public string $unit,
		public ?string $nodeContextPath = null,
	) {
	}
}
