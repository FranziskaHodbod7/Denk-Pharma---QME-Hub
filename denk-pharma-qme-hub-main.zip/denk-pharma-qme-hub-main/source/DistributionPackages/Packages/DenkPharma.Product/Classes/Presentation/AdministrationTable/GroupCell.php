<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class GroupCell
{
	public function __construct(
		public string $label,
		public bool $firstInGroup,
		public int $rowspan,
	) {
	}
}
