<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class AdministrationGroup
{
	public bool $hasPackageQuantity;
	public bool $hasStrength;
	public bool $hasApplicationRecommendation;

	/**
	 * @param list<TableRow> $rows
	 */
	public function __construct(
		public string $label,
		public ?string $nodeContextPath,
		public array $rows,
	) {
		$this->hasPackageQuantity = (bool) array_filter($rows, static fn(TableRow $row) => $row->packageQuantity->label !== '');
		$this->hasStrength = (bool) array_filter($rows, static fn(TableRow $row) => $row->formulations->substances !== []);
		$this->hasApplicationRecommendation = (bool) array_filter($rows, static fn(TableRow $row) => $row->applicationRecommendation !== '');
	}
}
