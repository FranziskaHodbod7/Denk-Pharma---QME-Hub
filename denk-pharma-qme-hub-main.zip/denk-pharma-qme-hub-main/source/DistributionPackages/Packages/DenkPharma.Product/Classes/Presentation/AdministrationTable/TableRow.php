<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class TableRow
{
	public function __construct(
		public GroupCell $administrationForm,
		public GroupCell $packageQuantity,
		public Formulations $formulations,
		public string $applicationRecommendation,
		public ?string $formulationNodeContextPath = null,
	) {
	}
}
