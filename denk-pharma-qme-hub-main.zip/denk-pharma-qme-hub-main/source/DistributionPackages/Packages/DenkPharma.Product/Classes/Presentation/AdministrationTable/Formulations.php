<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class Formulations
{
	/**
	 * @param list<string> $substances
	 * @param list<list<?Strength>> $rows
	 */
	public function __construct(
		public array $substances,
		public array $rows,
	) {
	}
}
