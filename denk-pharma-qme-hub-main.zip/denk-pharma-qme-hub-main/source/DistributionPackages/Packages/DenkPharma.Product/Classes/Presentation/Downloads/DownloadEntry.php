<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\Downloads;

use Neos\Flow\Annotations as Flow;
use Neos\Media\Domain\Model\AssetInterface;

#[Flow\Proxy(false)]
final readonly class DownloadEntry
{
	public function __construct(
		public AssetInterface $asset,
		public ?string $nodeContextPath = null,
	) {
	}
}
