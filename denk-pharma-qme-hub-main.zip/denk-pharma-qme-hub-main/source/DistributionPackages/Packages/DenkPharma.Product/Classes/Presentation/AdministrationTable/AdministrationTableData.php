<?php

declare(strict_types=1);

namespace DenkPharma\Product\Presentation\AdministrationTable;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class AdministrationTableData
{
	/**
	 * @param list<AdministrationGroup> $groups
	 */
	public function __construct(
		public array $groups,
		public bool $hasPackageQuantity,
		public bool $hasStrength,
		public bool $hasApplicationRecommendation,
	) {
	}
}
