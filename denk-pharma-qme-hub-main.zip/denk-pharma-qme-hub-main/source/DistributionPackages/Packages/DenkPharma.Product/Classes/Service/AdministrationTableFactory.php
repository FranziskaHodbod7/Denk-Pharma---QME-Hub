<?php

declare(strict_types=1);

namespace DenkPharma\Product\Service;

use DenkPharma\Product\Presentation\AdministrationTable\AdministrationGroup;
use DenkPharma\Product\Presentation\AdministrationTable\AdministrationTableData;
use DenkPharma\Product\Presentation\AdministrationTable\Formulations;
use DenkPharma\Product\Presentation\AdministrationTable\GroupCell;
use DenkPharma\Product\Presentation\AdministrationTable\Strength;
use DenkPharma\Product\Presentation\AdministrationTable\TableRow;
use DenkPharma\Product\Util\Iterables;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;

class AdministrationTableFactory
{
	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	/**
	 * @param list<Node> $administrations
	 */
	public function administrationGroups(array $administrations): AdministrationTableData
	{
		$grouped = Iterables::groupBy(
			$this->walkFormulations($administrations),
			static fn (array $f, ?string $prev) => $f['formTitle'] ?: ($prev ?? ''),
			static fn (array $f, ?string $prev) => $f['packageQuantity'] ?: ($prev ?? ''),
			static fn (array $f, ?string $prev) => $f['applicationRecommendation'] ?: ($prev ?? ''),
		);

		$groups = $this->composeGroups($grouped);

		return new AdministrationTableData(
			groups: $groups,
			hasPackageQuantity: (bool) array_filter($groups, static fn(AdministrationGroup $g) => $g->hasPackageQuantity),
			hasStrength: (bool) array_filter($groups, static fn(AdministrationGroup $g) => $g->hasStrength),
			hasApplicationRecommendation: (bool) array_filter($groups, static fn(AdministrationGroup $g) => $g->hasApplicationRecommendation),
		);
	}

	/**
	 * Walk the (admin → formulation → ingredient) tree. Pure: no cascade state,
	 * no grouping; just yields a flat map per formulation node with raw values.
	 *
	 * @param list<Node> $administrations
	 * @return iterable<array{formTitle: string, formNodeAddress: string, packageQuantity: string, formulationNodeAddress: string, applicationRecommendation: string, ingredients: array<string, Strength>}>
	 */
	private function walkFormulations(array $administrations): iterable
	{
		foreach ($administrations as $admin) {
			$subgraph = $this->contentRepositoryRegistry->subgraphForNode($admin);
			$formTitle = $this->referenceTitle($subgraph, $admin, 'administrationForm');
			$formNodeAddress = NodeAddress::fromNode($admin)->toJson();

			foreach ($subgraph->findChildNodes($admin->aggregateId, FindChildNodesFilter::create()) as $formulation) {
				yield [
					'formTitle' => $formTitle,
					'formNodeAddress' => $formNodeAddress,
					'packageQuantity' => $this->referenceTitle($subgraph, $formulation, 'packageQuantity'),
					'formulationNodeAddress' => NodeAddress::fromNode($formulation)->toJson(),
					'applicationRecommendation' => (string)($formulation->getProperty('applicationRecommendation') ?? ''),
					'ingredients' => $this->extractIngredients($subgraph, $formulation),
				];
			}
		}
	}

	/**
	 * Emit one AdministrationGroup per admin form, each containing the rows for that form.
	 *
	 * @param array<string, array<string, array<string, list<array{ingredients: array<string, Strength>}>>>> $grouped
	 * @return list<AdministrationGroup>
	 */
	private function composeGroups(array $grouped): array
	{
		$groups = [];
		foreach ($grouped as $formTitle => $packagings) {
			$formGroupSize = array_sum(array_map(count(...), $packagings));
			$formNodeAddress = current(current($packagings))[0]['formNodeAddress'] ?? null;
			$rows = [];
			$isFirstForm = true;
			foreach ($packagings as $pkgTitle => $recs) {
				$pkgGroupSize = count($recs);
				$isFirstPkg = true;
				foreach ($recs as $recTitle => $items) {
					$formulationAddress = $items[0]['formulationNodeAddress'] ?? null;
					$rows[] = new TableRow(
						administrationForm: $this->groupCell($formTitle, $isFirstForm, $formGroupSize),
						packageQuantity: $this->groupCell($pkgTitle, $isFirstPkg, $pkgGroupSize),
						formulations: $this->buildFormulations(array_map(static fn (array $f) => $f['ingredients'], $items)),
						applicationRecommendation: $recTitle,
						formulationNodeContextPath: $formulationAddress,
					);
					$isFirstForm = false;
					$isFirstPkg = false;
				}
			}
			$groups[] = new AdministrationGroup(
				label: $formTitle,
				nodeContextPath: $formNodeAddress,
				rows: $rows,
			);
		}
		return $groups;
	}

	private function groupCell(string $label, bool $isFirstInGroup, int $groupSize): GroupCell
	{
		return new GroupCell(
			label: $label,
			firstInGroup: $isFirstInGroup,
			rowspan: $isFirstInGroup ? $groupSize : 0,
		);
	}

	/**
	 * @return array<string, Strength> keyed by substance title
	 */
	private function extractIngredients(ContentSubgraphInterface $subgraph, Node $formulation): array
	{
		$ingredients = [];
		foreach ($subgraph->findChildNodes($formulation->aggregateId, FindChildNodesFilter::create()) as $ingredient) {
			$substance = $this->referenceTitle($subgraph, $ingredient, 'substance');
			if ($substance === '') {
				continue;
			}
			$ingredients[$substance] = new Strength(
				quantity: $ingredient->getProperty('quantity'),
				unit: $this->referenceTitle($subgraph, $ingredient, 'substance-unit'),
				nodeContextPath: NodeAddress::fromNode($ingredient)->toJson(),
			);
		}
		return $ingredients;
	}

	/**
	 * @param list<array<string, Strength>> $ingredientsList
	 */
	private function buildFormulations(array $ingredientsList): Formulations
	{
		$substances = [];
		foreach ($ingredientsList as $ingredients) {
			foreach (array_keys($ingredients) as $sub) {
				$substances[$sub] = true;
			}
		}
		$substances = array_keys($substances);

		$rows = [];
		foreach ($ingredientsList as $ingredients) {
			$row = [];
			foreach ($substances as $sub) {
				$row[] = $ingredients[$sub] ?? null;
			}
			$rows[] = $row;
		}

		return new Formulations(substances: $substances, rows: $rows);
	}

	private function referenceTitle(ContentSubgraphInterface $subgraph, Node $node, string $referenceName): string
	{
		$references = $subgraph->findReferences(
			$node->aggregateId,
			FindReferencesFilter::create(referenceName: $referenceName),
		);
		foreach ($references as $reference) {
			return (string)($reference->node->getProperty('title') ?? '');
		}
		return '';
	}
}
