<?php

declare(strict_types=1);

namespace DenkPharma\Product\Service;

use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;

class IngredientLabeler
{
	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	/**
	 * "120mg Paracetamol" — empty when no substance is referenced.
	 */
	public function forIngredient(Node $ingredient): string
	{
		$subgraph = $this->contentRepositoryRegistry->subgraphForNode($ingredient);
		$substance = $this->referenceTitle($subgraph, $ingredient, 'substance');
		if ($substance === '') {
			return '';
		}
		$unit = $this->referenceTitle($subgraph, $ingredient, 'substance-unit');
		$quantity = $ingredient->getProperty('quantity');
		$magnitude = $quantity !== null && $quantity !== '' ? (string)$quantity . $unit : '';
		return $magnitude !== '' ? "{$magnitude} {$substance}" : $substance;
	}

	/**
	 * "120mg Paracetamol + 10mg Caffeine" — joins ingredient labels with " + ".
	 * Empty when no ingredient yields a label.
	 */
	public function forFormulation(Node $formulation): string
	{
		$subgraph = $this->contentRepositoryRegistry->subgraphForNode($formulation);
		$parts = [];
		foreach ($subgraph->findChildNodes($formulation->aggregateId, FindChildNodesFilter::create()) as $ingredient) {
			$label = $this->forIngredient($ingredient);
			if ($label !== '') {
				$parts[] = $label;
			}
		}
		return implode(' + ', $parts);
	}

	private function referenceTitle(ContentSubgraphInterface $subgraph, Node $node, string $referenceName): string
	{
		$references = $subgraph->findReferences(
			$node->aggregateId,
			FindReferencesFilter::create(referenceName: $referenceName),
		);
		foreach ($references as $reference) {
			return (string)($reference->node->getProperty('title') ?? '');
		}
		return '';
	}
}
