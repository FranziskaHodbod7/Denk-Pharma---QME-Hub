function consumeTrackingCookie(name: string): string | undefined {
    const value = document.cookie
        .split('; ')
        .find(row => row.startsWith(`${name}=`))
        ?.split('=')[1]

    if (value) {
        document.cookie = `${name}=; Max-Age=0; path=/;`
    }

    return value
}

const trackingEvent = consumeTrackingCookie('DenkPharma_Tracking')

if (trackingEvent) {
    window.dataLayer = window.dataLayer || []
    window.dataLayer.push({ event: trackingEvent })
}
