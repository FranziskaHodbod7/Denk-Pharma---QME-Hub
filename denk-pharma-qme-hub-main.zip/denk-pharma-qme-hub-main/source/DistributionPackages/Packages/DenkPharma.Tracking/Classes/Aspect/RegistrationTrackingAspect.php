<?php

declare(strict_types=1);

namespace DenkPharma\Tracking\Aspect;

use Neos\Flow\Aop\JoinPointInterface;
use Neos\Flow\Annotations as Flow;

#[Flow\Aspect]
class RegistrationTrackingAspect
{
    #[Flow\AfterReturning("method(DenkPharma\User\Controller\RegisterController->onUserCreated())")]
    public function setAccountCreatedCookie(JoinPointInterface $joinPoint): void
    {
        $this->sendTrackingCookie('account_created');
    }

    protected function sendTrackingCookie(string $event): void
    {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

        setcookie('DenkPharma_Tracking', $event, [
            'expires'  => 0,
            'path'     => '/',
            'samesite' => 'Lax',
            'httponly' => false,
            'secure'   => $isHttps,
        ]);
    }
}
