# DenkPharma.LegacyUserImport

## CSV format

| # | Field       | Notes                                        |
|---|-------------|----------------------------------------------|
| 1 | firstName   |                                              |
| 2 | lastName    |                                              |
| 3 | email       | lowercased; must be a valid address          |
| 4 | language    | `EN` / `ES` / `FR` → `en_GB` / `es_ES` / `fr_FR` |
| 5 | territory   | stored as the user's country                 |
| 6 | city        | stored as the user's city                    |
| 7 | region      | recorded in the report                       |

## Usage

### 1. Import users

```bash
# Dry run — parses and reports, creates nothing
./flow legacyuserimport:import --csv Data/user_import/registrations.csv --dry-run

# Real import, writing the JSON report to a file for the notification step
./flow legacyuserimport:import --csv Data/user_import/registrations.csv --json Data/user_import/report.json
```

### 2. Send notifications

```bash
# Import first, then send using the written report
./flow legacyuserimport:import --csv registrations.csv --json report.json
./flow legacyuserimport:send --json report.json

# Dry run: render each mail, print the reset URL, optionally dump the HTML
./flow legacyuserimport:send --json report.json --dry-run --dump-dir Data/user_import/mails

# Staged test send: only the first N
./flow legacyuserimport:send --json report.json --limit 10
```
