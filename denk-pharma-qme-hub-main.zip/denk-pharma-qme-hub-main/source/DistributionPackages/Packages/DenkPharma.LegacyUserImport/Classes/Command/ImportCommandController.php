<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Command;

use DenkPharma\LegacyUserImport\Csv\CsvUserRowReader;
use DenkPharma\LegacyUserImport\Dto\ImportedUser;
use DenkPharma\LegacyUserImport\Dto\ImportStatus;
use DenkPharma\LegacyUserImport\Service\UserImporter;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;

class ImportCommandController extends CommandController
{
    #[Flow\Inject]
    protected UserImporter $importer;

    /**
     * Import legacy QME registrations from the CSV, creating active hub users.
     *
     * @param string $csv Path to the CSV to import
     * @param string $json Optional path to also write the JSON report to
     * @param bool $dryRun Parse and report without creating any users
     */
    public function importCommand(string $csv, string $json = '', bool $dryRun = false): void
    {
        if (!is_file($csv)) {
            $this->outputLine('<error>CSV not found: %s</error>', [$csv]);
            $this->quit(1);
        }

        $result = (new CsvUserRowReader())->read((string)file_get_contents($csv));
        foreach ($result->problems as $problem) {
            $this->outputLine('<comment>skipped row: %s</comment>', [$problem]);
        }

        $this->outputLine('<info>%s %d CSV row(s)...</info>', [$dryRun ? 'Dry-running' : 'Importing', count($result->rows)]);
        $report = $this->importer->import($result->rows, $dryRun, function (ImportedUser $user, int $index, int $total): void {
            $reason = $user->reason !== null ? sprintf(' (%s)', $user->reason) : '';
            $this->outputLine('  [%d/%d] %s %s%s', [$index, $total, $user->status->value, $user->email, $reason]);
        });

        $created = $report->countByStatus(ImportStatus::Created);
        $skipped = $report->countByStatus(ImportStatus::Skipped);
        $this->outputLine('<success>%s: %d created, %d skipped, %d CSV rows dropped</success>', [
            $dryRun ? 'Dry run' : 'Import',
            $created,
            $skipped,
            count($result->problems),
        ]);

        $encoded = $report->toJson();
        if ($json !== '') {
            file_put_contents($json, $encoded);
            $this->outputLine('<success>Report written to %s</success>', [$json]);
            return;
        }

        $this->outputLine('----- JSON -----');
        $this->output($encoded . "\n");
    }
}
