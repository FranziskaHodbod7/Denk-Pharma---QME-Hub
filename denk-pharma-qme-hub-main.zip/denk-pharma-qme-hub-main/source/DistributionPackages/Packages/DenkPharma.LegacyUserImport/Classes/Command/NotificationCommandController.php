<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Command;

use DenkPharma\LegacyUserImport\Dto\ImportedUser;
use DenkPharma\LegacyUserImport\Dto\ImportReport;
use DenkPharma\LegacyUserImport\Dto\ImportStatus;
use DenkPharma\LegacyUserImport\Dto\LanguageDimension;
use DenkPharma\LegacyUserImport\Dto\NotificationOutcome;
use DenkPharma\LegacyUserImport\Dto\NotificationStatus;
use DenkPharma\LegacyUserImport\Service\LegacyImportNotificationService;
use FormatD\UserManagement\Domain\Model\PasswordResetToken;
use FormatD\UserManagement\Domain\Repository\AbstractAccountRelatedTokenRepository;
use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Service\ConfigurationSetTrait;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;
use Neos\Flow\Persistence\PersistenceManagerInterface;
use Neos\Flow\Security\AccountRepository;
use Neos\Party\Domain\Service\PartyService;

class NotificationCommandController extends CommandController
{
    use ConfigurationSetTrait;

    protected const AUTH_PROVIDER = 'FormatD.UserManagementPlugin:Login';

    /**
     * Number of mails to send before pausing.
     */
    protected const BATCH_SIZE = 2;

    /**
     * Seconds to wait between batches, to avoid overwhelming the mail transport.
     */
    protected const BATCH_PAUSE_SECONDS = 1;

    #[Flow\Inject]
    protected LegacyImportNotificationService $notificationService;

    #[Flow\Inject]
    protected AccountRepository $accountRepository;

    #[Flow\Inject]
    protected AbstractAccountRelatedTokenRepository $tokenRepository;

    #[Flow\Inject]
    protected PartyService $partyService;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    public function initializeObject(): void
    {
        $this->initializeConfigurationSetObject();
    }

    /**
     * Send the hub-switch + password-reset email to each imported user.
     *
     * @param string $json Path to the import JSON report; reads stdin when empty
     * @param bool $dryRun Render each mail and print its reset URL without sending
     * @param int $limit Send only the first N (0 = all) — for a staged test send
     * @param string $dumpDir On dry-run, also write each rendered mail HTML to this directory
     */
    public function sendCommand(string $json = '', bool $dryRun = false, int $limit = 0, string $dumpDir = ''): void
    {
        $raw = $json !== '' ? (string)file_get_contents($json) : (string)file_get_contents('php://stdin');
        $report = ImportReport::fromJson($raw);

        $eligible = array_values(array_filter(
            $report->getUsers(),
            static fn (ImportedUser $importedUser): bool => $importedUser->status === ImportStatus::Created,
        ));
        $total = $limit > 0 ? min($limit, count($eligible)) : count($eligible);
        $this->outputLine('<info>%s %d notification(s), %d at a time with a %ds pause...</info>', [
            $dryRun ? 'Dry-running' : 'Sending',
            $total,
            self::BATCH_SIZE,
            self::BATCH_PAUSE_SECONDS,
        ]);

        $outcomes = [];
        $sent = 0;
        foreach ($eligible as $importedUser) {
            if ($limit > 0 && $sent >= $limit) {
                break;
            }

            $outcome = $this->processUser($importedUser, $dryRun, $dumpDir);
            $outcomes[] = $outcome;

            if ($outcome->status === NotificationStatus::Sent) {
                $sent++;
                $this->outputLine('  <success>[%d/%d] sent to %s</success>', [$sent, $total, $importedUser->email]);

                if (!$dryRun && $sent % self::BATCH_SIZE === 0 && $sent < $total) {
                    $this->outputLine('  <comment>waiting %ds before the next batch...</comment>', [self::BATCH_PAUSE_SECONDS]);
                    sleep(self::BATCH_PAUSE_SECONDS);
                }
            }
        }

        $this->report($outcomes, $dryRun);
    }

    protected function processUser(ImportedUser $importedUser, bool $dryRun, string $dumpDir = ''): NotificationOutcome
    {
        $account = $this->accountRepository->findActiveByAccountIdentifierAndAuthenticationProviderName(
            $importedUser->email,
            self::AUTH_PROVIDER,
        );
        if ($account === null) {
            return new NotificationOutcome($importedUser->email, NotificationStatus::Skipped, 'no-active-account');
        }

        $user = $this->partyService->getAssignedPartyOfAccount($account);
        if (!$user instanceof User) {
            return new NotificationOutcome($importedUser->email, NotificationStatus::Skipped, 'no-party');
        }

        $token = new PasswordResetToken();
        $token->setEmailAddress($importedUser->email);
        $token->setAccount($account);

        $locale = LanguageDimension::fromCsv($importedUser->language)->locale();

        try {
            if ($dryRun) {
                $rendered = $this->notificationService->renderHubSwitchNotification($user, $token, $locale, $this->configurationSet);
                $this->outputLine('<comment>[dry-run] %s (%s) subject: %s</comment>', [$importedUser->email, $locale, $rendered['subject']]);
                if (preg_match('#href="([^"]*tokenString[^"]*)"#', $rendered['html'], $matches) === 1) {
                    $this->outputLine('  reset URL: %s', [html_entity_decode($matches[1])]);
                } else {
                    $this->outputLine('  <error>reset URL not found in rendered mail</error>');
                }
                if ($dumpDir !== '') {
                    $file = rtrim($dumpDir, '/') . '/' . $locale . '_' . $importedUser->email . '.html';
                    file_put_contents($file, $rendered['html']);
                    $this->outputLine('  dumped: %s', [$file]);
                }
                return new NotificationOutcome($importedUser->email, NotificationStatus::Skipped, 'dry-run');
            }

            $this->tokenRepository->add($token);
            $this->persistenceManager->persistAll();
            $this->notificationService->sendHubSwitchNotification($user, $token, $locale, $this->configurationSet);

            return new NotificationOutcome($importedUser->email, NotificationStatus::Sent, null);
        } catch (\Throwable $exception) {
            $messages = [];
            for ($current = $exception; $current !== null; $current = $current->getPrevious()) {
                $messages[] = sprintf('%s: %s', (new \ReflectionClass($current))->getShortName(), $current->getMessage());
            }
            return new NotificationOutcome($importedUser->email, NotificationStatus::Failed, implode(' <- ', $messages));
        }
    }

    /**
     * @param list<NotificationOutcome> $outcomes
     */
    protected function report(array $outcomes, bool $dryRun): void
    {
        $counts = [NotificationStatus::Sent->value => 0, NotificationStatus::Skipped->value => 0, NotificationStatus::Failed->value => 0];
        foreach ($outcomes as $outcome) {
            $counts[$outcome->status->value]++;
            if ($outcome->status === NotificationStatus::Failed) {
                $this->outputLine('<error>FAILED %s: %s</error>', [$outcome->email, (string)$outcome->reason]);
            }
        }

        $this->outputLine('<success>%s: %d sent, %d skipped, %d failed</success>', [
            $dryRun ? 'Dry run' : 'Notification',
            $counts[NotificationStatus::Sent->value],
            $counts[NotificationStatus::Skipped->value],
            $counts[NotificationStatus::Failed->value],
        ]);
    }
}
