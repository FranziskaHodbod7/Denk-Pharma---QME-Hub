<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Csv;

use DenkPharma\LegacyUserImport\Dto\CsvUserRow;
use DenkPharma\LegacyUserImport\Dto\LanguageDimension;

final class CsvUserRowReader
{
    protected const BOM = "\xEF\xBB\xBF";

    public function read(string $csvContent): CsvReadResult
    {
        $stream = fopen('php://temp', 'r+');
        if ($stream === false) {
            throw new \RuntimeException('Unable to open a temporary stream for CSV parsing', 1753000002);
        }
        fwrite($stream, $this->stripBom($csvContent));
        rewind($stream);

        $rows = [];
        $problems = [];
        $offset = -1;

        // Empty escape string keeps parsing faithful to the source and avoids the PHP 8.4 default-escape deprecation.
        while (($record = fgetcsv($stream, null, ',', '"', '')) !== false) {
            if ($record === [null]) {
                continue;
            }

            $offset++;
            if ($offset === 0) {
                continue;
            }

            $values = array_map(static fn ($value): string => trim((string)$value), array_values($record));
            $values = array_pad(array_slice($values, 0, 7), 7, '');
            [$firstName, $lastName, $email, $language, $territory, $city, $region] = $values;

            $email = strtolower($email);
            if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                $problems[] = sprintf('Row %d: invalid or empty email "%s"', $offset, $email);
                continue;
            }

            try {
                $dimension = LanguageDimension::fromCsv($language);
            } catch (\InvalidArgumentException $exception) {
                $problems[] = sprintf('Row %d (%s): %s', $offset, $email, $exception->getMessage());
                continue;
            }

            $rows[] = new CsvUserRow($firstName, $lastName, $email, $dimension, $territory, $city, $region);
        }

        fclose($stream);

        return new CsvReadResult($rows, $problems);
    }

    protected function stripBom(string $content): string
    {
        return str_starts_with($content, self::BOM) ? substr($content, strlen(self::BOM)) : $content;
    }
}

final class CsvReadResult
{
    /**
     * @param list<CsvUserRow> $rows
     * @param list<string> $problems
     */
    public function __construct(
        public readonly array $rows,
        public readonly array $problems,
    ) {
    }
}
