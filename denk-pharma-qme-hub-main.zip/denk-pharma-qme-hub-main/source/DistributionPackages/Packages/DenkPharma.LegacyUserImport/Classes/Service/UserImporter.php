<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Service;

use DenkPharma\LegacyUserImport\Dto\CsvUserRow;
use DenkPharma\LegacyUserImport\Dto\ImportedUser;
use DenkPharma\LegacyUserImport\Dto\ImportReport;
use DenkPharma\LegacyUserImport\Dto\ImportStatus;
use DenkPharma\User\Domain\Model\User;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\PersistenceManagerInterface;
use Neos\Flow\Security\AccountRepository;
use Neos\Flow\Utility\Algorithms;
use Neos\Party\Domain\Repository\PartyRepository;
use FormatD\UserManagement\Domain\Service\UserService;

#[Flow\Scope('singleton')]
class UserImporter
{
    protected const AUTH_PROVIDER = 'FormatD.UserManagementPlugin:Login';
    protected const ROLE = 'DenkPharma.Hub:FrontendUser';
    protected const USER_CLASS = User::class;

    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected AccountRepository $accountRepository;

    #[Flow\Inject]
    protected PartyRepository $partyRepository;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    /**
     * @param list<CsvUserRow> $rows
     * @param null|callable(ImportedUser, int, int): void $onProgress Invoked after each row with the outcome, 1-based index and total
     */
    public function import(array $rows, bool $dryRun, ?callable $onProgress = null): ImportReport
    {
        $report = new ImportReport();
        $total = count($rows);

        foreach ($rows as $index => $row) {
            $outcome = $this->importRow($row, $dryRun);
            $report->add($outcome);
            if ($onProgress !== null) {
                $onProgress($outcome, $index + 1, $total);
            }
        }

        return $report;
    }

    protected function importRow(CsvUserRow $row, bool $dryRun): ImportedUser
    {
        $existing = $this->accountRepository->findByAccountIdentifierAndAuthenticationProviderName($row->email, self::AUTH_PROVIDER);
        if ($existing !== null) {
            return $this->outcome($row, ImportStatus::Skipped, null, null, 'already-exists');
        }

        if ($dryRun) {
            return $this->outcome($row, ImportStatus::Created, null, null, 'dry-run');
        }

        /** @var User $user */
        $user = $this->userService->createUser(
            $row->email,
            Algorithms::generateRandomString(40),
            $row->firstName,
            $row->lastName,
            [self::ROLE],
            self::AUTH_PROVIDER,
            self::USER_CLASS,
            false,
        );
        $user->setCountry($row->territory);
        $user->setCity($row->city);
        $this->partyRepository->update($user);
        $this->persistenceManager->persistAll();

        return $this->outcome(
            $row,
            ImportStatus::Created,
            $this->persistenceManager->getIdentifierByObject($user),
            $this->userService->getLastCreatedAccount()->getAccountIdentifier(),
            null,
        );
    }

    protected function outcome(CsvUserRow $row, ImportStatus $status, ?string $userId, ?string $accountId, ?string $reason): ImportedUser
    {
        return new ImportedUser(
            $row->email,
            $row->firstName,
            $row->lastName,
            $row->language->value,
            $row->territory,
            $row->city,
            $row->region,
            $userId,
            $accountId,
            $status,
            $reason,
        );
    }
}
