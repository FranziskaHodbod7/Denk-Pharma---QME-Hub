<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Service;

use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Domain\Model\PasswordResetToken;
use FormatD\UserManagement\Service\NotificationService;
use GuzzleHttp\Psr7\Uri;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Http\ServerRequestAttributes;
use Neos\Flow\I18n\Locale;
use Neos\Flow\I18n\Service as I18nService;
use Neos\Flow\Mvc\ActionRequest;
use Neos\Flow\Mvc\ActionRequestFactory;
use Neos\Flow\Mvc\Routing\Dto\RouteParameters;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Symfony\Component\Mime\Address;

/**
 * Sends the bespoke "switch to the new hub" email from the CLI. Extends the project's
 * NotificationService purely to reuse its Fusion-prototype rendering and mail helpers; the only
 * additions are a CLI-built ActionRequest and a resolved site node so the reused ResetLink
 * NodeLink can build an absolute URL.
 */
#[Flow\Scope('singleton')]
class LegacyImportNotificationService extends NotificationService
{
    protected const CONTENT_REPOSITORY_ID = 'default';
    protected const SITE_NODE_NAME = 'denk-pharma-qme-hub';
    protected const AUTHORING_DIMENSION = 'en_GB';

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected ServerRequestFactoryInterface $serverRequestFactory;

    #[Flow\Inject]
    protected ActionRequestFactory $actionRequestFactory;

    #[Flow\Inject]
    protected I18nService $i18nService;

    protected ?ActionRequest $cliActionRequest = null;

    protected ?Node $siteNode = null;

    public function sendHubSwitchNotification(User $user, PasswordResetToken $token, string $locale, array $configurationSet): void
    {
        $this->i18nService->getConfiguration()->setCurrentLocale(new Locale($locale));

        $request = $this->buildCliActionRequest();
        $request->setArgument('__site', $this->resolveSiteNode());
        $request->setArgument('__documentNode', $this->resolveSiteNode());

        $result = $this->renderFusionPrototype(
            $request,
            $configurationSet,
            'DenkPharma.LegacyUserImport:Notification.HubSwitch',
            [
                'user' => $user,
                'passwordResetToken' => $token,
                'configurationSet' => $configurationSet,
                'baseUri' => $this->baseUri,
            ],
        );

        $mail = $this->createMessage();
        $mail->subject($result['subject']);
        $mail->html($this->attachHtmlInlineImages($this->collapseDoubledBaseUri($result['html'])));
        $mail->to(new Address($token->getAccount()->getAccountIdentifier(), (string)$user->getName()));

        $this->sendMail($mail);
    }

    /**
     * Render the email without sending it — for --dry-run. Returns [subject, html].
     *
     * @return array{subject: string, html: string}
     */
    public function renderHubSwitchNotification(User $user, PasswordResetToken $token, string $locale, array $configurationSet): array
    {
        $this->i18nService->getConfiguration()->setCurrentLocale(new Locale($locale));

        $request = $this->buildCliActionRequest();
        $request->setArgument('__site', $this->resolveSiteNode());
        $request->setArgument('__documentNode', $this->resolveSiteNode());

        $result = $this->renderFusionPrototype(
            $request,
            $configurationSet,
            'DenkPharma.LegacyUserImport:Notification.HubSwitch',
            [
                'user' => $user,
                'passwordResetToken' => $token,
                'configurationSet' => $configurationSet,
                'baseUri' => $this->baseUri,
            ],
        );
        $result['html'] = $this->collapseDoubledBaseUri($result['html']);

        return $result;
    }

    /**
     * The shared EMail override prepends the configured baseUri to resource URIs, but under CLI the
     * resource target already absolutizes them with the same baseUri, so every resource link comes
     * out with the host twice. Collapse that exact duplication back to a single baseUri.
     */
    protected function collapseDoubledBaseUri(string $html): string
    {
        $baseUri = (string)$this->baseUri;
        if ($baseUri === '') {
            return $html;
        }

        return str_replace($baseUri . $baseUri, $baseUri, $html);
    }

    protected function buildCliActionRequest(): ActionRequest
    {
        if ($this->cliActionRequest !== null) {
            return $this->cliActionRequest;
        }

        $uri = new Uri($this->baseUri);
        $httpRequest = $this->serverRequestFactory->createServerRequest('GET', $uri);

        $routingParameters = ($httpRequest->getAttribute(ServerRequestAttributes::ROUTING_PARAMETERS) ?? RouteParameters::createEmpty())
            ->withParameter('requestUriHost', $uri->getHost())
            ->withParameter('siteNodeName', self::SITE_NODE_NAME)
            ->withParameter('contentRepositoryId', self::CONTENT_REPOSITORY_ID);

        $httpRequest = $httpRequest->withAttribute(ServerRequestAttributes::ROUTING_PARAMETERS, $routingParameters);

        $this->cliActionRequest = $this->actionRequestFactory->createActionRequest($httpRequest);

        return $this->cliActionRequest;
    }

    protected function resolveSiteNode(): Node
    {
        if ($this->siteNode !== null) {
            return $this->siteNode;
        }

        $contentRepository = $this->contentRepositoryRegistry->get(ContentRepositoryId::fromString(self::CONTENT_REPOSITORY_ID));
        $contentGraph = $contentRepository->getContentGraph(WorkspaceName::forLive());
        $sitesRoot = $contentGraph->findRootNodeAggregateByType(NodeTypeName::fromString('Neos.Neos:Sites'));
        if ($sitesRoot === null) {
            throw new \RuntimeException('No Neos.Neos:Sites root node in the live workspace', 1753000002);
        }

        $subgraph = $contentGraph->getSubgraph(
            DimensionSpacePoint::fromArray(['language' => self::AUTHORING_DIMENSION]),
            VisibilityConstraints::withoutRestrictions(),
        );

        foreach ($subgraph->findChildNodes($sitesRoot->nodeAggregateId, FindChildNodesFilter::create()) as $child) {
            $this->siteNode = $child;
            return $this->siteNode;
        }

        throw new \RuntimeException('No site node found under the Sites root', 1753000003);
    }
}
