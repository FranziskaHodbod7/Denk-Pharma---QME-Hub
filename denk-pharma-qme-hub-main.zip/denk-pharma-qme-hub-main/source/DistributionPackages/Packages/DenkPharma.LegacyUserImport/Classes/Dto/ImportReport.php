<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

final class ImportReport
{
    /**
     * @var list<ImportedUser>
     */
    protected array $users = [];

    public function add(ImportedUser $user): void
    {
        $this->users[] = $user;
    }

    /**
     * @return list<ImportedUser>
     */
    public function getUsers(): array
    {
        return $this->users;
    }

    public function countByStatus(ImportStatus $status): int
    {
        return count(array_filter($this->users, static fn (ImportedUser $user): bool => $user->status === $status));
    }

    public function toJson(): string
    {
        return (string)json_encode(
            ['users' => array_map(static fn (ImportedUser $user): array => $user->toArray(), $this->users)],
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES,
        );
    }

    public static function fromJson(string $json): self
    {
        $decoded = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        $report = new self();
        foreach ($decoded['users'] ?? [] as $userData) {
            $report->add(ImportedUser::fromArray($userData));
        }
        return $report;
    }
}
