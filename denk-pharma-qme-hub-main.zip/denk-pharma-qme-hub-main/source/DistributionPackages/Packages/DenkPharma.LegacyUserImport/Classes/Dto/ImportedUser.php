<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

final class ImportedUser
{
    public function __construct(
        public readonly string $email,
        public readonly string $firstName,
        public readonly string $lastName,
        public readonly string $language,
        public readonly string $territory,
        public readonly string $city,
        public readonly string $region,
        public readonly ?string $userIdentifier,
        public readonly ?string $accountIdentifier,
        public readonly ImportStatus $status,
        public readonly ?string $reason,
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'email' => $this->email,
            'firstName' => $this->firstName,
            'lastName' => $this->lastName,
            'language' => $this->language,
            'territory' => $this->territory,
            'city' => $this->city,
            'region' => $this->region,
            'userIdentifier' => $this->userIdentifier,
            'accountIdentifier' => $this->accountIdentifier,
            'status' => $this->status->value,
            'reason' => $this->reason,
        ];
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function fromArray(array $data): self
    {
        return new self(
            (string)$data['email'],
            (string)$data['firstName'],
            (string)$data['lastName'],
            (string)$data['language'],
            (string)$data['territory'],
            (string)$data['city'],
            (string)$data['region'],
            $data['userIdentifier'] !== null ? (string)$data['userIdentifier'] : null,
            $data['accountIdentifier'] !== null ? (string)$data['accountIdentifier'] : null,
            ImportStatus::from((string)$data['status']),
            $data['reason'] !== null ? (string)$data['reason'] : null,
        );
    }
}
