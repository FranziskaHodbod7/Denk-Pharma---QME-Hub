<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

final class CsvUserRow
{
    public function __construct(
        public readonly string $firstName,
        public readonly string $lastName,
        public readonly string $email,
        public readonly LanguageDimension $language,
        public readonly string $territory,
        public readonly string $city,
        public readonly string $region,
    ) {
    }
}
