<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

enum NotificationStatus: string
{
    case Sent = 'sent';
    case Skipped = 'skipped';
    case Failed = 'failed';
}
