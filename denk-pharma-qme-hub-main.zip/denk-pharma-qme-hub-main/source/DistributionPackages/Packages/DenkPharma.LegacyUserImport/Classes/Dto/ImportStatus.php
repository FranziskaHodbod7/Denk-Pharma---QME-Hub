<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

enum ImportStatus: string
{
    case Created = 'created';
    case Skipped = 'skipped';
}
