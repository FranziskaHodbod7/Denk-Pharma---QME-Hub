<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

final class NotificationOutcome
{
    public function __construct(
        public readonly string $email,
        public readonly NotificationStatus $status,
        public readonly ?string $reason,
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return ['email' => $this->email, 'status' => $this->status->value, 'reason' => $this->reason];
    }
}
