<?php

declare(strict_types=1);

namespace DenkPharma\LegacyUserImport\Dto;

enum LanguageDimension: string
{
    case EN = 'EN';
    case ES = 'ES';
    case FR = 'FR';

    public static function fromCsv(string $raw): self
    {
        $normalised = strtoupper(trim($raw));
        return self::tryFrom($normalised)
            ?? throw new \InvalidArgumentException(sprintf('Unsupported CSV language "%s"', $raw), 1753000001);
    }

    public function locale(): string
    {
        return match ($this) {
            self::EN => 'en_GB',
            self::ES => 'es_ES',
            self::FR => 'fr_FR',
        };
    }
}
