<?php

declare(strict_types=1);

namespace DenkPharma\Video\Eel;

use Neos\Eel\ProtectedContextAwareInterface;

class CachingHelper implements ProtectedContextAwareInterface
{
    /**
     * @return string[]
     */
    public function cacheRelevantNodeTypes(): array
    {
        return [
            "DenkPharma.Video:Document.Video",
			"Sitegeist.Taxonomy:Taxonomy"
        ];
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
