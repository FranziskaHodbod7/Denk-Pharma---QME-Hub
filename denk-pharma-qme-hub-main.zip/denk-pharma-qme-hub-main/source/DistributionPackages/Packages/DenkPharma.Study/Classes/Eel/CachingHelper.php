<?php

declare(strict_types=1);

namespace DenkPharma\Study\Eel;

use Neos\Eel\ProtectedContextAwareInterface;

class CachingHelper implements ProtectedContextAwareInterface
{
    /**
     * @return string[]
     */
    public function cacheRelevantNodeTypes(): array
    {
        return [
            "DenkPharma.Study:Document.Study",
			"Sitegeist.Taxonomy:Taxonomy"
        ];
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
