<?php

declare(strict_types=1);

namespace DenkPharma\TaxonomyIcons\Eel;

use FormatD\DesignSystem\Components\Icons\DataSource\IconDataSource;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class IconHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected IconDataSource $iconDataSource;

    /**
     * Icon options; when $selected names an existing icon, it is moved to the front.
     *
     * @return list<array{value: string, label: string, preview: string}>
     */
    public function options(?string $selected = ''): array
    {
        $selected ??= '';
        $data = $this->iconDataSource->getData();
        if ($selected !== '' && isset($data[$selected])) {
            $selectedOption = $data[$selected];
            unset($data[$selected]);
            return array_merge([$selectedOption], array_values($data));
        }
        return array_values($data);
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
