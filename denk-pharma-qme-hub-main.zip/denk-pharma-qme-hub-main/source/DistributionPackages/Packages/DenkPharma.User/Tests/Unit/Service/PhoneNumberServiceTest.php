<?php

declare(strict_types=1);

namespace DenkPharma\User\Tests\Unit\Service;

use DenkPharma\User\Domain\Exception\InvalidPhoneNumberException;
use DenkPharma\User\Service\PhoneNumberService;
use FormatD\DesignSystem\Components\Form\Eel\Helper\CountryHelper;
use Neos\Cache\Frontend\VariableFrontend;
use Neos\Flow\I18n\Configuration as I18nConfiguration;
use Neos\Flow\I18n\Locale;
use Neos\Flow\I18n\Service as LocalizationService;
use Neos\Flow\Tests\UnitTestCase;

class PhoneNumberServiceTest extends UnitTestCase
{
    protected PhoneNumberService $service;

    protected function setUp(): void
    {
        parent::setUp();

        $countryHelper = $this->createMock(CountryHelper::class);
        $countryHelper->method('getLabel')->willReturnCallback(static fn(string $isoCode): string => 'Country ' . $isoCode);

        $i18nConfiguration = new I18nConfiguration('en_GB');
        $i18nConfiguration->setCurrentLocale(new Locale('en_GB'));
        $localizationService = $this->createMock(LocalizationService::class);
        $localizationService->method('getConfiguration')->willReturn($i18nConfiguration);

        $cache = $this->createMock(VariableFrontend::class);
        $cache->method('get')->willReturn(false);

        $this->service = new PhoneNumberService();
        $this->inject($this->service, 'countryHelper', $countryHelper);
        $this->inject($this->service, 'localizationService', $localizationService);
        $this->inject($this->service, 'dialCodeCache', $cache);
        $this->service->initializeObject();
    }

    /**
     * @return array<string, array{0: string, 1: string, 2: string}>
     */
    public static function combinableNumbers(): array
    {
        return [
            'german mobile' => ['+49', '1701234567', '+49 1701234567'],
            'austrian mobile' => ['+43', '6641234567', '+43 6641234567'],
            'shared dial code' => ['+1', '2015550123', '+1 2015550123'],
            'swiss landline' => ['+41', '446681800', '+41 446681800'],
            'german trunk prefix is dropped' => ['+49', '0563123456', '+49 563123456'],
            'german mobile with trunk prefix' => ['+49', '01701234567', '+49 1701234567'],
            'italian leading zero is part of the number' => ['+39', '0212345678', '+39 0212345678'],
            'ivorian mobile leading zero is kept' => ['+225', '0123456789', '+225 0123456789'],
            'beninese mobile leading zero is kept' => ['+229', '0195123456', '+229 0195123456'],
        ];
    }

    /**
     * @dataProvider combinableNumbers
     * @test
     */
    public function combineNormalisesToTheStoredShape(string $dialCode, string $localNumber, string $expected): void
    {
        self::assertSame($expected, $this->service->combine($dialCode, $localNumber));
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public static function uncombinableNumbers(): array
    {
        return [
            'too short' => ['+49', '170'],
            'too long' => ['+49', '17012345671234'],
            'unassigned dial code' => ['+999', '1701234567'],
            'international access code instead of a plus' => ['0049', '1701234567'],
            'contains separators' => ['+49', '0170 123-4567'],
            'empty local number' => ['+49', ''],
            'access code retyped in the local part' => ['+49', '00491701234567'],
        ];
    }

    /**
     * @dataProvider uncombinableNumbers
     * @test
     */
    public function combineRejectsInvalidNumbers(string $dialCode, string $localNumber): void
    {
        $this->expectException(InvalidPhoneNumberException::class);
        $this->service->combine($dialCode, $localNumber);
    }

    /**
     * The form warns the user if the local number starts with the digits of the dial code. That
     * message must stay a warning. "+49 491701234567" is a real German fixed-line number, because
     * 491 is an area code. The form must therefore ask the user. It must not remove the digits, and
     * it must not reject the number.
     *
     * @test
     */
    public function aLocalNumberRepeatingTheDialCodeDigitsIsStillAcceptedWhenItIsValid(): void
    {
        self::assertSame('+49 491701234567', $this->service->combine('+49', '491701234567'));
        self::assertSame([], $this->service->validationErrors('+49', '491701234567'));
    }

    /**
     * @test
     */
    public function validationErrorsAreEmptyForAValidNumber(): void
    {
        self::assertSame([], $this->service->validationErrors('+49', '1701234567'));
    }

    /**
     * @return array<string, array{0: string, 1: string, 2: string}>
     */
    public static function invalidPairs(): array
    {
        return [
            'unassigned dial code' => ['+999', '1701234567', 'dialCode'],
            'non-geographical dial code' => ['+800', '12345678', 'dialCode'],
            'dial code without plus' => ['49', '1701234567', 'dialCode'],
            'empty local number' => ['+49', '', 'phoneNumber'],
            'local number without digits' => ['+49', '--', 'phoneNumber'],
            'too short for the region' => ['+49', '170', 'phoneNumber'],
            'too long for the region' => ['+49', '17012345671234', 'phoneNumber'],
            'international access code instead of a plus' => ['0049', '1701234567', 'dialCode'],
            'zero as the first digit after the plus' => ['+0049', '1701234567', 'dialCode'],
        ];
    }

    /**
     * @dataProvider invalidPairs
     * @test
     */
    public function validationErrorsNameTheOffendingField(string $dialCode, string $localNumber, string $expectedField): void
    {
        self::assertSame([$expectedField], array_keys($this->service->validationErrors($dialCode, $localNumber)));
    }

    /**
     * The acceptance criteria for the field. Each case names the rule that the number breaks.
     *
     * @return array<string, array{0: string, 1: string, 2: string}>
     */
    public static function acceptanceCriteriaViolations(): array
    {
        return [
            'fewer than 7 digits in total' => ['+49', '1234', PhoneNumberService::ERROR_LENGTH],
            'more than 15 digits in total' => ['+49', '17012345678901234', PhoneNumberService::ERROR_LENGTH],
            'space' => ['+49', '170 1234567', PhoneNumberService::ERROR_DIGITS_ONLY],
            'hyphen' => ['+49', '170-1234567', PhoneNumberService::ERROR_DIGITS_ONLY],
            'brackets' => ['+49', '(170)1234567', PhoneNumberService::ERROR_DIGITS_ONLY],
            'slash' => ['+49', '170/1234567', PhoneNumberService::ERROR_DIGITS_ONLY],
        ];
    }

    /**
     * @dataProvider acceptanceCriteriaViolations
     * @test
     */
    public function acceptanceCriteriaAreEnforcedAheadOfLibphonenumber(string $dialCode, string $localNumber, string $expectedCode): void
    {
        self::assertSame(['phoneNumber' => [$expectedCode]], $this->service->validationErrors($dialCode, $localNumber));
    }

    /**
     * The codes are the contract with the frontend. The frontend maps each code to a translated
     * message. If the service stops returning a code, the frontend shows the general message for
     * that code, and no test reports the change. This test finds that change.
     *
     * @test
     */
    public function everyErrorCodeIsReachable(): void
    {
        $produced = [];
        foreach ([['+999', '1701234567'], ['+49', ''], ['+49', '170 1234567'], ['+49', '1234'], ['+49', '111111111']] as [$dial, $local]) {
            foreach ($this->service->validationErrors($dial, $local) as $codes) {
                $produced = array_merge($produced, $codes);
            }
        }

        sort($produced);
        $declared = [
            PhoneNumberService::ERROR_DIGITS_ONLY,
            PhoneNumberService::ERROR_INVALID,
            PhoneNumberService::ERROR_LENGTH,
            PhoneNumberService::ERROR_REQUIRED,
            PhoneNumberService::ERROR_UNKNOWN_DIAL_CODE,
        ];
        sort($declared);

        self::assertSame($declared, $produced);
    }

    /**
     * Rule 3 applies to the stored number. The first digit after the "+" is the first digit of the
     * dial code. The dial code must therefore satisfy the rule, and the local number must not. The
     * service rejects the dial code "0049". The service accepts "+49" with "0563123456", and it
     * stores "+49 563123456".
     *
     * @test
     */
    public function theLeadingZeroCriterionAppliesToTheDiallingCodeNotTheLocalPart(): void
    {
        self::assertSame(
            ['dialCode' => [PhoneNumberService::ERROR_UNKNOWN_DIAL_CODE]],
            $this->service->validationErrors('0049', '1701234567')
        );

        self::assertSame([], $this->service->validationErrors('+49', '0563123456'));
        self::assertSame('+49 563123456', $this->service->combine('+49', '0563123456'));
    }

    /**
     * The service keeps a leading zero that belongs to the national number. Rule 3 therefore
     * permits the countries that have a zero at the start of a mobile number.
     *
     * @test
     */
    public function aLeadingZeroBelongingToTheNationalNumberSurvives(): void
    {
        self::assertSame('+39 0212345678', $this->service->combine('+39', '0212345678'));
        self::assertSame('+225 0123456789', $this->service->combine('+225', '0123456789'));
    }

    /**
     * @test
     */
    public function theDigitCountIsTakenOnTheStoredNumberNotTheTypedOne(): void
    {
        // The user types 12 digits. The stored number has 11 digits, because libphonenumber
        // removes the trunk prefix.
        self::assertSame([], $this->service->validationErrors('+49', '0563123456'));
        self::assertSame('+49 563123456', $this->service->combine('+49', '0563123456'));
    }

    /**
     * @test
     */
    public function theSevenDigitFloorCountsTheCountryCode(): void
    {
        // This number has 6 digits in total. libphonenumber alone accepts 6 digits for +49.
        self::assertNotSame([], $this->service->validationErrors('+49', '2345'));
    }

    /**
     * @test
     */
    public function libphonenumberStillRejectsNumbersTheDigitCountsAllow(): void
    {
        // This number has 11 digits in total. It has digits only, and it has no leading zero, so
        // it passes each acceptance criterion. Only libphonenumber's German metadata shows that
        // the number is not real.
        self::assertSame(
            ['phoneNumber' => [PhoneNumberService::ERROR_INVALID]],
            $this->service->validationErrors('+49', '111111111')
        );
    }

    /**
     * @return array<string, array{0: string, 1: bool}>
     */
    public static function dialCodes(): array
    {
        return [
            'geographical' => ['+49', true],
            'shared by several regions' => ['+1', true],
            'unassigned' => ['+999', false],
            'toll-free global network' => ['+800', false],
            'missing plus' => ['49', false],
            'empty' => ['', false],
            'international access code' => ['0049', false],
            'leading zero after the plus' => ['+0049', false],
        ];
    }

    /**
     * @dataProvider dialCodes
     * @test
     */
    public function isKnownDialCodeAcceptsGeographicalCodesOnly(string $dialCode, bool $expected): void
    {
        self::assertSame($expected, $this->service->isKnownDialCode($dialCode));
    }

    /**
     * @test
     */
    public function toE164StripsTheSeparatingSpace(): void
    {
        self::assertSame('+491701234567', $this->service->toE164('+49 1701234567'));
    }

    /**
     * @test
     */
    public function toE164PassesUnparsableStoredValuesThroughAsDigits(): void
    {
        self::assertSame('+4917', $this->service->toE164('+49 17'));
        self::assertSame('', $this->service->toE164(''));
    }

    /**
     * @test
     */
    public function splitUndoesCombine(): void
    {
        self::assertSame(
            ['dialCode' => '+49', 'localNumber' => '1701234567'],
            $this->service->split($this->service->combine('+49', '1701234567'))
        );
    }

    /**
     * @test
     */
    public function dialCodeOptionsCarryPerCodeLengthBoundsAndAreSortedByLabel(): void
    {
        $options = $this->service->dialCodeOptions();

        $labels = array_column($options, 'label');
        $sorted = $labels;
        sort($sorted);
        self::assertSame($sorted, $labels);

        $german = array_values(array_filter($options, static fn(array $o): bool => $o['label'] === 'Country DE (+49)'));
        self::assertCount(1, $german);
        self::assertSame('+49', $german[0]['value']);
        self::assertGreaterThan(0, $german[0]['minLength']);
        self::assertLessThanOrEqual(15, $german[0]['maxLength']);
        self::assertGreaterThanOrEqual($german[0]['minLength'], $german[0]['maxLength']);

        foreach ($options as $option) {
            self::assertTrue($this->service->isKnownDialCode($option['value']), $option['value'] . ' should be a known dial code');

            $dialCodeDigits = strlen($option['value']) - 1;
            self::assertLessThanOrEqual(
                PhoneNumberService::MAX_TOTAL_DIGITS,
                $dialCodeDigits + $option['maxLength'],
                $option['value'] . ' must not allow more than the permitted total digits'
            );
            self::assertGreaterThanOrEqual(
                PhoneNumberService::MIN_TOTAL_DIGITS,
                $dialCodeDigits + $option['minLength'],
                $option['value'] . ' must not accept fewer than the permitted total digits'
            );
            self::assertLessThanOrEqual($option['maxLength'], $option['minLength'], $option['value'] . ' bounds must not invert');
        }
    }
}
