<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260527125454 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add denkpharma_user_domain_model_userfieldofinterest table for User field-of-interest selections';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE denkpharma_user_domain_model_userfieldofinterest (persistence_object_identifier VARCHAR(40) NOT NULL, user VARCHAR(40) DEFAULT NULL, interest VARCHAR(36) NOT NULL, INDEX IDX_33A3BE218D93D649 (user), UNIQUE INDEX UNIQ_33A3BE218D93D6496C3E1A67 (user, interest), PRIMARY KEY(persistence_object_identifier)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_userfieldofinterest ADD CONSTRAINT FK_33A3BE218D93D649 FOREIGN KEY (user) REFERENCES denkpharma_user_domain_model_user (persistence_object_identifier) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_userfieldofinterest DROP FOREIGN KEY FK_33A3BE218D93D649');
        $this->addSql('DROP TABLE denkpharma_user_domain_model_userfieldofinterest');
    }
}
