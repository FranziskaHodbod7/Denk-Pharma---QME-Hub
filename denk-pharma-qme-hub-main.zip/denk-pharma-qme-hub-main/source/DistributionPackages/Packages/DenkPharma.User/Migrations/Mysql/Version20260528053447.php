<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260528053447 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Replace User onboardingstatusvalue string with onboardingprogress bitmask int';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user ADD onboardingprogress INT DEFAULT 0 NOT NULL, DROP onboardingstatusvalue');
    }

    public function down(Schema $schema): void
    {
        $this->addSql("ALTER TABLE denkpharma_user_domain_model_user ADD onboardingstatusvalue VARCHAR(255) DEFAULT 'none' NOT NULL, DROP onboardingprogress");
    }
}
