<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260907150726 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds the WhatsApp contact consent opt-in to the user. Existing users get no consent.';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user ADD whatsappconsentgiven TINYINT(1) NOT NULL');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP whatsappconsentgiven');
    }
}
