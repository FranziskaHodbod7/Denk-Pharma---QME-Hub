<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260520114545 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Set onboardingStatusValue to NOT NULL with default none';
    }

    public function up(Schema $schema): void
    {
        $this->addSql("UPDATE denkpharma_user_domain_model_user SET onboardingstatusvalue = 'none' WHERE onboardingstatusvalue IS NULL");
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user CHANGE onboardingstatusvalue onboardingstatusvalue VARCHAR(255) NOT NULL');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user CHANGE onboardingstatusvalue onboardingstatusvalue VARCHAR(255) DEFAULT NULL');
    }
}
