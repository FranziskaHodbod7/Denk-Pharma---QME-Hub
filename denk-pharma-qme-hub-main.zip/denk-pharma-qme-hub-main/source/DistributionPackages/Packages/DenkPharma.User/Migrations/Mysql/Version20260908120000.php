<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

class Version20260908120000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Reset onboardingprogress: onboarding is now the single newsletter consent step';
    }

    public function up(Schema $schema): void
    {
        $this->abortIf(
            $this->connection->getDatabasePlatform()->getName() !== 'mysql',
            'Migration can only be executed safely on "mysql".'
        );

        // The removed enum carried a commented-out DEPRECATED_Newsletter = 0b100, the bit the new
        // Newsletter case reuses. Rows holding it would read as complete and skip the consent
        // screen, so every user starts from zero and consents once.
        $this->addSql('UPDATE denkpharma_user_domain_model_user SET onboardingprogress = 0');
    }

    public function down(Schema $schema): void
    {
        $this->abortIf(true, 'Cannot restore the per-step onboarding bitmask: the source data is gone.');
    }
}
