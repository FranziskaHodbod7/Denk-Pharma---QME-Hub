<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20260520095243 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE denkpharma_user_domain_model_user (persistence_object_identifier VARCHAR(40) NOT NULL, onboardingstatusvalue VARCHAR(255) DEFAULT NULL, PRIMARY KEY(persistence_object_identifier)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user ADD CONSTRAINT FK_CCD371F047A46B0A FOREIGN KEY (persistence_object_identifier) REFERENCES neos_party_domain_model_abstractparty (persistence_object_identifier) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP FOREIGN KEY FK_CCD371F047A46B0A');
        $this->addSql('DROP TABLE denkpharma_user_domain_model_user');
    }
}
