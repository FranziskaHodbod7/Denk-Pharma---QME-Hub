<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

class Version20260909090000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Replace the onboardingprogress bitmask with onboardingstepidentifiers (simple_array)';
    }

    public function up(Schema $schema): void
    {
        $this->abortIf(
            $this->connection->getDatabasePlatform()->getName() !== 'mysql',
            'Migration can only be executed safely on "mysql".'
        );

        $this->addSql("ALTER TABLE denkpharma_user_domain_model_user ADD onboardingstepidentifiers LONGTEXT DEFAULT NULL COMMENT '(DC2Type:simple_array)'");

        // 0b100 was the Newsletter bit, the only step the bitmask still carried.
        $this->addSql("UPDATE denkpharma_user_domain_model_user SET onboardingstepidentifiers = 'newsletter' WHERE onboardingprogress & 4 = 4");

        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP onboardingprogress');
    }

    public function down(Schema $schema): void
    {
        $this->abortIf(
            $this->connection->getDatabasePlatform()->getName() !== 'mysql',
            'Migration can only be executed safely on "mysql".'
        );

        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user ADD onboardingprogress INT DEFAULT 0 NOT NULL');
        $this->addSql("UPDATE denkpharma_user_domain_model_user SET onboardingprogress = 4 WHERE FIND_IN_SET('newsletter', onboardingstepidentifiers)");
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP onboardingstepidentifiers');
    }
}
