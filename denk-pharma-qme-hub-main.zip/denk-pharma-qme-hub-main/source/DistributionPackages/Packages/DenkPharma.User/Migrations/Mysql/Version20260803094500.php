<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260803094500 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add title column to User for the academic title selection';
    }

    public function up(Schema $schema): void
    {
        $this->addSql("ALTER TABLE denkpharma_user_domain_model_user ADD title VARCHAR(20) DEFAULT '' NOT NULL");
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP title');
    }
}
