<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260527134354 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add professionalfield column to User for the professional-field taxonomy selection';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user ADD professionalfield VARCHAR(36) DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_user_domain_model_user DROP professionalfield');
    }
}
