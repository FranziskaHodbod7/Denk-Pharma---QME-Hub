<?php

declare(strict_types=1);

namespace DenkPharma\User\Validation\Validator;

use DenkPharma\User\Service\PhoneNumberService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Core\Bootstrap;
use Neos\Flow\Http\HttpRequestHandlerInterface;
use Neos\Flow\I18n\Translator;
use Neos\Flow\Validation\Validator\AbstractValidator;

/**
 * The register form posts the dialling code and the local number as two fields. A Flow validator
 * sees one value and gets no ActionRequest injected, so the companion field is read off the active
 * request. A Neos plugin nests every field under '--somePluginNamespace[fieldName]', which is why
 * the lookup walks the parsed body instead of reading one key.
 */
class PhoneNumberValidator extends AbstractValidator
{
    /**
     * @var array<string, mixed>
     */
    protected $supportedOptions = [
        'dialCodeArgument' => ['dialCode', 'Name of the request argument holding the dialling code', 'string'],
    ];

    /**
     * The empty number must reach isValid(), which reports it as the "required" error of the
     * service. Flow otherwise treats an empty value as valid and never calls isValid().
     *
     * @var bool
     */
    protected $acceptsEmptyValues = false;

    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    #[Flow\Inject(lazy: false)]
    protected Bootstrap $bootstrap;

    #[Flow\Inject]
    protected Translator $translator;

    /**
     * Set directly in tests; resolved from the request otherwise.
     */
    protected ?string $dialCode = null;

    protected function isValid($value): void
    {
        $localNumber = is_string($value) ? $value : '';
        $dialCode = $this->dialCode ?? $this->resolveDialCode();

        foreach ($this->phoneNumberService->validationErrors($dialCode, $localNumber) as $codes) {
            foreach ($codes as $code) {
                $this->addError($this->messageFor($code), 1757332800);
            }
        }
    }

    /**
     * The form shows the message of the error as it is, so the validator translates it. The keys
     * are the ones the onboarding wizard used, in DenkPharma.User:Phone.
     */
    protected function messageFor(string $code): string
    {
        $id = 'phone.error.' . $code;

        return $this->translator->translateById($id, [], null, null, 'Phone', 'DenkPharma.User') ?? $id;
    }

    protected function resolveDialCode(): string
    {
        $requestHandler = $this->bootstrap->getActiveRequestHandler();
        if (!$requestHandler instanceof HttpRequestHandlerInterface) {
            return '';
        }

        $parsedBody = $requestHandler->getHttpRequest()->getParsedBody();
        if (!is_array($parsedBody)) {
            return '';
        }

        return $this->findArgument($parsedBody, $this->options['dialCodeArgument'] ?? 'dialCode');
    }

    /**
     * @param array<mixed> $arguments
     */
    protected function findArgument(array $arguments, string $name): string
    {
        foreach ($arguments as $key => $argument) {
            if ($key === $name && is_string($argument)) {
                return $argument;
            }
            if (is_array($argument)) {
                $found = $this->findArgument($argument, $name);
                if ($found !== '') {
                    return $found;
                }
            }
        }

        return '';
    }
}
