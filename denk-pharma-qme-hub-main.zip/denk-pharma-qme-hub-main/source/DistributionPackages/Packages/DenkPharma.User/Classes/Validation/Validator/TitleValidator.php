<?php

declare(strict_types=1);

namespace DenkPharma\User\Validation\Validator;

use DenkPharma\User\Domain\Enum\Title;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Validation\Validator\AbstractValidator;

/** Accepts any value backing a Title case, including the empty string ("no title"). */
#[Flow\Scope('singleton')]
class TitleValidator extends AbstractValidator
{
    protected function isValid($value): void
    {
        if (!\is_string($value) || Title::tryFrom($value) === null) {
            $this->addError('Not a known title.', 1754210000);
        }
    }
}
