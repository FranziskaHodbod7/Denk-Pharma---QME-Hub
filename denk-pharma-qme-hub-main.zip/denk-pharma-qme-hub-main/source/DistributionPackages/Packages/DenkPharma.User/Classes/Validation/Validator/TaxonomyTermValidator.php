<?php

declare(strict_types=1);

namespace DenkPharma\User\Validation\Validator;

use DenkPharma\Core\Service\TaxonomyResolver;
use DenkPharma\User\Service\AuthoringSubgraphProvider;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Core\Bootstrap;
use Neos\Flow\Http\HttpRequestHandlerInterface;
use Neos\Flow\I18n\Translator;
use Neos\Flow\Validation\Validator\AbstractValidator;

/**
 * Checks that every submitted aggregate ID names a term of the configured vocabulary. This repeats
 * the check UserPreferencesService performs for the profile screens, in a place where the register
 * form can report the failure beside the field instead of through an exception.
 */
class TaxonomyTermValidator extends AbstractValidator
{
    /**
     * @var array<string, mixed>
     */
    protected $supportedOptions = [
        'vocabulary' => ['', 'Taxonomy vocabulary name, e.g. "professional-field"', 'string', true],
        'multiple' => [false, 'Accept a list of IDs instead of one', 'boolean'],
    ];

    /**
     * An empty selection is a valid answer. A field that must be answered carries a NotEmpty
     * validator of its own.
     *
     * @var bool
     */
    protected $acceptsEmptyValues = true;

    #[Flow\Inject]
    protected TaxonomyResolver $taxonomyResolver;

    #[Flow\Inject]
    protected AuthoringSubgraphProvider $authoringSubgraphProvider;

    #[Flow\Inject(lazy: false)]
    protected Bootstrap $bootstrap;

    #[Flow\Inject]
    protected Translator $translator;

    protected function isValid($value): void
    {
        $rawIds = ($this->options['multiple'] ?? false)
            ? (is_array($value) ? $value : [])
            : [$value];
        $rawIds = array_values(array_filter($rawIds, static fn($id): bool => is_string($id) && $id !== ''));

        if ($rawIds === []) {
            return;
        }

        $ids = [];
        foreach ($rawIds as $rawId) {
            try {
                $ids[] = NodeAggregateId::fromString($rawId);
            } catch (\InvalidArgumentException) {
                $this->addError($this->unknownTermMessage(), 1757332801);
                return;
            }
        }

        $requestHandler = $this->bootstrap->getActiveRequestHandler();
        if (!$requestHandler instanceof HttpRequestHandlerInterface) {
            $this->addError($this->unknownTermMessage(), 1757332802);
            return;
        }

        $subgraph = $this->authoringSubgraphProvider->forRequest($requestHandler->getHttpRequest());
        $resolved = $this->taxonomyResolver->resolveByIds($subgraph, (string)$this->options['vocabulary'], $ids);

        foreach ($ids as $id) {
            if (!isset($resolved[$id->value])) {
                $this->addError($this->unknownTermMessage(), 1757332803);
                return;
            }
        }
    }

    /** The form shows the message of the error as it is, so the validator translates it. */
    protected function unknownTermMessage(): string
    {
        $id = 'taxonomy.error.unknownTerm';

        return $this->translator->translateById($id, [], null, null, 'Main', 'DenkPharma.User') ?? $id;
    }
}
