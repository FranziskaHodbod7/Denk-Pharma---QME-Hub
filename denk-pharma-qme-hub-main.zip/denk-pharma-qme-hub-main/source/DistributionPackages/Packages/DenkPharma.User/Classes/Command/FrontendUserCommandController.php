<?php

declare(strict_types=1);

namespace DenkPharma\User\Command;

use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Domain\Repository\AbstractAccountRelatedTokenRepository;
use FormatD\UserManagement\Service\ConfigurationSetTrait;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;
use Neos\Flow\Persistence\PersistenceManagerInterface;
use Neos\Flow\Security\Account;
use Neos\Flow\Security\AccountRepository;
use Neos\Party\Domain\Model\ElectronicAddress;
use Neos\Party\Domain\Model\Person;
use Neos\Party\Domain\Repository\PartyRepository;
use Neos\Party\Domain\Service\PartyService;

/**
 * @Flow\Scope("singleton")
 */
class FrontendUserCommandController extends CommandController
{
    use ConfigurationSetTrait;

    #[Flow\Inject]
    protected AccountRepository $accountRepository;

    #[Flow\Inject]
    protected PartyRepository $partyRepository;

    #[Flow\Inject]
    protected PartyService $partyService;

    #[Flow\Inject]
    protected AbstractAccountRelatedTokenRepository $tokenRepository;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    public function initializeObject(): void
    {
        $this->initializeConfigurationSetObject();
    }

    /**
     * Permanently removes DenkPharma frontend users: their accounts, related tokens, email
     * address and the user record itself. Unlike the profile "delete account" flow, this does
     * not anonymize and keep the record - the row is gone.
     *
     * @param string $emails Comma-separated list of frontend user email addresses to hard-delete
     * @param bool $force Skip the confirmation prompt
     */
    public function hardDeleteCommand(string $emails, bool $force = false): void
    {
        $users = [];
        foreach ($this->parseEmails($emails) as $email) {
            $this->collectMatch($users, $this->findUserByEmail($email));
        }

        $this->confirmAndHardDelete($users, $force);
    }

    /**
     * Same as hardDeleteCommand, but reads the values from a CSV file (one per row, first column,
     * header row skipped). Each value may be either an email address or a user persistence-object
     * identifier - both are resolved to a DenkPharma frontend user, or reported and skipped.
     *
     * @param string $csv Path to the CSV file
     * @param bool $force Skip the confirmation prompt
     */
    public function hardDeleteFromCsvCommand(string $csv, bool $force = false): void
    {
        if (!is_file($csv)) {
            $this->outputLine('<error>CSV not found: %s</error>', [$csv]);
            $this->quit(1);
        }

        $users = [];
        foreach ($this->readCsvValues($csv) as $value) {
            $user = filter_var($value, FILTER_VALIDATE_EMAIL) !== false
                ? $this->findUserByEmail($value)
                : $this->findUserByIdentifier($value);
            $this->collectMatch($users, $user);
        }

        $this->confirmAndHardDelete($users, $force);
    }

    /**
     * Lists the frontend users whose account is inactive, with their email addresses: accounts
     * that never became active, and accounts an editor deactivated later. Both are valid deletion
     * candidates, so both feed the CSV by default.
     *
     * A registration before the double opt-in was removed created the account with an expiration
     * date, and only the opt-in link cleared it. Such an account still carries that date, so it is
     * pending. An account that an editor deactivated later carries one too. The command tells the
     * two apart by the distance between the creation date and the expiration date, purely so the
     * console output can label which is which - not to exclude either from the list.
     *
     * @param string $csv Write the list to this path as CSV. The file feeds hardDeleteFromCsv.
     * @param bool $includeDeactivated Also list the accounts that someone deactivated after use
     */
    public function listPendingCommand(string $csv = '', bool $includeDeactivated = true): void
    {
        $pending = [];
        $deactivatedAfterUse = [];
        foreach ($this->findInactiveFrontendAccounts() as $account) {
            $user = $this->partyService->getAssignedPartyOfAccount($account);
            if (!$user instanceof User) {
                continue;
            }

            $row = [
                'email' => $account->getAccountIdentifier(),
                'createdAt' => $account->getCreationDate()->format('Y-m-d H:i:s'),
                'inactiveSince' => $account->getExpirationDate()?->format('Y-m-d H:i:s') ?? '',
                'identifier' => $this->persistenceManager->getIdentifierByObject($user),
            ];

            if ($this->wasDeactivatedAtCreation($account)) {
                $pending[] = $row;
            } else {
                $deactivatedAfterUse[] = $row;
            }
        }

        $rows = $includeDeactivated ? array_merge($pending, $deactivatedAfterUse) : $pending;

        $this->outputLine();
        $this->outputLine('%d pending account(s):', [count($pending)]);
        foreach ($pending as $row) {
            $this->outputLine('  - %s (registered %s)', [$row['email'], $row['createdAt']]);
        }

        if ($deactivatedAfterUse !== []) {
            $this->outputLine();
            $this->outputLine(
                '<comment>%d account(s) became inactive long after registration. Someone deactivated them. %s</comment>',
                [count($deactivatedAfterUse), $includeDeactivated ? 'They are in the list.' : 'They are not in the list.']
            );
            foreach ($deactivatedAfterUse as $row) {
                $this->outputLine('  - %s (registered %s, inactive since %s)', [$row['email'], $row['createdAt'], $row['inactiveSince']]);
            }
        }

        if ($csv !== '') {
            $this->writeCsv($csv, $rows);
        }
    }

    /**
     * The registration sets the expiration date in the request that creates the account, so the two
     * dates are seconds apart. A later date means the account was in use before it became inactive.
     */
    protected function wasDeactivatedAtCreation(Account $account): bool
    {
        $expirationDate = $account->getExpirationDate();
        if ($expirationDate === null) {
            return false;
        }

        return abs($expirationDate->getTimestamp() - $account->getCreationDate()->getTimestamp()) <= 60;
    }

    /** @return list<Account> frontend accounts with an expiration date that passed */
    protected function findInactiveFrontendAccounts(): array
    {
        $query = $this->persistenceManager->createQueryForType(Account::class);
        $accounts = $query->matching(
            $query->logicalAnd(
                $query->equals('authenticationProviderName', $this->configurationSet['authenticationProviderNames'][0]),
                // A null expiration date fails this comparison, so an active account never matches.
                $query->lessThanOrEqual('expirationDate', new \DateTime())
            )
        )->execute();

        return array_values(iterator_to_array($accounts));
    }

    /** @param list<array<string, string>> $rows */
    protected function writeCsv(string $csv, array $rows): void
    {
        $stream = fopen($csv, 'w');
        if ($stream === false) {
            $this->outputLine('<error>Unable to write %s</error>', [$csv]);
            $this->quit(1);
        }

        // hardDeleteFromCsv reads the first column and skips the header row.
        fputcsv($stream, ['email', 'createdAt', 'inactiveSince', 'identifier'], ',', '"', '');
        foreach ($rows as $row) {
            fputcsv($stream, array_values($row), ',', '"', '');
        }

        fclose($stream);

        $this->outputLine();
        $this->outputLine('<success>wrote %d row(s) to %s</success>', [count($rows), $csv]);
    }

    protected function findUserByEmail(string $email): ?User
    {
        $authenticationProviderName = $this->configurationSet['authenticationProviderNames'][0];
        $account = $this->accountRepository->findByAccountIdentifierAndAuthenticationProviderName($email, $authenticationProviderName);
        if (!$account instanceof Account) {
            $this->outputLine('<comment>no account found for %s, skipping</comment>', [$email]);
            return null;
        }

        $user = $this->partyService->getAssignedPartyOfAccount($account);
        if (!$user instanceof User) {
            $this->outputLine('<comment>%s is not a DenkPharma frontend user, skipping</comment>', [$email]);
            return null;
        }

        return $user;
    }

    protected function findUserByIdentifier(string $identifier): ?User
    {
        $user = $this->persistenceManager->getObjectByIdentifier($identifier, User::class);
        if (!$user instanceof User) {
            $this->outputLine('<comment>no DenkPharma frontend user found for identifier %s, skipping</comment>', [$identifier]);
            return null;
        }

        return $user;
    }

    /** @param array<string,User> $users keyed by persistence identifier, deduplicated */
    protected function collectMatch(array &$users, ?User $user): void
    {
        if ($user === null) {
            return;
        }

        $users[$this->persistenceManager->getIdentifierByObject($user)] = $user;
    }

    /** @param array<string,User> $users keyed by persistence identifier */
    protected function confirmAndHardDelete(array $users, bool $force): void
    {
        if ($users === []) {
            $this->outputLine('Nothing to delete.');
            return;
        }

        $labels = [];
        foreach ($users as $identifier => $user) {
            $labels[$identifier] = $user->getPrimaryEmailAddress() ?? $identifier;
        }

        $this->outputLine();
        $this->outputLine('The following users will be <error>permanently and irreversibly</error> deleted:');
        foreach ($labels as $label) {
            $this->outputLine('  - %s', [$label]);
        }

        if (!$force && !$this->output->askConfirmation(sprintf('Hard-delete %d user(s) (yes/no)? ', count($users)), false)) {
            $this->outputLine('aborting...');
            return;
        }

        // Accounts and electronic addresses sit behind many-to-many join tables that reference the
        // party without an ON DELETE CASCADE on that column, so their join rows must be gone before
        // the party row is removed - hence detaching and removing the party are two separate
        // persistAll() phases, not one.
        $deletableAddressesByIdentifier = [];
        foreach ($users as $identifier => $user) {
            $deletableAddressesByIdentifier[$identifier] = $this->detachAccountsAndAddresses($user);
        }
        $this->persistenceManager->persistAll();

        foreach ($users as $identifier => $user) {
            $this->partyRepository->remove($user);
            $this->persistenceManager->remove($user->getName());
            foreach ($deletableAddressesByIdentifier[$identifier] as $electronicAddress) {
                $this->persistenceManager->remove($electronicAddress);
            }
            $this->outputLine('<success>deleted %s</success>', [$labels[$identifier]]);
        }

        $this->persistenceManager->persistAll();
    }

    /** @return list<ElectronicAddress> addresses no other party references, safe to remove once detached */
    protected function detachAccountsAndAddresses(User $user): array
    {
        $userId = $this->persistenceManager->getIdentifierByObject($user);

        $deletableAddresses = [];
        foreach ($user->getElectronicAddresses() as $electronicAddress) {
            if (!$this->isElectronicAddressSharedWithOtherParty($electronicAddress, $userId)) {
                $deletableAddresses[] = $electronicAddress;
            }
            $user->removeElectronicAddress($electronicAddress);
        }

        foreach ($user->getAccounts() as $account) {
            $this->tokenRepository->removeByAccount($account);
            $user->removeAccount($account);
            $this->accountRepository->remove($account);
        }

        return $deletableAddresses;
    }

    protected function isElectronicAddressSharedWithOtherParty(ElectronicAddress $electronicAddress, string $ownerId): bool
    {
        $query = $this->persistenceManager->createQueryForType(Person::class);
        $otherOwners = $query->matching(
            $query->logicalAnd(
                $query->contains('electronicAddresses', $electronicAddress),
                $query->logicalNot($query->equals('Persistence_Object_Identifier', $ownerId))
            )
        )->execute();

        return $otherOwners->count() > 0;
    }

    /** @return list<string> */
    protected function parseEmails(string $emails): array
    {
        $parsed = array_filter(array_map('trim', explode(',', $emails)));
        return array_values(array_unique(array_map('strtolower', $parsed)));
    }

    /** @return list<string> the first column of every non-empty row, header row skipped */
    protected function readCsvValues(string $csv): array
    {
        $stream = fopen($csv, 'r');
        if ($stream === false) {
            $this->outputLine('<error>Unable to open %s</error>', [$csv]);
            $this->quit(1);
        }

        $values = [];
        $row = -1;
        // Empty escape string keeps parsing faithful to the source and avoids the PHP 8.4 default-escape deprecation.
        while (($record = fgetcsv($stream, null, ',', '"', '')) !== false) {
            $row++;
            if ($row === 0 || $record === [null]) {
                continue;
            }

            $value = trim((string)($record[0] ?? ''));
            if ($value !== '') {
                $values[] = $value;
            }
        }

        fclose($stream);

        return $values;
    }
}
