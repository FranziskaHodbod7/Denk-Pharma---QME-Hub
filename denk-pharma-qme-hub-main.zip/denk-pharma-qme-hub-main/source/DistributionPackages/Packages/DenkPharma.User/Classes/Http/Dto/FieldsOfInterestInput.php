<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class FieldsOfInterestInput
{
    /**
     * @param list<NodeAggregateId> $ids
     */
    public function __construct(public array $ids)
    {
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        $raw = $body['fieldsOfInterest'] ?? null;
        if (!is_array($raw)) {
            throw new InvalidInputException(['fieldsOfInterest' => ['must be an array of strings']]);
        }

        $ids = [];
        foreach ($raw as $entry) {
            if (!is_string($entry)) {
                throw new InvalidInputException(['fieldsOfInterest' => ['must be an array of strings']]);
            }
            try {
                $ids[] = NodeAggregateId::fromString($entry);
            } catch (\InvalidArgumentException $e) {
                throw new InvalidInputException(['fieldsOfInterest' => [$e->getMessage()]]);
            }
        }
        return new self($ids);
    }
}
