<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Annotations as Flow;

/**
 * Structural only. Match, complexity and current-password checks live in
 * AccountProfileService::changePassword, which needs the account and the
 * configured password policy.
 */
#[Flow\Proxy(false)]
final readonly class PasswordInput
{
    public function __construct(
        public string $current,
        public string $new,
        public string $repeat,
    ) {
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        $errors = [];
        foreach (['current', 'new', 'repeat'] as $key) {
            if (!is_string($body[$key] ?? null)) {
                $errors[$key] = ['must be a string'];
            }
        }
        if ($errors !== []) {
            throw new InvalidInputException($errors);
        }

        return new self($body['current'], $body['new'], $body['repeat']);
    }
}
