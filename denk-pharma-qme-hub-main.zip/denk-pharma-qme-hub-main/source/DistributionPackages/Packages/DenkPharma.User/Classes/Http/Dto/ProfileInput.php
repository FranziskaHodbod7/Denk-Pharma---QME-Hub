<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Annotations as Flow;

// Not constructor-promoted: #[Flow\Validate] on a promoted parameter fatals Flow's reflection.
#[Flow\Proxy(false)]
final readonly class ProfileInput
{
    #[Flow\Validate(type: 'DenkPharma.User:Title')]
    public string $title;

    #[Flow\Validate(type: 'NotEmpty')]
    public string $firstName;

    #[Flow\Validate(type: 'NotEmpty')]
    public string $lastName;

    public string $city;

    #[Flow\Validate(type: 'NotEmpty')]
    public string $country;

    public string $dialCode;

    #[Flow\Validate(type: 'NotEmpty')]
    public string $phoneNumber;

    public function __construct(string $title, string $firstName, string $lastName, string $city, string $country, string $dialCode, string $phoneNumber)
    {
        $this->title = $title;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->city = $city;
        $this->country = $country;
        $this->dialCode = $dialCode;
        $this->phoneNumber = $phoneNumber;
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        $errors = [];
        foreach (['title', 'firstName', 'lastName', 'city', 'country', 'dialCode', 'phoneNumber'] as $key) {
            if (!\is_string($body[$key] ?? null)) {
                $errors[$key] = ['must be a string'];
            }
        }
        if ($errors !== []) {
            throw new InvalidInputException($errors);
        }

        // Trimmed so whitespace-only input doesn't pass as a value.
        // The controller combines dialCode + phoneNumber and validates the dialling code.
        return new self(
            trim($body['title']),
            trim($body['firstName']),
            trim($body['lastName']),
            $body['city'],
            $body['country'],
            trim($body['dialCode']),
            trim($body['phoneNumber']),
        );
    }
}
