<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class ProfessionalFieldInput
{
    public function __construct(public NodeAggregateId $id)
    {
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        if (!is_string($body['professionalField'] ?? null)) {
            throw new InvalidInputException(['professionalField' => ['must be a string']]);
        }
        try {
            return new self(NodeAggregateId::fromString($body['professionalField']));
        } catch (\InvalidArgumentException $e) {
            throw new InvalidInputException(['professionalField' => [$e->getMessage()]]);
        }
    }
}
