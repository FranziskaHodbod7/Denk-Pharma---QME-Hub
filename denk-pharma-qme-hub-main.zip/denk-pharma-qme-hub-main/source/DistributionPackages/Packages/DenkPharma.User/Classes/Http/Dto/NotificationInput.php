<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class NotificationInput
{
    public function __construct(public bool $subscribed, public bool $whatsAppConsent)
    {
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        $errors = [];
        if (!\is_bool($body['subscribed'] ?? null)) {
            $errors['subscribed'] = ['must be a boolean'];
        }
        if (!\is_bool($body['whatsAppConsent'] ?? null)) {
            $errors['whatsAppConsent'] = ['must be a boolean'];
        }
        if ($errors !== []) {
            throw new InvalidInputException($errors);
        }
        return new self($body['subscribed'], $body['whatsAppConsent']);
    }
}
