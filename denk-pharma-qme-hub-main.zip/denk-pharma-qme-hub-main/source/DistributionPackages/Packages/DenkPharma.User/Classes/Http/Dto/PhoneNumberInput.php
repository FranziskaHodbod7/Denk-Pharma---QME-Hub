<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(false)]
final readonly class PhoneNumberInput
{
    public string $dialCode;

    #[Flow\Validate(type: 'NotEmpty')]
    public string $phoneNumber;

    public function __construct(string $dialCode, string $phoneNumber)
    {
        $this->dialCode = $dialCode;
        $this->phoneNumber = $phoneNumber;
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        $errors = [];
        foreach (['dialCode', 'phoneNumber'] as $key) {
            if (!\is_string($body[$key] ?? null)) {
                $errors[$key] = ['must be a string'];
            }
        }
        if ($errors !== []) {
            throw new InvalidInputException($errors);
        }

        return new self(trim($body['dialCode']), trim($body['phoneNumber']));
    }
}
