<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Annotations as Flow;

/**
 * The consent screen after registration carries the newsletter flag alone. NotificationInput also
 * demands whatsAppConsent, which the register form collects and this screen must not overwrite.
 */
#[Flow\Proxy(false)]
final readonly class NewsletterConsentInput
{
    public function __construct(public bool $subscribed)
    {
    }

    /**
     * @param array<string, mixed> $body
     * @throws InvalidInputException
     */
    public static function fromArray(array $body): self
    {
        if (!\is_bool($body['subscribed'] ?? null)) {
            throw new InvalidInputException(['subscribed' => ['must be a boolean']]);
        }

        return new self($body['subscribed']);
    }
}
