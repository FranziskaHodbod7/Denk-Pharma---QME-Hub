<?php

declare(strict_types=1);

namespace DenkPharma\User\Http\Dto;

use Neos\Flow\Exception;

/**
 * Thrown by a request DTO's fromArray() when the body is structurally unusable
 * (missing keys, wrong primitive types) before the DTO can be constructed.
 */
final class InvalidInputException extends Exception
{
    /**
     * @param array<string, list<string>> $errors field name => messages
     */
    public function __construct(private readonly array $errors)
    {
        parent::__construct('The request input is invalid.', 1748000200);
    }

    /**
     * @return array<string, list<string>>
     */
    public function errors(): array
    {
        return $this->errors;
    }
}
