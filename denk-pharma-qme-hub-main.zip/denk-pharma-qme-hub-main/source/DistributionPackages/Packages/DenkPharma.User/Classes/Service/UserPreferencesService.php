<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\Core\Service\TaxonomyResolver;
use DenkPharma\User\Domain\Exception\InvalidPreferenceValueException;
use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Domain\Repository\UserRepository;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\PersistenceManagerInterface;

#[Flow\Scope('singleton')]
final class UserPreferencesService
{
    #[Flow\Inject]
    protected TaxonomyResolver $taxonomyResolver;

    #[Flow\Inject]
    protected UserRepository $userRepository;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    /**
     * @param list<NodeAggregateId> $ids
     * @throws InvalidPreferenceValueException
     */
    public function setFieldsOfInterest(User $user, ContentSubgraphInterface $subgraph, array $ids): void
    {
        $resolved = $this->taxonomyResolver->resolveByIds($subgraph, 'field-of-interest', $ids);
        $unknown = [];
        foreach ($ids as $id) {
            if (!isset($resolved[$id->value])) {
                $unknown[] = $id->value;
            }
        }
        if ($unknown !== []) {
            throw new InvalidPreferenceValueException(
                sprintf(
                    'Unknown field-of-interest aggregate ID(s): %s',
                    implode(', ', array_unique($unknown))
                ),
                1748000000
            );
        }

        $user->setFieldsOfInterest($ids);
        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserPreferencesUpdated($user);
    }

    /** @throws InvalidPreferenceValueException */
    public function setProfessionalField(User $user, ContentSubgraphInterface $subgraph, ?NodeAggregateId $id): void
    {
        if ($id !== null) {
            $resolved = $this->taxonomyResolver->resolveByIds($subgraph, 'professional-field', [$id]);
            if (!isset($resolved[$id->value])) {
                throw new InvalidPreferenceValueException(
                    sprintf('Unknown professional-field aggregate ID: %s', $id->value),
                    1748000001
                );
            }
        }

        $user->setProfessionalField($id);
        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserPreferencesUpdated($user);
    }

    public function setCommunicationConsents(User $user, bool $newsletterSubscribed, bool $whatsAppConsentGiven): void
    {
        $user->setNewsletterSubscribed($newsletterSubscribed);
        $user->setWhatsAppConsentGiven($whatsAppConsentGiven);
        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserPreferencesUpdated($user);
    }

    /**
     * The consent screen after registration answers this one question. setCommunicationConsents()
     * also writes the WhatsApp consent, which the register form collects.
     */
    public function setNewsletterSubscribed(User $user, bool $subscribed): void
    {
        $user->setNewsletterSubscribed($subscribed);
        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserPreferencesUpdated($user);
    }

    public function setPhoneNumber(User $user, string $phoneNumber): void
    {
        $user->setPhoneNumber($phoneNumber);
        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserPreferencesUpdated($user);
    }

    /** @Flow\Signal */
    public function emitUserPreferencesUpdated(User $user): void {}
}
