<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Neos\FrontendRouting\SiteDetection\SiteDetectionResult;
use Psr\Http\Message\ServerRequestInterface;

#[Flow\Scope('singleton')]
final class AuthoringSubgraphProvider
{
    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    /**
     * The subgraph taxonomy aggregate IDs validate against. en_GB is the authoring root and
     * taxonomy aggregate IDs are dimension-agnostic, so validation resolves in en_GB regardless
     * of the request locale.
     */
    public function forRequest(ServerRequestInterface $request): ContentSubgraphInterface
    {
        $siteDetectionResult = SiteDetectionResult::fromRequest($request);
        $contentRepository = $this->contentRepositoryRegistry->get($siteDetectionResult->contentRepositoryId);
        return $contentRepository->getContentSubgraph(
            WorkspaceName::forLive(),
            DimensionSpacePoint::fromArray(['language' => 'en_GB'])
        );
    }
}
