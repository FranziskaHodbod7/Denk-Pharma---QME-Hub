<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\User\Domain\Enum\Title;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\I18n\Locale;
use Neos\Flow\I18n\Translator;

/** Resolves Title cases to localised labels and dropdown options. */
#[Flow\Scope('singleton')]
final class TitleService
{
    private const TRANSLATION_SOURCE = 'Main';

    private const TRANSLATION_PACKAGE = 'DenkPharma.User';

    #[Flow\Inject]
    protected Translator $translator;

    /**
     * Options in declaration order, so "no title" comes first. Carries both `value` and `id`:
     * FormatD.FusionForm:Field.Select reads `id`, the Svelte selects read `value`.
     *
     * @return list<array{label: string, value: string, id: string}>
     */
    public function options(?Locale $locale = null): array
    {
        $options = [];
        foreach (Title::cases() as $title) {
            $options[] = [
                'label' => $this->label($title, $locale),
                'value' => $title->value,
                'id' => $title->value,
            ];
        }

        return $options;
    }

    /** Falls back to the translation id so a missing unit is visible rather than blank. */
    public function label(Title $title, ?Locale $locale = null): string
    {
        return $this->translator->translateById(
            $title->translationId(),
            [],
            null,
            $locale,
            self::TRANSLATION_SOURCE,
            self::TRANSLATION_PACKAGE,
        ) ?? $title->translationId();
    }
}
