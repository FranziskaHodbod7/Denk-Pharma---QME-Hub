<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\User\Dto\FeedCandidate;
use Neos\ContentRepository\Core\NodeType\NodeTypeManager;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindBackReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;

/**
 * Documents matched to a set of fields of interest, with interest-overlap count as the
 * primary ranking key. One public method per content type supplies that type's candidate
 * source and sort. Each accepts an $exclude list (e.g. editor-placed items the menu already
 * shows).
 */
final class FieldOfInterestFeedService
{
    public const string STUDY_TYPE = 'DenkPharma.Study:Document.Study';
    public const string PRODUCT_TYPE = 'DenkPharma.Product:Document.Product';
    public const string VIDEO_TYPE = 'DenkPharma.Video:Document.Video';
    public const string EVENT_TYPE = 'DenkPharma.Event:Document.Event';

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    /**
     * Studies referencing the given fields of interest, ranked by
     * interest-overlap then publication date (newest first).
     *
     * @param list<NodeAggregateId> $interestIds
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function studiesByInterests(Node $contextNode, array $interestIds, ?int $limit = null, array $exclude = []): array
    {
        return $this->rankAndTake(
            $this->directCandidates($contextNode, $interestIds, self::STUDY_TYPE),
            $this->byOverlapThenProperty('publicationDate', 'DESC'),
            $limit,
            $this->normalizeExclude($exclude)
        );
    }

    /**
     * Products matched to the given fields of interest — directly and via the
     * medication bridge — ranked by interest-overlap then title (A–Z).
     *
     * @param list<NodeAggregateId> $interestIds
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function productsByInterests(Node $contextNode, array $interestIds, ?int $limit = null, array $exclude = []): array
    {
        return $this->rankAndTake(
            $this->bridgedCandidates($contextNode, $interestIds, self::PRODUCT_TYPE),
            $this->byOverlapThenProperty('title', 'ASC'),
            $limit,
            $this->normalizeExclude($exclude)
        );
    }

    /**
     * Videos referencing the given fields of interest, ranked by
     * interest-overlap then publication date (newest first).
     *
     * @param list<NodeAggregateId> $interestIds
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function videosByInterests(Node $contextNode, array $interestIds, ?int $limit = null, array $exclude = []): array
    {
        return $this->rankAndTake(
            $this->directCandidates($contextNode, $interestIds, self::VIDEO_TYPE),
            $this->byOverlapThenProperty('publicationDate', 'DESC'),
            $limit,
            $this->normalizeExclude($exclude)
        );
    }

    /**
     * Upcoming events matched to the given fields of interest — directly and via the
     * medication bridge — ranked by interest-overlap then start date (soonest first).
     *
     * @param list<NodeAggregateId> $interestIds
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function eventsByInterests(Node $contextNode, array $interestIds, ?int $limit = null, array $exclude = []): array
    {
        return $this->rankAndTake(
            $this->bridgedCandidates($contextNode, $interestIds, self::EVENT_TYPE),
            $this->byOverlapThenProperty('eventStartDate', 'ASC'),
            $limit,
            $this->normalizeExclude($exclude),
            static fn(FeedCandidate $candidate): bool => !$candidate->node->getProperty('isPastEvent')
        );
    }

    /**
     * @param list<FeedCandidate> $candidates
     * @param callable $sort comparator over two FeedCandidate
     * @param array<string, true> $excludeIds aggregate-id set to drop
     * @param callable|null $filter predicate over a FeedCandidate
     * @return list<Node>
     */
    private function rankAndTake(array $candidates, callable $sort, ?int $limit, array $excludeIds = [], ?callable $filter = null): array
    {
        $candidates = array_values(array_filter(
            $candidates,
            static function (FeedCandidate $candidate) use ($excludeIds, $filter): bool {
                if (isset($excludeIds[$candidate->node->aggregateId->value])) {
                    return false;
                }
                return $filter === null || $filter($candidate);
            }
        ));
        usort($candidates, $sort);
        $nodes = array_map(static fn(FeedCandidate $candidate): Node => $candidate->node, $candidates);

        return $limit === null ? $nodes : array_slice($nodes, 0, $limit);
    }

    /**
     * Documents of $nodeType matched by the direct `fieldOfInterest` reference;
     * overlap = how many of the interests each document references.
     *
     * @param list<NodeAggregateId> $interestIds
     * @return list<FeedCandidate>
     */
    private function directCandidates(Node $contextNode, array $interestIds, string $nodeType): array
    {
        if ($interestIds === []) {
            return [];
        }

        $subgraph = $this->contentRepositoryRegistry->subgraphForNode($contextNode);
        $nodeTypeManager = $this->contentRepositoryRegistry
            ->get($subgraph->getContentRepositoryId())
            ->getNodeTypeManager();

        $overlap = [];
        $nodes = [];
        foreach ($interestIds as $interestId) {
            $backReferences = $subgraph->findBackReferences(
                $interestId,
                FindBackReferencesFilter::create(referenceName: 'fieldOfInterest')
            );
            foreach ($backReferences as $reference) {
                $document = $reference->node;
                if (!$this->isOfType($document, $nodeType, $nodeTypeManager)) {
                    continue;
                }
                $id = $document->aggregateId->value;
                $overlap[$id] = ($overlap[$id] ?? 0) + 1;
                $nodes[$id] = $document;
            }
        }

        return $this->toCandidates($overlap, $nodes);
    }

    /**
     * Documents of $nodeType matched to the interests via BOTH the direct `fieldOfInterest`
     * reference and the medication bridge (interest taxon → medications ← document). Overlap
     * = the number of distinct interests a document connects to through either path (deduped).
     *
     * @param list<NodeAggregateId> $interestIds
     * @return list<FeedCandidate>
     */
    private function bridgedCandidates(Node $contextNode, array $interestIds, string $nodeType): array
    {
        if ($interestIds === []) {
            return [];
        }

        $subgraph = $this->contentRepositoryRegistry->subgraphForNode($contextNode);
        $nodeTypeManager = $this->contentRepositoryRegistry
            ->get($subgraph->getContentRepositoryId())
            ->getNodeTypeManager();

        $matched = []; // documentId => array<interestId, true> — the unique set of matched interests
        $nodes = [];

        $record = function (Node $document, array $interestKeys) use (&$matched, &$nodes, $nodeType, $nodeTypeManager): void {
            if (!$this->isOfType($document, $nodeType, $nodeTypeManager)) {
                return;
            }
            $id = $document->aggregateId->value;
            foreach ($interestKeys as $interestKey) {
                $matched[$id][$interestKey] = true;
            }
            $nodes[$id] = $document;
        };

        // medication taxon => the interests that reference it
        $interestsByMedication = [];
        foreach ($interestIds as $interestId) {
            $medications = $subgraph->findReferences(
                $interestId,
                FindReferencesFilter::create(referenceName: 'medications')
            );
            foreach ($medications as $medication) {
                $interestsByMedication[$medication->node->aggregateId->value][$interestId->value] = true;
            }
        }

        // direct edge: documents referencing an interest's fieldOfInterest
        foreach ($interestIds as $interestId) {
            $backReferences = $subgraph->findBackReferences(
                $interestId,
                FindBackReferencesFilter::create(referenceName: 'fieldOfInterest')
            );
            foreach ($backReferences as $reference) {
                $record($reference->node, [$interestId->value]);
            }
        }

        // bridged edge: documents referencing a medication inherit that medication's interests
        foreach ($interestsByMedication as $medicationId => $interestKeys) {
            $backReferences = $subgraph->findBackReferences(
                NodeAggregateId::fromString($medicationId),
                FindBackReferencesFilter::create(referenceName: 'medications')
            );
            foreach ($backReferences as $reference) {
                $record($reference->node, array_keys($interestKeys));
            }
        }

		$overlap = array_map(static fn($interestSet): int => count($interestSet), $matched);

        return $this->toCandidates($overlap, $nodes);
    }

    /**
     * @param array<string, int> $overlap docId => overlap count
     * @param array<string, Node> $nodes docId => Node
     * @return list<FeedCandidate>
     */
    private function toCandidates(array $overlap, array $nodes): array
    {
        $candidates = [];
        foreach ($overlap as $id => $count) {
            $candidates[] = new FeedCandidate($nodes[$id], $count);
        }
        return $candidates;
    }

    /**
     * Normalizes a mixed exclude list (Node | NodeAggregateId | id string) to an aggregate-id set.
     *
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return array<string, true>
     */
    private function normalizeExclude(array $exclude): array
    {
        $ids = [];
        foreach ($exclude as $item) {
            if ($item instanceof Node) {
                $ids[$item->aggregateId->value] = true;
            } elseif ($item instanceof NodeAggregateId) {
                $ids[$item->value] = true;
            } elseif (is_string($item) && $item !== '') {
                $ids[$item] = true;
            }
        }
        return $ids;
    }

    /**
     * Overlap count descending; ties broken by the given property in the given
     * direction ('ASC'|'DESC'), nulls last.
     *
     * @return callable comparator over two FeedCandidate
     */
    private function byOverlapThenProperty(string $property, string $direction): callable
    {
        return static function (FeedCandidate $a, FeedCandidate $b) use ($property, $direction): int {
            if ($a->overlap !== $b->overlap) {
                return $b->overlap <=> $a->overlap;
            }
            $aValue = $a->node->getProperty($property);
            $bValue = $b->node->getProperty($property);
            if ($aValue === null || $bValue === null) {
                return ($aValue === null ? 1 : 0) <=> ($bValue === null ? 1 : 0);
            }
            $comparison = $aValue <=> $bValue;
            return $direction === 'DESC' ? -$comparison : $comparison;
        };
    }

    private function isOfType(Node $node, string $nodeType, NodeTypeManager $nodeTypeManager): bool
    {
        $type = $nodeTypeManager->getNodeType($node->nodeTypeName);
        return $type !== null && $type->isOfType($nodeType);
    }
}
