<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\User\Domain\Enum\Title;
use DenkPharma\User\Domain\Exception\InvalidCurrentPasswordException;
use DenkPharma\User\Domain\Exception\InvalidPasswordException;
use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Domain\Repository\UserRepository;
use FormatD\UserManagement\Validation\Validator\PasswordValidator;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\PersistenceManagerInterface;
use Neos\Flow\Security\Account;
use Neos\Flow\Security\AccountRepository;
use Neos\Flow\Security\Cryptography\HashService;
use Neos\Party\Domain\Model\PersonName;

#[Flow\Scope('singleton')]
final class AccountProfileService
{
    #[Flow\Inject]
    protected UserRepository $userRepository;

    #[Flow\Inject]
    protected AccountRepository $accountRepository;

    #[Flow\Inject]
    protected HashService $hashService;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    /**
     * Same source the registration/changePassword flow uses, so our rule never
     * diverges from the client's configured one.
     *
     * @phpstan-var array{minimum?: int, maximum?: int, requiredScore?: int, allowEmpty?: bool}
     */
    #[Flow\InjectConfiguration(path: 'configurationSets.default.validation.options.password', package: 'FormatD.UserManagement')]
    protected array $passwordValidationOptions = [];

    public function updateProfile(User $user, Title $title, string $firstName, string $lastName, string $city, string $country, string $phoneNumber): void
    {
        $name = $user->getName();
        if ($name === null) {
            $user->setName(new PersonName('', $firstName, '', $lastName));
        } else {
            $name->setFirstName($firstName);
            $name->setLastName($lastName);
        }

        $user->setTitle($title->value);
        $user->setCity($city);
        $user->setCountry($country);
        $user->setPhoneNumber($phoneNumber);

        $this->userRepository->update($user);
        $this->persistenceManager->persistAll();

        $this->emitUserProfileUpdated($user);
    }

    /** @Flow\Signal */
    public function emitUserProfileUpdated(User $user): void {}

    /**
     * @throws InvalidCurrentPasswordException
     * @throws InvalidPasswordException
     */
    public function changePassword(Account $account, string $current, string $new, string $repeat): void
    {
        if (!$this->hashService->validatePassword($current, $account->getCredentialsSource())) {
            throw new InvalidCurrentPasswordException('The current password is not correct.', 1748000100);
        }

        $result = (new PasswordValidator($this->passwordValidationOptions))->validate([$new, $repeat]);
        if ($result->hasErrors()) {
            throw new InvalidPasswordException($result->getFirstError()->render(), 1748000101);
        }

        $account->setCredentialsSource($this->hashService->hashPassword($new));
        $this->accountRepository->update($account);
        $this->persistenceManager->persistAll();
    }
}
