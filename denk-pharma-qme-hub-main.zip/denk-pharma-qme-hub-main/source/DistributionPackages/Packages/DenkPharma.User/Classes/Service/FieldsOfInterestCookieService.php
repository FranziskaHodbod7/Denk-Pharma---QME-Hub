<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\Core\Service\TaxonomyResolver;
use DenkPharma\User\Domain\Model\User;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;

/**
 * The front end reads the fields of interest of the visitor from a cookie. Login writes it, and so
 * does registration, because a visitor chooses the fields in the register form and never passes
 * through the login action.
 */
#[Flow\Scope('singleton')]
class FieldsOfInterestCookieService
{
    protected const COOKIE_NAME = 'dp_foi';

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected TaxonomyResolver $taxonomyResolver;

    public function write(User $user): void
    {
        $ids = $user->getFieldsOfInterest();
        if ($ids === []) {
            $this->clear();
            return;
        }

        $contentRepository = $this->contentRepositoryRegistry->get(ContentRepositoryId::fromString('default'));
        $subgraph = $contentRepository->getContentSubgraph(
            WorkspaceName::forLive(),
            DimensionSpacePoint::fromArray(['language' => 'en_GB'])
        );

        $resolved = $this->taxonomyResolver->resolveByIds($subgraph, 'field-of-interest', $ids);
        $nodeNames = array_values(array_map(
            static fn(Node $node): string => $node->name->value,
            $resolved
        ));

        $this->send((string)json_encode($nodeNames));
    }

    public function clear(): void
    {
        $this->send('[]');
    }

    protected function send(string $value): void
    {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

        setcookie(self::COOKIE_NAME, $value, [
            'expires'  => 0,
            'path'     => '/',
            'samesite' => 'Lax',
            'httponly' => false,
            'secure'   => $isHttps,
        ]);
    }
}
