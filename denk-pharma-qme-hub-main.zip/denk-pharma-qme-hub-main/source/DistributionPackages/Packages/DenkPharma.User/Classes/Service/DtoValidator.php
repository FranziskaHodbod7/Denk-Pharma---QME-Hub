<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use Neos\Error\Messages\Error;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Validation\ValidatorResolver;

#[Flow\Scope('singleton')]
final class DtoValidator
{
    #[Flow\Inject]
    protected ValidatorResolver $validatorResolver;

    /**
     * Runs the base validator conjunction (property #[Flow\Validate] rules plus any
     * auto-discovered custom validator) and flattens the result to a JSON-friendly map.
     *
     * @return array<string, list<string>> property path => messages, empty when valid
     */
    public function errorsFor(object $dto): array
    {
        $result = $this->validatorResolver->getBaseValidatorConjunction($dto::class)->validate($dto);

        $errors = [];
        foreach ($result->getFlattenedErrors() as $propertyPath => $propertyErrors) {
            $errors[$propertyPath] = array_map(
                static fn(Error $error): string => $error->render(),
                $propertyErrors
            );
        }
        return $errors;
    }
}
