<?php

declare(strict_types=1);

namespace DenkPharma\User\Service;

use DenkPharma\User\Domain\Exception\InvalidPhoneNumberException;
use FormatD\DesignSystem\Components\Form\Eel\Helper\CountryHelper;
use libphonenumber\NumberParseException;
use libphonenumber\PhoneNumber;
use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use Neos\Cache\Frontend\VariableFrontend;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\I18n\Service as LocalizationService;

/**
 * A phone number must pass two sets of rules.
 *
 * The first set is the acceptance criteria for the field:
 * 1. The number has MIN_TOTAL_DIGITS digits or more after the "+".
 * 2. The number has MAX_TOTAL_DIGITS digits or fewer in total.
 * 3. The first digit after the "+" is not a zero.
 * 4. The local number contains digits only. Spaces, hyphens, brackets and slashes are not
 *    permitted.
 *
 * These rules are flat. This class states them directly. It does not read them from metadata.
 *
 * Each rule applies to the stored number, not to the characters that the user typed. Rule 3 is
 * therefore a rule about the dial code:
 * - This class rejects the dial code "0049".
 * - This class accepts the dial code "+49" with the local number "0563123456". It stores
 *   "+49 563123456", because libphonenumber identifies the 0 as a German trunk prefix and then
 *   removes it.
 * - libphonenumber keeps a zero that belongs to the national number. Italian ("+39 0212345678"),
 *   Ivorian, Beninese, Gabonese and Congolese numbers stay complete.
 *
 * The second set of rules comes from libphonenumber. libphonenumber decides if the number is real
 * for the dial code. The digit counts cannot make this decision. libphonenumber holds the lengths
 * and the patterns of each region. It also maps a shared dial code (+1, +7) to the correct region.
 *
 * The stored format is "<dialCode> <nationalNumber>", for example "+49 1701234567". Remove the
 * single space to get E.164 format.
 */
#[Flow\Scope('singleton')]
final class PhoneNumberService
{
    /**
     * The digit limits from the acceptance criteria. A stored number has 7 digits or more, and 15
     * digits or fewer, in total. The total includes the dial code.
     *
     * E.164 sets the maximum of 15. E.164 sets no minimum, so the project sets the minimum of 7.
     *
     * Both values are totals. nationalNumberLengths() subtracts the digits of the dial code to
     * get a limit for the local number.
     */
    public const MIN_TOTAL_DIGITS = 7;
    public const MAX_TOTAL_DIGITS = 15;

    /**
     * The error codes that validationErrors() returns. These codes are part of the contract with
     * the frontend. The frontend maps each code to a translated message. If you rename a code, you
     * change the message that a user reads.
     */
    public const ERROR_UNKNOWN_DIAL_CODE = 'unknownDialCode';
    public const ERROR_REQUIRED = 'required';
    public const ERROR_DIGITS_ONLY = 'digitsOnly';
    public const ERROR_LENGTH = 'length';
    public const ERROR_INVALID = 'invalid';

    #[Flow\Inject]
    protected CountryHelper $countryHelper;

    #[Flow\Inject]
    protected LocalizationService $localizationService;

    /**
     * Objects.yaml injects this property. The property has no type declaration: Flow's lazy
     * property injection assigns a DependencyProxy before the first access, and a typed property
     * refuses that object.
     *
     * @var VariableFrontend
     */
    protected $dialCodeCache;

    protected PhoneNumberUtil $phoneNumberUtil;

    /** @var list<array{label: string, value: string, minLength: int, maxLength: int}>|null */
    protected ?array $dialCodeOptions = null;

    public function initializeObject(): void
    {
        $this->phoneNumberUtil = PhoneNumberUtil::getInstance();
    }

    /**
     * Returns one dial code for each region that libphonenumber supports. The localized country
     * label sets the sort order.
     *
     * minLength and maxLength are the digit limits for the local number. nationalNumberLengths()
     * calculates them. The input element uses maxLength for its maxlength attribute, and the
     * browser uses both values for its own check. validationErrors() makes the final decision.
     *
     * @return list<array{label: string, value: string, minLength: int, maxLength: int}>
     */
    public function dialCodeOptions(): array
    {
        if ($this->dialCodeOptions !== null) {
            return $this->dialCodeOptions;
        }

        $cacheIdentifier = 'dialCodes_' . md5((string)$this->localizationService->getConfiguration()->getCurrentLocale());
        $cached = $this->dialCodeCache->get($cacheIdentifier);
        if (is_array($cached)) {
            return $this->dialCodeOptions = $cached;
        }

        $options = [];
        foreach ($this->phoneNumberUtil->getSupportedRegions() as $territory) {
            $countryCode = $this->phoneNumberUtil->getCountryCodeForRegion($territory);
            if ($countryCode === 0) {
                continue;
            }

            $dialCode = '+' . $countryCode;
            $countryName = $this->countryHelper->getLabel($territory);
            $options[] = [
                'label' => $countryName !== '' ? \sprintf('%s (%s)', $countryName, $dialCode) : $dialCode,
                'value' => $dialCode,
                ...$this->nationalNumberLengths($countryCode),
            ];
        }

        usort($options, static fn(array $a, array $b): int => $a['label'] <=> $b['label']);

        $this->dialCodeCache->set($cacheIdentifier, $options);

        return $this->dialCodeOptions = $options;
    }

    public function isKnownDialCode(string $dialCode): bool
    {
        $digits = $this->digitsOf($dialCode);
        if ($digits === '' || !str_starts_with(trim($dialCode), '+')) {
            return false;
        }

        // Rule 3 of the acceptance criteria: the first digit after the "+" is not a zero. That
        // digit is the first digit of the dial code. This test also rejects an international
        // access code in place of the "+". Without this test, this method accepts "0049" as the
        // dial code 49.
        if (str_starts_with($digits, '0')) {
            return false;
        }

        // Toll-free, satellite and other global network codes map to the non-geographical entity
        // only. dialCodeOptions() does not offer these codes, so this method rejects them.
        $territories = $this->phoneNumberUtil->getRegionCodesForCountryCode((int)$digits);

        return $territories !== [] && $territories !== [PhoneNumberUtil::REGION_CODE_FOR_NON_GEO_ENTITY];
    }

    /**
     * Joins a dial code and a local number into the stored format "<dialCode> <number>".
     *
     * This method validates the pair. It does not trust the caller. Every caller therefore writes
     * the same format, and a caller that does not call validationErrors() cannot store an invalid
     * number. Both methods use one set of rules, so the two paths stay the same.
     *
     * @throws InvalidPhoneNumberException if the pair breaks a rule
     */
    public function combine(string $dialCode, string $localNumber): string
    {
        $errors = $this->validationErrors($dialCode, $localNumber);
        if ($errors !== []) {
            throw new InvalidPhoneNumberException(
                \sprintf(
                    'Phone number "%s %s" was rejected: %s',
                    $dialCode,
                    $localNumber,
                    implode('; ', array_merge(...array_values($errors)))
                ),
                1755500000
            );
        }

        $number = $this->parseNumber($dialCode, $localNumber);

        return '+' . $number->getCountryCode() . ' ' . $this->phoneNumberUtil->getNationalSignificantNumber($number);
    }

    /**
     * Returns error codes. This method does not return English text. The frontend maps each code
     * to a translated message. One translation therefore serves the check in the browser and this
     * check on the server. The response contains no English text.
     *
     * This method tests the acceptance criteria first, in the order of the rules. Each code
     * therefore names the rule that the number breaks. This method does not report a general
     * "invalid" code for a rule that has its own code.
     *
     * @return array<string, list<string>> field => error codes, empty if the pair is valid
     */
    public function validationErrors(string $dialCode, string $localNumber): array
    {
        if (!$this->isKnownDialCode($dialCode)) {
            return ['dialCode' => [self::ERROR_UNKNOWN_DIAL_CODE]];
        }

        if ($localNumber === '') {
            return ['phoneNumber' => [self::ERROR_REQUIRED]];
        }

        if ($this->digitsOf($localNumber) !== $localNumber) {
            return ['phoneNumber' => [self::ERROR_DIGITS_ONLY]];
        }

        try {
            $number = $this->parseNumber($dialCode, $localNumber);
        } catch (NumberParseException) {
            return ['phoneNumber' => [self::ERROR_INVALID]];
        }

        // The count uses the stored number. libphonenumber removes a trunk prefix before this
        // point, so a trunk prefix does not add to the total.
        $totalDigits = $this->storedTotalDigits($number);
        if ($totalDigits < self::MIN_TOTAL_DIGITS || $totalDigits > self::MAX_TOTAL_DIGITS) {
            return ['phoneNumber' => [self::ERROR_LENGTH]];
        }

        if (!$this->phoneNumberUtil->isValidNumber($number)) {
            return ['phoneNumber' => [self::ERROR_INVALID]];
        }

        return [];
    }

    /**
     * @return string the stored number in E.164 format, or an empty string if it has no digits
     */
    public function toE164(string $stored): string
    {
        $digits = $this->digitsOf($stored);
        if ($digits === '') {
            return '';
        }

        // The legacy import, and code that ran before this normalisation existed, can store a
        // value that libphonenumber cannot parse. This method then returns the digits without a
        // change. An incomplete number helps the caller more than an empty string.
        try {
            $number = $this->phoneNumberUtil->parse('+' . $digits);
        } catch (NumberParseException) {
            return '+' . $digits;
        }

        return $this->phoneNumberUtil->format($number, PhoneNumberFormat::E164);
    }

    /**
     * Splits a stored value at the first space.
     *
     * @return array{dialCode: string, localNumber: string}
     */
    public function split(string $stored): array
    {
        $value = trim($stored);
        $spaceIndex = strpos($value, ' ');
        if ($spaceIndex === false) {
            return ['dialCode' => $this->defaultDialCode(), 'localNumber' => $value];
        }

        return [
            'dialCode' => substr($value, 0, $spaceIndex),
            'localNumber' => trim(substr($value, $spaceIndex + 1)),
        ];
    }

    public function defaultDialCode(): string
    {
        return $this->dialCodeOptions()[0]['value'] ?? '';
    }

    /**
     * Removes every character except the digits from both parts, then joins the two parts. A "+"
     * in the local number therefore cannot change the number to a different country.
     *
     * validationErrors() rejects a local number that contains other characters. This method
     * therefore gets digits only from that path.
     *
     * This method does not reject a local number that starts with the digits of the dial code.
     * The dial code "+49" with the local number "491701234567" is a real German number, because
     * 491 is an area code. The form shows a warning for this shape. Only libphonenumber can decide
     * if the number is wrong, and usually the number is correct.
     *
     * This method also does not reject a leading zero. libphonenumber decides if the zero is a
     * trunk prefix to remove, or a part of the national number to keep.
     *
     * @throws NumberParseException
     */
    protected function parseNumber(string $dialCode, string $localNumber): PhoneNumber
    {
        return $this->phoneNumberUtil->parse('+' . $this->digitsOf($dialCode) . $this->digitsOf($localNumber));
    }

    /**
     * Returns the digit limits for the local number of one dial code.
     *
     * The limits start as libphonenumber's possible lengths for the regions that share the dial
     * code. This method then reduces the limits to the values that the total-digit rules permit.
     *
     * The acceptance criteria have priority. libphonenumber's general description covers every
     * type of number in a region, so its maximum can be more than the 15-digit total. The maximum
     * is more than the total for +49, +62, +81, +82, +234 and +598. Its minimum can also be less
     * than the 7-digit total.
     *
     * @return array{minLength: int, maxLength: int}
     */
    protected function nationalNumberLengths(int $countryCode): array
    {
        $dialCodeDigits = strlen((string)$countryCode);
        $allowedMin = max(1, self::MIN_TOTAL_DIGITS - $dialCodeDigits);
        $allowedMax = max(1, self::MAX_TOTAL_DIGITS - $dialCodeDigits);

        $lengths = [];
        foreach ($this->phoneNumberUtil->getRegionCodesForCountryCode($countryCode) as $territory) {
            $generalDesc = $this->phoneNumberUtil->getMetadataForRegion($territory)?->getGeneralDesc();
            foreach ($generalDesc?->getPossibleLength() ?? [] as $length) {
                if ($length > 0) {
                    $lengths[] = $length;
                }
            }
        }

        if ($lengths === []) {
            return ['minLength' => $allowedMin, 'maxLength' => $allowedMax];
        }

        return [
            'minLength' => min(max(min($lengths), $allowedMin), $allowedMax),
            'maxLength' => min(max($lengths), $allowedMax),
        ];
    }

    protected function storedTotalDigits(PhoneNumber $number): int
    {
        return strlen((string)$number->getCountryCode())
            + strlen($this->phoneNumberUtil->getNationalSignificantNumber($number));
    }

    protected function digitsOf(string $value): string
    {
        return preg_replace('/\D/', '', $value) ?? '';
    }
}
