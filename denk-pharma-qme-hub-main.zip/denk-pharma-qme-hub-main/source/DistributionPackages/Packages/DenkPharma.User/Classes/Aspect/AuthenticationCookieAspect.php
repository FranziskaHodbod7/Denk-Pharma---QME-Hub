<?php

declare(strict_types=1);

namespace DenkPharma\User\Aspect;

use DenkPharma\User\Domain\Model\User;
use DenkPharma\User\Service\FieldsOfInterestCookieService;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Aop\JoinPointInterface;

#[Flow\Aspect]
class AuthenticationCookieAspect
{
    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected FieldsOfInterestCookieService $fieldsOfInterestCookieService;

    #[Flow\AfterReturning("method(FormatD\UserManagementPlugin\Controller\AuthenticationController->onAuthenticationSuccess())")]
    public function setFieldsOfInterestCookieAfterLogin(JoinPointInterface $joinPoint): void
    {
        $user = $this->userService->getCurrentUser();
        if (!$user instanceof User) {
            return;
        }

        $this->fieldsOfInterestCookieService->write($user);
    }

    #[Flow\Before("method(FormatD\UserManagementPlugin\Controller\AuthenticationController->logoutAction())")]
    public function clearFieldsOfInterestCookieBeforeLogout(JoinPointInterface $joinPoint): void
    {
        $this->fieldsOfInterestCookieService->clear();
    }
}
