<?php

declare(strict_types=1);

namespace DenkPharma\User\Eel;

use DenkPharma\User\Domain\Enum\OnboardingStatus;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

#[Flow\Scope('singleton')]
class OnboardingHelper implements ProtectedContextAwareInterface
{
    /** @phpstan-return list<array{value: string, label: string}> */
    public function steps(): array
    {
        return OnboardingStatus::entries();
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
