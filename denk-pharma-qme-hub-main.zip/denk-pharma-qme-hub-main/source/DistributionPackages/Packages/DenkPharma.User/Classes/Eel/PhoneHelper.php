<?php

declare(strict_types=1);

namespace DenkPharma\User\Eel;

use DenkPharma\User\Service\PhoneNumberService;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

/**
 * Gives Fusion the dial-code options for the dropdown. PhoneNumberService holds the list and all
 * of the combine, split and validation logic. That service uses libphonenumber.
 */
#[Flow\Scope('singleton')]
class PhoneHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    /**
     * Returns the dial-code options. Each option holds the digit limits for its own dial code. The
     * form therefore needs no global minimum property and no global maximum property.
     *
     * @return list<array{label: string, value: string, minLength: int, maxLength: int}>
     */
    public function dialCodes(): array
    {
        return $this->phoneNumberService->dialCodeOptions();
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
