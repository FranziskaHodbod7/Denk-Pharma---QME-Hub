<?php

declare(strict_types=1);

namespace DenkPharma\User\Eel;

use DenkPharma\User\Service\TitleService;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

/** Exposes the title dropdown options to Fusion. */
#[Flow\Scope('singleton')]
class TitleHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected TitleService $titleService;

    /**
     * @return list<array{label: string, value: string, id: string}> localised, "no title" first
     */
    public function options(): array
    {
        return $this->titleService->options();
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
