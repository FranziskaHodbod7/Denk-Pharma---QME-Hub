<?php

declare(strict_types=1);

namespace DenkPharma\User\Eel;

use DenkPharma\User\Domain\Model\User;
use DenkPharma\User\Service\PhoneNumberService;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

/**
 * Exposes the logged-in user's current account values to Fusion (data-config pre-fill).
 * Kept separate from OnboardingHelper so account-settings stays independent of onboarding.
 */
#[Flow\Scope('singleton')]
class AccountHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    public function firstName(): string
    {
        $name = $this->currentUser()?->getName();
        return $name !== null ? $name->getFirstName() : '';
    }

    public function lastName(): string
    {
        $name = $this->currentUser()?->getName();
        return $name !== null ? $name->getLastName() : '';
    }

    public function email(): string
    {
        return (string)($this->currentUser()?->getPrimaryEmailAddress() ?? '');
    }

    public function title(): string
    {
        return $this->currentUser()?->getTitle() ?? '';
    }

    public function city(): string
    {
        return $this->currentUser()?->getCity() ?? '';
    }

    public function country(): string
    {
        return $this->currentUser()?->getCountry() ?? '';
    }

    public function phoneNumber(): string
    {
        return $this->currentUser()?->getPhoneNumber() ?? '';
    }

    public function phoneDialCode(): string
    {
        return $this->phoneNumberService->split($this->phoneNumber())['dialCode'];
    }

    public function phoneLocalNumber(): string
    {
        return $this->phoneNumberService->split($this->phoneNumber())['localNumber'];
    }

    public function professionalField(): ?string
    {
        return $this->currentUser()?->getProfessionalField()?->value;
    }

    /** @return list<string> */
    public function fieldsOfInterest(): array
    {
        $user = $this->currentUser();
        if ($user === null) {
            return [];
        }
        return array_map(static fn(NodeAggregateId $id): string => $id->value, $user->getFieldsOfInterest());
    }

    /**
     * A stable token for the current user's field-of-interest selection: order-independent,
     * changes iff the selection changes. The empty selection ("all fields of interest")
     * collapses to a single "all" token. Suitable as an `@cache.entryIdentifier` discriminator.
     */
    public function interestFingerprint(): string
    {
        $ids = $this->fieldsOfInterest();
        if ($ids === []) {
            return 'all';
        }
        sort($ids);
        return implode('_', $ids);
    }

    public function displayName(): string
    {
        $name = $this->currentUser()?->getName();

        return $name === null
			? ''
			: trim($name->getFirstName() . ' ' . $name->getLastName());
    }

    public function newsletterSubscribed(): bool
    {
        return $this->currentUser()?->isNewsletterSubscribed() ?? false;
    }

    public function whatsAppConsentGiven(): bool
    {
        return $this->currentUser()?->isWhatsAppConsentGiven() ?? false;
    }

    private function currentUser(): ?User
    {
        $user = $this->userService->getCurrentUser();
        return $user instanceof User ? $user : null;
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
