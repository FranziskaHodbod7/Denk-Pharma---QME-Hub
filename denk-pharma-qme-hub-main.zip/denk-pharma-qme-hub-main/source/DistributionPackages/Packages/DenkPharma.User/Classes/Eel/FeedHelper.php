<?php

declare(strict_types=1);

namespace DenkPharma\User\Eel;

use DenkPharma\Core\Service\TaxonomyResolver;
use DenkPharma\User\Service\FieldOfInterestFeedService;
use DenkPharma\User\Domain\Model\User;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;
use Neos\Neos\Fusion\Helper\CachingHelper;

/**
 * Exposes the current user's field-of-interest content feeds to Fusion. One method per
 * content type; the feed logic lives in FieldOfInterestFeedService. An empty interest
 * selection counts as "all available" — every field of interest. $exclude (a mix of
 * Node | NodeAggregateId | id string) drops items the caller already shows.
 */
#[Flow\Scope('singleton')]
class FeedHelper implements ProtectedContextAwareInterface
{
    /** Taxon node type underlying both the field-of-interest and medication vocabularies. */
    private const string TAXON_TYPE = 'Sitegeist.Taxonomy:Taxonomy';

    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected TaxonomyResolver $taxonomyResolver;

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected FieldOfInterestFeedService $feedService;

    #[Flow\Inject]
    protected CachingHelper $cachingHelper;

    /**
     * Studies matching the current user's fields of interest, ranked by
     * interest-overlap then publication date (newest first).
     *
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function matchingStudies(Node $contextNode, ?int $limit = null, array $exclude = []): array
    {
        return $this->feedService->studiesByInterests($contextNode, $this->interestIds($contextNode), $limit, $exclude);
    }

    /**
     * Products matching the current user's fields of interest — directly and via the
     * medication bridge — ranked by interest-overlap then title (A–Z).
     *
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function matchingProducts(Node $contextNode, ?int $limit = null, array $exclude = []): array
    {
        return $this->feedService->productsByInterests($contextNode, $this->interestIds($contextNode), $limit, $exclude);
    }

    /**
     * Videos matching the current user's fields of interest, ranked by
     * interest-overlap then publication date (newest first).
     *
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function matchingVideos(Node $contextNode, ?int $limit = null, array $exclude = []): array
    {
        return $this->feedService->videosByInterests($contextNode, $this->interestIds($contextNode), $limit, $exclude);
    }

    /**
     * Upcoming events matching the current user's fields of interest — directly and via the
     * medication bridge — ranked by interest-overlap then start date (soonest first).
     *
     * @param list<Node|NodeAggregateId|string> $exclude
     * @return list<Node>
     */
    public function matchingEvents(Node $contextNode, ?int $limit = null, array $exclude = []): array
    {
        return $this->feedService->eventsByInterests($contextNode, $this->interestIds($contextNode), $limit, $exclude);
    }

    /** @return array<int,string> entry tags flushing the studies feed; see feedTags() */
    public function studyTags(Node $contextNode): array
    {
        return $this->feedTags(FieldOfInterestFeedService::STUDY_TYPE, $contextNode);
    }

    /** @return array<int,string> entry tags flushing the products feed; see feedTags() */
    public function productTags(Node $contextNode): array
    {
        return $this->feedTags(FieldOfInterestFeedService::PRODUCT_TYPE, $contextNode);
    }

    /** @return array<int,string> entry tags flushing the videos feed; see feedTags() */
    public function videoTags(Node $contextNode): array
    {
        return $this->feedTags(FieldOfInterestFeedService::VIDEO_TYPE, $contextNode);
    }

    /** @return array<int,string> entry tags flushing the events feed; see feedTags() */
    public function eventTags(Node $contextNode): array
    {
        return $this->feedTags(FieldOfInterestFeedService::EVENT_TYPE, $contextNode);
    }

    /**
     * Node-type cache entry tags that flush a feed whenever a candidate document of
     * $documentType, or any taxon (field-of-interest or the medication bridge), changes.
     * Type-level, not per-node: documents newly published into the feed flush it too.
     *
     * @return array<int,string>
     */
    private function feedTags(string $documentType, Node $contextNode): array
    {
        return $this->cachingHelper->nodeTypeTag([$documentType, self::TAXON_TYPE], $contextNode);
    }

    /**
     * The current user's selected interests, or — when none are selected — every
     * available field of interest (the empty-selection sentinel).
     *
     * @return list<NodeAggregateId>
     */
    private function interestIds(Node $contextNode): array
    {
        $user = $this->userService->getCurrentUser();
        if ($user instanceof User) {
            $selected = $user->getFieldsOfInterest();
            if ($selected !== []) {
                return $selected;
            }
        }

        $subgraph = $this->contentRepositoryRegistry->subgraphForNode($contextNode);
        return array_map(
            static fn(Node $taxon): NodeAggregateId => $taxon->aggregateId,
            $this->taxonomyResolver->listAll($subgraph, 'field-of-interest')
        );
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
