<?php

declare(strict_types=1);

namespace DenkPharma\User\Util;

use GuzzleHttp\Psr7\Response;
use Neos\Flow\Annotations as Flow;
use Psr\Http\Message\ResponseInterface;

#[Flow\Proxy(false)]
final class JsonResponse
{
    /**
     * @param array<string, mixed> $payload
     * @throws \JsonException
     */
    public static function create(int $status, array $payload): ResponseInterface
    {
        return new Response(
            $status,
            ['Content-Type' => 'application/json'],
            json_encode($payload, JSON_THROW_ON_ERROR)
        );
    }
}
