<?php

declare(strict_types=1);

namespace DenkPharma\User\Util;

use Neos\Flow\Annotations as Flow;
use Psr\Http\Message\ServerRequestInterface;

#[Flow\Proxy(false)]
final class JsonBody
{
    /**
     * Decodes the request body once as a JSON object.
     *
     * @return array<string, mixed>|null null on JSON parse failure or non-object root
     */
    public static function decode(ServerRequestInterface $request): ?array
    {
        try {
            $payload = json_decode((string)$request->getBody(), true, flags: JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return null;
        }
        return is_array($payload) ? $payload : null;
    }
}
