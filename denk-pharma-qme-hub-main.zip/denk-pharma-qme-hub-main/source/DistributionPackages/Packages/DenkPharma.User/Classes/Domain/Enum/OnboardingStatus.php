<?php

declare(strict_types=1);

namespace DenkPharma\User\Domain\Enum;

/**
 * Registration now collects consent up front, so onboarding currently defines no steps of its
 * own: User::isOnboardingComplete() is vacuously true for every user, and
 * OnboardingRedirectMiddleware never redirects anywhere. Kept as the type future steps register
 * against, rather than removed outright.
 *
 * The backed value is the identifier a user carries once the step is finished. It is stored as
 * text, so adding or removing a case never renumbers the steps a user already has.
 */
enum OnboardingStatus: string
{
    public function label(): string
    {
        return match ($this) {};
    }

    /** @return list<array{value: string, label: string}> */
    public static function entries(): array
    {
        return array_map(
            static fn(self $case): array => ['value' => $case->value, 'label' => $case->label()],
            self::cases()
        );
    }
}
