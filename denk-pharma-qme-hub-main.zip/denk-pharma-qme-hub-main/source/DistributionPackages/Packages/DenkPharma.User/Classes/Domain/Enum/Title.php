<?php

declare(strict_types=1);

namespace DenkPharma\User\Domain\Enum;

/**
 * Academic title prefixed to a user's name.
 *
 * `None` is backed by the empty string, so "has no title" and "never answered" are one
 * stored state. Cases are stable keys rather than display strings, so a value stored in
 * one language still resolves in another.
 */
enum Title: string
{
    case None = '';
    case Dr = 'dr';
    case ProfDr = 'profDr';

    /** Translation unit id in DenkPharma.User's Main.xlf. */
    public function translationId(): string
    {
        return match ($this) {
            self::None => 'title.none',
            self::Dr => 'title.dr',
            self::ProfDr => 'title.profDr',
        };
    }
}
