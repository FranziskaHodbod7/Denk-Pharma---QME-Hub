<?php

declare(strict_types=1);

namespace DenkPharma\User\Domain\Model;

use Doctrine\ORM\Mapping as ORM;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;

#[Flow\Entity]
#[ORM\Table(uniqueConstraints: [new ORM\UniqueConstraint(columns: ['user', 'interest'])])]
class UserFieldOfInterest
{
    #[ORM\ManyToOne(targetEntity: User::class, inversedBy: 'fieldsOfInterest')]
    #[ORM\JoinColumn(onDelete: 'CASCADE')]
    protected User $user;

    #[ORM\Column(length: 36)]
    protected string $interest;

    public function __construct(User $user, NodeAggregateId $interest)
    {
        $this->user = $user;
        $this->interest = $interest->value;
    }

    public function getUser(): User
    {
        return $this->user;
    }

    public function getInterest(): NodeAggregateId
    {
        return NodeAggregateId::fromString($this->interest);
    }
}
