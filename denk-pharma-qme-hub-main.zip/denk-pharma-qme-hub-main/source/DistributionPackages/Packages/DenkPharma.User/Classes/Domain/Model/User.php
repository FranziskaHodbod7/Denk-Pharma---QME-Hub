<?php

declare(strict_types=1);

namespace DenkPharma\User\Domain\Model;

use DenkPharma\User\Domain\Enum\OnboardingStatus;
use DenkPharma\User\Domain\Enum\Title;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;

#[Flow\Entity]
class User extends \FormatD\UserManagement\Domain\Model\User
{
    /**
     * Identifiers of the onboarding steps this user has finished, held the way
     * Account::$roleIdentifiers holds its roles: text in a simple_array, so adding or removing a
     * step never renumbers what a user already carries.
     *
     * @var array<string>
     */
    #[ORM\Column(type: 'simple_array', nullable: true)]
    protected ?array $onboardingStepIdentifiers = [];

    /**
     * Backed value of a Title case. PersonName::$title is unusable for this: its contract is a
     * display string, concatenated into the searchable PersonName::$fullName column.
     *
     * Typed as string so the registration form can property-map into it.
     */
    #[Flow\Validate(type: 'DenkPharma.User:Title')]
    #[ORM\Column(length: 20, options: ['default' => ''])]
    protected string $title = '';

    #[ORM\Column(length: 36, nullable: true)]
    protected ?string $professionalField = null;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: UserFieldOfInterest::class, cascade: ['all'], orphanRemoval: true)]
    protected Collection $fieldsOfInterest;

    /**
     * Opt-in consent to be contacted via WhatsApp.
     */
    #[ORM\Column]
    protected bool $whatsAppConsentGiven = false;

    public function __construct()
    {
        parent::__construct();

        $this->fieldsOfInterest = new ArrayCollection();

        $this->newsletterSubscribed = true;
    }

    /**
     * The steps this user has finished, keyed by identifier.
     *
     * An identifier that no longer names a case is dropped here, the way
     * Account::initializeRoles() drops a role the policy no longer defines. Removing a step from
     * the enum therefore cannot leave a user unfinished forever.
     *
     * @return array<string, OnboardingStatus>
     */
    public function getOnboardingSteps(): array
    {
        $steps = [];
        foreach ($this->onboardingStepIdentifiers ?? [] as $key => $identifier) {
            $step = OnboardingStatus::tryFrom((string)$identifier);
            if ($step === null) {
                unset($this->onboardingStepIdentifiers[$key]);
                continue;
            }
            $steps[$step->value] = $step;
        }

        return $steps;
    }

    public function hasOnboardingStep(OnboardingStatus $step): bool
    {
        return array_key_exists($step->value, $this->getOnboardingSteps());
    }

    public function addOnboardingStep(OnboardingStatus $step): void
    {
        if ($this->hasOnboardingStep($step)) {
            return;
        }

        $this->onboardingStepIdentifiers ??= [];
        $this->onboardingStepIdentifiers[] = $step->value;
    }

    public function removeOnboardingStep(OnboardingStatus $step): void
    {
        $index = array_search($step->value, $this->onboardingStepIdentifiers ?? [], true);
        if ($index !== false) {
            unset($this->onboardingStepIdentifiers[$index]);
        }
    }

    public function isOnboardingComplete(): bool
    {
        foreach (OnboardingStatus::cases() as $case) {
            if (!$this->hasOnboardingStep($case)) {
                return false;
            }
        }

        return true;
    }

    /** @return list<string> */
    public function getOnboardingStepIdentifiers(): array
    {
        return array_keys($this->getOnboardingSteps());
    }

    /** @param array<int|string, mixed> $identifiers */
    public function setOnboardingStepIdentifiers(array $identifiers): void
    {
        $this->onboardingStepIdentifiers = [];
        foreach ($identifiers as $identifier) {
            $step = is_string($identifier) ? OnboardingStatus::tryFrom($identifier) : null;
            if ($step !== null) {
                $this->addOnboardingStep($step);
            }
        }
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function getTitleEnum(): Title
    {
        return Title::tryFrom($this->title) ?? Title::None;
    }

    public function getProfessionalField(): ?NodeAggregateId
    {
        return $this->professionalField === null ? null : NodeAggregateId::fromString($this->professionalField);
    }

    public function setProfessionalField(?NodeAggregateId $id): void
    {
        $this->professionalField = $id?->value;
    }

    /** @return list<NodeAggregateId> */
    public function getFieldsOfInterest(): array
    {
        $ids = [];
        foreach ($this->fieldsOfInterest as $entry) {
            $ids[] = $entry->getInterest();
        }
        return $ids;
    }

    /**
     * @param list<NodeAggregateId> $ids new selection; replaces the existing collection
     */
    public function setFieldsOfInterest(array $ids): void
    {
        $wanted = [];
        foreach ($ids as $id) {
            $wanted[$id->value] = $id;
        }

        foreach ($this->fieldsOfInterest as $existing) {
            $key = $existing->getInterest()->value;
            if (isset($wanted[$key])) {
                unset($wanted[$key]);
            } else {
                $this->fieldsOfInterest->removeElement($existing);
            }
        }

        foreach ($wanted as $id) {
            $this->fieldsOfInterest->add(new UserFieldOfInterest($this, $id));
        }
    }

    public function setWhatsAppConsentGiven(bool $whatsAppConsentGiven): void
    {
        $this->whatsAppConsentGiven = $whatsAppConsentGiven;
    }

    public function isWhatsAppConsentGiven(): bool
    {
        return $this->whatsAppConsentGiven ?? false;
    }
}
