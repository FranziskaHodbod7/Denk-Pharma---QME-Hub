<?php

declare(strict_types=1);

namespace DenkPharma\User\Domain\Exception;

use Neos\Flow\Exception;

final class InvalidCurrentPasswordException extends Exception
{
}
