<?php

declare(strict_types=1);

namespace DenkPharma\User\Dto;

use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Flow\Annotations as Flow;

/**
 * A matched feed document together with its interest-overlap count, for ranking.
 */
#[Flow\Proxy(false)]
final readonly class FeedCandidate
{
    public function __construct(
        public Node $node,
        public int $overlap,
    ) {
    }
}
