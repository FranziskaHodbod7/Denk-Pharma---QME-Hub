<?php

declare(strict_types=1);

namespace DenkPharma\User\Controller;

use DenkPharma\User\Domain\Model\User;
use DenkPharma\User\Http\Dto\InvalidInputException;
use DenkPharma\User\Http\Dto\NewsletterConsentInput;
use DenkPharma\User\Service\UserPreferencesService;
use DenkPharma\User\Util\JsonBody;
use DenkPharma\User\Util\JsonResponse;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Psr\Http\Message\ResponseInterface;

/**
 * Onboarding currently defines no steps  so nobody is ever redirected here.
 */
class OnboardingController extends ActionController
{
    /**
     * @var array<string>
     */
    protected $supportedMediaTypes = ['application/json'];

    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected UserPreferencesService $userPreferencesService;

    #[Flow\SkipCsrfProtection]
    public function newsletterAction(): ResponseInterface
    {
        $user = $this->currentUser();
        if ($user === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $body = JsonBody::decode($this->request->getHttpRequest());
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = NewsletterConsentInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        $this->userPreferencesService->setNewsletterSubscribed($user, $input->subscribed);

        return JsonResponse::create(200, ['success' => true, 'completed' => true]);
    }

    private function currentUser(): ?User
    {
        $user = $this->userService->getCurrentUser();
        return $user instanceof User ? $user : null;
    }
}
