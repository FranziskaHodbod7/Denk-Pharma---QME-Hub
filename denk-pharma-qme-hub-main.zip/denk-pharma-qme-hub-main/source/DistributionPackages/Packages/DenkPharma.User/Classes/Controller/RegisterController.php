<?php

declare(strict_types=1);

namespace DenkPharma\User\Controller;

use DenkPharma\User\Domain\Model\User;
use DenkPharma\User\Service\FieldsOfInterestCookieService;
use DenkPharma\User\Service\PhoneNumberService;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Error\Messages\Message;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\I18n\Translator;
use Neos\Flow\Log\Utility\LogEnvironment;
use Neos\Flow\Security\Account;
use Neos\Flow\Security\Authentication\TokenInterface;
use Neos\Flow\Session\SessionInterface;

/**
 * Registration without double opt-in: the account is active from the first request, the visitor is
 * logged in, and the confirmation mail is gone.
 *
 * activateAccountAction() is inherited and stays reachable, so opt-in links sent before this
 * change still activate their account until the pending accounts are deleted.
 */
class RegisterController extends \FormatD\UserManagementPlugin\Controller\RegisterController
{
    #[Flow\Inject]
    protected FieldsOfInterestCookieService $fieldsOfInterestCookieService;

    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    #[Flow\Inject]
    protected SessionInterface $session;

    #[Flow\Inject]
    protected Translator $translator;

    /**
     * @param array<int, string> $password
     *
     * @Flow\Validate(argumentName="user.name.firstName", type="NotEmpty")
     * @Flow\Validate(argumentName="user.name.firstName", type="StringLength", options={ "maximum"="50" })
     * @Flow\Validate(argumentName="user.name.firstName", type="RegularExpression", options={ "regularExpression"="/^((?!https?:).)*$/i" })
     * @Flow\Validate(argumentName="user.name.lastName", type="NotEmpty")
     * @Flow\Validate(argumentName="user.name.lastName", type="StringLength", options={ "maximum"="50" })
     * @Flow\Validate(argumentName="user.name.lastName", type="RegularExpression", options={ "regularExpression"="/^((?!https?:).)*$/i" })
     * @Flow\Validate(argumentName="termsOfUseAccepted", type="FormatD.UserManagement:True")
     * @Flow\Validate(argumentName="cookiesAccepted", type="FormatD.UserManagement:True")
     */
    public function createUserAction(
        \FormatD\UserManagement\Domain\Model\User $user,
        string $username,
        array $password,
        bool $termsOfUseAccepted,
        bool $cookiesAccepted
    ): void {
        if ($this->securityContext->getAccount()
            && \in_array($this->securityContext->getAccount()->getAuthenticationProviderName(), $this->configurationSet['authenticationProviderNames'], true)) {
            $this->handleRedirect('register.redirectIfAlreadyLoggedLogin');
        }

        $emailIdentifier = $this->getEmailIdentifierFromUserName($username);

        $account = $this->accountRepository->findByAccountIdentifierAndAuthenticationProviderName(
            $emailIdentifier,
            $this->configurationSet['authenticationProviderNames'][0]
        );

        if ($account instanceof Account) {
            $existingUser = $this->handleAlreadyRegisteredUserDuringRegistration($account, $user, $password);
            if (!$existingUser) {
                $this->forwardToReferringRequest();
            }
            $user = $existingUser;
            $account->setExpirationDate(null);
            $this->accountRepository->update($account);
            $this->persistenceManager->persistAll();
        } else {
            $account = $this->createNewUserAndAccount($emailIdentifier, $user, $password);
        }

        if (!$this->authenticateAccount($account)) {
            $this->logger->warning(
                'Registration created an active account but could not log the visitor in.',
                LogEnvironment::fromMethodName(__METHOD__)
            );
            $this->handleRedirect('register.redirectIfAlreadyLoggedLogin');
            return;
        }

        if ($user instanceof User) {
            $this->fieldsOfInterestCookieService->write($user);
        }

        // Own copy instead of dispatchMessage(): the vendor's 'register.accountCreated' text
        // still talks about a confirmation email, which this opt-in-free flow no longer sends.
        $this->addFlashMessage(
            $this->translateById('register.accountCreated.message'),
            $this->translateById('register.accountCreated.title'),
            Message::SEVERITY_NOTICE
        );

        $this->handleRedirect('register.redirectAfterAccountCreation', ['user' => $user]);
    }

    private function translateById(string $id): string
    {
        return $this->translator->translateById($id, [], null, null, 'Main', 'DenkPharma.User') ?? $id;
    }

    /**
     * The account is active from the start: there is no opt-in token to clear it later.
     *
     * @param array<int, string> $password
     */
    protected function createNewUserAndAccount(string $emailIdentifier, \FormatD\UserManagement\Domain\Model\User $user, array $password): Account
    {
        $primaryElectronicAddress = new \Neos\Party\Domain\Model\ElectronicAddress();
        $primaryElectronicAddress->setType($primaryElectronicAddress->getAvailableElectronicAddressTypes()['Email']);
        $primaryElectronicAddress->setIdentifier($emailIdentifier);
        $primaryElectronicAddress->setApproved(true);
        $user->setPrimaryElectronicAddress($primaryElectronicAddress);

        $user = $this->setAdditionalUserProperties($user);

        $this->userService->addUser(
            $emailIdentifier,
            $password[0],
            $user,
            $this->getNewUserRoles(),
            $this->configurationSet['authenticationProviderNames'][0],
            false
        );
        $account = $this->userService->getLastCreatedAccount();

        $this->onUserCreated($user);

        return $account;
    }

    /**
     * The parent copies the fields of its own user model one property at a time and cannot know
     * about the fields this package adds.
     *
     * @param array<int, string> $password
     */
    protected function handleAlreadyRegisteredUserDuringRegistration($existingAccount, $newUser, $password)
    {
        $existingUser = parent::handleAlreadyRegisteredUserDuringRegistration($existingAccount, $newUser, $password);

        if ($existingUser instanceof User && $newUser instanceof User) {
            $existingUser->setTitle($newUser->getTitle());
            $existingUser->setWhatsAppConsentGiven($newUser->isWhatsAppConsentGiven());
            // Reads the submitted values off the request, so this branch applies the same fields
            // the new-account branch does.
            $this->setAdditionalUserProperties($existingUser);
            $this->partyRepository->update($existingUser);
        }

        return $existingUser;
    }

    /**
     * On the new-account branch this runs before UserService::addUser() persists the party, so the
     * values go straight onto the model: UserPreferencesService is the update path and would call
     * persistAll() on what is still an unmanaged entity. The validators already performed its
     * taxonomy checks. handleAlreadyRegisteredUserDuringRegistration() calls the same method for a
     * re-registered account, where the caller persists.
     */
    protected function setAdditionalUserProperties($user)
    {
        if (!$user instanceof User) {
            return $user;
        }

        $professionalField = $this->argumentValue('professionalField');
        if ($professionalField !== '') {
            $user->setProfessionalField(NodeAggregateId::fromString($professionalField));
        }

        $fieldsOfInterest = $this->arguments->hasArgument('fieldsOfInterest')
            ? (array)$this->arguments->getArgument('fieldsOfInterest')->getValue()
            : [];
        $user->setFieldsOfInterest(array_map(
            static fn(string $id): NodeAggregateId => NodeAggregateId::fromString($id),
            array_values(array_filter($fieldsOfInterest, static fn($id): bool => is_string($id) && $id !== ''))
        ));

        $dialCode = $this->argumentValue('dialCode');
        $phoneNumber = $this->argumentValue('phoneNumber');
        if ($dialCode !== '' && $phoneNumber !== '') {
            $user->setPhoneNumber($this->phoneNumberService->combine($dialCode, $phoneNumber));
        }

        // combined newsletter and whatsapp checkbox
        $user->setNewsletterSubscribed($user->isWhatsAppConsentGiven());

        return $user;
    }

    protected function argumentValue(string $name): string
    {
        if (!$this->arguments->hasArgument($name)) {
            return '';
        }

        $value = $this->arguments->getArgument($name)->getValue();

        return is_string($value) ? $value : '';
    }

    /**
     * Logs the freshly created account in, the way FrontendUserImpersonationService does: the
     * security context is session scoped, so the token state survives the redirect.
     */
    protected function authenticateAccount(Account $account): bool
    {
        $providerNames = $this->configurationSet['authenticationProviderNames'];
        $authenticated = false;

        foreach ($this->securityContext->getAuthenticationTokens() as $token) {
            if (!\in_array($token->getAuthenticationProviderName(), $providerNames, true)) {
                continue;
            }

            $token->setAccount($account);
            $token->setAuthenticationStatus(TokenInterface::AUTHENTICATION_SUCCESSFUL);
            $authenticated = true;
        }

        if (!$authenticated) {
            return false;
        }

        // The security context is session scoped, and Flow keeps a session scoped object only for
        // a session that was started. A visitor who registers has none, so without this the
        // authenticated token is dropped at the redirect and the visitor lands on the login form.
        if (!$this->session->isStarted()) {
            $this->session->start();
        }

        $account->authenticationAttempted(TokenInterface::AUTHENTICATION_SUCCESSFUL);
        $this->accountRepository->update($account);
        $this->persistenceManager->persistAll();

        return true;
    }
}
