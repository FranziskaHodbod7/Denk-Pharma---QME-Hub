<?php

declare(strict_types=1);

namespace DenkPharma\User\Controller;

use DenkPharma\User\Domain\Enum\Title;
use DenkPharma\User\Domain\Exception\InvalidCurrentPasswordException;
use DenkPharma\User\Domain\Exception\InvalidPasswordException;
use DenkPharma\User\Domain\Exception\InvalidPreferenceValueException;
use DenkPharma\User\Domain\Model\User;
use DenkPharma\User\Http\Dto\FieldsOfInterestInput;
use DenkPharma\User\Http\Dto\InvalidInputException;
use DenkPharma\User\Http\Dto\NotificationInput;
use DenkPharma\User\Http\Dto\PasswordInput;
use DenkPharma\User\Http\Dto\ProfessionalFieldInput;
use DenkPharma\User\Http\Dto\ProfileInput;
use DenkPharma\User\Service\AccountProfileService;
use DenkPharma\User\Service\AuthoringSubgraphProvider;
use DenkPharma\User\Service\DtoValidator;
use DenkPharma\User\Service\PhoneNumberService;
use DenkPharma\User\Service\UserPreferencesService;
use DenkPharma\User\Util\JsonBody;
use DenkPharma\User\Util\JsonResponse;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Security\Context as SecurityContext;
use Psr\Http\Message\ResponseInterface;

class AccountController extends ActionController
{
    /**
     * @var array<string>
     */
    protected $supportedMediaTypes = ['application/json'];

    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected UserPreferencesService $userPreferencesService;

    #[Flow\Inject]
    protected AccountProfileService $accountProfileService;

    #[Flow\Inject]
    protected SecurityContext $securityContext;

    #[Flow\Inject]
    protected AuthoringSubgraphProvider $authoringSubgraphProvider;

    #[Flow\Inject]
    protected DtoValidator $dtoValidator;

    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    #[Flow\SkipCsrfProtection]
    public function profileAction(): ResponseInterface
    {
        $user = $this->currentUser();
        if ($user === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $body = JsonBody::decode($this->request->getHttpRequest());
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = ProfileInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        $errors = $this->dtoValidator->errorsFor($input);
        if ($errors !== []) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $errors]);
        }

        $phoneErrors = $this->phoneNumberService->validationErrors($input->dialCode, $input->phoneNumber);
        if ($phoneErrors !== []) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $phoneErrors]);
        }

        $phoneNumber = $this->phoneNumberService->combine($input->dialCode, $input->phoneNumber);
        $this->accountProfileService->updateProfile($user, Title::from($input->title), $input->firstName, $input->lastName, $input->city, $input->country, $phoneNumber);

        return JsonResponse::create(200, ['success' => true]);
    }

    #[Flow\SkipCsrfProtection]
    public function passwordAction(): ResponseInterface
    {
        if ($this->currentUser() === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $account = $this->securityContext->getAccount();
        if ($account === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $body = JsonBody::decode($this->request->getHttpRequest());
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = PasswordInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        try {
            $this->accountProfileService->changePassword($account, $input->current, $input->new, $input->repeat);
        } catch (InvalidCurrentPasswordException | InvalidPasswordException $e) {
            return JsonResponse::create(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        return JsonResponse::create(200, ['success' => true]);
    }

    #[Flow\SkipCsrfProtection]
    public function professionalFieldAction(): ResponseInterface
    {
        $user = $this->currentUser();
        if ($user === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $request = $this->request->getHttpRequest();
        $body = JsonBody::decode($request);
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = ProfessionalFieldInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        try {
            $this->userPreferencesService->setProfessionalField($user, $this->authoringSubgraphProvider->forRequest($request), $input->id);
        } catch (InvalidPreferenceValueException $e) {
            return JsonResponse::create(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        return JsonResponse::create(200, ['success' => true]);
    }

    #[Flow\SkipCsrfProtection]
    public function fieldsOfInterestAction(): ResponseInterface
    {
        $user = $this->currentUser();
        if ($user === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $request = $this->request->getHttpRequest();
        $body = JsonBody::decode($request);
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = FieldsOfInterestInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        try {
            $this->userPreferencesService->setFieldsOfInterest($user, $this->authoringSubgraphProvider->forRequest($request), $input->ids);
        } catch (InvalidPreferenceValueException $e) {
            return JsonResponse::create(422, ['success' => false, 'error' => $e->getMessage()]);
        }

        return JsonResponse::create(200, ['success' => true]);
    }

    #[Flow\SkipCsrfProtection]
    public function newsletterAction(): ResponseInterface
    {
        $user = $this->currentUser();
        if ($user === null) {
            return JsonResponse::create(403, ['success' => false]);
        }

        $body = JsonBody::decode($this->request->getHttpRequest());
        if ($body === null) {
            return JsonResponse::create(400, ['success' => false, 'error' => 'Request body must be a JSON object']);
        }

        try {
            $input = NotificationInput::fromArray($body);
        } catch (InvalidInputException $e) {
            return JsonResponse::create(422, ['success' => false, 'errors' => $e->errors()]);
        }

        $this->userPreferencesService->setCommunicationConsents($user, $input->subscribed, $input->whatsAppConsent);

        return JsonResponse::create(200, ['success' => true]);
    }

    private function currentUser(): ?User
    {
        $user = $this->userService->getCurrentUser();
        return $user instanceof User ? $user : null;
    }
}
