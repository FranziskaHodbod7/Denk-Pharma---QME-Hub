<script lang="ts">
	import type { DialCode } from "./phone";
	import SelectChevron from "./SelectChevron.svelte";
	import "./PhoneCodeSelect.scss";

	let {
		id,
		value = $bindable(),
		options,
		ariaLabel,
		name,
	}: {
		id: string;
		value: string;
		options: DialCode[];
		ariaLabel?: string;
		/** Set only inside a posted form; the account screens send their value as JSON. */
		name?: string;
	} = $props();
</script>

<div class="custom-select phone-code-select">
	<select {id} {name} class="select-input" bind:value required aria-label={ariaLabel}>
		{#each options as option (option.value + option.label)}
			<option value={option.value}>{option.label}</option>
		{/each}
	</select>
	<SelectChevron />
	<span class="phone-code-select__display" aria-hidden="true">{value}</span>
</div>
