<script lang="ts">
	import { untrack } from 'svelte'
	import './FieldsOfInterest.scss'

	interface Option {
		id: string
		label: string
	}

	interface Config {
		name: string
		options: Option[]
		selected: string[]
		dontKnowLabel: string
	}

	let { config }: { config: Config } = $props()

	let selected = $state<string[]>(untrack(() => [...config.selected]))
	let open = $state(false)

	const summary = $derived(
		selected.length === 0
			? config.dontKnowLabel
			: config.options.filter((option) => selected.includes(option.id)).map((option) => option.label).join(', ')
	)

	function toggle(id: string) {
		selected = selected.includes(id) ? selected.filter((value) => value !== id) : [...selected, id]
	}

	function clear() {
		selected = []
	}
</script>

<svelte:window onclick={(event) => { if (open && !(event.target as HTMLElement).closest('.registration-foi')) open = false }} />

<div class="registration-foi" class:registration-foi--open={open}>
	<button class="registration-foi__summary select-input" type="button" aria-expanded={open} onclick={() => (open = !open)}>
		{summary}
	</button>

	{#if open}
		<div class="registration-foi__options">
			{#each config.options as option}
				<label class="registration-foi__option">
					<input type="checkbox" checked={selected.includes(option.id)} onchange={() => toggle(option.id)} />
					{option.label}
				</label>
			{/each}
			<label class="registration-foi__option">
				<input type="checkbox" checked={selected.length === 0} onchange={clear} />
				{config.dontKnowLabel}
			</label>
		</div>
	{/if}

	<!--
		An empty selection still posts one entry. Flow registers an additional validated argument as
		required, so a form without any input for this field is rejected before the action runs, and
		"I do not know yet" is a valid answer. The server drops the empty entry.
	-->
	{#if selected.length === 0}
		<input type="hidden" name={config.name} value="" />
	{:else}
		{#each selected as id}
			<input type="hidden" name={config.name} value={id} />
		{/each}
	{/if}
</div>
