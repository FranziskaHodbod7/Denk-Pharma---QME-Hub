import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager'
import { mountAccountApp } from './mountAccountApp'
import NewsletterApp from './Notification.svelte'

export default class NewsletterManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		mountAccountApp(domSection, 'newsletter', NewsletterApp)
	}
}
