<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import { postAccount, notifySaveResult } from './accountApi'
	import SelectOption from '../SelectOption.svelte'
	import './ProfessionalField.scss'

	interface Option {
		id: string
		label: string
		icon?: string | null
	}

	interface Config {
		endpoint: string
		options: Option[]
		selected: string | null
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))

	let selected = $state<string | null>(untrack(() => config.selected))
	let loading = $state(false)

	const canSubmit = $derived(selected !== null && !loading)

	async function save() {
		if (!canSubmit) return
		loading = true
		notifySaveResult(await postAccount(config.endpoint, { professionalField: selected }), t)
		loading = false
	}
</script>

<div class="account-professional-field">
	<div class="account-professional-field__options one-grid">
		{#each config.options as option}
			<SelectOption
				type="radio"
				name="professionalField"
				value={option.id}
				label={option.label}
				icon={option.icon}
				onWhite
				bind:group={selected}
			/>
		{/each}
	</div>

	<button class="account-professional-field__save btn standard size-default" type="button" onclick={save} disabled={!canSubmit}>
		{t.translate('account.professionalField.save')}
	</button>
</div>
