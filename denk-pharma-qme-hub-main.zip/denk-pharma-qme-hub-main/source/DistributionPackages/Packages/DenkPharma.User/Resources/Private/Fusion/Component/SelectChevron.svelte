<!--
	`.custom-select select` sets `appearance: none`, so the native arrow is gone and the markup has
	to supply one. Render this as a direct sibling of the `<select>`: the design system colours
	`select + .form--icon` per state, which `currentColor` picks up.
-->
<div class="form--icon">
	<span class="svg-icon svg-stroke size-small" aria-hidden="true">
		<svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M16.25 7.5L10 13.75L3.75 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
		</svg>
	</span>
</div>
