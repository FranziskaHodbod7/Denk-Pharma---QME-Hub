<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import './Onboarding.scss'
	import ToggleSwitch from './ToggleSwitch.svelte'

	interface Config {
		redirectUrl: string
		endpoint: string
		subscribed: boolean
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))

	let subscribed = $state<boolean>(untrack(() => config.subscribed))
	let loading = $state(false)
	let error = $state(false)

	// The step completes whichever way the toggle stands: the visitor has answered the question.
	async function submit() {
		if (loading) return
		loading = true
		error = false

		try {
			const response = await fetch(config.endpoint, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
				credentials: 'same-origin',
				body: JSON.stringify({ subscribed }),
			})
			const data = await response.json().catch(() => null)
			if (!response.ok || !data?.success) {
				error = true
				return
			}
			window.location.href = config.redirectUrl
		} catch {
			error = true
		} finally {
			loading = false
		}
	}
</script>

<section class="onboarding-app section spacing-medium width-small light-grey light">
	<div class="container">
		<div class="onboarding-app__content">
			<div class="onboarding-app__step">
				<h2 class="onboarding-app__step-title heading-3">{t.translate('onboarding.step.newsletter.title')}</h2>
				<div class="text-wrapper">
					<p class="onboarding-app__step-description default-text">{t.translate('onboarding.step.newsletter.description')}</p>
				</div>
				<ToggleSwitch label={t.translate('onboarding.step.newsletter.optIn')} bind:checked={subscribed} />
			</div>

			{#if error}
				<p class="onboarding-app__error">{t.translate('onboarding.error')}</p>
			{/if}
		</div>

		<div class="onboarding-app__actions">
			<button class="onboarding-app__btn onboarding-app__btn--primary" type="button" onclick={submit} disabled={loading}>
				{loading ? '…' : t.translate('onboarding.action.finish')}
			</button>
		</div>
	</div>
</section>
