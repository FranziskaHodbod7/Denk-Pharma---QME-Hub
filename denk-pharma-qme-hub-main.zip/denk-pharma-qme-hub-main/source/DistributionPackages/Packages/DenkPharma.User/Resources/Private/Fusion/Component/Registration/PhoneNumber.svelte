<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import PhoneCodeSelect from '../PhoneCodeSelect.svelte'
	import PhoneNumberInput from '../PhoneNumberInput.svelte'
	import { mayContainDuplicateDialCode, maxLocalNumberLength, phoneErrorTranslationKey, phoneNumberError, phoneValueKey, type DialCode } from '../phone'
	import './PhoneNumber.scss'

	interface Config {
		dialCodeName: string
		dialCodeValue: string
		dialCodeId: string
		dialCodeLabel: string
		phoneNumberName: string
		phoneNumberValue: string
		phoneNumberId: string
		phoneNumberLabel: string
		phoneNumberPlaceholder: string
		duplicatePrefixWarning: string
		hasServerError: boolean
		serverError: string | null
		options: DialCode[]
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))

	let dialCode = $state(untrack(() => config.dialCodeValue || config.options[0]?.value || ''))
	let localNumber = $state(untrack(() => config.phoneNumberValue))

	// The widget owns the message. The server judged one exact pair of values, so its message
	// stands until the visitor changes either part of the number; the check in the browser takes
	// over from there.
	const rejectedValue = untrack(() => (config.hasServerError ? phoneValueKey(config.dialCodeValue, config.phoneNumberValue) : null))
	const showsServerError = $derived(rejectedValue !== null && phoneValueKey(dialCode, localNumber) === rejectedValue)

	const maxLength = $derived(maxLocalNumberLength(dialCode, config.options))
	const mayDuplicateDialCode = $derived(mayContainDuplicateDialCode(dialCode, localNumber))

	// Show no message for an empty input: the field must not report an error before the user types.
	// The server repeats every check, so the message from the browser is guidance, not the decision.
	const message = $derived.by(() => {
		if (showsServerError) return config.serverError
		if (localNumber === '') return null
		const code = phoneNumberError(dialCode, localNumber, config.options)
		return code === null ? null : t.translate(phoneErrorTranslationKey(code))
	})
</script>

<div class="registration-phone">
	<div class="registration-phone__controls">
		<div class="form--group registration-phone__code">
			<label class="form--label" for={config.dialCodeId}>{config.dialCodeLabel}</label>
			<PhoneCodeSelect id={config.dialCodeId} name={config.dialCodeName} bind:value={dialCode} options={config.options} ariaLabel={config.dialCodeLabel} />
		</div>
		<div class="form--group registration-phone__number">
			<label class="form--label" for={config.phoneNumberId}>{config.phoneNumberLabel}</label>
			<PhoneNumberInput
				id={config.phoneNumberId}
				name={config.phoneNumberName}
				bind:value={localNumber}
				maxlength={maxLength}
				ariaLabel={config.phoneNumberLabel}
				placeholder={config.phoneNumberPlaceholder}
			/>
		</div>
	</div>

	{#if message}
		<p class="help-inline">{message}</p>
	{/if}
	{#if mayDuplicateDialCode}
		<p class="help-inline help-inline--warning">{config.duplicatePrefixWarning}</p>
	{/if}
</div>
