import { mount, unmount } from "svelte"
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager"
import PhoneNumberApp from "./PhoneNumber.svelte"

export default class RegistrationPhoneNumberManager extends AbstractComponentManager {
    protected app: ReturnType<typeof mount> | null = null

    initialize(domSection: HTMLElement) {
        const el = domSection.querySelector<HTMLElement>('[data-registration-phone]')
        if (!el) return

        if (this.app) {
            unmount(this.app)
            this.app = null
        }

        this.app = mount(PhoneNumberApp, {
            target: el,
            props: {
                config: JSON.parse(el.dataset.config ?? '{}'),
                translations: JSON.parse(el.dataset.translations ?? '{}'),
            },
        })
    }
}
