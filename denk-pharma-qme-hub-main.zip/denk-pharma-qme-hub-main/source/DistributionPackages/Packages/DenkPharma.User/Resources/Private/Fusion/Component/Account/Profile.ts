import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager'
import { mountAccountApp } from './mountAccountApp'
import ProfileApp from './Profile.svelte'

export default class ProfileManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		mountAccountApp(domSection, 'profile', ProfileApp)
	}
}
