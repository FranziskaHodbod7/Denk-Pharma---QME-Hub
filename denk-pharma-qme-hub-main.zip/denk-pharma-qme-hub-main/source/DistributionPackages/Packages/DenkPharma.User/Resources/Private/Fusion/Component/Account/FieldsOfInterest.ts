import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager'
import { mountAccountApp } from './mountAccountApp'
import FieldsOfInterestApp from './FieldsOfInterest.svelte'

export default class FieldsOfInterestManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		mountAccountApp(domSection, 'fieldsOfInterest', FieldsOfInterestApp)
	}
}
