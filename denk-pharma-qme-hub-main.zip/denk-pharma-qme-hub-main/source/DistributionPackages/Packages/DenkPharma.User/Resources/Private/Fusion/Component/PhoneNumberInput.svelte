<script lang="ts">
	let {
		id,
		value = $bindable(),
		ariaLabel,
		maxlength,
		name,
		placeholder,
	}: {
		id: string
		value: string
		ariaLabel?: string
		maxlength?: number
		/** Set only inside a posted form; the account screens send their value as JSON. */
		name?: string
		placeholder?: string
	} = $props()

	function handleInput(event: Event & { currentTarget: HTMLInputElement }) {
		let digitsOnly = event.currentTarget.value.replace(/[^0-9]/g, '')
		if (maxlength !== undefined) digitsOnly = digitsOnly.slice(0, maxlength)
		// Force the DOM value directly so a rejected character disappears even when the sanitised
		// result equals the previous state — a case Svelte's diffing would otherwise skip.
		event.currentTarget.value = digitsOnly
		value = digitsOnly
	}
</script>

<div class="input">
	<input {id} {name} class="input-input" type="tel" inputmode="numeric" autocomplete="tel-national" aria-label={ariaLabel} {value} {maxlength} {placeholder} oninput={handleInput} />
</div>
