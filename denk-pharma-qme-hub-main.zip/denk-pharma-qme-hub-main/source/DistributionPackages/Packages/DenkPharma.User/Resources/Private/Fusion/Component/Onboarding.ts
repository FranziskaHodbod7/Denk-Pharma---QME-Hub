import { mount, unmount } from "svelte"
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager"
import OnboardingApp from "./Onboarding.svelte"

export default class OnboardingManager extends AbstractComponentManager {
    protected app: ReturnType<typeof mount> | null = null

    initialize(domSection: HTMLElement) {
        const el = domSection.querySelector<HTMLElement>('[data-onboarding-app]')
        if (!el) return

        if (this.app) {
            unmount(this.app)
            this.app = null
        }

        this.app = mount(OnboardingApp, {
            target: el,
            props: {
                config: JSON.parse(el.dataset.config ?? '{}'),
                translations: JSON.parse(el.dataset.translations ?? '{}'),
            },
        })
    }
}
