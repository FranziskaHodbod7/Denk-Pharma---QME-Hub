<script lang="ts">
	import './IconCard.scss'

	interface Props {
		title: string
		description?: string
		icon?: string | null
		withIconBackground?: boolean
	}

	let { title, description, icon, withIconBackground = false }: Props = $props()
</script>

<div class="icon-card">
	{#if icon}
		<div class="icon-card__icon" class:icon-card__icon--with-bg={withIconBackground} aria-hidden="true">
			{@html icon}
		</div>
	{/if}
	<div class="icon-card__body">
		<h6 class="icon-card__title">{title}</h6>
		{#if description}
			<p class="icon-card__description">{description}</p>
		{/if}
	</div>
</div>