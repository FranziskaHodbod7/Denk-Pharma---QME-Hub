<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import { postAccount, notifySaveResult } from './accountApi'
	import ToggleSwitch from '../ToggleSwitch.svelte'
	import './Notification.scss'

	interface Config {
		endpoint: string
		subscribed: boolean
		whatsAppConsent: boolean
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))

	let subscribed = $state<boolean>(untrack(() => config.subscribed))
	let whatsAppConsent = $state<boolean>(untrack(() => config.whatsAppConsent))
	let loading = $state(false)

	async function save() {
		if (loading) return
		loading = true
		notifySaveResult(await postAccount(config.endpoint, { subscribed, whatsAppConsent }), t)
		loading = false
	}
</script>

<div class="account-newsletter">
	<ToggleSwitch label={t.translate('account.newsletter.optIn')} bind:checked={subscribed} />
	<ToggleSwitch label={t.translate('account.newsletter.whatsAppOptIn')} bind:checked={whatsAppConsent} />

	<button class="account-newsletter__save btn standard size-default" type="button" onclick={save} disabled={loading}>
		{t.translate('account.newsletter.save')}
	</button>
</div>
