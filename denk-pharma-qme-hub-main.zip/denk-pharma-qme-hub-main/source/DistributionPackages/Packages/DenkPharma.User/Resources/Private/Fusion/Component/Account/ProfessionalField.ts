import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager'
import { mountAccountApp } from './mountAccountApp'
import ProfessionalFieldApp from './ProfessionalField.svelte'

export default class ProfessionalFieldManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		mountAccountApp(domSection, 'professionalField', ProfessionalFieldApp)
	}
}
