/**
 * The validation errors for each field. The account endpoint and the onboarding endpoint return
 * them with status 422, in this form:
 * `{ success: false, errors: { phoneNumber: ['length'] } }`
 *
 * Each value is an error code, not a message. The server sends no English text, so the page
 * translates each code.
 */
export type FieldErrors = Record<string, string[]>

/**
 * Reads the `errors` map from a response body. This function ignores every value that has the
 * wrong form.
 *
 * The body is data, not trusted input. A proxy error page or an old endpoint can send any value.
 * A map with the wrong form must give an empty result. This function must not throw an error,
 * because the page renders the result.
 */
export function parseFieldErrors(body: unknown): FieldErrors {
	if (typeof body !== 'object' || body === null) return {}

	const errors = (body as { errors?: unknown }).errors
	if (typeof errors !== 'object' || errors === null || Array.isArray(errors)) return {}

	const parsed: FieldErrors = {}
	for (const [field, codes] of Object.entries(errors as Record<string, unknown>)) {
		if (Array.isArray(codes)) {
			const strings = codes.filter((code): code is string => typeof code === 'string')
			if (strings.length > 0) parsed[field] = strings
		}
	}

	return parsed
}

/** Returns the first code for one field, or null if the field has no code. */
export function firstErrorCode(errors: FieldErrors, field: string): string | null {
	return errors[field]?.[0] ?? null
}

/**
 * Returns true if the form shows a message beside the input for every field in `errors`.
 *
 * A false result means that one error has no message beside an input. The caller must then show
 * its general error message, because no message on the form explains the failure.
 */
export function allErrorsShownInline(errors: FieldErrors, inlineFields: string[]): boolean {
	const fields = Object.keys(errors)
	return fields.length > 0 && fields.every((field) => inlineFields.includes(field))
}
