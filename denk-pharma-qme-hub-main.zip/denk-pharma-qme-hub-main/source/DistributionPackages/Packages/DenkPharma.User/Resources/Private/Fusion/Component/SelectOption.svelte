<script lang="ts">
	import './SelectOption.scss'

	interface Props {
		type?: 'radio' | 'checkbox'
		label: string
		value?: string
		name?: string
		icon?: string | null
		group?: string | null
		checked?: boolean
		/** Gray base instead of white, for use on white surfaces (e.g. account cards). */
		onWhite?: boolean
		onchange?: () => void
	}

	let {
		type = 'checkbox',
		label,
		value,
		name,
		icon,
		group = $bindable(undefined),
		checked = $bindable(undefined),
		onWhite = false,
		onchange,
	}: Props = $props()
</script>

<label class="select-option" class:select-option--on-white={onWhite}>
	{#if type === 'radio'}
		<input type="radio" {name} {value} bind:group />
	{:else}
		<input type="checkbox" bind:checked {onchange} />
	{/if}
	{#if icon}
		<span class="select-option__icon" aria-hidden="true">
			{@html icon}
		</span>
	{/if}
	{label}
</label>
