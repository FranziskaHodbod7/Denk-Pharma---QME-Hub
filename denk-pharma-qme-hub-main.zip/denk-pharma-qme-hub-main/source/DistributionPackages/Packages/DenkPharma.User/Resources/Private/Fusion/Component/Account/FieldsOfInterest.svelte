<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import { postAccount, notifySaveResult } from './accountApi'
	import SelectOption from '../SelectOption.svelte'
	import './FieldsOfInterest.scss'

	interface Option {
		id: string
		nodeName: string
		label: string
		icon?: string | null
	}

	interface Config {
		endpoint: string
		options: Option[]
		selected: string[]
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))

	let selected = $state<string[]>(untrack(() => [...config.selected]))
	let loading = $state(false)

	function toggle(id: string) {
		selected = selected.includes(id) ? selected.filter((v) => v !== id) : [...selected, id]
	}

	function clear() {
		selected = []
	}

	async function save() {
		if (loading) return
		loading = true
		const result = await postAccount(config.endpoint, { fieldsOfInterest: selected })
		notifySaveResult(result, t)
		if (result.ok) {
			const nodeNames = selected
				.map((id) => config.options.find((o) => o.id === id)?.nodeName ?? '')
				.filter(Boolean)
			try {
				localStorage.setItem('dp_foi', JSON.stringify(nodeNames))
			} catch {
				// localStorage unavailable (e.g. private browsing with storage blocked)
			}
		}
		loading = false
	}
</script>

<div class="account-fields-of-interest">
	<div class="account-fields-of-interest__options three-grid">
		{#each config.options as option}
			<SelectOption
				value={option.id}
				label={option.label}
				icon={option.icon}
				onWhite
				checked={selected.includes(option.id)}
				onchange={() => toggle(option.id)}
			/>
		{/each}
		<SelectOption
			label={t.translate('account.fieldsOfInterest.dontKnow')}
			onWhite
			checked={selected.length === 0}
			onchange={clear}
		/>
	</div>

	<button class="account-fields-of-interest__save btn standard size-default" type="button" onclick={save} disabled={loading}>
		{t.translate('account.fieldsOfInterest.save')}
	</button>
</div>
