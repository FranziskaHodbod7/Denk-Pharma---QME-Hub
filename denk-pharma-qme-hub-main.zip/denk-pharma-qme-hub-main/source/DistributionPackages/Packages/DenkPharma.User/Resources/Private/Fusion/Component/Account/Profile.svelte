<script lang="ts">
	import { untrack } from 'svelte'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import { postAccount, notifySaveResult } from './accountApi'
	import { isValidPhoneNumber, mayContainDuplicateDialCode, maxLocalNumberLength, phoneErrorTranslationKey, phoneNumberError, phoneValueKey, type DialCode, type PhoneServerVerdict } from '../phone'
	import { allErrorsShownInline, firstErrorCode } from '../fieldErrors'
	import PhoneCodeSelect from '../PhoneCodeSelect.svelte'
	import SelectChevron from '../SelectChevron.svelte'
	import PhoneNumberInput from '../PhoneNumberInput.svelte'
	import './Profile.scss'

	interface Values {
		title: string
		firstName: string
		lastName: string
		email: string
		city: string
		country: string
		phoneDialCode: string
		phoneNumber: string
	}

	interface Option {
		label: string
		value: string
	}

	interface Config {
		endpoint: string
		values: Values
		titles: Option[]
		countries: Option[]
		dialCodes: DialCode[]
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))
	const uid = crypto.randomUUID()

	let title = $state(untrack(() => config.values.title))
	let firstName = $state(untrack(() => config.values.firstName))
	let lastName = $state(untrack(() => config.values.lastName))
	let city = $state(untrack(() => config.values.city))
	let country = $state(untrack(() => config.values.country))
	let loading = $state(false)

	let phoneDialCode = $state(untrack(() => config.values.phoneDialCode))
	let phoneLocalNumber = $state(untrack(() => config.values.phoneNumber))

	const phoneValid = $derived(isValidPhoneNumber(phoneDialCode, phoneLocalNumber, config.dialCodes))
	const phoneMaxLength = $derived(maxLocalNumberLength(phoneDialCode, config.dialCodes))
	const phoneMayDuplicateDialCode = $derived(mayContainDuplicateDialCode(phoneDialCode, phoneLocalNumber))

	/** The fields for which this form shows a message beside the input, not a flash message. */
	const INLINE_ERROR_FIELDS = ['dialCode', 'phoneNumber']

	// The result from the server for the last save. This state is separate from the check in the
	// browser, because only the server can decide if a number is real for its dial code.
	let phoneVerdict = $state<PhoneServerVerdict | null>(null)
	const phoneValue = $derived(phoneValueKey(phoneDialCode, phoneLocalNumber))

	const phoneErrorKey = $derived.by(() => {
		if (phoneVerdict !== null && phoneVerdict.forValue === phoneValue) {
			return phoneErrorTranslationKey(phoneVerdict.code)
		}

		// Show no message for an empty input. The field must not show an error before the user
		// types a number.
		if (phoneLocalNumber === '') return null

		const code = phoneNumberError(phoneDialCode, phoneLocalNumber, config.dialCodes)
		return code === null ? null : phoneErrorTranslationKey(code)
	})

	const canSubmit = $derived(
		firstName.trim() !== '' &&
			lastName.trim() !== '' &&
			country.trim() !== '' &&
			phoneValid &&
			!loading
	)

	async function save() {
		if (!canSubmit) return
		loading = true

		const result = await postAccount(config.endpoint, {
			title,
			firstName,
			lastName,
			city,
			country,
			dialCode: phoneDialCode,
			phoneNumber: phoneLocalNumber,
		})

		const code = firstErrorCode(result.fieldErrors, 'phoneNumber') ?? firstErrorCode(result.fieldErrors, 'dialCode')
		phoneVerdict = code === null ? null : { forValue: phoneValue, code }
		notifySaveResult(result, t, allErrorsShownInline(result.fieldErrors, INLINE_ERROR_FIELDS))

		loading = false
	}
</script>

<div class="account-profile">
	<div class="account-profile__fields">
		<div class="form--group account-profile__field--third">
			<label class="form--label" for="{uid}-title">{t.translate('account.profile.title')}</label>
			<div class="custom-select">
				<select id="{uid}-title" class="select-input" bind:value={title}>
					{#each config.titles as option (option.value)}
						<option value={option.value}>{option.label}</option>
					{/each}
				</select>
				<SelectChevron />
			</div>
		</div>

		<div class="form--group account-profile__field--third">
			<label class="form--label" for="{uid}-firstName">{t.translate('account.profile.firstName')} *</label>
			<div class="input">
				<input id="{uid}-firstName" class="input-input" type="text" autocomplete="given-name" bind:value={firstName} />
			</div>
		</div>

		<div class="form--group account-profile__field--third">
			<label class="form--label" for="{uid}-lastName">{t.translate('account.profile.lastName')} *</label>
			<div class="input">
				<input id="{uid}-lastName" class="input-input" type="text" autocomplete="family-name" bind:value={lastName} />
			</div>
		</div>

		<div class="form--group account-profile__field--full">
			<label class="form--label" for="{uid}-email">{t.translate('account.profile.email')} *</label>
			<div class="input">
				<input id="{uid}-email" class="input-input" type="email" value={config.values.email} readonly />
			</div>
		</div>

		<div class="form--group">
			<label class="form--label" for="{uid}-city">{t.translate('account.profile.city')}</label>
			<div class="input">
				<input id="{uid}-city" class="input-input" type="text" autocomplete="address-level2" bind:value={city} />
			</div>
		</div>

		<div class="form--group">
			<label class="form--label" for="{uid}-country">{t.translate('account.profile.country')} *</label>
			<div class="custom-select">
				<select id="{uid}-country" class="select-input" bind:value={country} required>
					{#each config.countries as option (option.value)}
						<option value={option.value}>{option.label}</option>
					{/each}
				</select>
				<SelectChevron />
			</div>
		</div>

		<div class="form--group account-profile__field--full account-profile__phone">
			<label class="form--label" for="{uid}-phoneCode">{t.translate('account.profile.phone')} *</label>
			<div class="account-profile__phone-controls">
				<div class="account-profile__phone-code">
					<PhoneCodeSelect id="{uid}-phoneCode" bind:value={phoneDialCode} options={config.dialCodes} ariaLabel={t.translate('account.profile.phoneDialCode')} />
				</div>
				<div class="account-profile__phone-number">
					<PhoneNumberInput id="{uid}-phoneNumber" bind:value={phoneLocalNumber} ariaLabel={t.translate('account.profile.phoneNumber')} maxlength={phoneMaxLength} />
				</div>
			</div>
			{#if phoneErrorKey}
				<p class="help-inline">{t.translate(phoneErrorKey)}</p>
			{/if}
			{#if phoneMayDuplicateDialCode}
				<p class="help-inline help-inline--warning">{t.translate('account.profile.phoneDuplicatePrefixWarning')}</p>
			{/if}
		</div>
	</div>

	<div class="text-wrapper extra-small-text">
		<p>
			{t.translate('account.profile.requiredFields')}
		</p>
	</div>

	<button class="account-profile__save btn standard size-default" type="button" onclick={save} disabled={!canSubmit}>
		{t.translate('account.profile.save')}
	</button>
</div>
