<script lang="ts">
	import './ToggleSwitch.scss'

	interface Props {
		label?: string
		checked?: boolean
		disabled?: boolean
		onchange?: () => void
	}

	let { label, checked = $bindable(false), disabled = false, onchange }: Props = $props()
</script>

<label class="toggle-switch" class:toggle-switch--disabled={disabled}>
	<input type="checkbox" bind:checked {disabled} {onchange} />
	<span class="toggle-switch__track" aria-hidden="true">
		<span class="toggle-switch__knob"></span>
	</span>
	{#if label}
		<span class="toggle-switch__label">{label}</span>
	{/if}
</label>