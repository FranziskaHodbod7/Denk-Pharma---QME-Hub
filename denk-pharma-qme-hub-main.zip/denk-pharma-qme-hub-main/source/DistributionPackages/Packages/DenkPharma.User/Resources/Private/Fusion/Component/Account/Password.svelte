<script lang="ts">
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import { postAccount, notifySaveResult } from './accountApi'
	import './Password.scss'

	interface Config {
		endpoint: string
	}

	let { config, translations }: { config: Config; translations: Translations } = $props()

	const t = $derived(new TranslationService(translations))
	const uid = crypto.randomUUID()

	let current = $state('')
	let newPassword = $state('')
	let repeat = $state('')
	let showCurrent = $state(false)
	let showNew = $state(false)
	let showRepeat = $state(false)
	let loading = $state(false)

	const canSubmit = $derived(current !== '' && newPassword !== '' && repeat !== '' && !loading)

	async function save() {
		if (!canSubmit) return
		loading = true
		const result = await postAccount(config.endpoint, { current, new: newPassword, repeat })
		notifySaveResult(result, t)
		if (result.ok) {
			current = ''
			newPassword = ''
			repeat = ''
		}
		loading = false
	}
</script>

{#snippet eyeIcon(shown: boolean)}
	{#if shown}
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
			<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20C5 20 1 12 1 12a18.45 18.45 0 0 1 5.06-5.94" />
			<path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
			<path d="m1 1 22 22" />
			<path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" />
		</svg>
	{:else}
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
			<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
			<circle cx="12" cy="12" r="3" />
		</svg>
	{/if}
{/snippet}

<div class="account-password">
	<div class="form--group">
		<label class="form--label" for="{uid}-current">{t.translate('account.password.current')}</label>
		<div class="input input--with-icon icon-right">
			<input id="{uid}-current" class="input-input" type={showCurrent ? 'text' : 'password'} autocomplete="current-password" bind:value={current} />
			<button
				type="button"
				class="account-password__toggle"
				aria-label={showCurrent ? t.translate('account.password.hide') : t.translate('account.password.show')}
				onclick={() => (showCurrent = !showCurrent)}
			>
				{@render eyeIcon(showCurrent)}
			</button>
		</div>
	</div>

	<div class="form--group">
		<label class="form--label" for="{uid}-new">{t.translate('account.password.new')}</label>
		<div class="input input--with-icon icon-right">
			<input id="{uid}-new" class="input-input" type={showNew ? 'text' : 'password'} autocomplete="new-password" bind:value={newPassword} />
			<button
				type="button"
				class="account-password__toggle"
				aria-label={showNew ? t.translate('account.password.hide') : t.translate('account.password.show')}
				onclick={() => (showNew = !showNew)}
			>
				{@render eyeIcon(showNew)}
			</button>
		</div>
		<p class="account-password__hint">{t.translate('account.password.hint')}</p>
	</div>

	<div class="form--group">
		<label class="form--label" for="{uid}-repeat">{t.translate('account.password.repeat')}</label>
		<div class="input input--with-icon icon-right">
			<input id="{uid}-repeat" class="input-input" type={showRepeat ? 'text' : 'password'} autocomplete="new-password" bind:value={repeat} />
			<button
				type="button"
				class="account-password__toggle"
				aria-label={showRepeat ? t.translate('account.password.hide') : t.translate('account.password.show')}
				onclick={() => (showRepeat = !showRepeat)}
			>
				{@render eyeIcon(showRepeat)}
			</button>
		</div>
	</div>

	<button class="account-password__save btn standard size-default" type="button" onclick={save} disabled={!canSubmit}>
		{t.translate('account.password.save')}
	</button>
</div>
