import { mount, unmount } from "svelte"
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager"
import FieldsOfInterestApp from "./FieldsOfInterest.svelte"

export default class RegistrationFieldsOfInterestManager extends AbstractComponentManager {
    protected app: ReturnType<typeof mount> | null = null

    initialize(domSection: HTMLElement) {
        const el = domSection.querySelector<HTMLElement>('[data-registration-foi]')
        if (!el) return

        if (this.app) {
            unmount(this.app)
            this.app = null
        }

        this.app = mount(FieldsOfInterestApp, {
            target: el,
            props: { config: JSON.parse(el.dataset.config ?? '{}') },
        })
    }
}
