export interface DialCode {
	label: string
	value: string
	/**
	 * The digit limits for the local number of this dial code. PhoneNumberService takes
	 * libphonenumber's lengths for the region, then reduces them to the values that the
	 * 7-to-15 total-digit rule permits.
	 */
	minLength: number
	maxLength: number
}

const digitsOf = (value: string): string => value.replace(/\D/g, '')

export function findDialCode(options: DialCode[], dialCode: string): DialCode | undefined {
	return options.find((option) => option.value === dialCode)
}

/**
 * The error codes that PhoneNumberService returns. The browser and the server both use these
 * codes, so one translation serves the check in the browser and the check on the server.
 */
export type PhoneErrorCode = 'required' | 'digitsOnly' | 'length' | 'invalid' | 'unknownDialCode'

const PHONE_ERROR_KEYS: Record<PhoneErrorCode, string> = {
	required: 'phone.error.required',
	digitsOnly: 'phone.error.digitsOnly',
	length: 'phone.error.length',
	invalid: 'phone.error.invalid',
	unknownDialCode: 'phone.error.unknownDialCode',
}

/**
 * Returns the translation key for one code. The browser or the server can produce the code.
 *
 * An unknown code gives the general message. The page therefore never shows a raw key, and the
 * server can add a new code before this file knows about that code.
 */
export function phoneErrorTranslationKey(code: string): string {
	return PHONE_ERROR_KEYS[code as PhoneErrorCode] ?? PHONE_ERROR_KEYS.invalid
}

/**
 * One result from the server, together with the number that the server tested.
 *
 * The two values stay together to stop an old error message. If the user changes either part of
 * the number, `forValue` no longer matches the new number, and the result no longer applies. No
 * code has to reset the result.
 */
export interface PhoneServerVerdict {
	forValue: string
	code: string
}

/** Returns one string for a dial code and a local number, to compare with `forValue`. */
export function phoneValueKey(dialCode: string, localNumber: string): string {
	return `${dialCode} ${localNumber}`
}

/**
 * Applies the acceptance criteria that PhoneNumberService applies: digits only, and a total digit
 * count inside the limits. The limits of the selected dial code hold that count.
 *
 * This function does not reject a leading zero. The criteria apply to the stored number, and only
 * libphonenumber knows what happens to the zero. libphonenumber removes a trunk prefix, so
 * "+49 0563123456" becomes "+49 563123456". libphonenumber keeps a zero that belongs to the
 * national number, so "+39 0212345678" stays complete. This function therefore accepts two
 * lengths for a local number that starts with a zero: the length with the zero, and the length
 * without it. The server then decides which length applies.
 *
 * This function never returns 'invalid'. Only libphonenumber can decide if a number is real for a
 * dial code, and libphonenumber runs on the server. To make that decision here, the browser must
 * load the complete metadata set.
 */
export function phoneNumberError(dialCode: string, localNumber: string, options: DialCode[]): PhoneErrorCode | null {
	if (dialCode === '') return 'unknownDialCode'
	if (localNumber === '') return 'required'
	if (digitsOf(localNumber) !== localNumber) return 'digitsOnly'

	const selected = findDialCode(options, dialCode)
	if (selected === undefined) return 'unknownDialCode'

	const plausibleLengths = localNumber.startsWith('0')
		? [localNumber.length, localNumber.length - 1]
		: [localNumber.length]

	if (!plausibleLengths.some((length) => length >= selected.minLength && length <= selected.maxLength)) {
		return 'length'
	}

	return null
}

export function isValidPhoneNumber(dialCode: string, localNumber: string, options: DialCode[]): boolean {
	return phoneNumberError(dialCode, localNumber, options) === null
}

/**
 * Returns the number of digits that the input accepts for the selected dial code. The result is
 * one digit more than the stored number permits. The extra digit gives space for a trunk prefix,
 * which the server removes.
 *
 * The input must not cut a digit from a number while the user types, because the user does not see
 * that change. The server applies the true limit, because only the server knows the length of the
 * stored number.
 */
export function maxLocalNumberLength(dialCode: string, options: DialCode[]): number {
	const selected = findDialCode(options, dialCode)
	return selected === undefined ? 15 : selected.maxLength + 1
}

/**
 * Returns true if the local number starts with the digits of the selected dial code. The user
 * often types the dial code a second time, but some real local numbers also start with those
 * digits.
 *
 * The form shows a warning only. No code removes these digits, because a removal can change a
 * correct number, and the user does not see that change.
 */
export function mayContainDuplicateDialCode(dialCode: string, localNumber: string): boolean {
	const dialDigits = digitsOf(dialCode)
	return dialDigits !== '' && localNumber.startsWith(dialDigits)
}
