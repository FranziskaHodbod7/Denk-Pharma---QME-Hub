import { mount, type Component } from 'svelte'
import './section.scss'

/**
 * Mounts an account-section Svelte app onto every matching `[data-account-app="<appType>"]`
 * within the given DOM scope, reading its config from the inert application/json script
 * referenced by `data-config-id`. Guards against double-mounting the same element.
 */
export function mountAccountApp(
	domSection: Document | HTMLElement,
	appType: string,
	App: Component<any>,
): void {
	const mounts = domSection.querySelectorAll<HTMLElement>(`[data-account-app="${appType}"]`)
	for (const el of mounts) {
		if (el.dataset.mounted) continue

		const configId = el.dataset.configId
		const scriptEl = configId ? document.getElementById(configId) : null
		if (!scriptEl) continue

		const payload = JSON.parse(scriptEl.textContent ?? '{}')
		el.dataset.mounted = 'true'
		mount(App, {
			target: el,
			props: { config: payload.config ?? {}, translations: payload.translations ?? {} },
		})
	}
}
