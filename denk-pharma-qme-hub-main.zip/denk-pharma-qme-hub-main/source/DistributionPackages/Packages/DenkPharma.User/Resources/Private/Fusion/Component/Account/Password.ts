import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager'
import { mountAccountApp } from './mountAccountApp'
import PasswordApp from './Password.svelte'

export default class PasswordManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		mountAccountApp(domSection, 'password', PasswordApp)
	}
}
