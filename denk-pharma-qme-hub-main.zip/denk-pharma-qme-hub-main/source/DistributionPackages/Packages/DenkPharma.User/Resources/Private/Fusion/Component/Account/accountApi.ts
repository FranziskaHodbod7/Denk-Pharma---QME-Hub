import { Dispatcher } from '@packages/Application/FormatD.FlashMessages/Resources/Private/TypeScript/FlashMessages/dispatcher'
import type { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
import { parseFieldErrors, type FieldErrors } from '../fieldErrors'

export interface SaveResult {
	ok: boolean
	/** Server-provided message (e.g. a 422 validation reason); undefined on transport failure. */
	error?: string
	/** The error code for each field, from a 422 response. The form shows each one beside its input. */
	fieldErrors: FieldErrors
}

export async function postAccount(endpoint: string, body: unknown): Promise<SaveResult> {
	try {
		const response = await fetch(endpoint, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
			credentials: 'same-origin',
			body: JSON.stringify(body),
		})
		const data = await response.json().catch(() => null)
		if (response.ok && data?.success) {
			return { ok: true, fieldErrors: {} }
		}
		return {
			ok: false,
			error: typeof data?.error === 'string' ? data.error : undefined,
			fieldErrors: parseFieldErrors(data),
		}
	} catch {
		return { ok: false, fieldErrors: {} }
	}
}

/**
 * Shows the result of the save as a flash message.
 *
 * Set `suppressError` to true if the form already shows the reason beside an input. A message
 * beside the input tells the user more than a flash message with the same text. Two messages for
 * one field also look like two separate problems.
 */
export function notifySaveResult(result: SaveResult, t: TranslationService, suppressError = false): void {
	if (!result.ok && suppressError) return

	Dispatcher.dispatch(
		result.ok
			? { title: t.translate('account.success'), message: '', severity: 'OK' }
			: { title: result.error ?? t.translate('account.error'), message: '', severity: 'Error' },
	)
}
