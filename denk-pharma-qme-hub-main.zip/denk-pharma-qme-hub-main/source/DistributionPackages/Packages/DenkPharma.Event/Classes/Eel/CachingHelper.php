<?php

declare(strict_types=1);

namespace DenkPharma\Event\Eel;

use Neos\Eel\ProtectedContextAwareInterface;

class CachingHelper implements ProtectedContextAwareInterface
{
    /**
     * @return string[]
     */
    public function cacheRelevantNodeTypes(): array
    {
        return [
            "DenkPharma.Event:Document.Event",
			"Sitegeist.Taxonomy:Taxonomy"
        ];
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
