export interface ProviderRequest {
    baseUrl: string;
    /** Serialized NodeAddress JSON — caller assembles cr + aggregate + dimension + workspace. */
    nodeAddress: string;
}

export class EntityProvider {
    private readonly cache = new Map<string, Promise<HTMLElement | null>>();

    get(request: ProviderRequest): Promise<HTMLElement | null> {
        const cached = this.cache.get(request.nodeAddress);
        if (cached) return cached;

        const promise = this.fetch(request);
        this.cache.set(request.nodeAddress, promise);
        return promise;
    }

    private async fetch(request: ProviderRequest): Promise<HTMLElement | null> {
        const url = new URL(request.baseUrl, window.location.origin);
        url.searchParams.set('nodeAddress', request.nodeAddress);

        try {
            const response = await fetch(url.toString(), {
                method: 'GET',
                headers: { 'Accept': 'text/html' },
                credentials: 'same-origin',
            });

            if (response.status === 404) return null;
            if (!response.ok) {
                throw new Error(`EntityProvider: HTTP ${response.status}`);
            }

            const html = await response.text();
            const template = document.createElement('template');
            template.innerHTML = html.trim();
            const root = template.content.firstElementChild;
            return root instanceof HTMLElement ? root : null;
        } catch (error) {
            // Failures don't get cached, so a retry can succeed.
            this.cache.delete(request.nodeAddress);
            console.error('[EntityProvider]', error);
            return null;
        }
    }
}

export const entityProvider = new EntityProvider();
