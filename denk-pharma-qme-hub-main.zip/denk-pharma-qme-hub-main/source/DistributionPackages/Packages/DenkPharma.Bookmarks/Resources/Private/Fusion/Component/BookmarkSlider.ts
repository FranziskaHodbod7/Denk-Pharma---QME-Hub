import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
import { bookmarkStore, BookmarkKey, BookmarkState } from '../../TypeScript/BookmarkStore';

export default class BookmarkSliderComponentManager extends AbstractComponentManager {
    private storeUnsubscribe: (() => void) | null = null;

    initialize(domSection: HTMLElement) {
        this.storeUnsubscribe = bookmarkStore.subscribeAll(
            (key, state) => this.onStateChange(domSection, key, state),
        );
    }

    private onStateChange(container: HTMLElement, key: BookmarkKey, state: BookmarkState) {
        if (state.pending) return;
        if (!state.bookmarked) {
            this.removeSlide(container, key);
        }
    }

    private removeSlide(container: HTMLElement, key: BookmarkKey) {
        const slide = container.querySelector<HTMLElement>(`[data-bookmark-key="${key}"]`);
        if (!slide) return;

        const swiperSlide = slide.closest<HTMLElement>('.swiper-slide') ?? slide;
        const swiperEl = swiperSlide.closest<HTMLElement>('.swiper');
        swiperSlide.remove();

        if (swiperEl && (swiperEl as any).swiper) {
            (swiperEl as any).swiper.update();
        }

        const wrapper = container.querySelector<HTMLElement>('.bookmark-slider');
        if (!wrapper) return;

        const remaining = wrapper.querySelectorAll('[data-bookmark-key]');
        if (remaining.length === 0) {
            this.showEmptyState(wrapper);
        }
    }

    private showEmptyState(wrapper: HTMLElement) {
        const emptyText = wrapper.dataset.emptyText;
        if (!emptyText) return;

        let emptyEl = wrapper.querySelector<HTMLElement>('.bookmark-slider__empty');
        if (emptyEl) return;

        emptyEl = document.createElement('div');
        emptyEl.className = 'bookmark-slider__empty';
        emptyEl.textContent = emptyText;
        wrapper.prepend(emptyEl);
    }
}
