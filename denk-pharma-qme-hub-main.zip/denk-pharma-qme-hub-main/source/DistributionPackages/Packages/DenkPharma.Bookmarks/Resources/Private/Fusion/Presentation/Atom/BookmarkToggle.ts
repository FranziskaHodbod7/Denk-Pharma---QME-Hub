// @ts-ignore
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
import { bookmarkStore, BookmarkState } from '../../../TypeScript/BookmarkStore';
import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations';

let listLoadTriggered = false

export default class BookmarkToggleComponentManager extends AbstractComponentManager {
    // Idempotency guard against re-init calls binding the same button twice.
    private readonly bound = new WeakSet<HTMLButtonElement>()

    initialize(domSection: HTMLElement) {
        const buttons = domSection.querySelectorAll<HTMLButtonElement>('button[data-bookmark-toggle]');
        for (const button of buttons) {
            this.bindButton(button);
        }
    }

    private bindButton(button: HTMLButtonElement) {
        if (this.bound.has(button)) return;
        this.bound.add(button);

        // Read-only preview (e.g. edit mode): leave the disabled attribute alone,
        // don't subscribe to store updates, don't wire a click handler.
        if (button.dataset.bookmarkReadonly === 'true') return;

        const key = button.dataset.bookmarkKey;
        if (!key) return;

        if (!listLoadTriggered) {
            const listUri = button.dataset.bookmarkListUri
            if (listUri) {
                listLoadTriggered = true
                void bookmarkStore.loadAll(listUri)
            }
        }

        bookmarkStore.setTranslations(new TranslationService(JSON.parse(button.dataset.translations ?? '{}')));
        bookmarkStore.hydrate(key, false);
        bookmarkStore.subscribe(key, (state) => this.render(button, state));

        button.addEventListener('click', (event) => {
            event.preventDefault();
            const actionUri = button.dataset.actionUri;
            if (!actionUri) return;

            const formData = new FormData();
            formData.append('nodeAddress', button.dataset.nodeAddress ?? '');
            void bookmarkStore.request(key, actionUri, formData);
        });
    }

    private render(button: HTMLButtonElement, state: BookmarkState) {
        button.dataset.bookmarked = state.bookmarked ? 'true' : 'false';
        button.toggleAttribute('data-bookmark-pending', state.pending);
        if (state.error) {
            button.dataset.bookmarkError = state.error;
        } else {
            delete button.dataset.bookmarkError;
        }

        button.disabled = state.pending;

        // In icon-only mode the button carries an aria-label that must reflect the current state.
        if (button.hasAttribute('aria-label')) {
            const label = state.bookmarked
                ? button.dataset.labelMarked ?? ''
                : button.dataset.labelUnmarked ?? '';
            if (label) button.setAttribute('aria-label', label);
        }
    }
}
