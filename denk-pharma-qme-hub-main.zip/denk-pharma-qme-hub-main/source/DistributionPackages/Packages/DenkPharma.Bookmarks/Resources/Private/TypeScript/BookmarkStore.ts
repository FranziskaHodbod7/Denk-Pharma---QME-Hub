import { bookmarkApiClient, BookmarkApiClient, BookmarkAuthError } from './BookmarkApiClient'
import { Dispatcher } from '@packages/Application/FormatD.FlashMessages/Resources/Private/TypeScript/FlashMessages/dispatcher'
import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'

export type BookmarkKey = string; // `${contentRepositoryId}:${aggregateId}`

export type BookmarkErrorKind = 'update' | 'auth';

export interface BookmarkState {
    bookmarked: boolean;
    pending: boolean;
    error: BookmarkErrorKind | null;
}

export type BookmarkSubscriber = (state: BookmarkState) => void;
export type BookmarkGlobalSubscriber = (key: BookmarkKey, state: BookmarkState) => void;

const ERROR_TTL_MS = 2000;
const CHANNEL_NAME = 'denk-pharma-bookmarks';

interface ChannelMessage {
    key: BookmarkKey;
    bookmarked: boolean;
}

export class BookmarkStore {
    private readonly states = new Map<BookmarkKey, BookmarkState>();
    private readonly listeners = new Map<BookmarkKey, Set<BookmarkSubscriber>>();
    private readonly globalListeners = new Set<BookmarkGlobalSubscriber>();
    private readonly errorTimers = new Map<BookmarkKey, ReturnType<typeof setTimeout>>();
    private readonly channel: BroadcastChannel | null;
    private translationService: TranslationService | null = null;

    setTranslations(translationService: TranslationService): void {
        if (!this.translationService) {
            this.translationService = translationService;
        }
    }

    constructor(private readonly apiClient: BookmarkApiClient = bookmarkApiClient) {
        this.channel = typeof BroadcastChannel !== 'undefined'
            ? new BroadcastChannel(CHANNEL_NAME)
            : null;
        this.channel?.addEventListener('message', (event: MessageEvent<ChannelMessage>) => {
            this.applyExternalUpdate(event.data.key, event.data.bookmarked);
        });
    }

    hydrate(key: BookmarkKey, bookmarked: boolean): void {
        if (this.states.has(key)) return;
        this.states.set(key, { bookmarked, pending: false, error: null });
    }

    getState(key: BookmarkKey): BookmarkState | undefined {
        return this.states.get(key);
    }

    subscribe(key: BookmarkKey, listener: BookmarkSubscriber): () => void {
        let listeners = this.listeners.get(key);
        if (!listeners) {
            listeners = new Set();
            this.listeners.set(key, listeners);
        }
        listeners.add(listener);

        const current = this.states.get(key);
        if (current) listener(current);

        return () => listeners!.delete(listener);
    }

    subscribeAll(listener: BookmarkGlobalSubscriber): () => void {
        this.globalListeners.add(listener);
        return () => this.globalListeners.delete(listener);
    }

    async request(key: BookmarkKey, actionUri: string, formData: FormData): Promise<void> {
        const current = this.states.get(key);
        if (!current || current.pending) return;

        const optimistic = !current.bookmarked;

        this.cancelErrorTimer(key);
        this.update(key, { bookmarked: optimistic, pending: true, error: null });

        try {
            const result = await this.apiClient.toggle(actionUri, formData);
            const next = this.states.get(key)!;
            // Trust the server's value regardless of result.changed — covers the rare race
            // where the optimistic flip lost to another mutation.
            this.update(key, { ...next, bookmarked: result.bookmarked, pending: false });
            this.broadcast(key, result.bookmarked);
            if (result.changed) {
                Dispatcher.dispatch({
                    title: result.bookmarked
                        ? this.translationService?.translate('flashmessage.added.title', 'Bookmark added') ?? 'Bookmark added'
                        : this.translationService?.translate('flashmessage.removed.title', 'Bookmark removed') ?? 'Bookmark removed',
                    message: '',
                    severity: result.bookmarked ? 'OK' : 'Notice',
                })
            }
        } catch (error) {
            console.error('[BookmarkStore]', error);
            const errorKind: BookmarkErrorKind = error instanceof BookmarkAuthError ? 'auth' : 'update';
            const next = this.states.get(key)!;
            this.update(key, {
                ...next,
                bookmarked: current.bookmarked,
                pending: false,
                error: errorKind,
            });
            this.scheduleErrorClear(key);
            if (error instanceof BookmarkAuthError) {
                Dispatcher.dispatch({
                    title: this.translationService?.translate('flashmessage.autherror.title', 'Not logged in') ?? 'Not logged in',
                    message: this.translationService?.translate('flashmessage.autherror.message', 'Please log in to use bookmarks.') ?? 'Please log in to use bookmarks.',
                    severity: 'Warning',
                })
            } else {
                Dispatcher.dispatch({
                    title: this.translationService?.translate('flashmessage.error.title', 'Error') ?? 'Error',
                    message: this.translationService?.translate('flashmessage.error.message', 'The bookmark could not be updated.') ?? 'The bookmark could not be updated.',
                    severity: 'Error',
                })
            }
        }
    }

    async loadAll(listUri: string): Promise<void> {
        try {
            const keys = await this.apiClient.loadAll(listUri)
            for (const key of keys) {
                this.applyExternalUpdate(key, true)
            }
        } catch (error) {
            console.error('[BookmarkStore] loadAll failed:', error)
        }
    }

    applyExternalUpdate(key: BookmarkKey, bookmarked: boolean): void {
        const current = this.states.get(key);

        if (current?.pending) return;

        if (current === undefined) {
            this.update(key, { bookmarked, pending: false, error: null });
            return;
        }

        if (current.bookmarked === bookmarked && current.error === null) return;
        this.update(key, { ...current, bookmarked, error: null });
    }

    private update(key: BookmarkKey, state: BookmarkState): void {
        this.states.set(key, state);
        this.listeners.get(key)?.forEach(listener => listener(state));
        this.globalListeners.forEach(listener => listener(key, state));
    }

    private broadcast(key: BookmarkKey, bookmarked: boolean): void {
        this.channel?.postMessage({ key, bookmarked });
    }

    private scheduleErrorClear(key: BookmarkKey): void {
        const timer = setTimeout(() => {
            this.errorTimers.delete(key);
            const state = this.states.get(key);
            if (state?.error) {
                this.update(key, { ...state, error: null });
            }
        }, ERROR_TTL_MS);
        this.errorTimers.set(key, timer);
    }

    private cancelErrorTimer(key: BookmarkKey): void {
        const timer = this.errorTimers.get(key);
        if (timer !== undefined) {
            clearTimeout(timer);
            this.errorTimers.delete(key);
        }
    }
}

export const bookmarkStore = new BookmarkStore();
