// @ts-ignore
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
import { bookmarkStore, BookmarkKey, BookmarkState } from '../../TypeScript/BookmarkStore';

interface ListBinding {
    list: HTMLElement;
    knownKeys: Set<BookmarkKey>;
    countSingular: string;
    countPlural: string;
    emptyText: string;
}

export default class BookmarkListComponentManager extends AbstractComponentManager {
    private readonly bound = new WeakSet<HTMLElement>();
    private readonly bindings: ListBinding[] = [];
    private storeUnsubscribe: (() => void) | null = null;

    initialize(domSection: HTMLElement) {
        const lists = domSection.querySelectorAll<HTMLElement>('[data-bookmark-list]');
        for (const list of lists) {
            if (this.bound.has(list)) continue;
            this.bound.add(list);

            this.bindings.push(this.bindList(list));
        }

        if (this.bindings.length > 0 && !this.storeUnsubscribe) {
            this.storeUnsubscribe = bookmarkStore.subscribeAll(
                (key, state) => this.onStateChange(key, state),
            );
        }
    }

    private bindList(list: HTMLElement): ListBinding {
        const knownKeys = new Set<BookmarkKey>();
        list.querySelectorAll<HTMLElement>('[data-bookmark-key]').forEach((card) => {
            const key = card.dataset.bookmarkKey;
            if (key) knownKeys.add(key);
        });

        const countSingular = list.dataset.countSingular ?? '';
        const countPlural = list.dataset.countPlural ?? '';
        const emptyText = list.dataset.emptyText ?? '';

        return { list, knownKeys, countSingular, countPlural, emptyText };
    }

    private onStateChange(key: BookmarkKey, state: BookmarkState) {
        if (state.pending) return;

        if (!state.bookmarked) {
            for (const binding of this.bindings) {
                this.tryRemoveCard(binding, key);
            }
        }
    }

    private tryRemoveCard(binding: ListBinding, key: BookmarkKey) {
        if (!binding.knownKeys.has(key)) return;

        const card = Array.from(binding.list.querySelectorAll<HTMLElement>('[data-bookmark-key]'))
            .find(el => el.dataset.bookmarkKey === key);

        if (card) {
            (card.closest('li') ?? card).remove();
        }

        binding.knownKeys.delete(key);
        this.updateCount(binding);

        if (binding.knownKeys.size === 0) {
            this.showEmptyState(binding);
        }
    }

    private showEmptyState(binding: ListBinding) {
        if (!binding.emptyText) return;

        let emptyEl = binding.list.querySelector<HTMLElement>('.bookmark-list__empty');
        if (emptyEl) return;

        emptyEl = document.createElement('div');
        emptyEl.className = 'bookmark-list__empty bookmark-list__empty--animate';
        emptyEl.textContent = binding.emptyText;
        binding.list.appendChild(emptyEl);
    }

    private updateCount(binding: ListBinding) {
        const countEl = binding.list.querySelector<HTMLElement>('.bookmark-list__count');
        if (!countEl) return;
        const n = binding.knownKeys.size;
        const label = n === 1 ? binding.countSingular : binding.countPlural;
        countEl.textContent = label ? `${n} ${label}` : String(n);
    }
}
