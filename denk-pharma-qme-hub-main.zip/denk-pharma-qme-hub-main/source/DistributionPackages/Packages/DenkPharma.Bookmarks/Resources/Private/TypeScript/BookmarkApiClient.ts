export interface ToggleResponse {
    changed: boolean;
    bookmarked: boolean;
}

/** Tagged error so the store can distinguish auth failures from generic update failures. */
export class BookmarkAuthError extends Error {
    constructor() {
        super('Bookmark toggle: not authorised');
        this.name = 'BookmarkAuthError';
    }
}

export class BookmarkApiClient {
    async loadAll(listUri: string): Promise<string[]> {
        const response = await fetch(listUri, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            credentials: 'same-origin',
        })

        if (!response.ok) {
            throw new Error(`Bookmark list failed: HTTP ${response.status}`)
        }

        return (await response.json() as { keys: string[] }).keys
    }

    async toggle(actionUri: string, formData: FormData): Promise<ToggleResponse> {
        const response = await fetch(actionUri, {
            method: 'POST',
            headers: { 'Accept': 'application/json' },
            body: formData,
            credentials: 'same-origin',
        });

        if (response.status === 403) {
            throw new BookmarkAuthError();
        }

        // 200 = real toggle; 422 = controller refused (not live, node missing, no party).
        if (response.status !== 200 && response.status !== 422) {
            throw new Error(`Bookmark toggle failed: HTTP ${response.status}`);
        }

        return await response.json() as ToggleResponse;
    }
}

export const bookmarkApiClient = new BookmarkApiClient();
