# DenkPharma.Bookmarks

Per-user, per-aggregate frontend bookmarks. State propagates across browser tabs and across UI elements that watch the same aggregate.

## Domain

A bookmark binds a `Party` (logged-in user) to a `(contentRepositoryId, nodeAggregateId)` pair plus a creation instant. **Storage** is dimension- and workspace-agnostic — follows the user across language/region/preview boundaries. **Reads** are dimension-bound: `BookmarkedNodeFinder` resolves through the current document's subgraph, so a user browsing in DE only sees bookmarks whose target resolves in DE.

`Bookmark`: `(party, contentRepositoryId, nodeAggregateId, createdAt)`. Unique on `(party, cr, aggregate)`. `party` cascades on user deletion.

A bookmark is removed only when its target stops being a bookmark target: the aggregate is hard-removed, or its type changes to one without the `Bookmarkable` mixin. `BookmarkCleanupCatchUpHook` handles both via the `contentGraph` projection (`NodeAggregateWasRemoved`, `NodeAggregateTypeWasChanged`); DELETEs key on `(cr, aggregate)` and are idempotent.

## Backend layers

```
BookmarkController ── toggleAction (JSON) ──── BookmarkService ─── BookmarkRepository (Doctrine)
                  └─ cardAction (HTML fragment) ── FrontendSubgraphFactory ── CR
                                                                              
                                              BookmarkedNodeFinder ── batch-resolve via CR
                                                                       (mixin-aware filter)

BookmarkCleanupCatchUpHook ── (CR projection events) ── BookmarkRepository
```

- **`BookmarkService`** — `toggle`, `isBookmarked`, `isBookmarkable`. `toggle` throws `NodeIsNotBookmarkable` on non-bookmarkable nodes.
- **`BookmarkedNodeFinder`** — read-side; resolves stored bookmarks against a CR subgraph (visibility/role-aware via `FrontendSubgraphFactory`); mixin-aware type filter.
- **`BookmarkRepository`** — Doctrine; returns `Bookmark` entities only.

## Frontend architecture

Fusion follows the project's three-tier split (see `docs/node-architecture.md`):

- **Atom** — `Resources/Private/Fusion/Presentation/Atom/BookmarkToggle.fusion` — node-agnostic, plain props in, markup out. No `@cache` block, no helpers, no Security.
- **Component** — `Resources/Private/Fusion/Component/{BookmarkToggle,BookmarkCard,BookmarkList}.fusion` — node-aware bridges. Own the cache contract, call helpers, compose the Atom. `BookmarkToggle` is **cached per node** (its markup doesn't depend on the viewing user; bookmarked state is hydrated client-side); `BookmarkCard` and `BookmarkList` are `@cache.mode = 'uncached'`.

Client-side modules live in two places:

- `Resources/Private/TypeScript/` — shared, framework-agnostic singletons:
    - **`BookmarkApiClient`** — typed wrapper over the toggle endpoint. Stateless.
    - **`BookmarkStore`** — singleton observable state, keyed `${cr}:${aggregateId}`.
    - **`EntityProvider`** — typed fetcher for server-rendered fragments addressed by `nodeAddress`, with per-tab cache and concurrent-fetch dedup.
- Beside their `.fusion` files — DOM adapters loaded by `FormatD.ComponentLoader`:
    - `Presentation/Atom/BookmarkToggle.ts` — wires toggle buttons to the store.
    - `Component/BookmarkList.ts` — subscribes to the store; uses `EntityProvider` to pull new cards.

### State

Per key: `{ bookmarked, pending, error }` where `error ∈ { 'update', 'auth', null }`. All mutations and notifications flow through one `update()` method.

- **Optimistic flip.** `request()` flips `bookmarked` immediately; reconciles to server's value on success or reverts on failure.
- **Concurrent dispatch dedup.** Second click while `pending` is a no-op.
- **Transient errors.** `error` auto-clears after a TTL; clear is cancellable on a new request.
- **Cross-tab broadcast.** Only confirmed (post-server) state changes broadcast via `BroadcastChannel`. Optimistic flips never cross tabs. Feature-detected; older browsers degrade silently.
- **Hydrate on external update.** A broadcast for a previously-unknown key hydrates the key and notifies global listeners.

### Subscription shapes

- `subscribe(key, fn)` — fires synchronously with current state, then on every change.
- `subscribeAll(fn)` — fires on any key's change.

## Wire contracts

**Toggle endpoint** — `POST /bookmark/toggle`. Form fields: `__csrfToken`, `nodeAddress`. JSON response: `{changed, bookmarked}`. 200 = real change. 422 = controller refused (not live, node missing, no party). 403 = auth → `error: 'auth'` in the store.

**Card endpoint** — `GET /bookmark/card?nodeAddress={json}`. `text/html` out, or 404. Fragment root carries `data-node-type` and `data-bookmark-key`. Rendered via `Neos\Neos\View\FusionView` evaluating the `bookmarkCard` entry path — same `BookmarkCard` prototype used for SSR. Currently uncached (`BookmarkCard` declares `@cache mode='uncached'`); making it edge-cacheable per `(cr, aggregate, mode, role-bucket)` is future work.

**Data attributes (CSS contract)** — the toggle mirrors store state onto the button:

| Attribute | Values | Set by |
|---|---|---|
| `data-bookmarked` | `"true"` / `"false"` | server (initial) + JS (state) |
| `data-bookmark-pending` | present / absent | JS (in-flight request) |
| `data-bookmark-error` | `"update"` / `"auth"` / absent | JS (last error) |
| `data-bookmark-readonly` | `"true"` / absent | server (edit-mode preview only) |

`data-bookmark-readonly` is a hard skip signal for the JS adapter: when present, `BookmarkToggle.ts` neither hydrates the store nor binds a click handler. The button is also rendered with the `disabled` HTML attribute, so the browser handles input suppression.

The atom renders both icon and label variants; CSS shows the active ones via the attribute.

## Multi-instance widgets

`BookmarkList` is the building block for "current bookmarks" UIs. Each instance:

1. Server-renders matching bookmarks (via `BookmarkedNodeFinder` + `BookmarkCard`).
2. Computes its expanded node-type set at SSR time via the `expandTypes` Eel helper (subtype expansion lives server-side; JS does exact-match against the frozen list).
3. Subscribes via `subscribeAll`; on a not-yet-rendered key going `bookmarked: true`, fetches the card via `EntityProvider` and prepends.

The bookmarks page is three of these (Products / Studies / Events).

## Caller-facing pitfalls

### `@cache.context` contract

`Component.BookmarkCard` and `Component.BookmarkList` declare `@cache.mode = 'uncached'` with `@cache.context = ['node', 'documentNode']`. Only those two context variables cross the cache boundary. **Prop expressions evaluate within the restricted context** — so this looks correct but resolves to `null` on re-eval:

```fusion
<Neos.Fusion:Loop items={...} itemName="bookmarkedNode">
    <DenkPharma.Bookmarks:Component.BookmarkCard node={bookmarkedNode}/>
    {# bookmarkedNode is not in @cache.context — the prop ends up null #}
</Neos.Fusion:Loop>
```

Bind the loop variable as `node` via `@context.node` — that *is* in the allowed list:

```fusion
<DenkPharma.Bookmarks:Component.BookmarkCard @context.node={bookmarkedNode}/>
```

`BookmarkCard` reads `${node}` from outer context rather than a typed prop because it doubles as the entry path for `CardController` (`bookmarkCard = ...` in `Root.fusion`), where `FusionView` pushes the node into context via `assign('value', $node)`. Both call sites converge on the context-driven shape. (This will be revisited when `BookmarkCard` is refactored.)

### Bookmarks in a cached list (escape hatch)

The `@context.node` pattern above only works when the iterating parent is itself uncached — the loop re-runs every request, so the override resolves freshly per iteration. When the iterating parent is `@cache.mode = 'cached'`, the pattern silently breaks: the loop runs once at write time, embedded uncached toggle stubs are stored, and on each subsequent cache hit the stubs re-render against the parent's call-site scope (the page node) rather than the loop-local. Symptom: toggles work on the first request after `cache:flush`, then degenerate on every hit after — all toggles show the same/wrong state, or vanish if the page node isn't `Bookmarkable`.

Don't fight it with more `@context` placement — there's no Fusion-level bridging that survives a cached parent. Move the cache boundary inward: the outer list goes uncached and cheap, a per-item wrapper holds the expensive rendering and is cached per-node.

```fusion
# Per-item wrapper — cached, keyed on the item's node
prototype(MyVendor:Component.SomethingCard) < prototype(Neos.Fusion:Component) {

    @cache {
        mode = 'cached'
        entryIdentifier {
            node = ${Neos.Caching.entryIdentifierForNode(node)}
            cardStyle = ${cardStyle}    # any other rendering input that varies output
        }
        entryTags {
            0 = ${Neos.Caching.nodeTag(node)}
        }
    }

    @private {
        data = MyVendor:NodeData.Something { something = ${node} }
        bookmarkToggle = DenkPharma.Bookmarks:Component.BookmarkToggle {}    # picks up node from context default
    }

    renderer = MyVendor:Molecule.SomethingCard {
        @apply.data = ${private.data}
        style = ${cardStyle}
        bookmarkToggle = ${private.bookmarkToggle}
    }
}

# Outer list — uncached, just queries + iterates
prototype(MyVendor:Component.SomethingList) < prototype(Neos.Fusion:Component) {

    @cache {
        mode = 'uncached'
        context {
            1 = 'node'
            2 = 'documentNode'
            3 = 'site'
        }
    }

    @private {
        items = ${q(site).find('[instanceof MyVendor:Document.Something]').get()}
    }

    renderer = afx`
        <Neos.Fusion:Loop items={private.items} itemName="item">
            <MyVendor:Component.SomethingCard
                @context.node={item}
                @context.cardStyle="vertical"
            />
        </Neos.Fusion:Loop>
    `
}
```

Why it works: the per-item cache invalidates correctly on its own node tags, and the `BookmarkToggle`'s uncached stub now lives inside the per-item cached HTML. When that HTML is restored on a hit, it's processed within the still-running outer iteration where `node` *is* the current item — so the stub resolves correctly. The outer list pays per-request cost equal to one CR query + N cache lookups: bounded and cheap.

When *not* to reach for this: if the parent doesn't need to be cached (already per-user, or trivially small), stick with the simpler `@context.node` pattern above and an uncached parent — no wrapper needed. In-tree precedent for the per-item cached-wrapper pattern: `DenkPharma.Study:Component.Card` (cached per node, bookmark toggle inside), looped by `DenkPharma.Study:Component.CardMenuGrid`.

### Dynamic-add and ComponentLoader

When `BookmarkList` prepends a card client-side, the new card carries its own ComponentLoader registration script. The list manager dispatches a `ComponentLoaderReloadEvent` so the loader picks up the new registration and binds the inner toggle; otherwise the form would fall back to a plain browser POST.

### No-remove rule

Toggling off doesn't remove a card from a `BookmarkList`. The card stays (un-filled icon, still visible). The list grows monotonically within a session; reload reflects current truth.

## i18n

`Resources/Private/Translations/{en,fr,es}/Main.xlf`. English is the source language; the hardcoded fallback strings in `Component.BookmarkToggle`'s `I18n.translate(...)` calls are the canonical en values. The Component resolves labels and passes already-translated strings to the Atom.

## Extension points

| Goal | Where to plug in |
|---|---|
| New error kind | Extend `BookmarkErrorKind`; map status in client + controller |
| New widget reacting to bookmark changes | New manager subscribed via `subscribeAll`; reuse `EntityProvider` |
| Service-worker push | `bookmarkStore.applyExternalUpdate(key, bookmarked)` is the seam |
| Edge/CDN integration | Card endpoint identity is per-`(cr, aggregate, mode, role)`; switch to a cached strategy by changing `BookmarkCard`'s `@cache` mode |
| New visible toggle state | New `data-bookmark-*` attribute; CSS rule keyed off it |

## What's deferred

- Tests (project convention TBD)
- Real CSRF refresh on session expiry (currently: 403 surfaces as `error: 'auth'`)
- A11y live-region announcements
- MutationObserver-based subscription cleanup (no realised leak in current usage)
