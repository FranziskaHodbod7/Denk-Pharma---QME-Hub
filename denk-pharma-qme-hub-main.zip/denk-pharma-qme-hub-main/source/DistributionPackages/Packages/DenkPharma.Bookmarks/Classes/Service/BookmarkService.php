<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Service;

use DateTimeImmutable;
use DenkPharma\Bookmarks\Domain\Exception\NodeIsNotBookmarkable;
use DenkPharma\Bookmarks\Domain\Model\Bookmark;
use DenkPharma\Bookmarks\Domain\Repository\BookmarkRepository;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\Exception\IllegalObjectTypeException;
use Neos\Party\Domain\Model\AbstractParty;

class BookmarkService
{
	#[Flow\InjectConfiguration(path: 'bookmarkableMixinType')]
	protected string $bookmarkableMixinType;

	#[Flow\Inject]
	protected BookmarkRepository $repository;

	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	#[Flow\Inject]
	protected BookmarkCacheService $bookmarkCacheService;

	public function isBookmarkable(Node $node): bool
	{
		$nodeType = $this->contentRepositoryRegistry
			->get($node->contentRepositoryId)
			->getNodeTypeManager()
			->getNodeType($node->nodeTypeName);

		return $nodeType?->isOfType($this->bookmarkableMixinType) ?? false;
	}

	public function isBookmarked(AbstractParty $party, Node $node): bool
	{
		return $this->repository->existsForPartyAndNode(
			$party,
			$node->contentRepositoryId,
			$node->aggregateId,
		);
	}

	/**
	 * Adds the bookmark if missing, removes it if present.
	 *
	 * @return bool the new state — true = bookmarked, false = removed
	 * @throws NodeIsNotBookmarkable when $node's type does not carry the bookmarkable mixin
	 * @throws IllegalObjectTypeException
	 */
	public function toggle(AbstractParty $party, Node $node): bool
	{
		$this->assertBookmarkable($node);

		$existing = $this->repository->findOneByPartyAndNode(
			$party,
			$node->contentRepositoryId,
			$node->aggregateId,
		);

		if ($existing !== null) {
			$this->repository->remove($existing);
			$this->bookmarkCacheService->flushForToggledNode($node->aggregateId->value);
			return false;
		}

		$this->repository->add(new Bookmark(
			$party,
			$node->contentRepositoryId,
			$node->aggregateId,
			new DateTimeImmutable(),
		));
		$this->bookmarkCacheService->flushForToggledNode($node->aggregateId->value);
		return true;
	}

	/**
	 * @throws NodeIsNotBookmarkable
	 */
	private function assertBookmarkable(Node $node): void
	{
		if (!$this->isBookmarkable($node)) {
			throw NodeIsNotBookmarkable::forNode($node, $this->bookmarkableMixinType);
		}
	}
}
