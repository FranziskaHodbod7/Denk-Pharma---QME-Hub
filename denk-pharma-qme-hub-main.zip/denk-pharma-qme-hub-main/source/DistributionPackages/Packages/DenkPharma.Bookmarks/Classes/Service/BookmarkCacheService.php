<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Service;

use Neos\Flow\Annotations as Flow;
use Neos\Flow\Security\Context as SecurityContext;
use Neos\Fusion\Core\Cache\ContentCache;

#[Flow\Scope('singleton')]
class BookmarkCacheService
{
    #[Flow\Inject]
    protected SecurityContext $securityContext;

    #[Flow\Inject]
    protected ContentCache $contentCache;

    public function nodeUserTag(string $nodeAggregateId): ?string
    {
        $account = $this->securityContext->getAccount();
        return $account !== null
            ? 'DenkPharma_Bookmarks_NodeUser_' . sha1($nodeAggregateId . '_' . $account->getAccountIdentifier())
            : null;
    }

    public function userTag(): ?string
    {
        $account = $this->securityContext->getAccount();
        return $account !== null
            ? 'DenkPharma_Bookmarks_User_' . sha1($account->getAccountIdentifier())
            : null;
    }

    public function flushForToggledNode(string $nodeAggregateId): void
    {
        $tag = $this->nodeUserTag($nodeAggregateId);
        if ($tag !== null) {
            $this->contentCache->flushByTag($tag);
        }
        $userTag = $this->userTag();
        if ($userTag !== null) {
            $this->contentCache->flushByTag($userTag);
        }
    }
}
