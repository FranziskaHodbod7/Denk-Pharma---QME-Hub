<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Service;

use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\ContentRepositoryRegistry\SubgraphCachingInMemory\SubgraphCachePool;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Security\Context;
use Neos\Neos\Domain\SubtreeTagging\NeosVisibilityConstraints;
use Neos\Neos\Security\Authorization\ContentRepositoryAuthorizationService;

/**
 * Returns the subgraph a node would be resolved through if the frontend rendered it
 * via Neos\Neos\Controller\Frontend\NodeController::showAction. Combines:
 *
 * - role-based visibility constraints (subtree tags the current user can't access),
 * - explicit `excludeDisabled()` (since disabled nodes never render to frontend visitors).
 *
 * Single source of truth for "what the user would see if they browsed there directly".
 *
 * @api
 */
final class FrontendSubgraphFactory
{
	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	#[Flow\Inject]
	protected ContentRepositoryAuthorizationService $contentRepositoryAuthorizationService;

	#[Flow\Inject]
	protected Context $securityContext;

	// `@internal` per its docblock — but Neos.Neos's own NodeController::showAction
	// goes through it, so the precedent is established. We accept the dependency for
	// per-request subgraph reuse and findNodeById/findNodesByIds runtime caching.
	#[Flow\Inject]
	protected SubgraphCachePool $subgraphCachePool;

	public function forNode(Node $node): ContentSubgraphInterface
	{
		return $this->build(
			$node->contentRepositoryId,
			$node->workspaceName,
			$node->dimensionSpacePoint,
		);
	}

	public function forNodeAddress(NodeAddress $address): ContentSubgraphInterface
	{
		return $this->build(
			$address->contentRepositoryId,
			$address->workspaceName,
			$address->dimensionSpacePoint,
		);
	}

	private function build(
		ContentRepositoryId $contentRepositoryId,
		WorkspaceName       $workspaceName,
		DimensionSpacePoint $dimensionSpacePoint,
	): ContentSubgraphInterface {
		$visibilityConstraints = $this->contentRepositoryAuthorizationService
			->getVisibilityConstraints($contentRepositoryId, $this->securityContext->getRoles())
			->merge(NeosVisibilityConstraints::excludeDisabled());

		return $this->subgraphCachePool->getContentSubgraph(
			$this->contentRepositoryRegistry->get($contentRepositoryId),
			$workspaceName,
			$dimensionSpacePoint,
			$visibilityConstraints,
		);
	}
}
