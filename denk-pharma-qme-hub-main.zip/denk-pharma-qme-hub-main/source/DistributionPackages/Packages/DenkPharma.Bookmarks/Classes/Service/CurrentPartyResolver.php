<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Service;

use Neos\Flow\Annotations as Flow;
use Neos\Flow\Security\Context;
use Neos\Party\Domain\Model\AbstractParty;
use Neos\Party\Domain\Service\PartyService;

#[Flow\Scope('singleton')]
final class CurrentPartyResolver
{
	#[Flow\Inject]
	protected Context $securityContext;

	#[Flow\Inject]
	protected PartyService $partyService;

	public function resolve(): ?AbstractParty
	{
		$account = $this->securityContext->getAccount();
		if ($account === null) {
			return null;
		}

		return $this->partyService->getAssignedPartyOfAccount($account);
	}
}
