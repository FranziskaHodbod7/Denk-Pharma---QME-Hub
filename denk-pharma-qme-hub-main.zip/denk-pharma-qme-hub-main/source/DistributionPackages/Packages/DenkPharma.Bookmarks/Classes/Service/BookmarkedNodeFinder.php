<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Service;

use DenkPharma\Bookmarks\Domain\Model\Bookmark;
use DenkPharma\Bookmarks\Domain\Repository\BookmarkRepository;
use Neos\ContentRepository\Core\NodeType\NodeTypeManager;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateIds;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Party\Domain\Model\AbstractParty;

class BookmarkedNodeFinder
{
	#[Flow\Inject]
	protected BookmarkRepository $repository;

	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	/**
	 * @param list<NodeTypeName> $nodeTypes  empty = no filter; otherwise nodes must be of any listed type
	 * @return list<Node>
	 */
	public function findForParty(
		AbstractParty            $party,
		ContentSubgraphInterface $subgraph,
		array                    $nodeTypes = [],
		?int                     $limit = null,
	): array
	{
		$bookmarks = $this->repository->findAllByParty($party, $subgraph->getContentRepositoryId());
		if ($bookmarks === []) {
			return [];
		}

		// findNodesByIds order is undefined; we restore createdAt order via the lookup map below.
		$resolvedNodes = $subgraph->findNodesByIds(NodeAggregateIds::fromArray(
			array_map(static fn (Bookmark $b): string => $b->getNodeAggregateId()->value, $bookmarks)
		));

		$nodesById = [];
		foreach ($resolvedNodes as $node) {
			$nodesById[$node->aggregateId->value] = $node;
		}

		$nodeTypeManager = $this->contentRepositoryRegistry
			->get($subgraph->getContentRepositoryId())
			->getNodeTypeManager();

		$result = [];
		foreach ($bookmarks as $bookmark) {
			$node = $nodesById[$bookmark->getNodeAggregateId()->value] ?? null;
			if ($node === null) {
				continue;
			}

			if ($nodeTypes !== [] && !$this->matchesAny($node, $nodeTypes, $nodeTypeManager)) {
				continue;
			}

			$result[] = $node;
			if (count($result) === $limit) {
				break;
			}
		}

		return $result;
	}

	/**
	 * @param list<NodeTypeName> $nodeTypes
	 */
	private function matchesAny(
		Node            $node,
		array           $nodeTypes,
		NodeTypeManager $nodeTypeManager,
	): bool
	{
		$nodeType = $nodeTypeManager->getNodeType($node->nodeTypeName);
		if ($nodeType === null) {
			return false;
		}

		foreach ($nodeTypes as $expected) {
			if ($nodeType->isOfType($expected->value)) {
				return true;
			}
		}
		return false;
	}
}
