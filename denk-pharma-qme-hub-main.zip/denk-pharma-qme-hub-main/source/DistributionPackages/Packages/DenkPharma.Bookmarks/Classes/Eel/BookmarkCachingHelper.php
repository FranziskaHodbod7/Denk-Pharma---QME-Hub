<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Eel;

use DenkPharma\Bookmarks\Service\BookmarkCacheService;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class BookmarkCachingHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected BookmarkCacheService $cacheService;

    public function nodeUserTag(?Node $node): ?string
    {
        return $node !== null
            ? $this->cacheService->nodeUserTag($node->aggregateId->value)
            : null;
    }

    public function userTag(): ?string
    {
        return $this->cacheService->userTag();
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
