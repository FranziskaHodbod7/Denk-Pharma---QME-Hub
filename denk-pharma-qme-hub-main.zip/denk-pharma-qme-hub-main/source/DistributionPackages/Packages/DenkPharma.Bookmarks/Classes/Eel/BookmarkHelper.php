<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Eel;

use DenkPharma\Bookmarks\Service\BookmarkedNodeFinder;
use DenkPharma\Bookmarks\Service\BookmarkService;
use DenkPharma\Bookmarks\Service\CurrentPartyResolver;
use DenkPharma\Bookmarks\Service\FrontendSubgraphFactory;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class BookmarkHelper implements ProtectedContextAwareInterface
{
	#[Flow\Inject]
	protected BookmarkService $service;

	#[Flow\Inject]
	protected FrontendSubgraphFactory $frontendSubgraphFactory;

	#[Flow\Inject]
	protected CurrentPartyResolver $currentPartyResolver;

	#[Flow\Inject]
	protected BookmarkedNodeFinder $finder;

	#[Flow\Inject]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	public function isBookmarkable(?Node $node): bool
	{
		return $node !== null && $this->service->isBookmarkable($node);
	}

	public function isBookmarked(?Node $node): bool
	{
		if ($node === null || !$this->isBookmarkable($node)) {
			return false;
		}

		$party = $this->currentPartyResolver->resolve();
		return $party !== null && $this->service->isBookmarked($party, $node);
	}

	/** Serializes a NodeAddress to JSON for use in form fields and JS contexts. */
	public function nodeAddress(?Node $node): string
	{
		return $node === null ? '' : NodeAddress::fromNode($node)->toJson();
	}

	/** Returns `${contentRepositoryId}:${aggregateId}` — the JS-side BookmarkStore key. */
	public function bookmarkKey(?Node $node): string
	{
		if ($node === null) {
			return '';
		}
		return $node->contentRepositoryId->value . ':' . $node->aggregateId->value;
	}

	/**
	 * @param list<string> $nodeTypes
	 * @return list<Node>
	 */
	public function nodesForCurrentParty(?Node $contextNode, array $nodeTypes = [], ?int $limit = null): array
	{
		if ($contextNode === null) {
			return [];
		}

		$party = $this->currentPartyResolver->resolve();
		if ($party === null) {
			return [];
		}

		return $this->finder->findForParty(
			$party,
			$this->frontendSubgraphFactory->forNode($contextNode),
			array_map(static fn (string $t): NodeTypeName => NodeTypeName::fromString($t), $nodeTypes),
			$limit,
		);
	}

	/**
	 * Expands a node-type filter to include subtypes (excluding abstracts), so JS-side
	 * filtering can be a cheap exact-match against the result.
	 *
	 * @param list<string> $nodeTypes
	 * @return list<string>
	 */
	public function expandTypes(?Node $contextNode, array $nodeTypes): array
	{
		if ($contextNode === null || $nodeTypes === []) {
			return $nodeTypes;
		}

		$nodeTypeManager = $this->contentRepositoryRegistry
			->get($contextNode->contentRepositoryId)
			->getNodeTypeManager();

		$expanded = [];
		foreach ($nodeTypes as $typeName) {
			$expanded[$typeName] = true;
			foreach ($nodeTypeManager->getSubNodeTypes($typeName, false) as $subType) {
				$expanded[$subType->name->value] = true;
			}
		}
		return array_keys($expanded);
	}

	public function allowsCallOfMethod($methodName): bool
	{
		return true;
	}
}
