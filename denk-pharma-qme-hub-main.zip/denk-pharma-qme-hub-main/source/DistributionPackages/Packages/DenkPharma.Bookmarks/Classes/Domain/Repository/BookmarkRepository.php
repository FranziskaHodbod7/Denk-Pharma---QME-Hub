<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Domain\Repository;

use DenkPharma\Bookmarks\Domain\Model\Bookmark;
use Doctrine\ORM\EntityManagerInterface;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\QueryInterface;
use Neos\Flow\Persistence\Repository;
use Neos\Party\Domain\Model\AbstractParty;

#[Flow\Scope('singleton')]
class BookmarkRepository extends Repository
{
	public const string ENTITY_CLASSNAME = Bookmark::class;

	#[Flow\Inject]
	protected EntityManagerInterface $entityManager;

	public function findOneByPartyAndNode(
		AbstractParty       $party,
		ContentRepositoryId $contentRepositoryId,
		NodeAggregateId     $nodeAggregateId,
	): ?Bookmark
	{
		$query = $this->createQuery();

		/** @var Bookmark|null */
		return $query->matching(
			$query->logicalAnd(
				$query->equals('party', $party),
				$query->equals('contentRepositoryId', $contentRepositoryId->value),
				$query->equals('nodeAggregateId', $nodeAggregateId->value),
			)
		)->execute()->getFirst();
	}

	public function existsForPartyAndNode(
		AbstractParty       $party,
		ContentRepositoryId $contentRepositoryId,
		NodeAggregateId     $nodeAggregateId,
	): bool
	{
		return $this->findOneByPartyAndNode($party, $contentRepositoryId, $nodeAggregateId) !== null;
	}

	/**
	 * @return list<Bookmark> ordered by createdAt DESC
	 */
	public function findAllByParty(
		AbstractParty        $party,
		?ContentRepositoryId $contentRepositoryId = null,
	): array
	{
		$query = $this->createQuery();
		$constraints = [$query->equals('party', $party)];

		if ($contentRepositoryId !== null) {
			$constraints[] = $query->equals('contentRepositoryId', $contentRepositoryId->value);
		}

		return iterator_to_array(
			$query
				->matching($query->logicalAnd(...$constraints))
				->setOrderings(['createdAt' => QueryInterface::ORDER_DESCENDING])
				->execute()
		);
	}

	public function removeAllByParty(AbstractParty $party): void
	{
		$this->entityManager->createQuery(
			'DELETE FROM ' . Bookmark::class . ' b WHERE b.party = :party'
		)->setParameter('party', $party)->execute();
	}

	public function removeAllByContentRepositoryAndAggregate(
		ContentRepositoryId $contentRepositoryId,
		NodeAggregateId     $nodeAggregateId,
	): void
	{
		$this->entityManager->createQuery(
			'DELETE FROM ' . Bookmark::class . ' b
			 WHERE b.contentRepositoryId = :crId
			   AND b.nodeAggregateId = :nodeAggId'
		)->setParameters([
			'crId'      => $contentRepositoryId->value,
			'nodeAggId' => $nodeAggregateId->value,
		])->execute();
	}
}
