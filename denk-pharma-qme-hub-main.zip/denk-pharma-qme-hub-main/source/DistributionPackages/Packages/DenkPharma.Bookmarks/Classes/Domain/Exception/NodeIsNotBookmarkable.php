<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Domain\Exception;

use DenkPharma\Bookmarks\Exception;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;

final class NodeIsNotBookmarkable extends Exception
{
	public static function forNode(Node $node, string $expectedMixin): self
	{
		return new self(sprintf(
			'Node %s of type "%s" cannot be bookmarked: missing mixin "%s".',
			$node->aggregateId->value,
			$node->nodeTypeName->value,
			$expectedMixin,
		), 1761700000);
	}
}
