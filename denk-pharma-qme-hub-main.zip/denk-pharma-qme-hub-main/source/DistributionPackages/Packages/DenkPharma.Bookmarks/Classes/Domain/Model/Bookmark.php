<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Domain\Model;

use DateTimeImmutable;
use DateTimeInterface;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Neos\Party\Domain\Model\AbstractParty;

#[Flow\Entity(readOnly: true)]
#[ORM\Table(
	name: 'denkpharma_bookmarks_bookmark',
	uniqueConstraints: [
		new ORM\UniqueConstraint(
			columns: ['party', 'content_repository_id', 'node_aggregate_id']
		)
	]
)]
class Bookmark
{
	#[ORM\ManyToOne(targetEntity: AbstractParty::class)]
	#[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
	protected readonly AbstractParty $party;

	#[ORM\Column(name: 'content_repository_id', length: 16, nullable: false)]
	protected readonly string $contentRepositoryId;

	#[ORM\Column(name: 'node_aggregate_id', length: 64, nullable: false)]
	protected readonly string $nodeAggregateId;

	#[ORM\Column(name: 'created_at', type: Types::INTEGER, nullable: false)]
	protected readonly int $createdAt;

	public function __construct(
		AbstractParty       $party,
		ContentRepositoryId $contentRepositoryId,
		NodeAggregateId     $nodeAggregateId,
		DateTimeInterface   $createdAt,
	)
	{
		$this->party = $party;
		$this->contentRepositoryId = $contentRepositoryId->value;
		$this->nodeAggregateId = $nodeAggregateId->value;
		$this->createdAt = $createdAt->getTimestamp();
	}

	public function getParty(): AbstractParty
	{
		return $this->party;
	}

	public function getContentRepositoryId(): ContentRepositoryId
	{
		return ContentRepositoryId::fromString($this->contentRepositoryId);
	}

	public function getNodeAggregateId(): NodeAggregateId
	{
		return NodeAggregateId::fromString($this->nodeAggregateId);
	}

	/**
	 * Always returns UTC; convert with ->setTimezone() for display.
	 */
	public function getCreatedAt(): DateTimeImmutable
	{
		return new DateTimeImmutable('@' . $this->createdAt);
	}
}
