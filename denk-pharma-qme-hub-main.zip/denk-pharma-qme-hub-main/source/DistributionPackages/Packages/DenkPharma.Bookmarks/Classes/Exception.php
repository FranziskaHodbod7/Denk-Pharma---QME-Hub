<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks;

class Exception extends \Neos\Flow\Exception
{
}
