<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\CatchUpHook;

use DenkPharma\Bookmarks\Domain\Repository\BookmarkRepository;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\CatchUpHook\CatchUpHookFactoryDependencies;
use Neos\ContentRepository\Core\Projection\CatchUpHook\CatchUpHookFactoryInterface;
use Neos\ContentRepository\Core\Projection\CatchUpHook\CatchUpHookInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentGraphReadModelInterface;
use Neos\Flow\Annotations as Flow;

final class BookmarkCleanupCatchUpHookFactory implements CatchUpHookFactoryInterface
{
	#[Flow\Inject]
	protected BookmarkRepository $bookmarkRepository;

	#[Flow\InjectConfiguration(path: 'bookmarkableMixinType')]
	protected string $bookmarkableMixinType;

	public function build(CatchUpHookFactoryDependencies $dependencies): CatchUpHookInterface
	{
		assert($dependencies->projectionState instanceof ContentGraphReadModelInterface);

		return new BookmarkCleanupCatchUpHook(
			$dependencies->contentRepositoryId,
			$dependencies->nodeTypeManager,
			NodeTypeName::fromString($this->bookmarkableMixinType),
			$this->bookmarkRepository,
			$dependencies->projectionState,
		);
	}
}
