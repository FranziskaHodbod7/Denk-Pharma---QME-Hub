<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\CatchUpHook;

use DenkPharma\Bookmarks\Domain\Repository\BookmarkRepository;
use Neos\ContentRepository\Core\EventStore\EventInterface;
use Neos\ContentRepository\Core\Feature\NodeRemoval\Event\NodeAggregateWasRemoved;
use Neos\ContentRepository\Core\Feature\NodeTypeChange\Event\NodeAggregateTypeWasChanged;
use Neos\ContentRepository\Core\NodeType\NodeTypeManager;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\CatchUpHook\CatchUpHookInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentGraphReadModelInterface;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepository\Core\Subscription\SubscriptionStatus;
use Neos\EventStore\Model\EventEnvelope;

final readonly class BookmarkCleanupCatchUpHook implements CatchUpHookInterface
{
	public function __construct(
		private ContentRepositoryId            $contentRepositoryId,
		private NodeTypeManager                $nodeTypeManager,
		private NodeTypeName                   $bookmarkableMixinType,
		private BookmarkRepository             $bookmarkRepository,
		private ContentGraphReadModelInterface $contentGraphReadModel,
	) {
	}

	public function onBeforeCatchUp(SubscriptionStatus $subscriptionStatus): void
	{
	}

	public function onBeforeEvent(EventInterface $eventInstance, EventEnvelope $eventEnvelope): void
	{
	}

	public function onAfterEvent(EventInterface $eventInstance, EventEnvelope $eventEnvelope): void
	{
		match (true) {
			$eventInstance instanceof NodeAggregateWasRemoved     => $this->handleRemoval($eventInstance),
			$eventInstance instanceof NodeAggregateTypeWasChanged => $this->handleTypeChange($eventInstance),
			default                                                => null,
		};
	}

	public function onAfterBatchCompleted(): void
	{
	}

	public function onAfterCatchUp(): void
	{
	}

	private function handleRemoval(NodeAggregateWasRemoved $event): void
	{
		if (!$event->workspaceName->equals(WorkspaceName::forLive())) {
			return;
		}

		// Skip partial-DSP removals (e.g. an editor dropping only the de_DE specialization).
		// The aggregate still covers other DSPs and the bookmark stays meaningful — the
		// read-side will resolve via fallback. Only fully-removed aggregates trigger deletion.
		$remaining = $this->contentGraphReadModel
			->getContentGraph($event->workspaceName)
			->findNodeAggregateById($event->nodeAggregateId);
		if ($remaining !== null) {
			return;
		}

		$this->bookmarkRepository->removeAllByContentRepositoryAndAggregate(
			$this->contentRepositoryId,
			$event->nodeAggregateId,
		);
	}

	private function handleTypeChange(NodeAggregateTypeWasChanged $event): void
	{
		if (!$event->workspaceName->equals(WorkspaceName::forLive())) {
			return;
		}

		$newNodeType = $this->nodeTypeManager->getNodeType($event->newNodeTypeName);
		if ($newNodeType?->isOfType($this->bookmarkableMixinType->value)) {
			return;
		}

		$this->bookmarkRepository->removeAllByContentRepositoryAndAggregate(
			$this->contentRepositoryId,
			$event->nodeAggregateId,
		);
	}
}
