<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Controller;

use DenkPharma\Bookmarks\Domain\Exception\NodeIsNotBookmarkable;
use DenkPharma\Bookmarks\Domain\Repository\BookmarkRepository;
use DenkPharma\Bookmarks\Service\BookmarkService;
use DenkPharma\Bookmarks\Service\CurrentPartyResolver;
use DenkPharma\Bookmarks\Service\FrontendSubgraphFactory;
use GuzzleHttp\Psr7\Response;
use JsonException;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Persistence\Exception\IllegalObjectTypeException;
use Psr\Http\Message\ResponseInterface;

class BookmarkController extends ActionController
{
	/**
	 * @var array<string>
	 */
	protected $supportedMediaTypes = ['application/json'];

	#[Flow\Inject]
	protected FrontendSubgraphFactory $frontendSubgraphFactory;

	#[Flow\Inject]
	protected BookmarkService $bookmarkService;

	#[Flow\Inject]
	protected CurrentPartyResolver $currentPartyResolver;

	#[Flow\Inject]
	protected BookmarkRepository $bookmarkRepository;

	/**
	 * @throws NodeIsNotBookmarkable on crafted toggles against non-bookmarkable nodes
	 * @throws IllegalObjectTypeException
	 * @throws JsonException
	 */
	#[Flow\SkipCsrfProtection]
	public function toggleAction(string $nodeAddress): ResponseInterface
	{
		$party = $this->currentPartyResolver->resolve();
		if ($party === null) {
			return new Response(403, ['Content-Type' => 'application/json'], json_encode(['changed' => false, 'bookmarked' => false], JSON_THROW_ON_ERROR));
		}

		$address = NodeAddress::fromJsonString($nodeAddress);

		if (!$address->workspaceName->isLive()) {
			return $this->jsonResponse(changed: false, bookmarked: false);
		}

		$node = $this->frontendSubgraphFactory
			->forNodeAddress($address)
			->findNodeById($address->aggregateId);

		if ($node === null) {
			return $this->jsonResponse(changed: false, bookmarked: false);
		}

		$bookmarked = $this->bookmarkService->toggle($party, $node);
		return $this->jsonResponse(changed: true, bookmarked: $bookmarked);
	}

	/**
	 * @throws JsonException
	 */
	#[Flow\SkipCsrfProtection]
	public function listAction(): ResponseInterface
	{
		$party = $this->currentPartyResolver->resolve();
		if ($party === null) {
			return new Response(200, ['Content-Type' => 'application/json'], json_encode(['keys' => []], JSON_THROW_ON_ERROR));
		}

		$bookmarks = $this->bookmarkRepository->findAllByParty($party);
		$keys = array_map(
			static fn ($bookmark) => $bookmark->getContentRepositoryId()->value . ':' . $bookmark->getNodeAggregateId()->value,
			$bookmarks,
		);

		return new Response(200, ['Content-Type' => 'application/json'], json_encode(['keys' => $keys], JSON_THROW_ON_ERROR));
	}

	/**
	 * @throws JsonException
	 */
	private function jsonResponse(bool $changed, bool $bookmarked): ResponseInterface
	{
		return new Response(
			$changed ? 200 : 422,
			['Content-Type' => 'application/json'],
			json_encode(
				['changed' => $changed, 'bookmarked' => $bookmarked],
				JSON_THROW_ON_ERROR,
			),
		);
	}
}
