<?php

declare(strict_types=1);

namespace DenkPharma\Bookmarks\Controller;

use DenkPharma\Bookmarks\Service\FrontendSubgraphFactory;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Mvc\Exception\StopActionException;

class CardController extends ActionController
{
	/**
	 * @var array<string>
	 */
	protected $supportedMediaTypes = ['text/html'];

	#[Flow\Inject]
	protected FrontendSubgraphFactory $frontendSubgraphFactory;

	/**
	 * Renders a card fragment via FusionView (see Configuration/Views.yaml + Root.fusion).
	 *
	 * @throws StopActionException
	 */
	public function showAction(string $nodeAddress): void
	{
		$address = NodeAddress::fromJsonString($nodeAddress);

		if (!$address->workspaceName->isLive()) {
			$this->throwStatus(404);
		}

		$node = $this->frontendSubgraphFactory
			->forNodeAddress($address)
			->findNodeById($address->aggregateId);

		if ($node === null) {
			$this->throwStatus(404);
		}

		$this->view->assign('value', $node);
		$this->view->setFusionPath('bookmarkCard');
	}
}
