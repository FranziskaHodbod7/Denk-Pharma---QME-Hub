<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260430052138 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE denkpharma_bookmarks_bookmark (persistence_object_identifier VARCHAR(40) NOT NULL, party VARCHAR(40) NOT NULL, content_repository_id VARCHAR(16) NOT NULL, node_aggregate_id VARCHAR(64) NOT NULL, created_at INT NOT NULL, INDEX IDX_9054A3D689954EE0 (party), UNIQUE INDEX UNIQ_9054A3D689954EE0B13F2E692D9DC9 (party, content_repository_id, node_aggregate_id), PRIMARY KEY(persistence_object_identifier)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE denkpharma_bookmarks_bookmark ADD CONSTRAINT FK_9054A3D689954EE0 FOREIGN KEY (party) REFERENCES neos_party_domain_model_abstractparty (persistence_object_identifier) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE denkpharma_bookmarks_bookmark DROP FOREIGN KEY FK_9054A3D689954EE0');
        $this->addSql('DROP TABLE denkpharma_bookmarks_bookmark');
    }
}
