<?php

declare(strict_types=1);

namespace DenkPharma\CRM\Connector;

use DenkPharma\CRM\Connector\Service\CrmConnectorService;
use DenkPharma\User\Service\AccountProfileService;
use DenkPharma\User\Service\UserPreferencesService;
use FormatD\UserManagement\Domain\Service\UserService;
use Neos\Flow\Core\Bootstrap;
use Neos\Flow\Package\Package as BasePackage;

final class Package extends BasePackage
{
    public function boot(Bootstrap $bootstrap): void
    {
        $dispatcher = $bootstrap->getSignalSlotDispatcher();

        $dispatcher->connect(UserService::class, 'userCreated', CrmConnectorService::class, 'syncUser');
        $dispatcher->connect(AccountProfileService::class, 'userProfileUpdated', CrmConnectorService::class, 'syncUser');
        $dispatcher->connect(UserPreferencesService::class, 'userPreferencesUpdated', CrmConnectorService::class, 'syncUser');
    }
}
