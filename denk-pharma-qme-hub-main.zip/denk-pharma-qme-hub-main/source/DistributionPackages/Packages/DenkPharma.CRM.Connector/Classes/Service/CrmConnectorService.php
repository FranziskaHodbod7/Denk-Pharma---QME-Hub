<?php

declare(strict_types=1);

namespace DenkPharma\CRM\Connector\Service;

use DenkPharma\Core\Service\TaxonomyResolver;
use DenkPharma\User\Domain\Enum\Title;
use DenkPharma\User\Domain\Model\User as DenkPharmaUser;
use DenkPharma\User\Service\PhoneNumberService;
use DenkPharma\User\Service\TitleService;
use FormatD\UserManagement\Domain\Model\User;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\I18n\Locale;
use Psr\Log\LoggerInterface;
use Sitegeist\Taxonomy\Service\TaxonomyService;

#[Flow\Scope('singleton')]
final class CrmConnectorService
{
    #[Flow\Inject(lazy: false)]
    protected TaxonomyService $taxonomyService;

    #[Flow\Inject]
    protected TaxonomyResolver $taxonomyResolver;

    #[Flow\Inject]
    protected TitleService $titleService;

    #[Flow\Inject]
    protected PhoneNumberService $phoneNumberService;

    #[Flow\Inject]
    protected LoggerInterface $logger;

    #[Flow\InjectConfiguration(path: 'webhookUrl', package: 'DenkPharma.CRM.Connector')]
    protected string $webhookUrl = '';

    #[Flow\InjectConfiguration(path: 'enabled', package: 'DenkPharma.CRM.Connector')]
    protected bool $enabled = false;

    /** Builds and logs the payload but skips the HTTP call. */
    #[Flow\InjectConfiguration(path: 'dryRun', package: 'DenkPharma.CRM.Connector')]
    protected bool $dryRun = false;

    public function syncUser(User $user): void
    {
        if (!$this->enabled) {
            $this->logger->debug('DenkPharma.CRM.Connector: sync skipped (disabled)');
            return;
        }

        if ($this->webhookUrl === '') {
            $this->logger->warning('DenkPharma.CRM.Connector: sync skipped (no webhookUrl configured)');
            return;
        }

        $payload = $this->buildPayload($user);

        if ($this->dryRun) {
            $this->logger->info('DenkPharma.CRM.Connector: dry run, skipping POST', $payload);
            return;
        }

        $this->logger->info('DenkPharma.CRM.Connector: syncing user to n8n', [
            'userEmail' => $payload['emailAddress'] ?? 'unknown',
            'webhookUrl' => $this->webhookUrl,
        ]);
        $this->logger->debug('DenkPharma.CRM.Connector: Payload', $payload);

        try {
            $response = (new Client())->post($this->webhookUrl, ['json' => $payload]);

            $this->logger->info('DenkPharma.CRM.Connector: sync successful', [
                'userEmail' => $payload['emailAddress'] ?? 'unknown',
                'statusCode' => $response->getStatusCode(),
            ]);
        } catch (GuzzleException $e) {
            $this->logger->error('DenkPharma.CRM.Connector: sync failed', [
                'userEmail' => $payload['emailAddress'] ?? 'unknown',
                'webhookUrl' => $this->webhookUrl,
                'error' => $e->getMessage(),
                'payload' => $payload,
            ]);
        }
    }

    /** @return array<string, mixed> */
    protected function buildPayload(User $user): array
    {
        $name = $user->getName();

        $salutationLabel = '';
        $professionalFieldLabel = '';
        $fieldsOfInterestLabels = [];
        $whatsAppConsent = false;

        if ($user instanceof DenkPharmaUser) {
            $whatsAppConsent = $user->isWhatsAppConsentGiven();

            // "No title" is an absent value for the CRM, not a label to send.
            $title = $user->getTitleEnum();
            $salutationLabel = $title === Title::None ? '' : $this->titleService->label($title, new Locale('en_GB'));

            $subgraph = $this->buildSubgraph();

            $professionalFieldId = $user->getProfessionalField();
            if ($professionalFieldId !== null) {
                $resolved = $this->taxonomyResolver->resolveByIds($subgraph, 'professional-field', [$professionalFieldId]);
                $node = $resolved[$professionalFieldId->value] ?? null;
                if ($node !== null) {
                    $professionalFieldLabel = (string)($node->getProperty('title') ?? '');
                }
            }

            $fieldIds = $user->getFieldsOfInterest();
            if ($fieldIds !== []) {
                $resolved = $this->taxonomyResolver->resolveByIds($subgraph, 'field-of-interest', $fieldIds);
                foreach ($resolved as $node) {
                    $label = (string)($node->getProperty('title') ?? '');
                    if ($label !== '') {
                        $fieldsOfInterestLabels[] = $label;
                    }
                }
            }
        }

        return [
            'firstName' => $name?->getFirstName() ?? '',
            'lastName' => $name?->getLastName() ?? '',
            'emailAddress' => $user->getPrimaryEmailAddress() ?? '',
            'phoneNumber' => $this->phoneNumberService->toE164($user->getPhoneNumber() ?? ''),
            'addressCity' => $user->getCity(),
            'addressCountry' => $user->getCountry(),
            'privacyConsent' => true,
            'salutationName' => $salutationLabel,
            'title' => $professionalFieldLabel,
            'cProfession' => implode(', ', $fieldsOfInterestLabels),
            'cQMEHubMember' => $user->isNewsletterSubscribed(),
            'whatsapp_consent' => $whatsAppConsent,
        ];
    }

    protected function buildSubgraph(): ContentSubgraphInterface
    {
        return $this->taxonomyService
            ->getContentRepository()
            ->getContentGraph(WorkspaceName::forLive())
            ->getSubgraph(
                DimensionSpacePoint::fromArray(['language' => 'en_GB']),
                VisibilityConstraints::withoutRestrictions(),
            );
    }
}
