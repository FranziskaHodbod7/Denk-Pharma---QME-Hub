<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

/**
 * A product the load step will not import because its subtree carries an error finding.
 */
#[\Neos\Flow\Annotations\Proxy(false)]
final class SkippedProduct
{
    /**
     * @param string[] $reasons the error findings, as code or "code: detail"
     */
    public function __construct(
        public readonly string $sku,
        public readonly array $reasons,
    ) {
    }
}
