<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

/**
 * One node aggregate the load step intends to create: its type and id, where it sits (a parent
 * aggregate, optionally a tethered collection on that parent; or, for a product, the category whose
 * folder it belongs under), and the properties, taxonomy references and asset sources to set. Pure
 * data — the planner produces it from the model, the dry-run logs it, the writer will execute it.
 */
#[\Neos\Flow\Annotations\Proxy(false)]
final class PlannedNode
{
    /**
     * @param array<string, string|float> $properties
     * @param array<string, string[]> $references resolved reference name => target aggregate ids
     * @param array<string, string[]> $assets property name => source filenames
     */
    public function __construct(
        public readonly string $nodeType,
        public readonly string $nodeAggregateId,
        public readonly string $label,
        public readonly ?string $parentNodeAggregateId,
        public readonly ?string $tetheredParentName,
        public readonly ?string $category,
        public readonly array $properties,
        public readonly array $references,
        public readonly array $assets,
    ) {
    }
}
