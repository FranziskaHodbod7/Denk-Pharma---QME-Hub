<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

/**
 * The full plan for one load: the node aggregates to create (parents before children) and the
 * products skipped for carrying an error.
 */
#[\Neos\Flow\Annotations\Proxy(false)]
final class ImportPlan
{
    /**
     * @param PlannedNode[] $operations
     * @param SkippedProduct[] $skipped
     */
    public function __construct(
        public readonly array $operations,
        public readonly array $skipped,
    ) {
    }
}
