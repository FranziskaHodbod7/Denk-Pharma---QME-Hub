<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

/**
 * Outcome of a write: how many aggregates were created, the assets imported (or deferred when no
 * assets directory was given, or missing on disk), and properties dropped because the node type
 * doesn't (yet) declare them.
 */
#[\Neos\Flow\Annotations\Proxy(false)]
final class WriteResult
{
    /**
     * @param string[] $importedAssets
     * @param string[] $deferredAssets
     * @param string[] $missingAssets
     * @param string[] $droppedProperties
     */
    public function __construct(
        public readonly int $created,
        public readonly int $skipped,
        public readonly array $importedAssets,
        public readonly array $deferredAssets,
        public readonly array $missingAssets,
        public readonly array $droppedProperties,
    ) {
    }
}
