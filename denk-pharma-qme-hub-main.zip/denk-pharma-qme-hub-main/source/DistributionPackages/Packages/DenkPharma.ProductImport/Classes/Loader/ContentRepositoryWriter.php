<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

use DenkPharma\ProductImport\Util\NodeId;
use Neos\ContentRepository\Core\ContentRepository;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeCreation\Command\CreateNodeAggregateWithNode;
use Neos\ContentRepository\Core\Feature\NodeCreation\Dto\NodeAggregateIdsByNodePaths;
use Neos\ContentRepository\Core\Feature\NodeModification\Command\SetNodeProperties;
use Neos\ContentRepository\Core\Feature\NodeModification\Dto\PropertyValuesToWrite;
use Neos\ContentRepository\Core\Feature\NodeVariation\Command\CreateNodeVariant;
use Neos\ContentRepository\Core\Feature\NodeVariation\Exception\DimensionSpacePointIsAlreadyOccupied;
use Neos\ContentRepository\Core\SharedModel\Exception\NodeAggregateCurrentlyDoesNotExist;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesForName;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesToWrite;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindDescendantNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateIds;
use Neos\ContentRepository\Core\SharedModel\Node\ReferenceName;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\ResourceManagement\PersistentResource;
use Neos\Flow\ResourceManagement\ResourceManager;
use Neos\Media\Domain\Model\Asset;
use Neos\Media\Domain\Model\Document;
use Neos\Media\Domain\Model\Image;
use Neos\Media\Domain\Repository\AssetRepository;

/**
 * Executes an {@see ImportPlan} against the Content Repository: one CreateNodeAggregateWithNode per
 * operation, in the plan's parents-first order, in the live workspace and the en_GB dimension. The
 * `m:nodeId`s become aggregate ids (so re-running is idempotent), the plan's references become
 * taxonomy references, and a product's tethered collections (benefits/administrations/compositions)
 * get deterministic ids so its children attach to the right one.
 *
 * Not yet done here: importing the `m:src` files as media assets, and setting properties the node
 * type doesn't declare (e.g. `longDescription` until the field lands) — both are reported back.
 */
class ContentRepositoryWriter
{
    private const CONTENT_REPOSITORY_ID = 'default';
    private const LANGUAGE = 'en_GB';
    private const SITES_ROOT_TYPE = 'Neos.Neos:Sites';
    private const CATEGORY_FOLDER_TYPE = [
        'dietary-supplements' => 'DenkPharma.Hub:Document.Hub.ProductsDietarySupplementsFolder',
        'medicines' => 'DenkPharma.Hub:Document.Hub.ProductsPharmaceuticalsFolder',
        'other' => 'DenkPharma.Hub:Document.Hub.ProductsOtherFolder',
    ];
    private const PRODUCT_COLLECTIONS = ['benefits', 'administrations', 'compositions'];

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected ResourceManager $resourceManager;

    #[Flow\Inject]
    protected AssetRepository $assetRepository;

    /**
     * @var array<string, NodeAggregateId>
     */
    private array $folders = [];

    public function write(ImportPlan $plan, string $assetsDir = '', string $language = self::LANGUAGE): WriteResult
    {
        $contentRepository = $this->contentRepositoryRegistry->get(ContentRepositoryId::fromString(self::CONTENT_REPOSITORY_ID));
        $workspace = WorkspaceName::forLive();
        $enOrigin = OriginDimensionSpacePoint::fromArray(['language' => self::LANGUAGE]);
        $isEnglish = $language === self::LANGUAGE;
        $targetOrigin = $isEnglish ? $enOrigin : OriginDimensionSpacePoint::fromArray(['language' => $language]);
        $nodeTypeManager = $contentRepository->getNodeTypeManager();

        $created = 0;
        $importedAssets = [];
        $deferredAssets = [];
        $missingAssets = [];
        $droppedProperties = [];

        foreach ($plan->operations as $operation) {
            $nodeType = $nodeTypeManager->getNodeType(NodeTypeName::fromString($operation->nodeType));
            $properties = [];
            foreach ($operation->properties as $name => $value) {
                if ($nodeType !== null && $nodeType->hasProperty($name)) {
                    $properties[$name] = $value;
                } else {
                    $droppedProperties[] = sprintf('%s.%s', $operation->nodeAggregateId, $name);
                }
            }

            if ($isEnglish) {
                foreach ($operation->assets as $name => $sources) {
                    if ($assetsDir === '') {
                        foreach ($sources as $source) {
                            $deferredAssets[] = sprintf('%s.%s ← %s', $operation->nodeAggregateId, $name, $source);
                        }
                        continue;
                    }
                    $value = $this->importAssets($name, $sources, $assetsDir, $importedAssets, $missingAssets);
                    if ($value !== null) {
                        $properties[$name] = $value;
                    }
                }

                $command = CreateNodeAggregateWithNode::create(
                    $workspace,
                    NodeAggregateId::fromString($operation->nodeAggregateId),
                    NodeTypeName::fromString($operation->nodeType),
                    $enOrigin,
                    $this->parentId($operation, $contentRepository),
                    null,
                    PropertyValuesToWrite::fromArray($properties),
                    $this->references($operation->references),
                );
                if ($operation->category !== null) {
                    $command = $command->withTetheredDescendantNodeAggregateIds($this->productCollections($operation->nodeAggregateId));
                }
                $contentRepository->handle($command);
            } else {
                $nodeAggregateId = NodeAggregateId::fromString($operation->nodeAggregateId);
                try {
                    $contentRepository->handle(
                        CreateNodeVariant::create($workspace, $nodeAggregateId, $enOrigin, $targetOrigin)
                    );
                } catch (DimensionSpacePointIsAlreadyOccupied) {
                    // variant already exists — fall through to SetNodeProperties
                } catch (NodeAggregateCurrentlyDoesNotExist) {
                    // no en_GB base yet — create it, then add the language variant
                    $fallback = CreateNodeAggregateWithNode::create(
                        $workspace, $nodeAggregateId, NodeTypeName::fromString($operation->nodeType),
                        $enOrigin, $this->parentId($operation, $contentRepository), null,
                        PropertyValuesToWrite::fromArray($properties), $this->references($operation->references),
                    );
                    if ($operation->category !== null) {
                        $fallback = $fallback->withTetheredDescendantNodeAggregateIds($this->productCollections($operation->nodeAggregateId));
                    }
                    $contentRepository->handle($fallback);
                    try {
                        $contentRepository->handle(
                            CreateNodeVariant::create($workspace, $nodeAggregateId, $enOrigin, $targetOrigin)
                        );
                    } catch (DimensionSpacePointIsAlreadyOccupied) {
                    }
                }
                if ($properties !== []) {
                    $contentRepository->handle(
                        SetNodeProperties::create($workspace, $nodeAggregateId, $targetOrigin, PropertyValuesToWrite::fromArray($properties))
                    );
                }
            }

            $created++;
        }

        return new WriteResult($created, count($plan->skipped), $importedAssets, $deferredAssets, $missingAssets, $droppedProperties);
    }

    /**
     * Import a node's assets and return the property value to set: an Image for `image`, a list of
     * Documents for `downloads`. Missing files are recorded and skipped.
     *
     * @param string[] $sources
     * @param string[] $imported
     * @param string[] $missing
     */
    private function importAssets(string $name, array $sources, string $assetsDir, array &$imported, array &$missing): Image|array|null
    {
        if ($name === 'image') {
            return $this->importAsset($sources[0], $assetsDir, true, $imported, $missing);
        }

        $documents = [];
        foreach ($sources as $source) {
            $document = $this->importAsset($source, $assetsDir, false, $imported, $missing);
            if ($document !== null) {
                $documents[] = $document;
            }
        }

        return $documents === [] ? null : $documents;
    }

    /**
     * @param string[] $imported
     * @param string[] $missing
     */
    private function importAsset(string $filename, string $assetsDir, bool $isImage, array &$imported, array &$missing): ?Asset
    {
        $path = rtrim($assetsDir, '/') . '/' . $filename;
        $resource = is_file($path) ? $this->resourceManager->importResource($path) : false;
        if (!$resource instanceof PersistentResource) {
            $missing[] = $filename;
            return null;
        }

        $asset = $isImage ? new Image($resource) : new Document($resource);
        $this->assetRepository->add($asset);
        $imported[] = $filename;

        return $asset;
    }

    private function parentId(PlannedNode $operation, ContentRepository $contentRepository): NodeAggregateId
    {
        if ($operation->category !== null) {
            return $this->folder($operation->category, $contentRepository);
        }
        if ($operation->tetheredParentName !== null) {
            return NodeAggregateId::fromString(NodeId::for($operation->parentNodeAggregateId, $operation->tetheredParentName));
        }

        return NodeAggregateId::fromString($operation->parentNodeAggregateId);
    }

    private function productCollections(string $productNodeId): NodeAggregateIdsByNodePaths
    {
        $byPath = [];
        foreach (self::PRODUCT_COLLECTIONS as $name) {
            $byPath[$name] = NodeId::for($productNodeId, $name);
        }

        return NodeAggregateIdsByNodePaths::fromArray($byPath);
    }

    /**
     * @param array<string, string[]> $references
     */
    private function references(array $references): NodeReferencesToWrite
    {
        if ($references === []) {
            return NodeReferencesToWrite::createEmpty();
        }

        $forNames = [];
        foreach ($references as $name => $ids) {
            $forNames[] = NodeReferencesForName::fromTargets(
                ReferenceName::fromString($name),
                NodeAggregateIds::create(...array_map(static fn (string $id): NodeAggregateId => NodeAggregateId::fromString($id), $ids)),
            );
        }

        return NodeReferencesToWrite::create(...$forNames);
    }

    private function folder(string $category, ContentRepository $contentRepository): NodeAggregateId
    {
        if (!isset($this->folders[$category])) {
            $node = $this->findFolderNode($category, $contentRepository);
            if ($node === null) {
                throw new \RuntimeException(sprintf('No %s found to place %s products under', self::CATEGORY_FOLDER_TYPE[$category] ?? 'folder', $category));
            }
            $this->folders[$category] = $node->aggregateId;
        }

        return $this->folders[$category];
    }

    /**
     * Read-only preview of where each category's products will be created — the folder's title and
     * id, or null when no such folder exists yet. A placement pre-flight to run before writing.
     *
     * @return array<string, ?string>
     */
    public function describeTargets(ImportPlan $plan): array
    {
        $contentRepository = $this->contentRepositoryRegistry->get(ContentRepositoryId::fromString(self::CONTENT_REPOSITORY_ID));

        $targets = [];
        foreach ($plan->operations as $operation) {
            if ($operation->category === null || array_key_exists($operation->category, $targets)) {
                continue;
            }
            $node = $this->findFolderNode($operation->category, $contentRepository);
            $targets[$operation->category] = $node !== null
                ? sprintf('%s [%s]', (string)($node->getProperty('title') ?? $node->nodeTypeName->value), $node->aggregateId->value)
                : null;
        }

        return $targets;
    }

    /**
     * Read back a node and its descendants from the live CR (read-only) as `type 'title' [refs]`
     * lines — for verifying what an import actually created.
     *
     * @return string[]
     */
    public function readSubtree(string $nodeAggregateId): array
    {
        $contentRepository = $this->contentRepositoryRegistry->get(ContentRepositoryId::fromString(self::CONTENT_REPOSITORY_ID));
        $subgraph = $contentRepository->getContentGraph(WorkspaceName::forLive())->getSubgraph(
            DimensionSpacePoint::fromArray(['language' => self::LANGUAGE]),
            VisibilityConstraints::withoutRestrictions(),
        );

        $root = $subgraph->findNodeById(NodeAggregateId::fromString($nodeAggregateId));
        if ($root === null) {
            return [];
        }

        $lines = [$this->describe($root, $subgraph)];
        foreach ($subgraph->findDescendantNodes($root->aggregateId, FindDescendantNodesFilter::create()) as $node) {
            $lines[] = '  ' . $this->describe($node, $subgraph);
        }

        return $lines;
    }

    private function describe(Node $node, ContentSubgraphInterface $subgraph): string
    {
        $typeParts = explode('.', $node->nodeTypeName->value);
        $title = (string)($node->getProperty('title') ?? $node->getProperty('description') ?? $node->getProperty('substanceText') ?? '');

        $references = [];
        foreach ($subgraph->findReferences($node->aggregateId, FindReferencesFilter::create()) as $reference) {
            $references[$reference->name->value] = true;
        }

        $assets = [];
        $image = $node->getProperty('image');
        if ($image instanceof Asset) {
            $assets[] = 'image:' . $image->getResource()->getFilename();
        }
        $downloads = $node->getProperty('downloads');
        if (is_array($downloads) && $downloads !== []) {
            $assets[] = 'downloads:' . count($downloads);
        }

        return sprintf(
            '%s%s%s%s',
            (string)end($typeParts),
            $title !== '' ? sprintf(" '%s'", mb_strimwidth($title, 0, 40, '…')) : '',
            $references !== [] ? '  [refs: ' . implode(', ', array_keys($references)) . ']' : '',
            $assets !== [] ? '  [' . implode(', ', $assets) . ']' : '',
        );
    }

    private function findFolderNode(string $category, ContentRepository $contentRepository): ?Node
    {
        $nodeType = self::CATEGORY_FOLDER_TYPE[$category] ?? throw new \RuntimeException(sprintf('No products folder type mapped for category "%s"', $category));

        $contentGraph = $contentRepository->getContentGraph(WorkspaceName::forLive());
        $sitesRoot = $contentGraph->findRootNodeAggregateByType(NodeTypeName::fromString(self::SITES_ROOT_TYPE));
        if ($sitesRoot === null) {
            return null;
        }

        $subgraph = $contentGraph->getSubgraph(
            DimensionSpacePoint::fromArray(['language' => self::LANGUAGE]),
            VisibilityConstraints::withoutRestrictions(),
        );
        foreach ($subgraph->findDescendantNodes($sitesRoot->nodeAggregateId, FindDescendantNodesFilter::create(nodeTypes: $nodeType)) as $folder) {
            return $folder;
        }

        return null;
    }
}
