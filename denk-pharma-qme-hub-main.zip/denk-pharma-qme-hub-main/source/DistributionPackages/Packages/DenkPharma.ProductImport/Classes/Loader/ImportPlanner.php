<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Loader;

use DenkPharma\ProductImport\Converter\FindingCollector;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;

/**
 * Turns the import model into an ordered list of node-aggregate creations — pure, so the whole load
 * decision (node types, hierarchy, which references resolve, which products are skipped) is
 * unit-testable without a Content Repository. The dry-run logs the plan; the writer will execute it.
 *
 * Products whose subtree carries an error finding are skipped (none imported), so importability is a
 * per-product property. Only resolved references (those with an `m:ref` node id) are set; unresolved
 * ones are simply left off. Operations are emitted parents-first, ready to create in order.
 */
final class ImportPlanner
{
    private const NODE_TYPE = [
        'product' => 'DenkPharma.Product:Document.Product',
        'benefit' => 'DenkPharma.Product:Content.Benefit',
        'administration' => 'DenkPharma.Product:Content.Administration',
        'formulation' => 'DenkPharma.Product:Content.Administration.Formulation',
        'ingredient' => 'DenkPharma.Product:Content.Administration.Formulation.Ingredient',
        'composition' => 'DenkPharma.Product:Content.Composition',
        'row' => 'DenkPharma.Product:Content.Composition.Row',
    ];

    public function plan(ImportDocument $document, string $language = 'en_GB'): ImportPlan
    {
        $operations = [];
        $skipped = [];
        foreach ($document->products as $product) {
            $errors = $this->errors($product);
            if ($errors !== []) {
                $skipped[] = new SkippedProduct($product->sku, $errors);
                continue;
            }
            array_push($operations, ...$this->planProduct($product, $language));
        }

        return new ImportPlan($operations, $skipped);
    }

    /**
     * @return string[]
     */
    private function errors(ImportProduct $product): array
    {
        $reasons = [];
        foreach (FindingCollector::collect(new ImportDocument([$product])) as $finding) {
            if ($finding->severity === Severity::Error) {
                $reasons[] = $finding->detail !== null ? sprintf('%s: %s', $finding->code, $finding->detail) : $finding->code;
            }
        }

        return $reasons;
    }

    /**
     * @return PlannedNode[]
     */
    private function planProduct(ImportProduct $product, string $language): array
    {
        $nodes = [];
        $nodes[] = new PlannedNode(
            nodeType: self::NODE_TYPE['product'],
            nodeAggregateId: $product->nodeId,
            label: $product->title->get($language) ?? $product->sku,
            parentNodeAggregateId: null,
            tetheredParentName: null,
            category: $product->category->value,
            properties: $this->clean([
                'externalImportIdentifier' => $product->sku,
                'title' => $product->title->get($language),
                'uriPathSegment' => $product->uriPathSegment->get($language),
                'shortDescription' => $product->shortDescription?->get($language),
                'longDescription' => $product->longDescription?->get($language),
                'ingredients' => $product->ingredients?->get($language),
                'storageInstructions' => $product->storageInstructions?->get($language),
            ]),
            references: $this->clean(['medications' => $this->resolvedIds($product->medications)]),
            assets: $this->clean(['image' => $product->image !== null ? [$product->image] : []]),
        );

        foreach ($product->benefits as $benefit) {
            $nodes[] = new PlannedNode(
                nodeType: self::NODE_TYPE['benefit'],
                nodeAggregateId: $benefit->nodeId,
                label: $benefit->description->get($language) ?? 'benefit',
                parentNodeAggregateId: $product->nodeId,
                tetheredParentName: 'benefits',
                category: null,
                properties: $this->clean(['description' => $benefit->description->get($language)]),
                references: [],
                assets: [],
            );
        }

        foreach ($product->administrations as $administration) {
            $nodes[] = new PlannedNode(
                nodeType: self::NODE_TYPE['administration'],
                nodeAggregateId: $administration->nodeId,
                label: $administration->administrationForm->value,
                parentNodeAggregateId: $product->nodeId,
                tetheredParentName: 'administrations',
                category: null,
                properties: [],
                references: $this->clean(['administrationForm' => $this->resolvedIds([$administration->administrationForm])]),
                assets: $this->clean(['downloads' => $administration->downloads]),
            );
            array_push($nodes, ...$this->planFormulations($administration, $language));
        }

        foreach ($product->compositions as $composition) {
            $nodes[] = new PlannedNode(
                nodeType: self::NODE_TYPE['composition'],
                nodeAggregateId: $composition->nodeId,
                label: $composition->title?->get($language) ?? 'composition',
                parentNodeAggregateId: $product->nodeId,
                tetheredParentName: 'compositions',
                category: null,
                properties: $this->clean(['title' => $composition->title?->get($language)]),
                references: [],
                assets: [],
            );
            foreach ($composition->rows as $row) {
                $nodes[] = new PlannedNode(
                    nodeType: self::NODE_TYPE['row'],
                    nodeAggregateId: $row->nodeId,
                    label: $row->substanceText?->get($language) ?? $row->substance?->value ?? 'row',
                    parentNodeAggregateId: $composition->nodeId,
                    tetheredParentName: null,
                    category: null,
                    properties: $this->clean([
                        'substanceText' => $row->substanceText?->get($language),
                        'perUnit' => $row->perUnit?->get($language),
                        'nrv' => $row->nrv?->get($language),
                    ]),
                    references: $this->clean(['substance' => $row->substance !== null ? $this->resolvedIds([$row->substance]) : []]),
                    assets: [],
                );
            }
        }

        return $nodes;
    }

    /**
     * @return PlannedNode[]
     */
    private function planFormulations(ImportAdministration $administration, string $language): array
    {
        $nodes = [];
        foreach ($administration->formulations as $formulation) {
            $nodes[] = new PlannedNode(
                nodeType: self::NODE_TYPE['formulation'],
                nodeAggregateId: $formulation->nodeId,
                label: $formulation->packageQuantity?->value ?? 'formulation',
                parentNodeAggregateId: $administration->nodeId,
                tetheredParentName: null,
                category: null,
                properties: $this->clean([
                    'externalImportIdentifier' => $formulation->externalIdentifier !== '' ? $formulation->externalIdentifier : null,
                    'applicationRecommendation' => $formulation->applicationRecommendation?->get($language),
                ]),
                references: $this->clean(['packageQuantity' => $formulation->packageQuantity !== null ? $this->resolvedIds([$formulation->packageQuantity]) : []]),
                assets: [],
            );
            foreach ($formulation->ingredients as $ingredient) {
                $nodes[] = new PlannedNode(
                    nodeType: self::NODE_TYPE['ingredient'],
                    nodeAggregateId: $ingredient->nodeId,
                    label: $ingredient->substance->value,
                    parentNodeAggregateId: $formulation->nodeId,
                    tetheredParentName: null,
                    category: null,
                    properties: ['quantity' => (float)$ingredient->quantity],
                    references: $this->clean([
                        'substance' => $this->resolvedIds([$ingredient->substance]),
                        'substance-unit' => $this->resolvedIds([$ingredient->unit]),
                    ]),
                    assets: [],
                );
            }
        }

        return $nodes;
    }

    /**
     * @param Reference[] $references
     * @return string[]
     */
    private function resolvedIds(array $references): array
    {
        $ids = [];
        foreach ($references as $reference) {
            if ($reference->nodeId !== null) {
                $ids[] = $reference->nodeId;
            }
        }

        return $ids;
    }

    /**
     * Keep only what will actually be written — drop null scalars and empty lists.
     *
     * @param array<string, mixed> $values
     * @return array<string, mixed>
     */
    private function clean(array $values): array
    {
        return array_filter($values, static fn (mixed $value): bool => $value !== null && $value !== []);
    }
}
