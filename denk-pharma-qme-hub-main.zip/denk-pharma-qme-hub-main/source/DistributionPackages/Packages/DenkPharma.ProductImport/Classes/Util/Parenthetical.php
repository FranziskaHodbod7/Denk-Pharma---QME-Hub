<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * A value optionally carrying a trailing parenthetical note,
 * e.g. "Vitamin D3 (Cholecalciferol)" → base "Vitamin D3", note "(Cholecalciferol)".
 */
final class Parenthetical
{
    private function __construct(
        public readonly string $base,
        public readonly ?string $note,
    ) {
    }

    /**
     * Split a single trailing "(…)" group off the value. The note keeps its parentheses;
     * a value without a trailing group yields the whole trimmed string as base and a null note.
     */
    public static function from(string $value): self
    {
        $value = trim($value);

        if (preg_match('/^(.*?)\s*(\([^)]*\))\s*$/', $value, $matches) === 1) {
            return new self(trim($matches[1]), $matches[2]);
        }

        return new self($value, null);
    }
}
