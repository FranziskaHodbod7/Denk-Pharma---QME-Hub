<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * Splits a comma-separated cell (e.g. the indication list) into clean values.
 */
final class CommaList
{
    /**
     * Split on commas, trim each part, drop empties.
     *
     * @return list<string>
     */
    public static function split(string $value): array
    {
        $parts = array_map('trim', explode(',', $value));

        return array_values(array_filter($parts, static fn (string $part): bool => $part !== ''));
    }
}
