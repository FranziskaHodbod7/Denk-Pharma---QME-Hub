<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

use Behat\Transliterator\Transliterator;

/**
 * Slugifies a title into a uri-path-segment using the same transliterator Neos relies on,
 * so imported segments match what the editor UI would produce.
 */
final class Slug
{
    public static function fromTitle(string $title): string
    {
        return Transliterator::urlize($title);
    }
}
