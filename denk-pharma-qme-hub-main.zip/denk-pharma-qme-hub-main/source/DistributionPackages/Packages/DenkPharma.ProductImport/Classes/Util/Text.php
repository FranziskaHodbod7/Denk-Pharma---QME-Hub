<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * Plain-text normalization for cells that should collapse to a single line.
 */
final class Text
{
    /**
     * Collapse all whitespace runs (including embedded line breaks) to single spaces, and trim.
     */
    public static function singleLine(string $value): string
    {
        return trim((string)preg_replace('/\s+/u', ' ', $value));
    }
}
