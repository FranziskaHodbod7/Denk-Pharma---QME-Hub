<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * Helpers for the taxonomy reference values carried in the import CSVs.
 */
final class TaxonomyValue
{
    /**
     * Whether a value follows the taxon-title policy: kebab-case — lowercase
     * a–z / 0–9 segments joined by single hyphens, with a double hyphen allowed
     * between segments for "combi" values. No triple+ hyphens, no leading/trailing hyphen.
     */
    public static function isKebabCase(string $value): bool
    {
        return preg_match('/^[a-z0-9]+(?:-{1,2}[a-z0-9]+)*$/', $value) === 1;
    }
}
