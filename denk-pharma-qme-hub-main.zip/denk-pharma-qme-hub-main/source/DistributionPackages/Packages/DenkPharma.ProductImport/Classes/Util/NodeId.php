<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

use Ramsey\Uuid\Uuid;

/**
 * Deterministic node-aggregate ids for the import tree: UUIDv5 over a fixed import namespace,
 * so re-running the converter yields stable ids. The output is a valid Neos NodeAggregateId.
 */
final class NodeId
{
    private const NAMESPACE_URN = 'urn:denkpharma:product-import';

    /**
     * Mint a stable id from one or more seed parts, e.g. NodeId::for('DENK_1236', 'film coated tablet').
     */
    public static function for(string ...$seedParts): string
    {
        $namespace = Uuid::uuid5(Uuid::NAMESPACE_URL, self::NAMESPACE_URN);

        return Uuid::uuid5($namespace, implode('|', $seedParts))->toString();
    }
}
