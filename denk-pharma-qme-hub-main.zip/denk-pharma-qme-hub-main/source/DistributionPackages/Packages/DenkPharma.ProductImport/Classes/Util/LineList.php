<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * Splits a multi-line cell (e.g. the benefits block) into clean line items.
 */
final class LineList
{
    /**
     * Split on line breaks, strip a single leading bullet marker ("- "), trim, drop empties.
     *
     * @return list<string>
     */
    public static function split(string $value): array
    {
        $items = [];

        foreach (preg_split('/\R/u', $value) ?: [] as $line) {
            $line = trim($line);
            $line = trim((string)preg_replace('/^-\s+/', '', $line));
            if ($line !== '') {
                $items[] = $line;
            }
        }

        return $items;
    }
}
