<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Util;

/**
 * Normalisation for the numeric quantity cell of a formulation ingredient.
 */
final class Quantity
{
    /**
     * Canonicalize a raw quantity cell to a decimal string, or null if it isn't a plain number.
     * Accepts a decimal comma (German export) and surrounding whitespace; the textual form is
     * preserved otherwise (no rounding, no trailing-zero stripping).
     */
    public static function normalize(string $raw): ?string
    {
        $value = str_replace(',', '.', trim($raw));

        if (preg_match('/^\d+(?:\.\d+)?$/', $value) !== 1) {
            return null;
        }

        return $value;
    }
}
