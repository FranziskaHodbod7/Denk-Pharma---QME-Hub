<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A composition table (nutritional information) holding its rows.
 */
final class ImportComposition
{
    /**
     * @param ImportCompositionRow[] $rows
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly ?TranslatedText $title,
        public readonly array $rows,
        public readonly array $findings,
    ) {
    }
}
