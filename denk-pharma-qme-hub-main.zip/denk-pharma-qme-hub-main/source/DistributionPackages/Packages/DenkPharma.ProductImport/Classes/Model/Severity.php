<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * Severity of a validation finding. Meaning for the import is a step-2 concern; the XML records it.
 */
enum Severity: string
{
    case Error = 'error';
    case Warning = 'warning';
    case Notice = 'notice';
}
