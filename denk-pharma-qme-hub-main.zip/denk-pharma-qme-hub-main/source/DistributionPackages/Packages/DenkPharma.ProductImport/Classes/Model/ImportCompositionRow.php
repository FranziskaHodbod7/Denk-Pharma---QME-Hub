<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * One row of a composition table. `substance` (resolved taxonomy) and `substanceText` (free text)
 * may both be present — both render when non-empty.
 */
final class ImportCompositionRow
{
    /**
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly ?Reference $substance,
        public readonly ?TranslatedText $substanceText,
        public readonly ?TranslatedText $perUnit,
        public readonly ?TranslatedText $nrv,
        public readonly array $findings,
    ) {
    }
}
