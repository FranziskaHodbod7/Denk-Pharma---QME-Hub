<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A taxonomy reference: the human value, plus either a resolved node id (`m:ref`) or a finding
 * recording why it didn't resolve (`v:`).
 */
final class Reference
{
    public function __construct(
        public readonly string $value,
        public readonly ?string $nodeId = null,
        public readonly ?Finding $finding = null,
    ) {
    }

    public static function resolved(string $value, string $nodeId): self
    {
        return new self($value, $nodeId);
    }

    public static function unresolved(string $value, Finding $finding): self
    {
        return new self($value, null, $finding);
    }
}
