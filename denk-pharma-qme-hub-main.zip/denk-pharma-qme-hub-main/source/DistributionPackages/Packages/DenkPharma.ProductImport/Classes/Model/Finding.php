<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A validation finding raised while building the model — serialized into the `v:` namespace.
 */
final class Finding
{
    public function __construct(
        public readonly Severity $severity,
        public readonly string $code,
        public readonly ?string $detail = null,
    ) {
    }
}
