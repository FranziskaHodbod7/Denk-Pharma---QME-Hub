<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * An administration form (grouped by dosage form), holding its formulations.
 */
final class ImportAdministration
{
    /**
     * @param string[] $downloads
     * @param ImportFormulation[] $formulations
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly Reference $administrationForm,
        public readonly array $downloads,
        public readonly array $formulations,
        public readonly array $findings,
    ) {
    }
}
