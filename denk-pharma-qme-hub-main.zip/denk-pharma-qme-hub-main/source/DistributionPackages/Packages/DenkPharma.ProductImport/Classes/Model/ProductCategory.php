<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * The catalog category a product was exported under. Not a CR property — it drives step-2 folder
 * placement (which in turn governs the product's auto-mode alerts).
 */
enum ProductCategory: string
{
    case DietarySupplements = 'dietary-supplements';
    case Medicines = 'medicines';
    case Other = 'other';
}
