<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A translatable text field: an immutable language → value map. Today every instance carries just
 * en_GB; fr_FR/es_ES are added as translations are merged in.
 */
final class TranslatedText
{
    /**
     * @param string[] $values language => value
     */
    private function __construct(public readonly array $values)
    {
    }

    public static function in(string $language, string $value): self
    {
        return new self([$language => $value]);
    }

    public function with(string $language, string $value): self
    {
        return new self(array_merge($this->values, [$language => $value]));
    }

    public function get(string $language): ?string
    {
        return $this->values[$language] ?? null;
    }
}
