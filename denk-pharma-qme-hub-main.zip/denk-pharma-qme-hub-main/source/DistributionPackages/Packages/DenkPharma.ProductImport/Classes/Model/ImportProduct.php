<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A product as the import understands it — intent-shaped, mirroring the CR storage tree.
 */
#[\Neos\Flow\Annotations\Proxy(false)]
final class ImportProduct
{
    /**
     * @param Reference[] $medications
     * @param ImportBenefit[] $benefits
     * @param ImportAdministration[] $administrations
     * @param ImportComposition[] $compositions
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $sku,
        public readonly ProductCategory $category,
        public readonly string $nodeId,
        public readonly TranslatedText $uriPathSegment,
        public readonly TranslatedText $title,
        public readonly ?TranslatedText $shortDescription,
        public readonly ?TranslatedText $longDescription,
        public readonly ?TranslatedText $ingredients,
        public readonly ?TranslatedText $storageInstructions,
        public readonly ?string $image,
        public readonly array $medications,
        public readonly array $benefits,
        public readonly array $administrations,
        public readonly array $compositions,
        public readonly array $findings,
    ) {
    }

    public function withFinding(Finding $finding): self
    {
        return new self(
            $this->sku,
            $this->category,
            $this->nodeId,
            $this->uriPathSegment,
            $this->title,
            $this->shortDescription,
            $this->longDescription,
            $this->ingredients,
            $this->storageInstructions,
            $this->image,
            $this->medications,
            $this->benefits,
            $this->administrations,
            $this->compositions,
            [...$this->findings, $finding],
        );
    }
}
