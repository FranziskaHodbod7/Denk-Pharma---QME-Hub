<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * One benefit line item.
 */
final class ImportBenefit
{
    /**
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly TranslatedText $description,
        public readonly array $findings,
    ) {
    }
}
