<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * One ingredient of a formulation: a substance + unit reference and a normalized quantity.
 * No freeform fallback here — an unresolved substance is a warning (it won't render).
 */
final class ImportIngredient
{
    /**
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly Reference $substance,
        public readonly Reference $unit,
        public readonly string $quantity,
        public readonly array $findings,
    ) {
    }
}
