<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * The whole import: every product the converter produced. Serialized into the `<products>` root.
 */
final class ImportDocument
{
    /**
     * @param ImportProduct[] $products
     * @param Finding[] $findings document-level findings (e.g. duplicate identifiers)
     */
    public function __construct(
        public readonly array $products,
        public readonly array $findings = [],
    ) {
    }
}
