<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Model;

/**
 * A package/strength variant under an administration form.
 */
final class ImportFormulation
{
    /**
     * @param ImportIngredient[] $ingredients
     * @param Finding[] $findings
     */
    public function __construct(
        public readonly string $nodeId,
        public readonly string $externalIdentifier,
        public readonly ?Reference $packageQuantity,
        public readonly ?TranslatedText $applicationRecommendation,
        public readonly array $ingredients,
        public readonly array $findings,
    ) {
    }
}
