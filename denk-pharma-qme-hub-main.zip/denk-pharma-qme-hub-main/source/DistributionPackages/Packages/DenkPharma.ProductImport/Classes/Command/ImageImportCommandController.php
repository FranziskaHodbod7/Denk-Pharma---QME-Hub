<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Command;

use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeModification\Command\SetNodeProperties;
use Neos\ContentRepository\Core\Feature\NodeModification\Dto\PropertyValuesToWrite;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindDescendantNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;
use Neos\Flow\ResourceManagement\PersistentResource;
use Neos\Flow\ResourceManagement\ResourceManager;
use Neos\Media\Domain\Model\Image;
use Neos\Media\Domain\Repository\AssetRepository;

/**
 * Imports product and administration images from a language-partitioned folder tree.
 *
 * Expected structure:
 *   <inputDir>/
 *     en_GB/  DENK_1234_front.jpg   (product)
 *     en_GB/  DENK_1234_1_front.jpg (administration)
 *     fr_FR/  …
 *     es_ES/  …
 *
 * Matching uses externalImportIdentifier stored on each node: the file's basename
 * must start with the identifier followed by '_' (or be exactly the identifier).
 * The longest match wins, so an administration ID takes priority over its product ID.
 */
class ImageImportCommandController extends CommandController
{
    private const CONTENT_REPOSITORY_ID = 'default';
    private const SITES_ROOT_TYPE = 'Neos.Neos:Sites';
    private const NODE_TYPES = [
        'DenkPharma.Product:Document.Product',
        'DenkPharma.Product:Content.Administration.Formulation',
    ];
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected ResourceManager $resourceManager;

    #[Flow\Inject]
    protected AssetRepository $assetRepository;

    /**
     * Import product and administration images from a folder tree partitioned by language.
     *
     * Each immediate subfolder of <inputDir> must be a language identifier (e.g. en_GB).
     * Images are matched to nodes via their externalImportIdentifier:
     *
     *   DENK_1234_anything.jpg   → Product  externalImportIdentifier="DENK_1234"
     *   DENK_1234_1_anything.jpg → Administration externalImportIdentifier="DENK_1234_1"
     *
     * @param string $inputDir Base directory containing <language>/ subfolders
     * @param bool $dryRun Show matches without writing to the Content Repository
     */
    public function importCommand(string $inputDir, bool $dryRun = false): void
    {
        $base = rtrim($inputDir, '/');
        if (!is_dir($base)) {
            $this->outputLine('<error>Directory not found: %s</error>', [$base]);
            $this->quit(1);
        }

        $langDirs = array_filter(glob($base . '/*', GLOB_ONLYDIR) ?: [], static fn (string $d): bool => is_dir($d));
        if ($langDirs === []) {
            $this->outputLine('<error>No language subfolders found in %s</error>', [$base]);
            $this->quit(1);
        }

        $contentRepository = $this->contentRepositoryRegistry->get(
            ContentRepositoryId::fromString(self::CONTENT_REPOSITORY_ID)
        );
        $contentGraph = $contentRepository->getContentGraph(WorkspaceName::forLive());
        $sitesRoot = $contentGraph->findRootNodeAggregateByType(NodeTypeName::fromString(self::SITES_ROOT_TYPE));
        if ($sitesRoot === null) {
            $this->outputLine('<error>No sites root found in the Content Repository</error>');
            $this->quit(1);
        }

        $totalImported = 0;
        $totalErrors = 0;

        foreach ($langDirs as $langDir) {
            $language = basename($langDir);
            $this->outputLine('');
            $this->outputLine('<comment>%s</comment>', [$language]);

            $subgraph = $contentGraph->getSubgraph(
                DimensionSpacePoint::fromArray(['language' => $language]),
                VisibilityConstraints::withoutRestrictions(),
            );

            // Build identifier → aggregateId lookup for this language dimension.
            $lookup = [];
            foreach (self::NODE_TYPES as $nodeType) {
                foreach ($subgraph->findDescendantNodes(
                    $sitesRoot->nodeAggregateId,
                    FindDescendantNodesFilter::create(nodeTypes: $nodeType),
                ) as $node) {
                    $identifier = $node->getProperty('externalImportIdentifier');
                    if (is_string($identifier) && $identifier !== '') {
                        $lookup[$identifier] = $node->aggregateId;
                    }
                }
            }

            if ($lookup === []) {
                $this->outputLine('  No nodes with externalImportIdentifier — run product import first');
                continue;
            }

            // Longest identifier first so a more-specific admin ID beats the product ID.
            uksort($lookup, static fn (string $a, string $b): int => strlen($b) <=> strlen($a));

            $images = array_filter(
                glob($langDir . '/*') ?: [],
                static fn (string $p): bool => is_file($p) && in_array(
                    strtolower(pathinfo($p, PATHINFO_EXTENSION)),
                    self::ALLOWED_EXTENSIONS,
                    true,
                ),
            );

            if ($images === []) {
                $this->outputLine('  No image files found');
                continue;
            }

            $langImported = 0;
            $unmatched = [];

            foreach ($images as $filePath) {
                $filename = basename($filePath);
                $basename = pathinfo($filename, PATHINFO_FILENAME);

                $matchedIdentifier = null;
                $matchedAggregateId = null;
                foreach ($lookup as $identifier => $aggregateId) {
                    if ($basename === $identifier || str_starts_with($basename, $identifier . '_')) {
                        $matchedIdentifier = $identifier;
                        $matchedAggregateId = $aggregateId;
                        break;
                    }
                }

                if ($matchedAggregateId === null) {
                    $unmatched[] = $filename;
                    continue;
                }

                if ($dryRun) {
                    $this->outputLine('  %s → %s', [$filename, $matchedIdentifier]);
                    continue;
                }

                $resource = $this->resourceManager->importResource($filePath);
                if (!$resource instanceof PersistentResource) {
                    $this->outputLine('  <error>Failed to read %s</error>', [$filename]);
                    $totalErrors++;
                    continue;
                }

                $image = new Image($resource);
                $this->assetRepository->add($image);

                try {
                    $contentRepository->handle(
                        SetNodeProperties::create(
                            WorkspaceName::forLive(),
                            $matchedAggregateId,
                            OriginDimensionSpacePoint::fromArray(['language' => $language]),
                            PropertyValuesToWrite::fromArray(['image' => $image]),
                        )
                    );
                    $this->outputLine('  <success>✓</success> %s → %s', [$filename, $matchedIdentifier]);
                    $langImported++;
                    $totalImported++;
                } catch (\Throwable $e) {
                    $this->outputLine('  <error>Failed to set image on %s: %s</error>', [$matchedIdentifier, $e->getMessage()]);
                    $totalErrors++;
                }
            }

            $this->outputLine('  Imported: %d  |  Unmatched: %d', [$langImported, count($unmatched)]);
            foreach ($unmatched as $f) {
                $this->outputLine('  <comment>unmatched</comment> %s', [$f]);
            }
        }

        $this->outputLine('');
        if ($dryRun) {
            $this->outputLine('<comment>Dry run — no changes written</comment>');
        } else {
            $this->outputLine('<success>Done. Imported: %d  Errors: %d</success>', [$totalImported, $totalErrors]);
        }
    }
}
