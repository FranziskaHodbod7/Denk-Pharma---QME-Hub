<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Command;

use DenkPharma\ProductImport\Converter\BinaryLocator;
use DenkPharma\ProductImport\Converter\Columns;
use DenkPharma\ProductImport\Converter\CsvReader;
use DenkPharma\ProductImport\Converter\DocumentAssembler;
use DenkPharma\ProductImport\Converter\FindingCollector;
use DenkPharma\ProductImport\Converter\Locator;
use DenkPharma\ProductImport\Converter\ModelBuilder;
use DenkPharma\ProductImport\Converter\ProductAssembler;
use DenkPharma\ProductImport\Converter\Segmenter;
use DenkPharma\ProductImport\Converter\XmlReader;
use DenkPharma\ProductImport\Converter\XmlSerializer;
use DenkPharma\ProductImport\Loader\ContentRepositoryWriter;
use DenkPharma\ProductImport\Loader\ImportPlan;
use DenkPharma\ProductImport\Loader\ImportPlanner;
use DenkPharma\ProductImport\Loader\WriteResult;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Taxonomy\ContentRepositoryTaxonomyResolver;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;

/**
 * CLI entry point for the product CSV → domain XML converter. Thin glue over the (unit-tested)
 * converter stages — the only untested logic here is the file I/O.
 */
class ImportCommandController extends CommandController
{
    #[Flow\Inject]
    protected ContentRepositoryTaxonomyResolver $resolver;

    #[Flow\Inject]
    protected ContentRepositoryWriter $writer;

    /**
     * Convert the product CSVs in a directory into the validated domain XML.
     *
     * @param string $inputDir Directory of <language>.<category>.<type>.csv files
     * @param string $output Path to write the domain XML to
     * @param string $language Language dimension to convert
     * @param string $assetsDir Directory of <identifier>[.<extension>] binaries (images, downloads)
     */
    public function convertCommand(string $inputDir, string $output, string $language = 'en_GB', string $assetsDir = ''): void
    {
        $directory = rtrim($inputDir, '/');
        if (!is_dir($directory)) {
            $this->outputLine('<error>Input directory not found: %s</error>', [$directory]);
            $this->quit(1);
        }

        $filenames = array_map('basename', glob($directory . '/*.csv') ?: []);
        $located = Locator::locate($filenames);

        foreach ($located['problems'] as $problem) {
            $this->outputLine('<error>Skipping unrecognized file: %s</error>', [$problem]);
        }

        $binaries = $this->binaries($assetsDir);
        $assembler = new ProductAssembler(new ModelBuilder($this->resolver, $binaries));
        $products = [];
        foreach ($located['pairs'] as $pair) {
            if ($pair->language !== $language) {
                continue;
            }
            $basic = $pair->basic !== null ? $this->bundles($directory, $pair->basic) : [];
            $variants = $pair->variants !== null ? $this->bundles($directory, $pair->variants) : [];
            $products = array_merge($products, $assembler->assemble($basic, $variants, $pair->category, $language));
        }

        $outputDirectory = dirname($output);
        if (!is_dir($outputDirectory) || !is_writable($outputDirectory)) {
            $this->outputLine('<error>Cannot write to %s (output directory missing or not writable)</error>', [$output]);
            $this->quit(1);
        }

        $document = DocumentAssembler::assemble($products);
        $xml = (new XmlSerializer())->serialize($document, (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM), implode(', ', $filenames));
        file_put_contents($output, $xml);

        $this->outputLine('<success>Wrote %d products to %s</success>', [count($products), $output]);
        $this->reportFindings($document);
        if ($binaries !== null) {
            $this->reportBinaries($binaries);
        }
    }

    /**
     * Load a domain XML into the Content Repository — or, with --dry-run, just log the plan.
     *
     * Import en_GB first. Subsequent language imports create dimension variants on the existing
     * node aggregates and set the language-specific text properties.
     *
     * @param string $input Path to the domain XML produced by convert
     * @param string $language Language dimension stored in the XML (must match the convert run)
     * @param bool $dryRun Log the planned node aggregates without writing them
     * @param string $sku Import only the product with this identifier (for a scoped run)
     * @param string $assetsDir Directory of binaries to import (image/downloads); omit to defer assets
     */
    public function importCommand(string $input, string $language = 'en_GB', bool $dryRun = false, string $sku = '', string $assetsDir = ''): void
    {
        if (!is_file($input)) {
            $this->outputLine('<error>Input XML not found: %s</error>', [$input]);
            $this->quit(1);
        }

        $document = (new XmlReader())->read((string)file_get_contents($input));
        if ($sku !== '') {
            $document = $this->onlyProduct($document, $sku);
        }
        $plan = (new ImportPlanner())->plan($document, $language);

        if ($dryRun) {
            $this->reportTargets($this->writer->describeTargets($plan));
            $this->reportPlan($plan);
            return;
        }

        $this->outputLine('Importing %d node aggregates into the Content Repository (%d products skipped)…', [count($plan->operations), count($plan->skipped)]);
        $this->reportWrite($this->writer->write($plan, $assetsDir, $language));
    }

    /**
     * Report a completed write: the count created, properties dropped as undeclared, and assets
     * still awaiting the media-import step.
     */
    private function reportWrite(WriteResult $result): void
    {
        $this->outputLine('<success>Created %d node aggregates (%d products skipped).</success>', [$result->created, $result->skipped]);

        if ($result->droppedProperties !== []) {
            $names = array_map(static fn (string $entry): string => substr($entry, (int)strrpos($entry, '.') + 1), $result->droppedProperties);
            $summary = [];
            foreach (array_count_values($names) as $name => $count) {
                $summary[] = sprintf('%s ×%d', $name, $count);
            }
            $this->outputLine('<comment>Dropped %d undeclared properties: %s</comment>', [count($result->droppedProperties), implode(', ', $summary)]);
        }

        if ($result->importedAssets !== []) {
            $this->outputLine('<success>Imported %d assets: %s</success>', [count($result->importedAssets), implode(', ', $result->importedAssets)]);
        }
        if ($result->missingAssets !== []) {
            $this->outputLine('<error>%d asset files missing: %s</error>', [count($result->missingAssets), implode(', ', $result->missingAssets)]);
        }
        if ($result->deferredAssets !== []) {
            $this->outputLine('<comment>%d assets not imported (no --assets-dir given):</comment>', [count($result->deferredAssets)]);
            foreach ($result->deferredAssets as $asset) {
                $this->outputLine('  %s', [$asset]);
            }
        }
    }

    private function onlyProduct(ImportDocument $document, string $sku): ImportDocument
    {
        $products = array_values(array_filter($document->products, static fn (ImportProduct $product): bool => $product->sku === $sku));
        if ($products === []) {
            $this->outputLine('<error>No product with identifier %s in the XML</error>', [$sku]);
            $this->quit(1);
        }

        return new ImportDocument($products, $document->findings);
    }

    /**
     * Log the folder each category's products will be created under (read from the CR).
     *
     * @param array<string, ?string> $targets
     */
    private function reportTargets(array $targets): void
    {
        $this->outputLine('<comment>Target folders (live workspace, en_GB)</comment>');
        foreach ($targets as $category => $descriptor) {
            if ($descriptor === null) {
                $this->outputLine('  <error>%s → NOT FOUND — create the folder before importing</error>', [$category]);
            } else {
                $this->outputLine('  %s → %s', [$category, $descriptor]);
            }
        }
    }

    /**
     * Log the planned node aggregates as an indented tree, then the skipped products.
     */
    private function reportPlan(ImportPlan $plan): void
    {
        $this->outputLine('<comment>Dry run — no changes written</comment>');

        $depths = $this->depths($plan->operations);
        foreach ($plan->operations as $node) {
            $indent = str_repeat('  ', $depths[$node->nodeAggregateId]);
            $folder = $node->category !== null ? sprintf('  [%s products folder]', $node->category) : '';
            $this->outputLine();
            $this->outputLine('%s<success>CREATE</success> %s  %s%s', [$indent, $this->leafType($node->nodeType), $this->truncate($node->label), $folder]);
            if ($node->properties !== []) {
                $this->outputLine('%s  props:  %s', [$indent, implode(', ', array_keys($node->properties))]);
            }
            foreach ($node->references as $name => $ids) {
                $this->outputLine('%s  ref:    %s → %s', [$indent, $name, implode(', ', $ids)]);
            }
            foreach ($node->assets as $name => $sources) {
                $this->outputLine('%s  asset:  %s → %s', [$indent, $name, implode(', ', $sources)]);
            }
        }

        if ($plan->skipped !== []) {
            $this->outputLine();
            $this->outputLine('<error>Skipped (%d)</error>', [count($plan->skipped)]);
            foreach ($plan->skipped as $skipped) {
                $this->outputLine('  %s — %s', [$skipped->sku, implode('; ', $skipped->reasons)]);
            }
        }

        $this->outputLine();
        $this->outputLine('<comment>Plan: %d node aggregates, %d products skipped</comment>', [count($plan->operations), count($plan->skipped)]);
    }

    /**
     * Tree depth of each operation from its parent chain — for indenting the log.
     *
     * @param \DenkPharma\ProductImport\Loader\PlannedNode[] $operations
     * @return array<string, int>
     */
    private function depths(array $operations): array
    {
        $parents = [];
        foreach ($operations as $node) {
            $parents[$node->nodeAggregateId] = $node->parentNodeAggregateId;
        }

        $depths = [];
        foreach ($operations as $node) {
            $depth = 0;
            $parent = $node->parentNodeAggregateId;
            while ($parent !== null && array_key_exists($parent, $parents)) {
                $depth++;
                $parent = $parents[$parent];
            }
            $depths[$node->nodeAggregateId] = $depth;
        }

        return $depths;
    }

    private function leafType(string $nodeType): string
    {
        $parts = explode('.', substr($nodeType, (int)strpos($nodeType, ':') + 1));

        return (string)end($parts);
    }

    private function truncate(string $label): string
    {
        return mb_strlen($label) > 50 ? mb_substr($label, 0, 49) . '…' : $label;
    }

    /**
     * Read a node and its descendants back from the live CR (read-only) — to verify an import.
     *
     * @param string $nodeId The node aggregate id to inspect
     */
    public function inspectCommand(string $nodeId): void
    {
        $lines = $this->writer->readSubtree($nodeId);
        if ($lines === []) {
            $this->outputLine('<error>No node %s in the live workspace</error>', [$nodeId]);
            $this->quit(1);
        }

        foreach ($lines as $line) {
            $this->outputLine('%s', [$line]);
        }
    }

    /**
     * Build the binary index from the assets directory, feeding it one filename at a time. Returns
     * null when no directory was given; quits when the given one is unusable.
     */
    private function binaries(string $assetsDir): ?BinaryLocator
    {
        if ($assetsDir === '') {
            return null;
        }

        $directory = rtrim($assetsDir, '/');
        if (!is_dir($directory)) {
            $this->outputLine('<error>Assets directory not found: %s</error>', [$directory]);
            $this->quit(1);
        }

        $locator = new BinaryLocator();
        foreach (glob($directory . '/*') ?: [] as $path) {
            if (is_file($path)) {
                $locator->addFile(basename($path));
            }
        }

        return $locator;
    }

    /**
     * Print the binary problems — unallowed extensions, duplicates and unclaimed files. Log only;
     * these never reach the XML.
     */
    private function reportBinaries(BinaryLocator $binaries): void
    {
        $problems = $binaries->problems();
        $labels = ['unallowed' => 'unallowed extension', 'duplicate' => 'duplicate', 'orphan' => 'orphan'];

        $this->outputLine();
        $this->outputLine('Binaries');
        $clean = true;
        foreach ($labels as $key => $label) {
            if ($problems[$key] === []) {
                continue;
            }
            $clean = false;
            $this->outputLine('  <comment>%s</comment> (%d)', [$label, count($problems[$key])]);
            foreach ($problems[$key] as $line) {
                $this->outputLine('    %s', [$line]);
            }
        }
        if ($clean) {
            $this->outputLine('  no problems');
        }
    }

    /**
     * Print every finding grouped by severity and code — the reconciliation worklist for the run.
     */
    private function reportFindings(ImportDocument $document): void
    {
        $byCode = [Severity::Error->value => [], Severity::Warning->value => [], Severity::Notice->value => []];
        foreach (FindingCollector::collect($document) as $finding) {
            $byCode[$finding->severity->value][$finding->code][] = $finding->detail;
        }

        foreach ($byCode as $severity => $codes) {
            $tag = $severity === Severity::Error->value ? 'error' : 'comment';
            foreach ($codes as $code => $details) {
                $this->outputLine();
                $this->outputLine('  <%1$s>%2$s</%1$s> %3$s (%4$d)', [$tag, strtoupper($severity), $code, count($details)]);
                $occurrences = array_count_values(array_map(static fn (?string $detail): string => $detail ?? '', $details));
                ksort($occurrences, SORT_STRING);
                foreach ($occurrences as $detail => $count) {
                    $this->outputLine('    %3d×  %s', [$count, $detail]);
                }
            }
        }
    }

    /**
     * @return \DenkPharma\ProductImport\Converter\ProductBundle[]
     */
    private function bundles(string $directory, string $filename): array
    {
        $content = file_get_contents($directory . '/' . $filename);
        if ($content === false) {
            $this->outputLine('<error>Could not read %s</error>', [$filename]);
            $this->quit(1);
        }

        $mapped = Columns::map(CsvReader::rows((string)$content));
        foreach ($mapped['unknownHeaders'] as $header) {
            $this->outputLine('<comment>Unexpected header in %s: %s</comment>', [$filename, $header]);
        }

        return Segmenter::segment($mapped['rows']);
    }
}
