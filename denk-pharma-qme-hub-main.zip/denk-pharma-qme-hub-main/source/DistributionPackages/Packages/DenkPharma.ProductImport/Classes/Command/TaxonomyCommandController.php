<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Command;

use DenkPharma\ProductImport\Converter\Columns;
use DenkPharma\ProductImport\Converter\CsvReader;
use DenkPharma\ProductImport\Converter\DocumentAssembler;
use DenkPharma\ProductImport\Converter\FindingCollector;
use DenkPharma\ProductImport\Converter\Locator;
use DenkPharma\ProductImport\Converter\ModelBuilder;
use DenkPharma\ProductImport\Converter\ProductAssembler;
use DenkPharma\ProductImport\Converter\Segmenter;
use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Taxonomy\ContentRepositoryTaxonomyResolver;
use DenkPharma\ProductImport\Taxonomy\TaxonomyMappings;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeCreation\Command\CreateNodeAggregateWithNode;
use Neos\ContentRepository\Core\Feature\NodeModification\Command\SetNodeProperties;
use Neos\ContentRepository\Core\Feature\NodeModification\Dto\PropertyValuesToWrite;
use Neos\ContentRepository\Core\Feature\NodeVariation\Command\CreateNodeVariant;
use Neos\ContentRepository\Core\Feature\NodeVariation\Exception\DimensionSpacePointIsAlreadyOccupied;
use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindDescendantNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeName;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;
use Sitegeist\Taxonomy\Service\TaxonomyService;

class TaxonomyCommandController extends CommandController
{
    private const LANGUAGE = 'en_GB';
    private const TAXONOMY_NODE_TYPE = 'Sitegeist.Taxonomy:Taxonomy';

    #[Flow\Inject]
    protected TaxonomyService $taxonomyService;

    #[Flow\Inject]
    protected ContentRepositoryTaxonomyResolver $resolver;

    /**
     * List all unresolved taxonomy terms across every vocabulary by scanning the product CSV files.
     * Read-only — use taxonomy:seed-single to create terms for a specific vocabulary.
     *
     * For non-en_GB languages, terms are split into two groups:
     *   - "needs translation": the en_GB node exists but the local-language title is not yet set
     *   - "needs node": no en_GB equivalent found, a new node aggregate must be created
     *
     * @param string $inputDir Directory of <language>.<category>.<type>.csv files
     * @param string $language Language dimension to scan
     */
    public function seedCommand(string $inputDir, string $language = self::LANGUAGE): void
    {
        $directory = rtrim($inputDir, '/');
        if (!is_dir($directory)) {
            $this->outputLine('<error>Input directory not found: %s</error>', [$directory]);
            $this->quit(1);
        }

        $enSubgraph = $this->buildEnSubgraph();
        $document = $this->buildDocument($directory, $language);
        [$needsNode, $needsTitle] = $this->collectMissing(FindingCollector::collect($document), $enSubgraph, $language);

        if ($needsNode === [] && $needsTitle === []) {
            $this->outputLine('<success>No unresolved taxonomy terms found.</success>');
            return;
        }

        if ($needsNode !== []) {
            $total = array_sum(array_map('count', $needsNode));
            $this->outputLine('Found %d missing term(s) across %d vocabular%s:', [$total, count($needsNode), count($needsNode) === 1 ? 'y' : 'ies']);
            foreach ($needsNode as $vocabulary => $terms) {
                $this->outputLine();
                $this->renderTermTree($vocabulary, $terms);
            }
        }

        if ($needsTitle !== []) {
            if ($needsNode !== []) {
                $this->outputLine();
            }
            $total = array_sum(array_map('count', $needsTitle));
            $this->outputLine('Found %d term(s) needing %s translation across %d vocabular%s:', [
                $total,
                $language,
                count($needsTitle),
                count($needsTitle) === 1 ? 'y' : 'ies',
            ]);
            foreach ($needsTitle as $vocabulary => $terms) {
                $this->outputLine();
                $this->renderTermTree($vocabulary, $terms);
            }
        }
    }

    /**
     * Seed missing taxonomy terms for a single vocabulary by scanning the product CSV files.
     * Use taxonomy:seed first to see what is missing across all vocabularies.
     *
     * For non-en_GB languages, existing en_GB nodes gain a specialised variant with the
     * local-language title instead of creating new node aggregates.
     *
     * @param string $inputDir Directory of <language>.<category>.<type>.csv files
     * @param string $vocabulary Vocabulary to seed, e.g. "administration-form" or "medications"
     * @param bool $dryRun List the terms that would be created without writing them
     * @param string $language Language dimension to scan
     */
    public function seedSingleCommand(string $inputDir, string $vocabulary, bool $dryRun = false, string $language = self::LANGUAGE): void
    {
        $directory = rtrim($inputDir, '/');
        if (!is_dir($directory)) {
            $this->outputLine('<error>Input directory not found: %s</error>', [$directory]);
            $this->quit(1);
        }

        $enSubgraph = $this->buildEnSubgraph();
        $document = $this->buildDocument($directory, $language);
        [$allNeedsNode, $allNeedsTitle] = $this->collectMissing(FindingCollector::collect($document), $enSubgraph, $language);
        $needsNode = isset($allNeedsNode[$vocabulary]) ? [$vocabulary => $allNeedsNode[$vocabulary]] : [];
        $needsTitle = isset($allNeedsTitle[$vocabulary]) ? [$vocabulary => $allNeedsTitle[$vocabulary]] : [];

        if ($needsNode === [] && $needsTitle === []) {
            $this->outputLine('<success>No unresolved terms for vocabulary "%s".</success>', [$vocabulary]);
            return;
        }

        if ($needsNode !== []) {
            $this->renderTermTree($vocabulary, $needsNode[$vocabulary]);
        }
        if ($needsTitle !== []) {
            $this->outputLine('<comment>Terms needing %s translation:</comment>', [$language]);
            $this->renderTermTree($vocabulary, $needsTitle[$vocabulary]);
        }

        if ($dryRun) {
            $this->outputLine();
            $this->outputLine('<comment>Dry run — no changes written.</comment>');
            return;
        }

        $this->outputLine();
        $created = 0;
        $skippedVocabs = 0;
        $translated = 0;

        if ($needsNode !== []) {
            [$c, $s] = $this->seed($needsNode, $enSubgraph, $language);
            $created += $c;
            $skippedVocabs += $s;
        }
        if ($needsTitle !== []) {
            $translated += $this->seedVariantTitles($needsTitle, $enSubgraph, $language);
        }

        $parts = [];
        if ($created > 0) {
            $parts[] = "{$created} term(s) created";
        }
        if ($translated > 0) {
            $parts[] = "{$translated} variant title(s) updated";
        }
        $suffix = $skippedVocabs > 0 ? ' (vocabulary not found)' : '';
        $this->outputLine('<success>Done: %s%s.</success>', [implode(', ', $parts) ?: 'nothing to do', $suffix]);
    }

    /**
     * Render a vocabulary block with terms grouped by their computed parent path.
     * New parent nodes that would be created are marked with "#".
     *
     * @param array<string, string> $terms slug → humanTitle
     */
    private function renderTermTree(string $vocabulary, array $terms): void
    {
        $groups = $this->groupByParent($terms);
        $newParents = array_filter(array_keys($groups), static fn (string $p): bool => $p !== '');
        $label = $newParents !== []
            ? sprintf('%d+%d', count($newParents), count($terms))
            : (string)count($terms);

        $this->outputLine('<comment>%s</comment> (%s)', [$vocabulary, $label]);

        foreach ($groups as $parent => $children) {
            if ($parent !== '') {
                $this->outputLine('  %s', [$parent]);
            }
            $indent = $parent !== '' ? '    ' : '  ';
            foreach ($children as $slug => $humanTitle) {
                $this->outputLine('%s%-40s  %s', [$indent, $slug, $humanTitle]);
            }
        }
    }

    /**
     * Group terms by the parent segment their slugToPath produces.
     * Terms with no parent (flat) are grouped under the '' key, which sorts first.
     *
     * @param array<string, string> $terms slug → humanTitle
     * @return array<string, array<string, string>> parent → [slug => humanTitle]
     */
    private function groupByParent(array $terms): array
    {
        $groups = [];
        foreach ($terms as $slug => $humanTitle) {
            $parent = TaxonomyMappings::parentFromPath(TaxonomyMappings::slugToPath($slug));
            $groups[$parent][$slug] = $humanTitle;
        }
        ksort($groups);
        return $groups;
    }

    /**
     * Run the CSV parsing pipeline and return the assembled document.
     */
    private function buildDocument(string $directory, string $language): \DenkPharma\ProductImport\Model\ImportDocument
    {
        $filenames = array_map('basename', glob($directory . '/*.csv') ?: []);
        $located = Locator::locate($filenames);

        $assembler = new ProductAssembler(new ModelBuilder($this->resolver));
        $products = [];
        foreach ($located['pairs'] as $pair) {
            if ($pair->language !== $language) {
                continue;
            }
            $basic = $pair->basic !== null ? $this->bundles($directory, $pair->basic) : [];
            $variants = $pair->variants !== null ? $this->bundles($directory, $pair->variants) : [];
            $products = array_merge($products, $assembler->assemble($basic, $variants, $pair->category, $language));
        }

        return DocumentAssembler::assemble($products);
    }

    /**
     * Collect unresolved taxonomy findings and split them into two buckets:
     *   [0] needsNode  — vocab → [enSlug => localTitle]  no en_GB node exists yet; must create one
     *   [1] needsTitle — vocab → [enSlug => localTitle]  en_GB node exists; variant title must be set
     *
     * Slugs are always English at this point — TaxonomySubstitution normalises all values to their
     * en_GB equivalents at ingress before ModelBuilder resolves them. For non-en_GB languages,
     * terms that resolve to an existing en_GB node go into needsTitle; everything else into needsNode.
     *
     * @param Finding[] $findings
     * @return array{array<string, array<string, string>>, array<string, array<string, string>>}
     */
    private function collectMissing(array $findings, ContentSubgraphInterface $enSubgraph, string $language): array
    {
        $candidates = [];
        foreach ($findings as $finding) {
            if ($finding->severity !== Severity::Warning || $finding->code !== 'unresolved-taxonomy') {
                continue;
            }
            [$vocabulary, $humanTitle, $slug] = $this->parseDetail($finding->detail ?? '');
            if ($vocabulary === '' || $slug === '') {
                continue;
            }
            $candidates[$vocabulary][$slug] ??= $humanTitle;
        }

        $isEnglish = ($language === self::LANGUAGE);
        $targetSubgraph = $isEnglish ? null : $this->buildSubgraphForLanguage($language);

        $needsNode = [];
        $needsTitle = [];

        foreach ($candidates as $vocabulary => $terms) {
            $enVocabularyNode = $this->taxonomyService->findVocabularyByName($enSubgraph, $vocabulary);

            foreach ($terms as $localSlug => $localTitle) {
                $enSlug = $localSlug;

                $enNodeId = $this->resolver->resolve($vocabulary, $enSlug);
                $enNodeMatches = ($enNodeId === null && $enVocabularyNode !== null)
                    ? $this->findByNodeName($enSlug, $enVocabularyNode->aggregateId, $enSubgraph)
                    : [];

                $enExists = $enNodeId !== null || $enNodeMatches !== [];

                if ($isEnglish) {
                    if (!$enExists) {
                        $needsNode[$vocabulary][$enSlug] ??= $localTitle;
                    }
                    continue;
                }

                if (!$enExists) {
                    $needsNode[$vocabulary][$enSlug] ??= $localTitle;
                    continue;
                }

                // en_GB node exists — check whether the target-language variant already has the right title
                $expectedTitle = TaxonomyMappings::normalizeTaxonomyTitle($vocabulary, $localTitle);
                $targetVocabularyNode = ($enVocabularyNode !== null && $targetSubgraph !== null)
                    ? $this->taxonomyService->findVocabularyByName($targetSubgraph, $vocabulary)
                    : null;
                $targetNodes = ($targetVocabularyNode !== null && $targetSubgraph !== null)
                    ? $this->findByNodeName($enSlug, $targetVocabularyNode->aggregateId, $targetSubgraph)
                    : [];
                $currentTitle = $targetNodes !== [] ? $targetNodes[0]->getProperty('title') : null;

                if ($currentTitle !== $expectedTitle) {
                    $needsTitle[$vocabulary][$enSlug] ??= $localTitle;
                }
            }
        }

        ksort($needsNode);
        ksort($needsTitle);
        foreach ($needsNode as &$terms) {
            ksort($terms);
        }
        foreach ($needsTitle as &$terms) {
            ksort($terms);
        }

        return [$needsNode, $needsTitle];
    }

    /**
     * Parse a finding detail into [vocabulary, humanTitle, slug].
     * Format: "no '<vocab>' term for '<title>'" or "no '<vocab>' term for '<title>' (tried '<slug>')"
     *
     * @return array{string, string, string}
     */
    private function parseDetail(string $detail): array
    {
        if (!preg_match("/^no '([^']+)' term for '([^']+)'(?: \(tried '([^']+)'\))?$/", $detail, $m)) {
            return ['', '', ''];
        }

        return [$m[1], $m[2], isset($m[3]) && $m[3] !== '' ? $m[3] : $m[2]];
    }

    private function buildEnSubgraph(): ContentSubgraphInterface
    {
        return $this->buildSubgraphForLanguage(self::LANGUAGE);
    }

    private function buildSubgraphForLanguage(string $language): ContentSubgraphInterface
    {
        return $this->taxonomyService->getContentRepository()
            ->getContentGraph(WorkspaceName::forLive())
            ->getSubgraph(
                DimensionSpacePoint::fromArray(['language' => $language]),
                VisibilityConstraints::withoutRestrictions(),
            );
    }

    /**
     * Create Sitegeist.Taxonomy:Taxonomy node aggregates for each missing (vocabulary, enSlug) pair.
     * Intermediate parent nodes derived from slugToPath are created first.
     *
     * When $language is not en_GB the node is still created under the en_GB origin (canonical name),
     * but the local-language variant immediately receives the supplied localTitle via SetNodeProperties.
     *
     * @param array<string, array<string, string>> $needsNode vocabulary → [enSlug => localTitle]
     * @return array{int, int} [created, skippedVocabCount]
     */
    private function seed(array $needsNode, ContentSubgraphInterface $enSubgraph, string $language): array
    {
        $contentRepository = $this->taxonomyService->getContentRepository();
        $workspace = WorkspaceName::forLive();
        $enOrigin = OriginDimensionSpacePoint::fromArray(['language' => self::LANGUAGE]);
        $generalizations = $contentRepository->getVariationGraph()->getRootGeneralizations();
        $isEnglish = ($language === self::LANGUAGE);
        $targetOrigin = $isEnglish ? $enOrigin : OriginDimensionSpacePoint::fromArray(['language' => $language]);

        $created = 0;
        $skippedVocabs = 0;

        foreach ($needsNode as $vocabularyName => $terms) {
            $vocabulary = $this->taxonomyService->findVocabularyByName($enSubgraph, $vocabularyName);
            if ($vocabulary === null) {
                $this->outputLine('<error>Vocabulary "%s" not found — skipped</error>', [$vocabularyName]);
                $skippedVocabs++;
                continue;
            }

            // Create any intermediate parent nodes first.
            $parentNodeIds = [];
            foreach ($this->groupByParent($terms) as $parentSlug => $_) {
                if ($parentSlug === '') {
                    continue;
                }
                $matches = $this->findByNodeName($parentSlug, $vocabulary->aggregateId, $enSubgraph);
                if ($matches !== []) {
                    $parentNodeIds[$parentSlug] = $matches[0]->aggregateId;
                    continue;
                }

                $parentAggregateId = NodeAggregateId::create();
                $enTitle = ucwords(str_replace('-', ' ', $parentSlug));
                $contentRepository->handle(
                    CreateNodeAggregateWithNode::create(
                        workspaceName: $workspace,
                        nodeAggregateId: $parentAggregateId,
                        nodeTypeName: NodeTypeName::fromString(self::TAXONOMY_NODE_TYPE),
                        originDimensionSpacePoint: $enOrigin,
                        parentNodeAggregateId: $vocabulary->aggregateId,
                        initialPropertyValues: PropertyValuesToWrite::fromArray(['title' => $enTitle, 'description' => '']),
                    )->withNodeName(NodeName::fromString($parentSlug))
                );
                $this->createVariants($parentAggregateId, $enOrigin, $workspace, $generalizations);
                if (!$isEnglish) {
                    try {
                        $contentRepository->handle(CreateNodeVariant::create($workspace, $parentAggregateId, $enOrigin, $targetOrigin));
                    } catch (DimensionSpacePointIsAlreadyOccupied) {
                    }
                }
                $this->outputLine('  Created  %s / %s  <comment>(parent)</comment>', [$vocabularyName, $parentSlug]);
                $parentNodeIds[$parentSlug] = $parentAggregateId;
                $created++;
            }

            // Create leaf terms under their respective parents.
            foreach ($terms as $enSlug => $localTitle) {
                $matches = $this->findByNodeName($enSlug, $vocabulary->aggregateId, $enSubgraph);
                if (count($matches) > 1) {
                    $this->outputLine('<error>  Ambiguous  %s / %s — %d nodes share that name, skipped</error>', [$vocabularyName, $enSlug, count($matches)]);
                    continue;
                }
                if (count($matches) === 1) {
                    $this->outputLine('  Skipped  %s / %s (node already exists)', [$vocabularyName, $enSlug]);
                    continue;
                }

                $parentSlug = TaxonomyMappings::parentFromPath(TaxonomyMappings::slugToPath($enSlug));
                $parentNodeAggregateId = $parentSlug !== ''
                    ? $parentNodeIds[$parentSlug]
                    : $vocabulary->aggregateId;

                // Use en_GB title: the supplied title if this is an English seed run, otherwise
                // derive from the slug so the en_GB node gets a readable English label.
                $enTitle = $isEnglish
                    ? TaxonomyMappings::normalizeTaxonomyTitle($vocabularyName, $localTitle)
                    : ucwords(str_replace('-', ' ', $enSlug));

                $nodeAggregateId = NodeAggregateId::create();
                $contentRepository->handle(
                    CreateNodeAggregateWithNode::create(
                        workspaceName: $workspace,
                        nodeAggregateId: $nodeAggregateId,
                        nodeTypeName: NodeTypeName::fromString(self::TAXONOMY_NODE_TYPE),
                        originDimensionSpacePoint: $enOrigin,
                        parentNodeAggregateId: $parentNodeAggregateId,
                        initialPropertyValues: PropertyValuesToWrite::fromArray([
                            'title' => $enTitle,
                            'description' => '',
                        ]),
                    )->withNodeName(NodeName::fromString($enSlug))
                );
                $this->createVariants($nodeAggregateId, $enOrigin, $workspace, $generalizations);

                // For non-English seeds ensure the target-language variant exists, then set its title.
                if (!$isEnglish) {
                    try {
                        $contentRepository->handle(CreateNodeVariant::create($workspace, $nodeAggregateId, $enOrigin, $targetOrigin));
                    } catch (DimensionSpacePointIsAlreadyOccupied) {
                    }
                    $localNormalised = TaxonomyMappings::normalizeTaxonomyTitle($vocabularyName, $localTitle);
                    $contentRepository->handle(
                        SetNodeProperties::create(
                            workspaceName: $workspace,
                            nodeAggregateId: $nodeAggregateId,
                            originDimensionSpacePoint: $targetOrigin,
                            propertyValues: PropertyValuesToWrite::fromArray(['title' => $localNormalised]),
                        )
                    );
                }

                $this->outputLine('  Created  %s / %s', [$vocabularyName, TaxonomyMappings::slugToPath($enSlug)]);
                $created++;
            }
        }

        return [$created, $skippedVocabs];
    }

    /**
     * Set the local-language title on existing en_GB node variants.
     * Called when the en_GB node already exists but the target-language variant still carries the
     * English title (or a stale one). Creates the variant first if it does not yet exist.
     *
     * @param array<string, array<string, string>> $needsTitle vocabulary → [enSlug => localTitle]
     */
    private function seedVariantTitles(array $needsTitle, ContentSubgraphInterface $enSubgraph, string $language): int
    {
        $contentRepository = $this->taxonomyService->getContentRepository();
        $workspace = WorkspaceName::forLive();
        $enOrigin = OriginDimensionSpacePoint::fromArray(['language' => self::LANGUAGE]);
        $targetOrigin = OriginDimensionSpacePoint::fromArray(['language' => $language]);
        $targetSubgraph = $this->buildSubgraphForLanguage($language);
        $updated = 0;

        foreach ($needsTitle as $vocabularyName => $terms) {
            $enVocabularyNode = $this->taxonomyService->findVocabularyByName($enSubgraph, $vocabularyName);
            if ($enVocabularyNode === null) {
                $this->outputLine('<error>Vocabulary "%s" not found — skipped</error>', [$vocabularyName]);
                continue;
            }

            foreach ($terms as $enSlug => $localTitle) {
                $enMatches = $this->findByNodeName($enSlug, $enVocabularyNode->aggregateId, $enSubgraph);
                if ($enMatches === []) {
                    $this->outputLine('<error>  Not found  %s / %s in en_GB — skipped</error>', [$vocabularyName, $enSlug]);
                    continue;
                }

                $nodeAggregateId = $enMatches[0]->aggregateId;

                // Ensure the target-language variant exists.
                $targetVocabularyNode = $this->taxonomyService->findVocabularyByName($targetSubgraph, $vocabularyName);
                $targetExists = $targetVocabularyNode !== null
                    && $this->findByNodeName($enSlug, $targetVocabularyNode->aggregateId, $targetSubgraph) !== [];

                if (!$targetExists) {
                    try {
                        $contentRepository->handle(
                            CreateNodeVariant::create($workspace, $nodeAggregateId, $enOrigin, $targetOrigin)
                        );
                    } catch (DimensionSpacePointIsAlreadyOccupied) {
                        // variant exists but was not found via name — proceed to SetNodeProperties
                    }
                }

                $localNormalised = TaxonomyMappings::normalizeTaxonomyTitle($vocabularyName, $localTitle);
                $contentRepository->handle(
                    SetNodeProperties::create(
                        workspaceName: $workspace,
                        nodeAggregateId: $nodeAggregateId,
                        originDimensionSpacePoint: $targetOrigin,
                        propertyValues: PropertyValuesToWrite::fromArray(['title' => $localNormalised]),
                    )
                );

                $this->outputLine('  Translated  %s / %s  →  %s', [$vocabularyName, $enSlug, $localNormalised]);
                $updated++;
            }
        }

        return $updated;
    }

    /**
     * @param \Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint[] $generalizations
     */
    private function createVariants(NodeAggregateId $nodeAggregateId, OriginDimensionSpacePoint $origin, WorkspaceName $workspace, array $generalizations): void
    {
        $contentRepository = $this->taxonomyService->getContentRepository();
        foreach ($generalizations as $dimensionSpacePoint) {
            $otherOrigin = OriginDimensionSpacePoint::fromDimensionSpacePoint($dimensionSpacePoint);
            if ($origin->equals($otherOrigin)) {
                continue;
            }
            $contentRepository->handle(CreateNodeVariant::create($workspace, $nodeAggregateId, $origin, $otherOrigin));
        }
    }

    /**
     * Find all Sitegeist.Taxonomy:Taxonomy descendants of a vocabulary whose node name matches
     * the given slug — at any depth. Returns an empty array (create), one element (skip, exists),
     * or multiple elements (error, ambiguous).
     *
     * @return Node[]
     */
    private function findByNodeName(string $slug, NodeAggregateId $vocabularyId, ContentSubgraphInterface $subgraph): array
    {
        $matches = [];
        foreach ($subgraph->findDescendantNodes($vocabularyId, FindDescendantNodesFilter::create(nodeTypes: self::TAXONOMY_NODE_TYPE)) as $node) {
            if ($node->name?->value === $slug) {
                $matches[] = $node;
            }
        }
        return $matches;
    }

    /**
     * @return \DenkPharma\ProductImport\Converter\ProductBundle[]
     */
    private function bundles(string $directory, string $filename): array
    {
        $content = file_get_contents($directory . '/' . $filename);
        if ($content === false) {
            $this->outputLine('<error>Could not read %s</error>', [$filename]);
            $this->quit(1);
        }

        $mapped = Columns::map(CsvReader::rows((string)$content));
        return Segmenter::segment($mapped['rows']);
    }
}
