<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

/**
 * Indexes the binary import directory by identifier. The command feeds filenames in one at a time
 * via addFile(); the model pulls assets back out during the build — image() for a product (root
 * id), downloads() for a variant. Naming, extension and duplicate problems, plus files that nothing
 * claimed, are reported via problems() as a log; they are deliberately not model findings and never
 * reach the XML.
 */
final class BinaryLocator
{
    private const IMAGE_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];
    private const DOWNLOAD_EXTENSIONS = ['pdf'];
    private const NAME = '/^(DENK_\d+(?:_\d+)?)(?:-(\d+))?$/';

    /** @var array<string, string[]> product id => image filenames */
    private array $images = [];

    /** @var array<string, array<array{counter: ?int, file: string}>> variant id => download entries */
    private array $downloadFiles = [];

    /** @var string[] every filename with an allowed extension (the orphan candidates) */
    private array $allowed = [];

    /** @var array<string, true> filenames handed out to the build */
    private array $consumed = [];

    /** @var string[] filenames whose extension is not allowed */
    private array $unallowed = [];

    public function addFile(string $filename): void
    {
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $isImage = in_array($extension, self::IMAGE_EXTENSIONS, true);
        $isDownload = in_array($extension, self::DOWNLOAD_EXTENSIONS, true);

        if (!$isImage && !$isDownload) {
            $this->unallowed[] = $filename;
            return;
        }

        $this->allowed[] = $filename;

        if (!preg_match(self::NAME, pathinfo($filename, PATHINFO_FILENAME), $match)) {
            return; // allowed extension, but not a DENK identifier — stays unclaimed (orphan)
        }

        $id = $match[1];
        $counter = isset($match[2]) ? (int)$match[2] : null;

        if ($isImage) {
            $this->images[$id][] = $filename;
        } else {
            $this->downloadFiles[$id][] = ['counter' => $counter, 'file' => $filename];
        }
    }

    public function image(string $productId): ?string
    {
        $candidates = $this->images[$productId] ?? [];
        $bare = array_values(array_filter(
            $candidates,
            static fn (string $file): bool => pathinfo($file, PATHINFO_FILENAME) === $productId,
        ));

        if (count($candidates) !== 1 || count($bare) !== 1) {
            return null; // missing, duplicated or counter-suffixed — left for problems()
        }

        $this->consumed[$bare[0]] = true;

        return $bare[0];
    }

    /**
     * @return string[]
     */
    public function downloads(string $variantId): array
    {
        $entries = $this->downloadFiles[$variantId] ?? [];
        if (!$this->downloadsAreConsistent($entries)) {
            return []; // ambiguous naming — left for problems()
        }

        usort($entries, static fn (array $a, array $b): int => ($a['counter'] ?? 0) <=> ($b['counter'] ?? 0));
        $files = array_map(static fn (array $entry): string => $entry['file'], $entries);
        foreach ($files as $file) {
            $this->consumed[$file] = true;
        }

        return $files;
    }

    /**
     * Duplicates and unallowed extensions are intrinsic to the directory; orphans are whatever the
     * build never consumed. Call after building so consumption is complete.
     *
     * @return array{unallowed: string[], duplicate: string[], orphan: string[]}
     */
    public function problems(): array
    {
        $duplicate = [];
        $duplicateFiles = [];
        foreach ($this->images as $id => $files) {
            if (count($files) > 1) {
                $duplicate[] = sprintf('%s image: %s', $id, implode(', ', $this->sorted($files)));
                $duplicateFiles += array_fill_keys($files, true);
            }
        }
        foreach ($this->downloadFiles as $id => $entries) {
            if (!$this->downloadsAreConsistent($entries)) {
                $files = array_map(static fn (array $entry): string => $entry['file'], $entries);
                $duplicate[] = sprintf('%s downloads: %s', $id, implode(', ', $this->sorted($files)));
                $duplicateFiles += array_fill_keys($files, true);
            }
        }

        $orphan = array_values(array_filter(
            $this->allowed,
            fn (string $file): bool => !isset($this->consumed[$file]) && !isset($duplicateFiles[$file]),
        ));

        return [
            'unallowed' => $this->sorted($this->unallowed),
            'duplicate' => $duplicate,
            'orphan' => $this->sorted($orphan),
        ];
    }

    /**
     * @param array<array{counter: ?int, file: string}> $entries
     */
    private function downloadsAreConsistent(array $entries): bool
    {
        if ($entries === []) {
            return true;
        }

        $counters = array_map(static fn (array $entry): ?int => $entry['counter'], $entries);
        if (in_array(null, $counters, true)) {
            return count($entries) === 1; // a counter-less file must stand alone
        }

        return count($counters) === count(array_unique($counters)); // no repeated counter
    }

    /**
     * @param string[] $files
     * @return string[]
     */
    private function sorted(array $files): array
    {
        sort($files);

        return $files;
    }
}
