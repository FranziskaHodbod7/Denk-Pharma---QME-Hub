<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

/**
 * A product grouped out of one CSV file: its identifier row, the blank-id sub-rows attached
 * directly to it, and any variant sub-records. Rows are raw positional cells; semantic
 * interpretation is the model-builder's job.
 */
final class ProductBundle
{
    /**
     * @param string[] $leadRow
     * @param array[] $subRows
     * @param VariantBundle[] $variants
     */
    public function __construct(
        public readonly string $identifier,
        public readonly array $leadRow,
        public readonly array $subRows,
        public readonly array $variants,
    ) {
    }
}
