<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

/**
 * A variant sub-record of a product (e.g. DENK_2345_1): its identifier row plus the blank-id
 * sub-rows attached to it. Rows are raw positional cells; meaning is the model-builder's job.
 */
final class VariantBundle
{
    /**
     * @param string[] $leadRow
     * @param array[] $subRows
     */
    public function __construct(
        public readonly string $identifier,
        public readonly array $leadRow,
        public readonly array $subRows,
    ) {
    }
}
