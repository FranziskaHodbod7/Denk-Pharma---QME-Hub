<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;

/**
 * Serializes the import model to the domain XML. Pure and deterministic — envelope metadata
 * (`generatedAt`, `sources`) is passed in rather than read from the clock. The `m:`/`v:` prefixes
 * are declared once on the root and written as literal names, so the output stays free of the
 * per-element xmlns redeclarations the namespace-aware DOM API would otherwise emit.
 */
final class XmlSerializer
{
    private const NS_RESOLUTION = 'urn:denkpharma:import:resolution';
    private const NS_VALIDATION = 'urn:denkpharma:import:validation';

    public function serialize(ImportDocument $document, string $generatedAt = '', string $sources = ''): string
    {
        $doc = new \DOMDocument('1.0', 'UTF-8');
        $doc->formatOutput = true;

        $root = $doc->createElement('products');
        $doc->appendChild($root);
        $root->setAttribute('xmlns:m', self::NS_RESOLUTION);
        $root->setAttribute('xmlns:v', self::NS_VALIDATION);
        if ($generatedAt !== '') {
            $root->setAttribute('generatedAt', $generatedAt);
        }
        if ($sources !== '') {
            $root->setAttribute('sources', $sources);
        }

        $root->appendChild($this->summary($doc, $document));
        $this->findings($doc, $root, $document->findings);

        foreach ($document->products as $product) {
            $root->appendChild($this->product($doc, $product));
        }

        return (string)$doc->saveXML();
    }

    private function summary(\DOMDocument $doc, ImportDocument $document): \DOMElement
    {
        $counts = [Severity::Error->value => 0, Severity::Warning->value => 0, Severity::Notice->value => 0];
        foreach (FindingCollector::collect($document) as $finding) {
            $counts[$finding->severity->value]++;
        }

        $summary = $doc->createElement('v:summary');
        $summary->setAttribute('products', (string)count($document->products));
        $summary->setAttribute('errors', (string)$counts[Severity::Error->value]);
        $summary->setAttribute('warnings', (string)$counts[Severity::Warning->value]);
        $summary->setAttribute('notices', (string)$counts[Severity::Notice->value]);

        return $summary;
    }

    private function product(\DOMDocument $doc, ImportProduct $product): \DOMElement
    {
        $element = $doc->createElement('product');
        $element->setAttribute('sku', $product->sku);
        $element->setAttribute('m:nodeId', $product->nodeId);
        $element->setAttribute('category', $product->category->value);

        $this->translatable($doc, $element, 'uriPathSegment', $product->uriPathSegment);
        $this->translatable($doc, $element, 'title', $product->title);
        $this->translatable($doc, $element, 'shortDescription', $product->shortDescription);
        $this->translatable($doc, $element, 'longDescription', $product->longDescription);
        $this->translatable($doc, $element, 'ingredients', $product->ingredients);
        $this->translatable($doc, $element, 'storageInstructions', $product->storageInstructions);

        if ($product->image !== null) {
            $image = $doc->createElement('image');
            $image->setAttribute('m:src', $product->image);
            $element->appendChild($image);
        }

        if ($product->medications !== []) {
            $medications = $doc->createElement('medications');
            foreach ($product->medications as $reference) {
                $medications->appendChild($this->reference($doc, 'medication', $reference));
            }
            $element->appendChild($medications);
        }

        if ($product->benefits !== []) {
            $benefits = $doc->createElement('benefits');
            foreach ($product->benefits as $benefit) {
                $node = $doc->createElement('benefit');
                $node->setAttribute('m:nodeId', $benefit->nodeId);
                $this->translatedValues($doc, $node, $benefit->description);
                $this->findings($doc, $node, $benefit->findings);
                $benefits->appendChild($node);
            }
            $element->appendChild($benefits);
        }

        $this->administrations($doc, $element, $product);
        $this->compositions($doc, $element, $product);
        $this->findings($doc, $element, $product->findings);

        return $element;
    }

    private function administrations(\DOMDocument $doc, \DOMElement $product, ImportProduct $importProduct): void
    {
        if ($importProduct->administrations === []) {
            return;
        }

        $administrations = $doc->createElement('administrations');
        foreach ($importProduct->administrations as $administration) {
            $node = $doc->createElement('administration');
            $node->setAttribute('m:nodeId', $administration->nodeId);
            $node->appendChild($this->reference($doc, 'administrationForm', $administration->administrationForm));
            if ($administration->downloads !== []) {
                $downloads = $doc->createElement('downloads');
                foreach ($administration->downloads as $download) {
                    $downloadNode = $doc->createElement('download');
                    $downloadNode->setAttribute('m:src', $download);
                    $downloads->appendChild($downloadNode);
                }
                $node->appendChild($downloads);
            }
            $this->findings($doc, $node, $administration->findings);

            if ($administration->formulations !== []) {
                $formulations = $doc->createElement('formulations');
                foreach ($administration->formulations as $formulation) {
                    $formulationNode = $doc->createElement('formulation');
                    $formulationNode->setAttribute('m:nodeId', $formulation->nodeId);
                    $formulationNode->setAttribute('m:identifier', $formulation->externalIdentifier);
                    if ($formulation->packageQuantity !== null) {
                        $formulationNode->appendChild($this->reference($doc, 'packageQuantity', $formulation->packageQuantity));
                    }
                    $this->translatable($doc, $formulationNode, 'applicationRecommendation', $formulation->applicationRecommendation);

                    if ($formulation->ingredients !== []) {
                        $ingredients = $doc->createElement('ingredients');
                        foreach ($formulation->ingredients as $ingredient) {
                            $ingredientNode = $doc->createElement('ingredient');
                            $ingredientNode->setAttribute('m:nodeId', $ingredient->nodeId);
                            $ingredientNode->setAttribute('quantity', $ingredient->quantity);
                            $ingredientNode->appendChild($this->reference($doc, 'substance', $ingredient->substance));
                            $ingredientNode->appendChild($this->reference($doc, 'unit', $ingredient->unit));
                            $this->findings($doc, $ingredientNode, $ingredient->findings);
                            $ingredients->appendChild($ingredientNode);
                        }
                        $formulationNode->appendChild($ingredients);
                    }

                    $this->findings($doc, $formulationNode, $formulation->findings);
                    $formulations->appendChild($formulationNode);
                }
                $node->appendChild($formulations);
            }

            $administrations->appendChild($node);
        }

        $product->appendChild($administrations);
    }

    private function compositions(\DOMDocument $doc, \DOMElement $product, ImportProduct $importProduct): void
    {
        if ($importProduct->compositions === []) {
            return;
        }

        $compositions = $doc->createElement('compositions');
        foreach ($importProduct->compositions as $composition) {
            $node = $doc->createElement('composition');
            $node->setAttribute('m:nodeId', $composition->nodeId);
            $this->translatable($doc, $node, 'title', $composition->title);

            if ($composition->rows !== []) {
                $rows = $doc->createElement('rows');
                foreach ($composition->rows as $row) {
                    $rowNode = $doc->createElement('row');
                    $rowNode->setAttribute('m:nodeId', $row->nodeId);
                    if ($row->substance !== null) {
                        $rowNode->appendChild($this->reference($doc, 'substance', $row->substance));
                    }
                    $this->translatable($doc, $rowNode, 'substanceText', $row->substanceText);
                    $this->translatable($doc, $rowNode, 'perUnit', $row->perUnit);
                    $this->translatable($doc, $rowNode, 'nrv', $row->nrv);
                    $this->findings($doc, $rowNode, $row->findings);
                    $rows->appendChild($rowNode);
                }
                $node->appendChild($rows);
            }

            $this->findings($doc, $node, $composition->findings);
            $compositions->appendChild($node);
        }

        $product->appendChild($compositions);
    }

    private function reference(\DOMDocument $doc, string $name, Reference $reference): \DOMElement
    {
        $element = $doc->createElement($name);
        $element->appendChild($doc->createTextNode($reference->value));

        if ($reference->nodeId !== null) {
            $element->setAttribute('m:ref', $reference->nodeId);
        } elseif ($reference->finding !== null) {
            $element->setAttribute('v:status', $reference->finding->code);
        }

        return $element;
    }

    private function translatable(\DOMDocument $doc, \DOMElement $parent, string $name, ?TranslatedText $text): void
    {
        if ($text === null) {
            return;
        }

        $element = $doc->createElement($name);
        $this->translatedValues($doc, $element, $text);
        $parent->appendChild($element);
    }

    private function translatedValues(\DOMDocument $doc, \DOMElement $parent, TranslatedText $text): void
    {
        foreach ($text->values as $language => $value) {
            $translation = $doc->createElement('t');
            $translation->setAttribute('lang', (string)$language);
            $translation->appendChild($doc->createTextNode($value));
            $parent->appendChild($translation);
        }
    }

    /**
     * @param Finding[] $findings
     */
    private function findings(\DOMDocument $doc, \DOMElement $parent, array $findings): void
    {
        foreach ($findings as $finding) {
            $issue = $doc->createElement('v:issue');
            $issue->setAttribute('severity', $finding->severity->value);
            $issue->setAttribute('code', $finding->code);
            if ($finding->detail !== null) {
                $issue->setAttribute('detail', $finding->detail);
            }
            $parent->appendChild($issue);
        }
    }
}
