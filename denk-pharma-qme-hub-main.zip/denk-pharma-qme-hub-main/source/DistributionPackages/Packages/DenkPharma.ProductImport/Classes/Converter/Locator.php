<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\ProductCategory;

/**
 * Groups CSV file names following the imposed convention `<language>.<category>.<type>.csv`
 * (e.g. `en_GB.dietary-supplements.basic.csv`) into per-(language, category) pairs. Pure — the
 * caller supplies the directory listing. Non-CSV names are ignored; names that don't fit the
 * convention (or carry an unknown category/type) are reported as problems.
 */
final class Locator
{
    /**
     * @param string[] $filenames
     * @return array ['pairs' => FilePair[], 'problems' => string[]]
     */
    public static function locate(array $filenames): array
    {
        $groups = [];
        $problems = [];

        foreach ($filenames as $filename) {
            if (!str_ends_with($filename, '.csv')) {
                continue;
            }

            $parts = explode('.', substr($filename, 0, -4));
            $category = count($parts) === 3 ? ProductCategory::tryFrom($parts[1]) : null;

            if ($category === null || $parts[0] === '' || !in_array($parts[2], ['basic', 'variants'], true)) {
                $problems[] = $filename;
                continue;
            }

            $key = $parts[0] . '|' . $parts[1];
            $groups[$key] ??= ['language' => $parts[0], 'category' => $category, 'basic' => null, 'variants' => null];
            $groups[$key][$parts[2]] = $filename;
        }

        return [
            'pairs' => array_map(
                static fn (array $group): FilePair => new FilePair($group['language'], $group['category'], $group['basic'], $group['variants']),
                array_values($groups),
            ),
            'problems' => $problems,
        ];
    }
}
