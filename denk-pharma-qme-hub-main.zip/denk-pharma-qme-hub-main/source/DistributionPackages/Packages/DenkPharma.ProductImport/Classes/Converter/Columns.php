<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

/**
 * Maps the import CSVs' awkward, long, multi-line header names to stable clean field names.
 * Matching normalizes headers (collapse whitespace, drop a trailing "*see …" annotation,
 * lowercase), so casing and line breaks don't matter. The per-category Basic layouts are
 * handled by presence: a known header maps to its clean name, an unknown one is reported.
 */
final class Columns
{
    private const VOCABULARY = [
        'product identifier'             => 'productIdentifier',
        'product name'                   => 'productName',
        'short description'              => 'shortDescription',
        'long description'               => 'longDescription',
        'benefits'                       => 'benefits',
        'indication/medication'          => 'indication',
        'dosage form'                    => 'dosageForm',
        'ingredients'                    => 'ingredientsText',
        'ingredients - nutrient'         => 'compositionNutrient',
        'ingredients - per unit'         => 'compositionPerUnit',
        'ingredients - nrv'              => 'compositionNrv',
        'storage recommendation'         => 'storage',
        'pack size'                      => 'packSize',
        'composition - active substance' => 'formulationSubstance',
        'composition - quantity'         => 'formulationQuantity',
        'composition - unit'             => 'formulationUnit',
        'recommended dosage'             => 'applicationRecommendation',
    ];

    public static function normalizeHeader(string $header): string
    {
        $header = (string)preg_replace('/\s+/u', ' ', $header);

        $annotation = strpos($header, '*');
        if ($annotation !== false) {
            $header = substr($header, 0, $annotation);
        }

        return strtolower(trim($header));
    }

    public static function cleanName(string $rawHeader): ?string
    {
        return self::VOCABULARY[self::normalizeHeader($rawHeader)] ?? null;
    }

    /**
     * Remap CSV rows (header at row 0) to clean-keyed associative data rows. Unknown header
     * columns are dropped from the rows and returned separately (for an unexpected-structure
     * finding). Returns ['rows' => clean-keyed data rows, 'unknownHeaders' => string[]].
     *
     * @param array[] $rows
     * @return array
     */
    public static function map(array $rows): array
    {
        if ($rows === []) {
            return ['rows' => [], 'unknownHeaders' => []];
        }

        $header = array_shift($rows);
        $names = [];
        $unknown = [];

        foreach ($header as $index => $rawHeader) {
            $clean = self::cleanName((string)$rawHeader);
            if ($clean !== null) {
                $names[$index] = $clean;
                continue;
            }
            $label = trim((string)preg_replace('/\s+/u', ' ', (string)$rawHeader));
            if ($label !== '') {
                $unknown[] = $label;
            }
        }

        $mapped = [];
        foreach ($rows as $row) {
            $clean = [];
            foreach ($names as $index => $name) {
                $clean[$name] = (string)($row[$index] ?? '');
            }
            $mapped[] = $clean;
        }

        return ['rows' => $mapped, 'unknownHeaders' => $unknown];
    }
}
