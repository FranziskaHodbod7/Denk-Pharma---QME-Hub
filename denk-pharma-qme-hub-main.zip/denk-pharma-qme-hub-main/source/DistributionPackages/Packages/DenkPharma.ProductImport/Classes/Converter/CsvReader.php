<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use League\Csv\Reader;

/**
 * Parses raw CSV content into rectangular, positional rows, preserving order. This stage only
 * handles CSV mechanics — quoted multi-line cells, embedded commas, ragged rows; column meaning
 * is the segmenter's concern. The header is returned as row 0; every row is padded/truncated to
 * the header's column count so downstream index access is safe.
 */
final class CsvReader
{
    /**
     * @return list<list<string>>
     */
    public static function rows(string $content): array
    {
        $reader = Reader::fromString($content);
        $reader->setEscape('');        // RFC 4180: double-quote enclosure only, no backslash escaping
        $reader->skipInputBOM();

        $records = [];
        foreach ($reader->getRecords() as $record) {
            $records[] = array_values($record);
        }

        if ($records === []) {
            return [];
        }

        $width = count($records[0]);

        return array_map(
            static fn (array $row): array => array_pad(array_slice($row, 0, $width), $width, ''),
            $records,
        );
    }
}
