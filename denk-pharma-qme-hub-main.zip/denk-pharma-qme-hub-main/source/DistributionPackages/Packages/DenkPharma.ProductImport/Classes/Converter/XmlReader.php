<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;

/**
 * Parses the domain XML back into the import model — the inverse of {@see XmlSerializer}, and the
 * input half of the CR load step. Reconstructs everything the XML carries: node ids, scalar and
 * translatable fields, resolved/unresolved references, asset sources and `<v:issue>` findings. The
 * `v:summary` and reference `v:status` are lossy by design (severity/detail aren't serialized for
 * references), so an unresolved reference is rebuilt with a warning carrying just its status code.
 */
final class XmlReader
{
    private const NS_RESOLUTION = 'urn:denkpharma:import:resolution';
    private const NS_VALIDATION = 'urn:denkpharma:import:validation';

    public function read(string $xml): ImportDocument
    {
        $document = new \DOMDocument();
        $document->loadXML($xml);
        $root = $document->documentElement;

        $products = array_map(fn (\DOMElement $el): ImportProduct => $this->product($el), $this->children($root, 'product'));

        return new ImportDocument($products, $this->findings($root));
    }

    private function product(\DOMElement $el): ImportProduct
    {
        $image = $this->child($el, 'image');

        return new ImportProduct(
            sku: $el->getAttribute('sku'),
            category: ProductCategory::from($el->getAttribute('category')),
            nodeId: $el->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
            uriPathSegment: $this->translatable($el, 'uriPathSegment'),
            title: $this->translatable($el, 'title'),
            shortDescription: $this->translatable($el, 'shortDescription'),
            longDescription: $this->translatable($el, 'longDescription'),
            ingredients: $this->translatable($el, 'ingredients'),
            storageInstructions: $this->translatable($el, 'storageInstructions'),
            image: $image?->getAttributeNS(self::NS_RESOLUTION, 'src'),
            medications: array_map(fn (\DOMElement $r): Reference => $this->reference($r), $this->collection($el, 'medications', 'medication')),
            benefits: $this->benefits($el),
            administrations: $this->administrations($el),
            compositions: $this->compositions($el),
            findings: $this->findings($el),
        );
    }

    /**
     * @return ImportBenefit[]
     */
    private function benefits(\DOMElement $el): array
    {
        return array_map(
            fn (\DOMElement $b): ImportBenefit => new ImportBenefit(
                $b->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                $this->translatedValues($b),
                $this->findings($b),
            ),
            $this->collection($el, 'benefits', 'benefit'),
        );
    }

    /**
     * @return ImportAdministration[]
     */
    private function administrations(\DOMElement $el): array
    {
        return array_map(
            fn (\DOMElement $a): ImportAdministration => new ImportAdministration(
                $a->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                $this->reference($this->child($a, 'administrationForm')),
                array_map(fn (\DOMElement $d): string => $d->getAttributeNS(self::NS_RESOLUTION, 'src'), $this->collection($a, 'downloads', 'download')),
                $this->formulations($a),
                $this->findings($a),
            ),
            $this->collection($el, 'administrations', 'administration'),
        );
    }

    /**
     * @return ImportFormulation[]
     */
    private function formulations(\DOMElement $el): array
    {
        return array_map(
            function (\DOMElement $f): ImportFormulation {
                $package = $this->child($f, 'packageQuantity');

                return new ImportFormulation(
                    $f->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                    $f->getAttributeNS(self::NS_RESOLUTION, 'identifier'),
                    $package !== null ? $this->reference($package) : null,
                    $this->translatable($f, 'applicationRecommendation'),
                    $this->ingredients($f),
                    $this->findings($f),
                );
            },
            $this->collection($el, 'formulations', 'formulation'),
        );
    }

    /**
     * @return ImportIngredient[]
     */
    private function ingredients(\DOMElement $el): array
    {
        return array_map(
            fn (\DOMElement $i): ImportIngredient => new ImportIngredient(
                $i->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                $this->reference($this->child($i, 'substance')),
                $this->reference($this->child($i, 'unit')),
                $i->getAttribute('quantity'),
                $this->findings($i),
            ),
            $this->collection($el, 'ingredients', 'ingredient'),
        );
    }

    /**
     * @return ImportComposition[]
     */
    private function compositions(\DOMElement $el): array
    {
        return array_map(
            fn (\DOMElement $c): ImportComposition => new ImportComposition(
                $c->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                $this->translatable($c, 'title'),
                $this->rows($c),
                $this->findings($c),
            ),
            $this->collection($el, 'compositions', 'composition'),
        );
    }

    /**
     * @return ImportCompositionRow[]
     */
    private function rows(\DOMElement $el): array
    {
        return array_map(
            function (\DOMElement $r): ImportCompositionRow {
                $substance = $this->child($r, 'substance');

                return new ImportCompositionRow(
                    $r->getAttributeNS(self::NS_RESOLUTION, 'nodeId'),
                    $substance !== null ? $this->reference($substance) : null,
                    $this->translatable($r, 'substanceText'),
                    $this->translatable($r, 'perUnit'),
                    $this->translatable($r, 'nrv'),
                    $this->findings($r),
                );
            },
            $this->collection($el, 'rows', 'row'),
        );
    }

    private function reference(\DOMElement $el): Reference
    {
        $value = $el->textContent;
        $nodeId = $el->getAttributeNS(self::NS_RESOLUTION, 'ref');
        if ($nodeId !== '') {
            return Reference::resolved($value, $nodeId);
        }

        return Reference::unresolved($value, new Finding(Severity::Warning, $el->getAttributeNS(self::NS_VALIDATION, 'status'), null));
    }

    private function translatable(\DOMElement $parent, string $localName): ?TranslatedText
    {
        $el = $this->child($parent, $localName);

        return $el !== null ? $this->translatedValues($el) : null;
    }

    private function translatedValues(\DOMElement $el): ?TranslatedText
    {
        $text = null;
        foreach ($this->children($el, 't') as $translation) {
            $language = $translation->getAttribute('lang');
            $text = $text === null
                ? TranslatedText::in($language, $translation->textContent)
                : $text->with($language, $translation->textContent);
        }

        return $text;
    }

    /**
     * @return Finding[]
     */
    private function findings(\DOMElement $el): array
    {
        $findings = [];
        foreach ($el->childNodes as $child) {
            if ($child instanceof \DOMElement && $child->namespaceURI === self::NS_VALIDATION && $child->localName === 'issue') {
                $findings[] = new Finding(
                    Severity::from($child->getAttribute('severity')),
                    $child->getAttribute('code'),
                    $child->hasAttribute('detail') ? $child->getAttribute('detail') : null,
                );
            }
        }

        return $findings;
    }

    /**
     * The items of a wrapper element (e.g. the `<medication>`s inside `<medications>`).
     *
     * @return \DOMElement[]
     */
    private function collection(\DOMElement $parent, string $wrapper, string $item): array
    {
        $wrap = $this->child($parent, $wrapper);

        return $wrap !== null ? $this->children($wrap, $item) : [];
    }

    /**
     * @return \DOMElement[]
     */
    private function children(\DOMElement $el, string $localName): array
    {
        $out = [];
        foreach ($el->childNodes as $child) {
            if ($child instanceof \DOMElement && $child->namespaceURI === null && ($child->localName ?? $child->nodeName) === $localName) {
                $out[] = $child;
            }
        }

        return $out;
    }

    private function child(\DOMElement $el, string $localName): ?\DOMElement
    {
        return $this->children($el, $localName)[0] ?? null;
    }
}
