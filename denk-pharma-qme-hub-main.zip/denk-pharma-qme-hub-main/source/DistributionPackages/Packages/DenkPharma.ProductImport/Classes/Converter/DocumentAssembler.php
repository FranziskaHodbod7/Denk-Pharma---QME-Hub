<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\Severity;

/**
 * Wraps the products built across all sources into one document. A SKU used by more than one product
 * is a duplicate identifier: every product carrying it is stamped with an error so none are imported
 * (no dedup). Keeping the error on the products — not the document — means importability is a
 * per-product check: skip any product whose subtree holds an error finding.
 */
final class DocumentAssembler
{
    /**
     * @param ImportProduct[] $products
     */
    public static function assemble(array $products): ImportDocument
    {
        $counts = [];
        foreach ($products as $product) {
            $counts[$product->sku] = ($counts[$product->sku] ?? 0) + 1;
        }

        $gated = array_map(
            static fn (ImportProduct $product): ImportProduct => $counts[$product->sku] > 1
                ? $product->withFinding(new Finding(
                    Severity::Error,
                    'duplicate-identifier',
                    sprintf('%s is used by %d products; none are imported', $product->sku, $counts[$product->sku]),
                ))
                : $product,
            $products,
        );

        return new ImportDocument($gated);
    }
}
