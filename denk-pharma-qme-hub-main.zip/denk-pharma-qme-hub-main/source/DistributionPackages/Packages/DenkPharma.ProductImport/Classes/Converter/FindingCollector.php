<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportDocument;

/**
 * Walks the whole import tree and gathers every finding — the node-level findings and the ones
 * carried by unresolved references alike. The serializer uses it for the summary counts; the
 * convert command uses it to print the breakdown.
 */
final class FindingCollector
{
    /**
     * @return Finding[]
     */
    public static function collect(ImportDocument $document): array
    {
        $findings = $document->findings;
        foreach ($document->products as $product) {
            array_push($findings, ...$product->findings);
            foreach ($product->medications as $reference) {
                if ($reference->finding !== null) {
                    $findings[] = $reference->finding;
                }
            }
            foreach ($product->benefits as $benefit) {
                array_push($findings, ...$benefit->findings);
            }
            foreach ($product->administrations as $administration) {
                array_push($findings, ...$administration->findings);
                if ($administration->administrationForm->finding !== null) {
                    $findings[] = $administration->administrationForm->finding;
                }
                foreach ($administration->formulations as $formulation) {
                    array_push($findings, ...$formulation->findings);
                    if ($formulation->packageQuantity?->finding !== null) {
                        $findings[] = $formulation->packageQuantity->finding;
                    }
                    foreach ($formulation->ingredients as $ingredient) {
                        array_push($findings, ...$ingredient->findings);
                        if ($ingredient->substance->finding !== null) {
                            $findings[] = $ingredient->substance->finding;
                        }
                        if ($ingredient->unit->finding !== null) {
                            $findings[] = $ingredient->unit->finding;
                        }
                    }
                }
            }
            self::compositionFindings($product->compositions, $findings);
        }

        return $findings;
    }

    /**
     * @param ImportComposition[] $compositions
     * @param Finding[] $findings
     */
    private static function compositionFindings(array $compositions, array &$findings): void
    {
        foreach ($compositions as $composition) {
            array_push($findings, ...$composition->findings);
            foreach ($composition->rows as $row) {
                array_push($findings, ...$row->findings);
                if ($row->substance?->finding !== null) {
                    $findings[] = $row->substance->finding;
                }
            }
        }
    }
}
