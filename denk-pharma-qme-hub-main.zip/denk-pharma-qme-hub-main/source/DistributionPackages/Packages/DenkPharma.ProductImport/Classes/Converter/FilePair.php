<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\ProductCategory;

/**
 * The Basic + Variants file pair for one (language, category), located by the naming convention
 * `<language>.<category>.<type>.csv`. Either half may be missing.
 */
final class FilePair
{
    public function __construct(
        public readonly string $language,
        public readonly ProductCategory $category,
        public readonly ?string $basic,
        public readonly ?string $variants,
    ) {
    }
}
