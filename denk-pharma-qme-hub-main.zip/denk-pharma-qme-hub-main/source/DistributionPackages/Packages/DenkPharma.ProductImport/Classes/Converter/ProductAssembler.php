<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;

/**
 * Pairs the Basic and Variants bundles of one (language, category) by SKU and builds a product for
 * each distinct SKU — Basic order first, then any Variants-only SKUs.
 */
final class ProductAssembler
{
    public function __construct(private readonly ModelBuilder $builder)
    {
    }

    /**
     * @param ProductBundle[] $basic
     * @param ProductBundle[] $variants
     * @return ImportProduct[]
     */
    public function assemble(array $basic, array $variants, ProductCategory $category, string $language): array
    {
        $basicBySku = $this->byIdentifier($basic);
        $variantsBySku = $this->byIdentifier($variants);

        $products = [];
        foreach (array_keys($basicBySku + $variantsBySku) as $sku) {
            $products[] = $this->builder->build(
                $basicBySku[$sku] ?? null,
                $variantsBySku[$sku] ?? null,
                $category,
                $language,
            );
        }

        return $products;
    }

    /**
     * @param ProductBundle[] $bundles
     * @return array<string, ProductBundle>
     */
    private function byIdentifier(array $bundles): array
    {
        $byIdentifier = [];
        foreach ($bundles as $bundle) {
            $byIdentifier[$bundle->identifier] = $bundle;
        }

        return $byIdentifier;
    }
}
