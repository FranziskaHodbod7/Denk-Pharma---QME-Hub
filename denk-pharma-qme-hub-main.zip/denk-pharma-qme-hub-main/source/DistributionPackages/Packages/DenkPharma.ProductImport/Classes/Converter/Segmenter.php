<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

/**
 * Groups the clean-keyed rows of a single CSV file into product bundles, using only the
 * `productIdentifier` column and row emptiness — no other domain semantics. A `DENK_<n>` row
 * opens a product, a `DENK_<n>_<m>` row opens a variant under it, a fully blank row is a
 * separator, and any other non-empty row is a sub-row attached to the current variant (or, if
 * none yet, the current product).
 */
final class Segmenter
{
    /**
     * @param array[] $dataRows clean-keyed rows (header already mapped away)
     * @return ProductBundle[]
     */
    public static function segment(array $dataRows): array
    {
        $products = [];
        $productIndex = -1;
        $variantIndex = -1;

        foreach ($dataRows as $row) {
            $id = trim((string)($row['productIdentifier'] ?? ''));

            if (preg_match('/^DENK_\d+$/', $id) === 1) {
                $products[] = ['identifier' => $id, 'leadRow' => $row, 'subRows' => [], 'variants' => []];
                $productIndex = array_key_last($products);
                $variantIndex = -1;
                continue;
            }

            if (preg_match('/^DENK_\d+_\d+$/', $id) === 1) {
                if ($productIndex === -1) {
                    $products[] = [
                        'identifier' => (string)preg_replace('/_\d+$/', '', $id),
                        'leadRow' => [],
                        'subRows' => [],
                        'variants' => [],
                    ];
                    $productIndex = array_key_last($products);
                }
                $products[$productIndex]['variants'][] = ['identifier' => $id, 'leadRow' => $row, 'subRows' => []];
                $variantIndex = array_key_last($products[$productIndex]['variants']);
                continue;
            }

            if (self::isBlank($row)) {
                continue;
            }

            if ($productIndex === -1) {
                continue;
            }

            if ($variantIndex >= 0) {
                $products[$productIndex]['variants'][$variantIndex]['subRows'][] = $row;
            } else {
                $products[$productIndex]['subRows'][] = $row;
            }
        }

        return array_map(self::toBundle(...), $products);
    }

    /**
     * @param string[] $row
     */
    private static function isBlank(array $row): bool
    {
        foreach ($row as $cell) {
            if (trim((string)$cell) !== '') {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array $product
     */
    private static function toBundle(array $product): ProductBundle
    {
        $variants = array_map(
            static fn (array $variant): VariantBundle => new VariantBundle(
                $variant['identifier'],
                $variant['leadRow'],
                $variant['subRows'],
            ),
            $product['variants'],
        );

        return new ProductBundle($product['identifier'], $product['leadRow'], $product['subRows'], $variants);
    }
}
