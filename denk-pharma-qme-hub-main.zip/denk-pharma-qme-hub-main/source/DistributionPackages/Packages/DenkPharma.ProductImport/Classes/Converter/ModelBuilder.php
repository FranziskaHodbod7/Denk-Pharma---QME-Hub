<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Converter;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;
use DenkPharma\ProductImport\Taxonomy\TaxonomyMappings;
use DenkPharma\ProductImport\Taxonomy\TaxonomyResolver;
use DenkPharma\ProductImport\Taxonomy\TaxonomySubstitution;
use DenkPharma\ProductImport\Util\CommaList;
use DenkPharma\ProductImport\Util\LineList;
use DenkPharma\ProductImport\Util\NodeId;
use DenkPharma\ProductImport\Util\Parenthetical;
use DenkPharma\ProductImport\Util\Quantity;
use DenkPharma\ProductImport\Util\Slug;
use DenkPharma\ProductImport\Util\TaxonomyValue;
use DenkPharma\ProductImport\Util\Text;

/**
 * Builds the intent-shaped product model from one product's (Basic, Variants) bundle pair,
 * resolving taxonomy references and accruing findings as it goes. Pure given the injected
 * resolver, so it tests against the in-memory fake.
 */
final class ModelBuilder
{
    private const ROOT_MEDICATIONS = 'medications';
    private const ROOT_ADMINISTRATION_FORM = 'administration-form';
    private const ROOT_PACKAGING = 'packaging';
    private const ROOT_SUBSTANCE = 'substance';
    private const ROOT_SUBSTANCE_UNIT = 'substance-unit';

    private string $language = '';

    public function __construct(
        private readonly TaxonomyResolver $resolver,
        private readonly ?BinaryLocator $binaries = null,
    ) {
    }

    public function build(
        ?ProductBundle $basic,
        ?ProductBundle $variants,
        ProductCategory $category,
        string $language,
    ): ImportProduct {
        $this->language = $language;
        $lead = $basic?->leadRow ?? $variants?->leadRow ?? [];
        $sku = $basic?->identifier ?? $variants?->identifier ?? '';
        $name = Text::singleLine((string)($lead['productName'] ?? ''));

        $findings = [];
        if ($basic === null) {
            $findings[] = new Finding(Severity::Error, 'missing-master', sprintf('product %s has no Basic-data master row', $sku));
        }

        $administrations = $this->administrations($variants, $sku, $language);
        $this->checkDosageFormMismatch($basic, $administrations, $findings);

        return new ImportProduct(
            sku: $sku,
            category: $category,
            nodeId: NodeId::for($sku),
            uriPathSegment: TranslatedText::in($language, Slug::fromTitle($name)),
            title: TranslatedText::in($language, $name),
            shortDescription: $this->text((string)($lead['shortDescription'] ?? ''), $language),
            longDescription: $this->text((string)($lead['longDescription'] ?? ''), $language),
            ingredients: $this->text((string)($lead['ingredientsText'] ?? ''), $language),
            storageInstructions: $this->text((string)($lead['storage'] ?? ''), $language),
            image: $this->binaries?->image($sku),
            medications: $this->medications((string)($lead['indication'] ?? '')),
            benefits: $this->benefits((string)($lead['benefits'] ?? ''), $sku, $language),
            administrations: $administrations,
            compositions: $this->compositions($basic, $sku, $language),
            findings: $findings,
        );
    }

    private function text(string $value, string $language): ?TranslatedText
    {
        $value = trim($value);

        return $value === '' ? null : TranslatedText::in($language, $value);
    }

    /**
     * @return Reference[]
     */
    private function medications(string $value): array
    {
        return array_map(
            fn (string $indication): Reference => $this->reference($indication, self::ROOT_MEDICATIONS),
            CommaList::split($value),
        );
    }

    /**
     * @return ImportBenefit[]
     */
    private function benefits(string $value, string $sku, string $language): array
    {
        $benefits = [];
        foreach (LineList::split($value) as $index => $line) {
            $benefits[] = new ImportBenefit(
                NodeId::for($sku, 'benefit', (string)$index),
                TranslatedText::in($language, $line),
                [],
            );
        }

        return $benefits;
    }

    /**
     * Group the product's variant rows by their (atomic) dosage-form value — one administration per
     * distinct value. Each variant row is a formulation; extra pack-size sub-rows become sibling
     * formulations under the same administration; substance sub-rows become its ingredients.
     *
     * @return ImportAdministration[]
     */
    private function administrations(?ProductBundle $variants, string $sku, string $language): array
    {
        if ($variants === null) {
            return [];
        }

        $byForm = [];
        $previousForm = '';

        foreach ($variants->variants as $variant) {
            $lead = $variant->leadRow;
            $form = trim((string)($lead['dosageForm'] ?? '')) ?: $previousForm;
            $form = TaxonomySubstitution::normalize($language, self::ROOT_ADMINISTRATION_FORM, $form);
            $previousForm = $form;
            $recommendation = $this->text((string)($lead['applicationRecommendation'] ?? ''), $language);

            if (!isset($byForm[$form])) {
                $byForm[$form] = [
                    'ref' => $this->reference($form, self::ROOT_ADMINISTRATION_FORM),
                    'downloads' => [],
                    'formulations' => [],
                    'findings' => [],
                ];
            }
            $byForm[$form]['downloads'] = array_merge(
                $byForm[$form]['downloads'],
                $this->binaries?->downloads($variant->identifier) ?? [],
            );

            $ingredients = [];
            $extraPacks = [];
            $orphaned = false;
            foreach ($variant->subRows as $sub) {
                $strayForm = trim((string)($sub['dosageForm'] ?? ''));
                if ($strayForm !== '') {
                    // A dosage form on a sub-row is a new administration that lost its variant id;
                    // it and everything following it in this variant is a data error — flag and discard.
                    $byForm[$form]['findings'][] = new Finding(
                        Severity::Error,
                        'orphan-row',
                        sprintf("stray dosage row '%s' under %s has no variant id; it and its rows were dropped", $strayForm, $variant->identifier),
                    );
                    $orphaned = true;
                    continue;
                }
                if ($orphaned) {
                    continue;
                }
                if (trim((string)($sub['formulationSubstance'] ?? '')) !== '') {
                    $ingredients[] = $this->ingredient($sub, $variant->identifier, count($ingredients));
                } elseif (trim((string)($sub['packSize'] ?? '')) !== '') {
                    $extraPacks[] = TaxonomySubstitution::normalize($language, self::ROOT_PACKAGING, trim((string)$sub['packSize']));
                }
            }

            $byForm[$form]['formulations'][] = $this->formulation(
                NodeId::for($variant->identifier),
                $variant->identifier,
                trim((string)($lead['packSize'] ?? '')),
                $recommendation,
                $ingredients,
            );
            foreach ($extraPacks as $pack) {
                $byForm[$form]['formulations'][] = $this->formulation(
                    NodeId::for($variant->identifier, $pack),
                    '',
                    $pack,
                    $recommendation,
                    [],
                );
            }
        }

        $administrations = [];
        foreach ($byForm as $form => $group) {
            $administrations[] = new ImportAdministration(
                NodeId::for($sku, 'administration', $form),
                $group['ref'],
                $group['downloads'],
                $group['formulations'],
                $group['findings'],
            );
        }

        return $administrations;
    }

    /**
     * @param ImportIngredient[] $ingredients
     */
    private function formulation(string $nodeId, string $externalIdentifier, string $packSize, ?TranslatedText $recommendation, array $ingredients): ImportFormulation
    {
        $packageQuantity = $packSize !== '' ? $this->reference($packSize, self::ROOT_PACKAGING) : null;

        return new ImportFormulation($nodeId, $externalIdentifier, $packageQuantity, $recommendation, $ingredients, []);
    }

    /**
     * @param string[] $sub
     */
    private function ingredient(array $sub, string $variantId, int $index): ImportIngredient
    {
        $rawQuantity = trim((string)($sub['formulationQuantity'] ?? ''));
        $quantity = Quantity::normalize($rawQuantity);

        $findings = [];
        if ($quantity === null) {
            $findings[] = new Finding(Severity::Warning, 'quantity-not-numeric', sprintf("quantity '%s' is not numeric", $rawQuantity));
        }

        return new ImportIngredient(
            NodeId::for($variantId, 'ingredient', (string)$index),
            $this->reference(trim((string)($sub['formulationSubstance'] ?? '')), self::ROOT_SUBSTANCE),
            $this->reference(trim((string)($sub['formulationUnit'] ?? '')), self::ROOT_SUBSTANCE_UNIT),
            $quantity ?? $rawQuantity,
            $findings,
        );
    }

    /**
     * Collapse the Basic bundle's nutrient sub-rows into composition table(s).
     *
     * A row with a non-empty nutrient label but no per-unit and no NRV value is a section
     * separator that starts a new named table. When no separators are present a single
     * untitled table is returned, preserving the original behaviour.
     *
     * @return ImportComposition[]
     */
    private function compositions(?ProductBundle $basic, string $sku, string $language): array
    {
        if ($basic === null) {
            return [];
        }

        $groups = [];           // list of [?string $title, ImportCompositionRow[] $rows]
        $currentTitle = null;
        $currentRows = [];
        $hasSeparators = false;

        foreach ($basic->subRows as $index => $sub) {
            $nutrient = trim((string)($sub['compositionNutrient'] ?? ''));
            if ($nutrient === '') {
                continue;
            }

            $perUnit = trim((string)($sub['compositionPerUnit'] ?? ''));
            $nrv = trim((string)($sub['compositionNrv'] ?? ''));

            if ($perUnit === '' && $nrv === '') {
                // Separator row: flush current group and open a new named table
                $hasSeparators = true;
                if ($currentTitle !== null || $currentRows !== []) {
                    $groups[] = [$currentTitle, $currentRows];
                }
                $currentTitle = $nutrient;
                $currentRows = [];
            } else {
                $currentRows[] = $this->compositionRow($sub, $nutrient, $sku, $index, $language);
            }
        }

        if ($currentTitle !== null || $currentRows !== []) {
            $groups[] = [$currentTitle, $currentRows];
        }

        if ($groups === []) {
            return [];
        }

        if (!$hasSeparators) {
            return [new ImportComposition(NodeId::for($sku, 'composition'), null, $groups[0][1], [])];
        }

        $compositions = [];
        foreach ($groups as $tableIndex => [$title, $rows]) {
            $compositions[] = new ImportComposition(
                NodeId::for($sku, 'composition', (string)$tableIndex),
                $title !== null ? TranslatedText::in($language, $title) : null,
                $rows,
                [],
            );
        }

        return $compositions;
    }

    /**
     * @param string[] $sub
     */
    private function compositionRow(array $sub, string $nutrient, string $sku, int $index, string $language): ImportCompositionRow
    {
        $parts = Parenthetical::from(TaxonomySubstitution::normalize($language, self::ROOT_SUBSTANCE, $nutrient));
        $candidate = TaxonomyValue::isKebabCase($parts->base) ? $parts->base : Slug::fromTitle($parts->base);
        $nodeId = $candidate !== '' ? $this->resolver->resolve(self::ROOT_SUBSTANCE, $candidate) : null;

        $findings = [];
        if ($nodeId !== null) {
            $substance = Reference::resolved($candidate, $nodeId);
            $substanceText = $parts->note !== null ? TranslatedText::in($language, $parts->note) : null;
        } else {
            $substance = null;
            $substanceText = TranslatedText::in($language, $nutrient);
            $findings[] = new Finding(Severity::Notice, 'substance-freeform', sprintf("'%s' kept as free text", $nutrient));
        }

        return new ImportCompositionRow(
            NodeId::for($sku, 'composition-row', (string)$index),
            $substance,
            $substanceText,
            $this->text((string)($sub['compositionPerUnit'] ?? ''), $language),
            $this->text((string)($sub['compositionNrv'] ?? ''), $language),
            $findings,
        );
    }

    /**
     * The Variants file is authoritative for administration forms; flag (but don't act on) a Basic
     * dosage form that doesn't appear among them. Compared slugified so formatting differences
     * (e.g. "film coated tablet" vs "film-coated-tablet") aren't false positives.
     *
     * @param ImportAdministration[] $administrations
     * @param Finding[] $findings
     */
    private function checkDosageFormMismatch(?ProductBundle $basic, array $administrations, array &$findings): void
    {
        if ($basic === null || $administrations === []) {
            return;
        }
        $basicForm = trim((string)($basic->leadRow['dosageForm'] ?? ''));
        if ($basicForm === '') {
            return;
        }

        $variantForms = array_map(static fn (ImportAdministration $a): string => $a->administrationForm->value, $administrations);
        if (!in_array(Slug::fromTitle($basicForm), $variantForms, true)) {
            $findings[] = new Finding(
                Severity::Notice,
                'dosageform-mismatch',
                sprintf("Basic dosage form '%s' is not among the Variants forms; Variants used", $basicForm),
            );
        }
    }

    /**
     * Resolve a value to a taxonomy node. Titles are expected kebab-case, but the source is
     * human-supplied: a non-kebab value is slugified and retried. When the slug resolves we keep
     * the slug (not the original) as the stored value; only an outright miss keeps the original.
     */
    private function reference(string $value, string $root): Reference
    {
        $value = TaxonomySubstitution::normalize($this->language, $root, $value);
        $normalized = TaxonomyMappings::normalizeTaxonomyName($root, $value);
        $candidate = TaxonomyValue::isKebabCase($normalized) ? $normalized : Slug::fromTitle($normalized);
        $nodeId = $candidate !== '' ? $this->resolver->resolve($root, $candidate) : null;

        if ($nodeId !== null) {
            return Reference::resolved($candidate, $nodeId);
        }

        $detail = $candidate === $value
            ? sprintf("no '%s' term for '%s'", $root, $value)
            : sprintf("no '%s' term for '%s' (tried '%s')", $root, $value, $candidate);

        return Reference::unresolved($value, new Finding(Severity::Warning, 'unresolved-taxonomy', $detail));
    }
}
