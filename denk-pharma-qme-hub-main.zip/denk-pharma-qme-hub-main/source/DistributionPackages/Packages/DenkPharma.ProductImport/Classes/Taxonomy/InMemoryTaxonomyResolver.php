<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Taxonomy;

/**
 * A taxonomy resolver backed by a plain in-memory vocabulary — used in tests so the pure converter
 * stages can be exercised without a content repository.
 */
final class InMemoryTaxonomyResolver implements TaxonomyResolver
{
    /**
     * @param array $byRoot root => [value => nodeId]
     */
    public function __construct(private readonly array $byRoot)
    {
    }

    public function resolve(string $root, string $value): ?string
    {
        return $this->byRoot[$root][$value] ?? null;
    }
}
