<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Taxonomy;

/**
 * Single source of truth for all taxonomy mapping and path-generation rules.
 *
 * Every method has an explicit match arm for known exceptions and a `default`
 * that applies the general algorithm. Add new exceptions here rather than
 * scattering them across ModelBuilder or TaxonomyCommandController.
 */
final class TaxonomyMappings
{
    /**
     * Normalise a raw CSV value to the human-readable title stored on the taxon node.
     * This runs alongside normalizeTaxonomyName: the name produces the slug, this produces the title.
     *
     * Default: keep the raw value as-is (symbols stay symbols, slugs stay slugs).
     * Exceptions: word forms that should display as their canonical symbol/abbreviation.
     *
     * Examples:
     *   ('substance-unit', '%')          → %         (symbol kept)
     *   ('substance-unit', 'percentage') → %         (word → canonical symbol)
     *   ('substance-unit', 'μg')         → μg        (symbol kept)
     */
    public static function normalizeTaxonomyTitle(string $vocabulary, string $raw): string
    {
        return match ($vocabulary) {
            'substance-unit' => match ($raw) {
                'percentage' => '%',
                default => $raw,
            },
            'medications' => match ($raw) {
                default => $raw,
            },
            default => $raw,
        };
    }

    /**
     * Normalise a raw CSV value to the slug used in the taxonomy, keyed by vocabulary.
     *
     * Add a new arm to the outer match for each vocabulary that needs special handling.
     * Default: pass the value through unchanged.
     *
     * Examples:
     *   ('substance-unit', '%')          → percent
     *   ('substance-unit', 'percentage') → percent
     *   ('substance-unit', 'mg')         → mg     (unchanged)
     *   ('medications',    'anything')   → anything (no exceptions yet)
     */
    public static function normalizeTaxonomyName(string $vocabulary, string $raw): string
    {
        return match ($vocabulary) {
            'substance-unit' => match ($raw) {
                '%', 'percentage' => 'percent',
                'μg' => 'microgram',
                default => $raw,
            },
            'packaging' => match ($raw) {
                default => str_replace(
                    ['tablets', 'lozenges', 'capsules'],
                    ['tablet',  'lozenge',  'capsule'],
                    $raw,
                ),
            },
            default => $raw,
        };
    }

    /**
     * Convert a node-name slug to the path it should occupy under its vocabulary.
     *
     * Exceptions: slugs where the default last-word grouping would produce the
     * wrong parent. Default: single-word slugs are flat; multi-word slugs group
     * under the singularised last word of the base form (digit suffix stripped).
     *
     * Examples (default behaviour):
     *   capsule-30                → capsule/capsule-30
     *   chewable-tablets-30       → tablet/chewable-tablets-30
     *   film-coated-tablet        → tablet/film-coated-tablet
     *   hard-capsule              → capsule/hard-capsule
     *   gastroresistant-tablets   → tablet/gastroresistant-tablets
     *   solution-for-injection    → injection/solution-for-injection
     *   acyclovir                 → acyclovir   (single word → flat)
     *   tablet                    → tablet      (single word → flat, becomes a parent itself)
     */
    public static function slugToPath(string $slug): string
    {
        $override = match ($slug) {
            'zoledronic-acid',
            'other-products',
            'minerals-vitamins' => $slug,
            'vitamin-b1' => 'vitamin/vitamin-b1',
            'vitamin-b6' => 'vitamin/vitamin-b6',
            default => null,
        };

        if ($override !== null) {
            return $override;
        }

        $parts = explode('-', $slug);

        if (count($parts) === 1) {
            return $slug;
        }

        // Strip a trailing digit segment (e.g. "capsule-30" → base "capsule") before
        // extracting the group word so it refers to the form, not the count.
        $base = preg_match('/^\d+$/', (string)end($parts))
            ? implode('-', array_slice($parts, 0, -1))
            : $slug;

        $baseParts = explode('-', $base);
        $lastWord = (string)end($baseParts);
        $group = str_ends_with($lastWord, 's') ? substr($lastWord, 0, -1) : $lastWord;

        return $group . '/' . $slug;
    }

    /**
     * Extract the parent segment from a path produced by slugToPath().
     * Returns '' for flat (parentless) terms.
     *
     * Examples:
     *   capsule/capsule-30   → capsule
     *   acyclovir            → ''
     */
    public static function parentFromPath(string $path): string
    {
        $slash = strpos($path, '/');
        return $slash !== false ? substr($path, 0, $slash) : '';
    }
}
