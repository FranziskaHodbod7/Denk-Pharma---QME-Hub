<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Taxonomy;

/**
 * Resolves a (kebab-case) value to an existing taxonomy node id within a taxonomy root, or null
 * when nothing matches. The one seam that touches the content repository — everything else in the
 * converter stays pure and tests against an in-memory implementation.
 */
interface TaxonomyResolver
{
    public function resolve(string $root, string $value): ?string;
}
