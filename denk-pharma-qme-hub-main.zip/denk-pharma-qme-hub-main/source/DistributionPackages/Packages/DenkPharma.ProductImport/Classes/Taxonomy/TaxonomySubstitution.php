<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Taxonomy;

/**
 * Normalizes translated CSV taxonomy values to their canonical English equivalents at ingress.
 *
 * Operates on raw human-readable text (before slugification). All fr_FR and es_ES
 * terminology is mapped back to its en_GB equivalent so every taxonomy lookup uses
 * a consistent English identifier, regardless of which language file supplied the data.
 *
 * Source of truth for all mappings: source/Data/taxonomy_translations/*.csv
 */
final class TaxonomySubstitution
{
    public static function normalize(string $language, string $vocabulary, string $value): string
    {
        if ($value === '') {
            return $value;
        }

        return match ($language) {
            'fr_FR' => self::normalizeFrench($vocabulary, $value),
            'es_ES' => self::normalizeSpanish($vocabulary, $value),
            default => $value,
        };
    }

    private static function normalizeFrench(string $vocabulary, string $value): string
    {
        return match ($vocabulary) {
            'administration-form' => match ($value) {
                'crème'                             => 'cream',
                'poudre'                            => 'powder',
                'poudre pour suspension orale'      => 'powder for oral suspension',
                'comprimé'                          => 'tablet',
                'comprimé pelliculé'                => 'film coated tablet',
                'gélule, comprimé pelliculé'        => 'soft capsule, film coated tablet',
                'comprimé effervescent'             => 'effervescent tablet',
                'comprimé vaginal'                  => 'vaginal tablet',
                'comprimé de libération prolongée'  => 'extended release tablet',
                'comprimé gastrorésistant'          => 'gastroresistant tablets',
                'comprimé orodispersible'           => 'orodispersable tablet',
                'comprimé à croquer'                => 'chewable tablet',
                'suppositoire'                      => 'suppository',
                'suspension pour injection'         => 'solution for injection',
                'solution pour perfusion'           => 'solution for infusion',
                'gélule'                            => 'hard capsule',
                default                             => $value,
            },
            'medications' => match ($value) {
                'Analgésiques'                  => 'Analgesics',
                'Antiallergiques'               => 'Antiallergics',
                'Antiasthmatiques'              => 'Antiasthmatics',
                'Antibiotiques'                 => 'Antibiotics',
                'Antiémétiques'                 => 'Antiemetics',
                'Antipaludiques'                => 'Antimalarials',
                'Antiviraux & antifongiques'    => 'Antivirals and antifungals',
                'Médicaments cardiovasculaires' => 'Cardiovascular',
                'Médicaments gastro-intestinaux' => 'Digestion',
                'Médicaments métaboliques'      => 'Family planning & pregnancy',
                'Vitamines & minéraux'          => 'Minerals & Vitamins',
                'Neurologie'                    => 'Neurology',
                'Médicaments oncologiques'      => 'Oncology',
                default                         => $value,
            },
            'packaging' => match ($value) {
                'sachets'                   => 'stick',
                'sachets-10'                => 'stick-10',
                'sachets-12'                => 'stick-12',
                'sachets-14'                => 'stick-14',
                'sachets-20'                => 'stick-20',
                'sachets-30'                => 'stick-30',
                'comprimé-pelliculé'        => 'film-coated-tablets',
                'comprimé-pelliculé-30'     => 'film-coated-tablets-30',
                'comprimé-effervescent'     => 'effervescent tablets',
                'comprimé-effervescent-20'  => 'effervescent-tablets-20',
                'comprimé'                  => 'tablet',
                'comprimé-20'               => 'tablet-20',
                'comprimé-30'               => 'tablet-30',
                'comprimé-100'              => 'tablet-100',
                'gélule'                    => 'capsule',
                'gélule-30'                 => 'capsule-30',
                'gélule-60'                 => 'capsule-60',
                default                     => $value,
            },
            'substance' => match ($value) {
                'Aciclovir'             => 'Acyclovir',
                'Amoxicilline'          => 'Amoxicillin',
                'Acide clavulanique'    => 'Clavulanate',
                'Artésunate'            => 'Artesunate',
                'Sulfaméthoxypyrazine'  => 'Sulfamethoxypyrazine',
                'Pyriméthamine'         => 'Pyrimethamine',
                'Aténolol'              => 'Atenolol',
                'Cholécalciférol'       => 'Cholecalciferol',
                'Carvédilol'            => 'Carvedilol',
                'Ciprofloxacine'        => 'Ciprofloxacin',
                'Fer'                   => 'Iron',
                'Ibuprofène'            => 'Ibuprofen',
                'Caféine'               => 'Caffeine',
                'Oméprazole'            => 'Omeprazole',
                'Énalapril'             => 'Enalapril',
                'Ézétimibe'             => 'Ezetimibe',
                'Furosémide'            => 'Furosemide',
                'Granisétron'           => 'Granisetron',
                'Létrozole'             => 'Letrozole',
                'Lévofloxacin'          => 'Levofloxacin',
                'Linézolid'             => 'Linezolid',
                'Metformine'            => 'Metformin',
                'Nifédipine'            => 'Nifedipine',
                'Ondansétron'           => 'Ondensatron',
                'Périndopril'           => 'Perindopril',
                'Prégabalin'            => 'Pregabalin',
                'Rosuvastatine'         => 'Rosuvastatin',
                'Simvastatine'          => 'Simvastatin',
                'Torasémide'            => 'Torasemide',
                'Voriconazole'          => 'Variconazole',
                'Montélukast'           => 'Montelukast',
                'Diclofénac'            => 'Diclofenac',
                'Etofénamate'           => 'Etofenamate',
                'Paracétamol'           => 'Paracetamol',
                'Acide zolédronique'    => 'Zoledronic acid',
                default                 => $value,
            },
            default => $value,
        };
    }

    private static function normalizeSpanish(string $vocabulary, string $value): string
    {
        return match ($vocabulary) {
            'administration-form' => match ($value) {
                'polvo'                                         => 'powder',
                'polvo para suspensión oral'                    => 'powder for oral suspension',
                'comprimidos'                                   => 'tablet',
                'comprimidos con cubierta pelicular'            => 'film coated tablet',
                'cápsula blanda, comprimidos con cubierta pelicular' => 'soft capsule, film coated tablet',
                'comprimidos efervescentes'                     => 'effervescent tablet',
                'comprimidos de liberación prolongada'          => 'extended release tablet',
                'comprimidos gastroresistentes'                 => 'gastroresistant tablets',
                'comprimidos bucodispersables'                  => 'orodispersable tablet',
                'comprimidos masticables'                       => 'chewable tablet',
                'supositorios'                                  => 'suppository',
                'ampollas'                                      => 'solution for injection',
                'cápsula dura'                                  => 'hard capsule',
                'cápsulas'                                      => 'capsule',
                'solución para infusión'                        => 'solution for infusion',
                default                                         => $value,
            },
            'medications' => match ($value) {
                'Analgésicos'                   => 'Analgesics',
                'Antialérgicos'                 => 'Antiallergics',
                'Antiasmáticos'                 => 'Antiasthmatics',
                'Antibióticos'                  => 'Antibiotics',
                'Antieméticos'                  => 'Antiemetics',
                'Antivirales y antimicóticos'   => 'Antivirals and antifungals',
                'Medicamentos cardiovasculares' => 'Cardiovascular',
                'Medicamentos gastrointestinales' => 'Digestion',
                'Medicamentos metabólicos'      => 'Metabolics',
                'Vitaminas y minerales'         => 'Minerals & Vitamins',
                'Medicamentos oncológicos'      => 'Oncology',
                default                         => $value,
            },
            'packaging' => match ($value) {
                'sobre-10'                   => 'stick-10',
                'sobre-12'                   => 'stick-12',
                'sobre-14'                   => 'stick-14',
                'sobre-20'                   => 'stick-20',
                'sobre-30'                   => 'stick-30',
                'comprimidos-recubiertos-30' => 'film-coated-tablets-30',
                'comprimidos-efervescentes-20' => 'effervescent-tablets-20',
                'comprimidos'                => 'tablet',
                'comprimidos-100'            => 'tablet-100',
                'comprimidos-30'             => 'tablet-30',
                'comprimidos-masticables-30' => 'chewable-tablets-30',
                'cápsulas-30'               => 'capsule-30',
                'cápsulas-60'               => 'capsule-60',
                default                      => $value,
            },
            'substance' => match ($value) {
                'Amlodipino'            => 'Amlodipine',
                'Valsartán'             => 'Valsartan',
                'Aciclovir'             => 'Acyclovir',
                'Amoxicillina'          => 'Amoxicillin',
                'Ácido clavulánico'     => 'Clavulanate',
                'Anastrozol'            => 'Anastrozole',
                'Azitromicina'          => 'Azithromycin',
                'Hidroclorotiazida'     => 'Hydrochlorothiazide',
                'Ciprofloxacina'        => 'Ciprofloxacin',
                'Losartán'              => 'Losartan',
                'Desloratadina'         => 'Desloratadine',
                'Diclofenaco sódico'    => 'Diclofenac',
                'Ibuprofeno'            => 'Ibuprofen',
                'Fluconazol'            => 'Fluconazole',
                'Furosemida'            => 'Furosemide',
                'Glimeperida'           => 'Glimeperide',
                'Granisertón'           => 'Granisetron',
                'Letrozol'              => 'Letrozole',
                'Levofloxacino'         => 'Levofloxacin',
                'Magnesio'              => 'Magnesium',
                'Metformina'            => 'Metformin',
                'Nifedipino'            => 'Nifedipine',
                'Ondensatrón'           => 'Ondensatron',
                'Pantoprazol'           => 'Pantoprazole',
                'Codeína'               => 'Codeine',
                'Pregabalina'           => 'Pregabalin',
                'Rosuvastatina'         => 'Rosuvastatin',
                'Simvastatina'          => 'Simvastatin',
                'Torasemida'            => 'Torasemide',
                'Vildagliptina'         => 'Vildagliptin',
                'Voriconazol'           => 'Variconazole',
                'Ácido zoledrónico'     => 'Zoledronic acid',
                'Ácido zoledr'          => 'Zoledronic acid',
                default                 => $value,
            },
            default => $value,
        };
    }
}
