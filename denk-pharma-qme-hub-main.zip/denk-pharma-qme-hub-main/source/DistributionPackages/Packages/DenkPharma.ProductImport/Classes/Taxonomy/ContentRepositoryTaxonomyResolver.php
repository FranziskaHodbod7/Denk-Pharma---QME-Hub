<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Taxonomy;

use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindDescendantNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\Flow\Annotations as Flow;
use Sitegeist\Taxonomy\Service\TaxonomyService;

/**
 * Resolves taxonomy term titles to node aggregate ids against the live content repository in the
 * en_GB dimension. The one CR-touching converter class — verified by running the import, not by
 * unit tests. Per-vocabulary `title → id` maps are built lazily and cached for the run.
 */
class ContentRepositoryTaxonomyResolver implements TaxonomyResolver
{
    #[Flow\Inject]
    protected TaxonomyService $taxonomyService;

    /**
     * @var array<string, array<string, string>>
     */
    private array $maps = [];

    private ?ContentSubgraphInterface $subgraph = null;

    public function resolve(string $root, string $value): ?string
    {
        $this->maps[$root] ??= $this->buildMap($root);

        return $this->maps[$root][$value] ?? null;
    }

    /**
     * @return array<string, string>
     */
    private function buildMap(string $vocabularyName): array
    {
        $subgraph = $this->subgraph();
        $vocabulary = $this->taxonomyService->findVocabularyByName($subgraph, $vocabularyName);
        if ($vocabulary === null) {
            return [];
        }

        $map = [];
        $terms = $subgraph->findDescendantNodes(
            $vocabulary->aggregateId,
            FindDescendantNodesFilter::create(nodeTypes: 'Sitegeist.Taxonomy:Taxonomy'),
        );
        foreach ($terms as $term) {
            // Index by node name — the slug set at creation time — so manually-created nodes
            // whose title differs from their slug (e.g. "Antivirals and antifungals" vs
            // "antivirals-and-antifungals") are still resolved correctly.
            if ($term->name !== null) {
                $map[$term->name->value] = $term->aggregateId->value;
            }
            // Also index by lowercased title as a fallback for nodes without a node name.
            $title = strtolower((string)($term->getProperty('title') ?? ''));
            if ($title !== '') {
                $map[$title] ??= $term->aggregateId->value;
            }
        }

        return $map;
    }

    private function subgraph(): ContentSubgraphInterface
    {
        return $this->subgraph ??= $this->taxonomyService
            ->getContentRepository()
            ->getContentGraph(WorkspaceName::forLive())
            ->getSubgraph(
                DimensionSpacePoint::fromArray(['language' => 'en_GB']),
                VisibilityConstraints::withoutRestrictions(),
            );
    }
}
