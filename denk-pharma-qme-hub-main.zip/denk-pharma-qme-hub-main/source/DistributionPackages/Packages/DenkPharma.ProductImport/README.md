# DenkPharma.ProductImport

One-off converter that turns the product-catalog CSV exports into a single, validated **domain
XML** — phase one of a `CSV → domain XML → Content Repository` import. (The CR load step is
separate.)

## Input

CSV files in one directory, named `<language>.<category>.<type>.csv`:

- `<language>` — a content-dimension value, e.g. `en_GB`, `fr_FR`, `es_ES`
- `<category>` — `dietary-supplements` · `medicines` · `other`
- `<type>` — `basic` (product master + composition table) · `variants` (administration forms,
  formulations, ingredients)

e.g. `en_GB.dietary-supplements.basic.csv`, `en_GB.medicines.variants.csv`. Files that don't match
the convention are reported and skipped.

## Test

```bash
./flow taxonomy:seed --input-dir /app/source/Data/ImportTest --dry-run

./flow denkpharma.productimport:import:convert --input-dir /app/source/Data/ImportTest --output /app/source/Data/ImportTest/products.xml

./flow denkpharma.productimport:import:import --input /app/source/Data/ImportTest/products.xml --dry-run
```

## Usage

Run inside the app container (e.g. `docker exec <app> …` or `./fd cli …`):

```bash
# convert every set in a directory (default language: en_GB)
./flow denkpharma.productimport:import:convert \
    --input-dir /app/source/Data/import \
    --output products.xml

# a specific language set
./flow denkpharma.productimport:import:convert \
    --input-dir /app/source/Data/import --output products.fr.xml --language fr_FR

# include binaries (images + downloads)
./flow denkpharma.productimport:import:convert \
    --input-dir /app/source/Data/import --assets-dir /app/source/Data/import/binaries --output products.xml
```

Exits non-zero (and says why) if the input or assets directory, or the output location, is unusable.

## Binaries

`--assets-dir` points at a flat directory of binaries named by the **identifier** they belong to:

- `DENK_1234.jpg` — a product's hero **image** (the root id; one per product).
- `DENK_1234_1.pdf` — a **download** on variant `DENK_1234_1`'s administration. For more than one,
  append a counter: `DENK_1234_1-1.pdf`, `DENK_1234_1-2.pdf`, …

The build *pulls*: it asks the locator for the image of each product and the downloads of each
variant, so the identifier alone fixes the slot. Allowed extensions are `png/jpg/jpeg/webp` (images)
and `pdf` (downloads). Resolved files become `<image m:src="…"/>` / `<download m:src="…"/>` in the
XML; the actual files are imported in the CR load step.

Binary problems are **logged, never written to the XML** — in three buckets: `unallowed extension`,
`duplicate` (two files resolving to the same slot, ignoring extension/counter), and `orphan` (a file
nothing claimed — including a mis-slotted one, e.g. a `.pdf` named with a product id).

## Output

The XML is **intent-shaped**: it mirrors the CR storage tree (product → administrations →
formulations → ingredients; product → compositions → rows) but stays human-readable. Everything
the converter *derives* lives in two namespaces, so the data itself stays clean:

- `m:` (resolution) — `m:nodeId` (deterministic UUIDv5) and `m:ref` (resolved taxonomy node)
- `v:` (validation) — a `<v:summary>` plus inline `<v:issue>` / `v:status` findings

Translatable fields are wrapped in `<t lang="…">`.

### Validation findings

| severity | codes |
|---|---|
| error   | `duplicate-identifier`, `orphan-row` |
| warning | `unresolved-taxonomy` |
| notice  | `substance-freeform`, `dosageform-mismatch` |

Taxonomy values are matched against kebab-case titles; a non-kebab value is slugified and retried,
and the slug is kept as the stored value when it resolves.

## Loading into the CR

Phase two of the import reads the domain XML and creates the node aggregates. `XmlReader` parses the
XML back into the model; `ImportPlanner` turns that into an ordered, parents-first list of node
creations (using the `m:nodeId`s as aggregate ids and the `m:ref`s as references), skipping any
product whose subtree carries an error; `ContentRepositoryWriter` executes it in the **live**
workspace and en_GB, placing each product under its category folder and importing binaries as media
assets. The plan is a pure function of the model, so the decision logic is fully unit-tested.

```bash
# preview the plan and target folders, without writing anything
./flow denkpharma.productimport:import:import --input products.xml --dry-run

# load (optionally scope to one product with --sku, and import binaries with --assets-dir)
./flow denkpharma.productimport:import:import --input products.xml --assets-dir /app/source/Data/import/binaries

# read a created node + descendants back, to verify
./flow denkpharma.productimport:import:inspect --node-id <m:nodeId>
```

After a load, run **both** of these (clears stale compiled proxies, and conforms the new aggregates
to the current node-type structure — tethered children etc.):

```bash
./flow flow:cache:flush
./flow structureadjustments:fix
```

The import is **create-once** (no upsert): re-running over already-imported ids fails with "node
aggregate already exists", so reset the CR to a clean state before re-importing. Properties the node
type doesn't declare (e.g. `longDescription`) and missing asset files are logged, not fatal.

## Tests

```bash
bin/phpunit -c Build/BuildEssentials/PhpUnit/UnitTests.xml \
    Packages/Application/DenkPharma.ProductImport/Tests/Unit
```
