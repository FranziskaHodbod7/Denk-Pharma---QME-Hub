<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\NodeId;
use Neos\Flow\Tests\UnitTestCase;

class NodeIdTest extends UnitTestCase
{
    /**
     * @test
     */
    public function forIsDeterministic(): void
    {
        self::assertSame(NodeId::for('DENK_2345'), NodeId::for('DENK_2345'));
    }

    /**
     * @test
     */
    public function forDistinguishesDifferentSeeds(): void
    {
        self::assertNotSame(NodeId::for('DENK_2345'), NodeId::for('DENK_2346'));
    }

    /**
     * @test
     */
    public function forCombinesSeedParts(): void
    {
        self::assertNotSame(
            NodeId::for('DENK_1236', 'film coated tablet'),
            NodeId::for('DENK_1236'),
        );
    }

    /**
     * @test
     */
    public function forProducesAValidVersion5Uuid(): void
    {
        self::assertMatchesRegularExpression(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/',
            NodeId::for('DENK_2345'),
        );
    }
}
