<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\CommaList;
use Neos\Flow\Tests\UnitTestCase;

class CommaListTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     * @param list<string> $expected
     */
    public function splitTrimsAndDropsEmpties(string $value, array $expected): void
    {
        self::assertSame($expected, CommaList::split($value));
    }

    /**
     * @return array<string, array{0: string, 1: list<string>}>
     */
    public function examples(): array
    {
        return [
            'single'       => ['antibiotics', ['antibiotics']],
            'two values'   => ['analgesics, digestion', ['analgesics', 'digestion']],
            'empty middle' => ['a, ,b', ['a', 'b']],
            'untrimmed'    => ['a,b ,c', ['a', 'b', 'c']],
            'empty string' => ['', []],
            'only commas'  => [' , ', []],
        ];
    }
}
