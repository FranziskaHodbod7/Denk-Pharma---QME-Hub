<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Taxonomy;

use DenkPharma\ProductImport\Taxonomy\InMemoryTaxonomyResolver;
use Neos\Flow\Tests\UnitTestCase;

class InMemoryTaxonomyResolverTest extends UnitTestCase
{
    /**
     * @test
     */
    public function resolvesAKnownValueWithinItsRoot(): void
    {
        $resolver = new InMemoryTaxonomyResolver(['/medications' => ['magnesium' => 'node-1']]);

        self::assertSame('node-1', $resolver->resolve('/medications', 'magnesium'));
    }

    /**
     * @test
     */
    public function returnsNullForAnUnknownValue(): void
    {
        $resolver = new InMemoryTaxonomyResolver(['/medications' => ['magnesium' => 'node-1']]);

        self::assertNull($resolver->resolve('/medications', 'unknown'));
    }

    /**
     * @test
     */
    public function returnsNullForAnUnknownRoot(): void
    {
        $resolver = new InMemoryTaxonomyResolver([]);

        self::assertNull($resolver->resolve('/substance', 'anything'));
    }
}
