<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\LineList;
use Neos\Flow\Tests\UnitTestCase;

class LineListTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     * @param list<string> $expected
     */
    public function splitStripsBulletsAndDropsEmpties(string $value, array $expected): void
    {
        self::assertSame($expected, LineList::split($value));
    }

    /**
     * @return array<string, array{0: string, 1: list<string>}>
     */
    public function examples(): array
    {
        return [
            'all bullets'           => ["- A\n- B\n- C", ['A', 'B', 'C']],
            'intro then bullets'    => ["Intro\n- bullet", ['Intro', 'bullet']],
            'single bullet'         => ['- one', ['one']],
            'blank lines dropped'   => ["A\n\nB", ['A', 'B']],
            'no bullets'            => ['no bullets here', ['no bullets here']],
            'internal hyphens kept' => ['- with-hyphen-word', ['with-hyphen-word']],
            'empty'                 => ['', []],
        ];
    }
}
