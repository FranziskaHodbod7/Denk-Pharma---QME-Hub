<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\Locator;
use DenkPharma\ProductImport\Model\ProductCategory;
use Neos\Flow\Tests\UnitTestCase;

class LocatorTest extends UnitTestCase
{
    /**
     * @test
     */
    public function pairsBasicAndVariantsOfTheSameLanguageAndCategory(): void
    {
        $result = Locator::locate([
            'en_GB.dietary-supplements.basic.csv',
            'en_GB.dietary-supplements.variants.csv',
        ]);

        self::assertCount(1, $result['pairs']);
        $pair = $result['pairs'][0];
        self::assertSame('en_GB', $pair->language);
        self::assertSame(ProductCategory::DietarySupplements, $pair->category);
        self::assertSame('en_GB.dietary-supplements.basic.csv', $pair->basic);
        self::assertSame('en_GB.dietary-supplements.variants.csv', $pair->variants);
        self::assertSame([], $result['problems']);
    }

    /**
     * @test
     */
    public function separatesDistinctCategories(): void
    {
        $result = Locator::locate([
            'en_GB.medicines.basic.csv',
            'en_GB.dietary-supplements.basic.csv',
        ]);

        self::assertCount(2, $result['pairs']);
    }

    /**
     * @test
     */
    public function reportsUnparseableAndUnknownNames(): void
    {
        $result = Locator::locate(['garbage.csv', 'en_GB.unknown.basic.csv']);

        self::assertSame([], $result['pairs']);
        self::assertSame(['garbage.csv', 'en_GB.unknown.basic.csv'], $result['problems']);
    }

    /**
     * @test
     */
    public function leavesAMissingHalfNull(): void
    {
        $result = Locator::locate(['en_GB.other.basic.csv']);

        self::assertCount(1, $result['pairs']);
        self::assertSame('en_GB.other.basic.csv', $result['pairs'][0]->basic);
        self::assertNull($result['pairs'][0]->variants);
    }

    /**
     * @test
     */
    public function ignoresNonCsvFiles(): void
    {
        $result = Locator::locate(['README.md', 'en_GB.medicines.variants.csv']);

        self::assertCount(1, $result['pairs']);
        self::assertSame([], $result['problems']);
    }
}
