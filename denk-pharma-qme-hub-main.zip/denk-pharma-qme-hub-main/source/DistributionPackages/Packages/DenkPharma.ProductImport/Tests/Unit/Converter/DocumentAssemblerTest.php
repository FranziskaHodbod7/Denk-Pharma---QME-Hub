<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\DocumentAssembler;
use DenkPharma\ProductImport\Converter\ModelBuilder;
use DenkPharma\ProductImport\Converter\ProductBundle;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Taxonomy\InMemoryTaxonomyResolver;
use Neos\Flow\Tests\UnitTestCase;

class DocumentAssemblerTest extends UnitTestCase
{
    private function product(string $sku): ImportProduct
    {
        return (new ModelBuilder(new InMemoryTaxonomyResolver([])))
            ->build(new ProductBundle($sku, ['productName' => 'X'], [], []), null, ProductCategory::Medicines, 'en_GB');
    }

    /**
     * @test
     */
    public function leavesUniqueProductsUnflagged(): void
    {
        $document = DocumentAssembler::assemble([$this->product('DENK_1'), $this->product('DENK_2')]);

        self::assertCount(2, $document->products);
        self::assertSame([], $document->findings);
        self::assertSame([], $document->products[0]->findings);
        self::assertSame([], $document->products[1]->findings);
    }

    /**
     * @test
     */
    public function stampsEveryProductSharingADuplicateSkuSoNoneAreImported(): void
    {
        $document = DocumentAssembler::assemble([$this->product('DENK_1'), $this->product('DENK_1')]);

        self::assertSame([], $document->findings);
        self::assertCount(2, $document->products);
        foreach ($document->products as $product) {
            self::assertSame('duplicate-identifier', $product->findings[0]->code);
        }
    }
}
