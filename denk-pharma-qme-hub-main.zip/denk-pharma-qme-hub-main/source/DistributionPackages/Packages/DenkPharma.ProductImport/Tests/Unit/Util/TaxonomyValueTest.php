<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\TaxonomyValue;
use Neos\Flow\Tests\UnitTestCase;

class TaxonomyValueTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider kebabCaseExamples
     */
    public function isKebabCaseRecognisesThePolicy(string $value, bool $expected): void
    {
        self::assertSame($expected, TaxonomyValue::isKebabCase($value));
    }

    /**
     * @return array<string, array{0: string, 1: bool}>
     */
    public function kebabCaseExamples(): array
    {
        return [
            'simple slug'      => ['minerals-and-vitamins', true],
            'slug with digits' => ['stick-14', true],
            'single segment'   => ['powder', true],
            'spaces (label)'   => ['film coated tablet', false],
            'capitalised'      => ['Vitamin C', false],
            'empty'            => ['', false],
            'leading hyphen'   => ['-tablet', false],
            'trailing hyphen'  => ['tablet-', false],
            'double hyphen (combi)' => ['a--b', true],
            'combi value'      => ['soft-capsule--film-coated-tablet', true],
            'triple hyphen'    => ['a---b', false],
        ];
    }
}
