<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\Quantity;
use Neos\Flow\Tests\UnitTestCase;

class QuantityTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     */
    public function normalizeCanonicalisesNumericValues(string $raw, ?string $expected): void
    {
        self::assertSame($expected, Quantity::normalize($raw));
    }

    /**
     * @return array<string, array{0: string, 1: ?string}>
     */
    public function examples(): array
    {
        return [
            'integer'           => ['1000', '1000'],
            'decimal dot'       => ['62.5', '62.5'],
            'decimal comma'     => ['4,5', '4.5'],
            'surrounding space' => ['  25  ', '25'],
            'empty'             => ['', null],
            'non-numeric'       => ['abc', null],
            'value with unit'   => ['5 mg', null],
            'percent'           => ['5%', null],
        ];
    }
}
