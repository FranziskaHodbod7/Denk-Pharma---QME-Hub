<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\ModelBuilder;
use DenkPharma\ProductImport\Converter\ProductAssembler;
use DenkPharma\ProductImport\Converter\ProductBundle;
use DenkPharma\ProductImport\Converter\VariantBundle;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Taxonomy\InMemoryTaxonomyResolver;
use Neos\Flow\Tests\UnitTestCase;

class ProductAssemblerTest extends UnitTestCase
{
    private function assembler(array $vocabulary = []): ProductAssembler
    {
        return new ProductAssembler(new ModelBuilder(new InMemoryTaxonomyResolver($vocabulary)));
    }

    /**
     * @test
     */
    public function pairsBundlesBySkuAndBuilds(): void
    {
        $basic = [
            new ProductBundle('DENK_1', ['productName' => 'A'], [], []),
            new ProductBundle('DENK_2', ['productName' => 'B'], [], []),
        ];
        $variants = [
            new ProductBundle('DENK_1', [], [], [new VariantBundle('DENK_1_1', ['dosageForm' => 'tablet'], [])]),
        ];

        $products = $this->assembler(['administration-form' => ['tablet' => 'af-tab']])
            ->assemble($basic, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertCount(2, $products);
        self::assertSame('DENK_1', $products[0]->sku);
        self::assertCount(1, $products[0]->administrations);
        self::assertSame('DENK_2', $products[1]->sku);
        self::assertSame([], $products[1]->administrations);
    }

    /**
     * @test
     */
    public function variantsOnlyProductGetsAMissingMaster(): void
    {
        $variants = [new ProductBundle('DENK_9', [], [], [])];

        $products = $this->assembler()->assemble([], $variants, ProductCategory::Medicines, 'en_GB');

        self::assertCount(1, $products);
        self::assertSame('DENK_9', $products[0]->sku);
        self::assertSame('missing-master', $products[0]->findings[0]->code);
    }
}
