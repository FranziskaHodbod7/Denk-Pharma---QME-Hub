<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\CsvReader;
use Neos\Flow\Tests\UnitTestCase;

class CsvReaderTest extends UnitTestCase
{
    /**
     * @test
     */
    public function parsesASimpleTable(): void
    {
        self::assertSame(
            [['a', 'b', 'c'], ['1', '2', '3']],
            CsvReader::rows("a,b,c\n1,2,3"),
        );
    }

    /**
     * @test
     */
    public function keepsQuotedMultiLineCellAsOneField(): void
    {
        self::assertSame(
            [['a', 'b'], ["line1\nline2", 'x']],
            CsvReader::rows("a,b\n\"line1\nline2\",x"),
        );
    }

    /**
     * @test
     */
    public function keepsQuotedCommaInsideField(): void
    {
        self::assertSame(
            [['a', 'b'], ['x,y', 'z']],
            CsvReader::rows("a,b\n\"x,y\",z"),
        );
    }

    /**
     * @test
     */
    public function padsShortRowsToHeaderWidth(): void
    {
        self::assertSame(
            [['a', 'b', 'c'], ['1', '2', '']],
            CsvReader::rows("a,b,c\n1,2"),
        );
    }

    /**
     * @test
     */
    public function preservesEmptyInteriorCells(): void
    {
        self::assertSame(
            [['a', 'b', 'c'], ['1', '', '3']],
            CsvReader::rows("a,b,c\n1,,3"),
        );
    }

    /**
     * @test
     */
    public function returnsEmptyForEmptyInput(): void
    {
        self::assertSame([], CsvReader::rows(''));
    }
}
