<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\Columns;
use Neos\Flow\Tests\UnitTestCase;

class ColumnsTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider headerNormalizations
     */
    public function normalizeHeaderCleansAwkwardHeaders(string $raw, string $expected): void
    {
        self::assertSame($expected, Columns::normalizeHeader($raw));
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public function headerNormalizations(): array
    {
        return [
            'plain'                   => ['Product Identifier', 'product identifier'],
            'multi-line + annotation' => ["Indication/Medication\n*see List of Indications", 'indication/medication'],
            'newline inside'          => ["Ingredients - \nNutrient", 'ingredients - nutrient'],
            'casing'                  => ['Dosage Form', 'dosage form'],
            'extra whitespace'        => ['  Short   Description  ', 'short description'],
        ];
    }

    /**
     * @test
     * @dataProvider headerMappings
     */
    public function cleanNameMapsKnownHeaders(string $raw, ?string $expected): void
    {
        self::assertSame($expected, Columns::cleanName($raw));
    }

    /**
     * @return array<string, array{0: string, 1: ?string}>
     */
    public function headerMappings(): array
    {
        return [
            'identifier'                          => ['Product Identifier', 'productIdentifier'],
            'dosage form (basic)'                 => ['Dosage form', 'dosageForm'],
            'dosage form (variants, annotated)'   => ["Dosage Form\n*see list of all dosage forms", 'dosageForm'],
            'basic ingredients → composition'     => ['Ingredients - Nutrient', 'compositionNutrient'],
            'variants composition → formulation'  => ['Composition - Active Substance', 'formulationSubstance'],
            'unknown'                             => ['Totally Unknown Column', null],
            'blank'                               => ['', null],
        ];
    }

    /**
     * @test
     */
    public function mapRemapsRowsToCleanKeysAndReportsUnknownHeaders(): void
    {
        $rows = [
            ['Product Identifier', 'Product Name', "Indication/Medication\n*see List of Indications", 'Mystery Column'],
            ['DENK_2345', 'arthro active Denk', 'minerals-and-vitamins', 'junk'],
            ['', '', '', ''],
        ];

        $result = Columns::map($rows);

        self::assertSame(
            [
                ['productIdentifier' => 'DENK_2345', 'productName' => 'arthro active Denk', 'indication' => 'minerals-and-vitamins'],
                ['productIdentifier' => '', 'productName' => '', 'indication' => ''],
            ],
            $result['rows'],
        );
        self::assertSame(['Mystery Column'], $result['unknownHeaders']);
    }

    /**
     * @test
     */
    public function mapReturnsEmptyForNoRows(): void
    {
        self::assertSame(['rows' => [], 'unknownHeaders' => []], Columns::map([]));
    }
}
