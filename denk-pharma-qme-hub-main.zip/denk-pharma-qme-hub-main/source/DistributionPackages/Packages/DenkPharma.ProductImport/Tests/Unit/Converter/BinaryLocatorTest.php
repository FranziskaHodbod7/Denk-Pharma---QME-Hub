<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\BinaryLocator;
use Neos\Flow\Tests\UnitTestCase;

class BinaryLocatorTest extends UnitTestCase
{
    private function locator(string ...$filenames): BinaryLocator
    {
        $locator = new BinaryLocator();
        foreach ($filenames as $filename) {
            $locator->addFile($filename);
        }

        return $locator;
    }

    /**
     * @test
     */
    public function returnsTheImageForAProductAndOrdersDownloadsByCounter(): void
    {
        $locator = $this->locator('DENK_7777.jpg', 'DENK_7777_1-2.pdf', 'DENK_7777_1-1.pdf');

        self::assertSame('DENK_7777.jpg', $locator->image('DENK_7777'));
        self::assertSame(['DENK_7777_1-1.pdf', 'DENK_7777_1-2.pdf'], $locator->downloads('DENK_7777_1'));
    }

    /**
     * @test
     */
    public function returnsASingleCounterlessDownload(): void
    {
        $locator = $this->locator('DENK_7777_1.pdf');

        self::assertSame(['DENK_7777_1.pdf'], $locator->downloads('DENK_7777_1'));
    }

    /**
     * @test
     */
    public function consumedFilesAreNotOrphans(): void
    {
        $locator = $this->locator('DENK_7777.jpg', 'DENK_7777_1.pdf');
        $locator->image('DENK_7777');
        $locator->downloads('DENK_7777_1');

        self::assertSame([], $locator->problems()['orphan']);
    }

    /**
     * @test
     */
    public function flagsAnUnallowedExtension(): void
    {
        $locator = $this->locator('DENK_7777.txt');

        self::assertSame(['DENK_7777.txt'], $locator->problems()['unallowed']);
    }

    /**
     * @test
     */
    public function flagsTwoImagesForOneProductAsDuplicateNotOrphan(): void
    {
        $locator = $this->locator('DENK_7777.jpg', 'DENK_7777.png');

        self::assertNull($locator->image('DENK_7777'));
        $problems = $locator->problems();
        self::assertSame(['DENK_7777 image: DENK_7777.jpg, DENK_7777.png'], $problems['duplicate']);
        self::assertSame([], $problems['orphan']);
    }

    /**
     * @test
     */
    public function flagsDownloadsMixingBareAndCounterAsDuplicate(): void
    {
        $locator = $this->locator('DENK_7777_1.pdf', 'DENK_7777_1-1.pdf');

        self::assertSame([], $locator->downloads('DENK_7777_1'));
        self::assertSame(
            ['DENK_7777_1 downloads: DENK_7777_1-1.pdf, DENK_7777_1.pdf'],
            $locator->problems()['duplicate'],
        );
    }

    /**
     * @test
     */
    public function reportsAllowedButUnclaimedFilesAsOrphans(): void
    {
        $locator = $this->locator('DENK_9999.jpg', 'logo.png');

        self::assertSame(['DENK_9999.jpg', 'logo.png'], $locator->problems()['orphan']);
    }
}
