<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\BinaryLocator;
use DenkPharma\ProductImport\Converter\ModelBuilder;
use DenkPharma\ProductImport\Converter\ProductBundle;
use DenkPharma\ProductImport\Converter\VariantBundle;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Taxonomy\InMemoryTaxonomyResolver;
use DenkPharma\ProductImport\Util\NodeId;
use Neos\Flow\Tests\UnitTestCase;

class ModelBuilderTest extends UnitTestCase
{
    /**
     * @param array $vocabulary
     */
    private function builder(array $vocabulary = []): ModelBuilder
    {
        return new ModelBuilder(new InMemoryTaxonomyResolver($vocabulary));
    }

    // --- (a) product-level fields -------------------------------------------------------------

    /**
     * @test
     */
    public function buildsProductLevelFieldsFromTheBasicBundle(): void
    {
        $basic = new ProductBundle('DENK_2345', [
            'productName' => 'arthro active Denk',
            'shortDescription' => "So you can enjoy being active\n- With collagen",
            'longDescription' => 'Our body is exposed to stresses.',
            'ingredientsText' => 'Collagen, maltodextrin',
            'storage' => 'Store below 25°C',
        ], [], []);

        $product = $this->builder()->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        self::assertSame('DENK_2345', $product->sku);
        self::assertSame(ProductCategory::DietarySupplements, $product->category);
        self::assertSame(NodeId::for('DENK_2345'), $product->nodeId);
        self::assertSame('arthro active Denk', $product->title->get('en_GB'));
        self::assertSame('arthro-active-denk', $product->uriPathSegment->get('en_GB'));
        self::assertSame("So you can enjoy being active\n- With collagen", $product->shortDescription->get('en_GB'));
        self::assertSame('Our body is exposed to stresses.', $product->longDescription->get('en_GB'));
        self::assertSame('Collagen, maltodextrin', $product->ingredients->get('en_GB'));
        self::assertSame('Store below 25°C', $product->storageInstructions->get('en_GB'));
        self::assertSame([], $product->findings);
    }

    /**
     * @test
     */
    public function resolvesMedicationsAndFlagsMisses(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X', 'indication' => 'antibiotics, oncology'], [], []);

        $product = $this->builder(['medications' => ['antibiotics' => 'tax-ab']])
            ->build($basic, null, ProductCategory::Medicines, 'en_GB');

        self::assertCount(2, $product->medications);
        self::assertSame('tax-ab', $product->medications[0]->nodeId);
        self::assertNull($product->medications[1]->nodeId);
        self::assertSame('unresolved-taxonomy', $product->medications[1]->finding->code);
    }

    /**
     * @test
     */
    public function slugifiesNonKebabMedicationValuesAndKeepsTheSlug(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X', 'indication' => 'Vitamin C'], [], []);

        $product = $this->builder(['medications' => ['vitamin-c' => 'tax-vc']])
            ->build($basic, null, ProductCategory::Medicines, 'en_GB');

        self::assertSame('tax-vc', $product->medications[0]->nodeId);
        self::assertSame('vitamin-c', $product->medications[0]->value);
        self::assertNull($product->medications[0]->finding);
    }

    /**
     * @test
     */
    public function leavesNonKebabUnresolvedWhenEvenTheSlugMisses(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X', 'indication' => 'Vitamin C'], [], []);

        $product = $this->builder()->build($basic, null, ProductCategory::Medicines, 'en_GB');

        self::assertNull($product->medications[0]->nodeId);
        self::assertSame('Vitamin C', $product->medications[0]->value);
        self::assertSame('unresolved-taxonomy', $product->medications[0]->finding->code);
    }

    /**
     * @test
     */
    public function splitsBenefitsIntoLineItems(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X', 'benefits' => "- Highly bioavailable\n- One a day"], [], []);

        $product = $this->builder()->build($basic, null, ProductCategory::Medicines, 'en_GB');

        self::assertCount(2, $product->benefits);
        self::assertSame('Highly bioavailable', $product->benefits[0]->description->get('en_GB'));
        self::assertSame('One a day', $product->benefits[1]->description->get('en_GB'));
    }

    /**
     * @test
     */
    public function flagsAMissingMaster(): void
    {
        $variants = new ProductBundle('DENK_1234', [], [], []);

        $product = $this->builder()->build(null, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertSame('DENK_1234', $product->sku);
        self::assertCount(1, $product->findings);
        self::assertSame('missing-master', $product->findings[0]->code);
        self::assertSame(Severity::Error, $product->findings[0]->severity);
    }

    // --- (b) administrations / formulations / ingredients ------------------------------------

    /**
     * @test
     */
    public function buildsAnAdministrationWithIngredients(): void
    {
        $basic = new ProductBundle('DENK_1234', ['productName' => 'Acyclovir Denk'], [], []);
        $variant = new VariantBundle(
            'DENK_1234_1',
            ['dosageForm' => 'cream', 'packSize' => '', 'applicationRecommendation' => ''],
            [['formulationSubstance' => 'acyclovir', 'formulationQuantity' => '5', 'formulationUnit' => 'percent']],
        );
        $variants = new ProductBundle('DENK_1234', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['cream' => 'af-cream'],
            'substance' => ['acyclovir' => 's-acy'],
            'substance-unit' => ['percent' => 'u-pct'],
        ])->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertCount(1, $product->administrations);
        $administration = $product->administrations[0];
        self::assertSame('af-cream', $administration->administrationForm->nodeId);
        self::assertCount(1, $administration->formulations);
        $formulation = $administration->formulations[0];
        self::assertNull($formulation->packageQuantity);
        self::assertCount(1, $formulation->ingredients);
        self::assertSame('s-acy', $formulation->ingredients[0]->substance->nodeId);
        self::assertSame('u-pct', $formulation->ingredients[0]->unit->nodeId);
        self::assertSame('5', $formulation->ingredients[0]->quantity);
    }

    /**
     * @test
     */
    public function groupsVariantsOfTheSameDosageFormIntoOneAdministration(): void
    {
        $basic = new ProductBundle('DENK_1236', ['productName' => 'Amva Denk'], [], []);
        $v1 = new VariantBundle('DENK_1236_1', ['dosageForm' => 'film-coated-tablet'], [['formulationSubstance' => 'amlodipin', 'formulationQuantity' => '1000', 'formulationUnit' => 'mg']]);
        $v2 = new VariantBundle('DENK_1236_2', ['dosageForm' => 'film-coated-tablet'], [['formulationSubstance' => 'amlodipin', 'formulationQuantity' => '1500', 'formulationUnit' => 'mg']]);
        $variants = new ProductBundle('DENK_1236', [], [], [$v1, $v2]);

        $product = $this->builder([
            'administration-form' => ['film-coated-tablet' => 'af-fct'],
            'substance' => ['amlodipin' => 's-aml'],
            'substance-unit' => ['mg' => 'u-mg'],
        ])->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertCount(1, $product->administrations);
        self::assertCount(2, $product->administrations[0]->formulations);
    }

    /**
     * @test
     */
    public function aCombiFormWithMultiplePacksIsOneAdministrationWithSiblingFormulations(): void
    {
        $basic = new ProductBundle('DENK_2346', ['productName' => 'brain active Denk'], [], []);
        $variant = new VariantBundle(
            'DENK_2346_1',
            ['dosageForm' => 'soft-capsule--film-coated-tablet', 'packSize' => 'capsules-30', 'applicationRecommendation' => 'Consume daily'],
            [['packSize' => 'film-coated-tablets-30']],
        );
        $variants = new ProductBundle('DENK_2346', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['soft-capsule--film-coated-tablet' => 'af-combi'],
            'packaging' => ['capsule-30' => 'p-cap', 'film-coated-tablet-30' => 'p-fct'],
        ])->build($basic, $variants, ProductCategory::DietarySupplements, 'en_GB');

        self::assertCount(1, $product->administrations);
        $administration = $product->administrations[0];
        self::assertSame('af-combi', $administration->administrationForm->nodeId);
        self::assertCount(2, $administration->formulations);
        self::assertSame('p-cap', $administration->formulations[0]->packageQuantity->nodeId);
        self::assertSame('p-fct', $administration->formulations[1]->packageQuantity->nodeId);
        self::assertSame('Consume daily', $administration->formulations[1]->applicationRecommendation->get('en_GB'));
    }

    /**
     * @test
     */
    public function normalizesIngredientQuantitiesAndFlagsNonNumeric(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [], []);
        $variant = new VariantBundle('DENK_1_1', ['dosageForm' => 'tablet'], [
            ['formulationSubstance' => 'alpha', 'formulationQuantity' => '4,5', 'formulationUnit' => 'mg'],
            ['formulationSubstance' => 'beta', 'formulationQuantity' => 'abc', 'formulationUnit' => 'mg'],
        ]);
        $variants = new ProductBundle('DENK_1', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['tablet' => 'af-tab'],
            'substance' => ['alpha' => 's-a', 'beta' => 's-b'],
            'substance-unit' => ['mg' => 'u-mg'],
        ])->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        $ingredients = $product->administrations[0]->formulations[0]->ingredients;
        self::assertSame('4.5', $ingredients[0]->quantity);
        self::assertSame('abc', $ingredients[1]->quantity);
        self::assertSame('quantity-not-numeric', $ingredients[1]->findings[0]->code);
    }

    /**
     * @test
     */
    public function flagsAStrayDosageRowAndDiscardsItsTrailingRows(): void
    {
        $basic = new ProductBundle('DENK_1236', ['productName' => 'Amva Denk'], [], []);
        $variant = new VariantBundle('DENK_1236_3', ['dosageForm' => 'film-coated-tablet'], [
            ['formulationSubstance' => 'amlodipin', 'formulationQuantity' => '3000', 'formulationUnit' => 'mg'],
            ['dosageForm' => 'cream'],                                                                          // stray: missing variant id
            ['formulationSubstance' => 'clavulanate', 'formulationQuantity' => '62.5', 'formulationUnit' => 'mg'], // belongs to the stray form
        ]);
        $variants = new ProductBundle('DENK_1236', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['film-coated-tablet' => 'af-fct'],
            'substance' => ['amlodipin' => 's-aml'],
            'substance-unit' => ['mg' => 'u-mg'],
        ])->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertCount(1, $product->administrations);
        self::assertSame('orphan-row', $product->administrations[0]->findings[0]->code);
        // the stray "cream" row AND its trailing Clavulanate ingredient are discarded, not grafted onto _3
        self::assertCount(1, $product->administrations[0]->formulations[0]->ingredients);
        self::assertSame('amlodipin', $product->administrations[0]->formulations[0]->ingredients[0]->substance->value);
    }

    // --- (c) compositions ---------------------------------------------------------------------

    /**
     * @test
     */
    public function resolvesACompositionSubstanceAndKeepsTheParentheticalAsText(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'vitamin-d3 (Cholecalciferol)', 'compositionPerUnit' => '25 µg', 'compositionNrv' => '500%'],
        ], []);

        $product = $this->builder(['substance' => ['vitamin-d3' => 's-d3']])
            ->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        self::assertCount(1, $product->compositions);
        $row = $product->compositions[0]->rows[0];
        self::assertSame('s-d3', $row->substance->nodeId);
        self::assertSame('vitamin-d3', $row->substance->value);
        self::assertSame('(Cholecalciferol)', $row->substanceText->get('en_GB'));
        self::assertSame('25 µg', $row->perUnit->get('en_GB'));
        self::assertSame('500%', $row->nrv->get('en_GB'));
    }

    /**
     * @test
     */
    public function fallsBackToFreeTextWhenACompositionSubstanceDoesNotResolve(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'Vitamin C', 'compositionPerUnit' => '40 mg', 'compositionNrv' => '50'],
        ], []);

        $product = $this->builder()->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        $row = $product->compositions[0]->rows[0];
        self::assertNull($row->substance);
        self::assertSame('Vitamin C', $row->substanceText->get('en_GB'));
        self::assertSame('substance-freeform', $row->findings[0]->code);
        self::assertSame(Severity::Notice, $row->findings[0]->severity);
    }

    /**
     * @test
     */
    public function collapsesNutrientRowsIntoOneCompositionAndSkipsNonNutrientSubRows(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'Vitamin C', 'compositionPerUnit' => '40 mg', 'compositionNrv' => '50'],
            ['compositionNutrient' => 'Vitamin K', 'compositionPerUnit' => '75 µg', 'compositionNrv' => '100'],
            ['dosageForm' => 'soft capsule'],
        ], []);

        $product = $this->builder()->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        self::assertCount(1, $product->compositions);
        self::assertCount(2, $product->compositions[0]->rows);
    }

    /**
     * @test
     */
    public function slugifiesACompositionSubstanceToResolveAndKeepsTheSlug(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'Vitamin C', 'compositionPerUnit' => '40 mg', 'compositionNrv' => '50'],
        ], []);

        $product = $this->builder(['substance' => ['vitamin-c' => 's-vc']])
            ->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        $row = $product->compositions[0]->rows[0];
        self::assertSame('s-vc', $row->substance->nodeId);
        self::assertSame('vitamin-c', $row->substance->value);
        self::assertNull($row->substanceText);
        self::assertSame([], $row->findings);
    }

    /**
     * @test
     */
    public function splitsSeparatorRowsIntoMultipleNamedCompositionTables(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'Per film-coated tablet', 'compositionPerUnit' => '', 'compositionNrv' => ''],
            ['compositionNutrient' => 'Pantothenic acid', 'compositionPerUnit' => '5 mg', 'compositionNrv' => '83'],
            ['compositionNutrient' => 'Ginkgo extract', 'compositionPerUnit' => '100 mg', 'compositionNrv' => ''],
            ['compositionNutrient' => 'Per capsule', 'compositionPerUnit' => '', 'compositionNrv' => ''],
            ['compositionNutrient' => 'Omega-3 fatty acids', 'compositionPerUnit' => '300 mg', 'compositionNrv' => ''],
        ], []);

        $product = $this->builder()->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        self::assertCount(2, $product->compositions);

        self::assertSame('Per film-coated tablet', $product->compositions[0]->title->get('en_GB'));
        self::assertCount(2, $product->compositions[0]->rows);
        self::assertSame('Pantothenic acid', $product->compositions[0]->rows[0]->substanceText->get('en_GB'));
        self::assertSame('Ginkgo extract', $product->compositions[0]->rows[1]->substanceText->get('en_GB'));

        self::assertSame('Per capsule', $product->compositions[1]->title->get('en_GB'));
        self::assertCount(1, $product->compositions[1]->rows);
        self::assertSame('Omega-3 fatty acids', $product->compositions[1]->rows[0]->substanceText->get('en_GB'));
    }

    /**
     * @test
     */
    public function rowsBeforeFirstSeparatorFormAnUntitledLeadingTable(): void
    {
        $basic = new ProductBundle('DENK_1', ['productName' => 'X'], [
            ['compositionNutrient' => 'Vitamin C', 'compositionPerUnit' => '40 mg', 'compositionNrv' => '50'],
            ['compositionNutrient' => 'Per capsule', 'compositionPerUnit' => '', 'compositionNrv' => ''],
            ['compositionNutrient' => 'DHA', 'compositionPerUnit' => '250 mg', 'compositionNrv' => ''],
        ], []);

        $product = $this->builder()->build($basic, null, ProductCategory::DietarySupplements, 'en_GB');

        self::assertCount(2, $product->compositions);
        self::assertNull($product->compositions[0]->title);
        self::assertCount(1, $product->compositions[0]->rows);
        self::assertSame('Per capsule', $product->compositions[1]->title->get('en_GB'));
        self::assertCount(1, $product->compositions[1]->rows);
    }

    /**
     * @test
     */
    public function flagsADosageFormMismatchBetweenBasicAndVariants(): void
    {
        $basic = new ProductBundle('DENK_2345', ['productName' => 'arthro active Denk', 'dosageForm' => 'powder'], [], []);
        $variant = new VariantBundle('DENK_2345_1', ['dosageForm' => 'powder-water-soluble', 'packSize' => 'stick-14'], []);
        $variants = new ProductBundle('DENK_2345', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['powder-water-soluble' => 'af-pws'],
            'packaging' => ['stick-14' => 'p-s14'],
        ])->build($basic, $variants, ProductCategory::DietarySupplements, 'en_GB');

        self::assertContains('dosageform-mismatch', array_map(static fn ($finding) => $finding->code, $product->findings));
    }

    /**
     * @test
     */
    public function doesNotFlagADosageFormThatMatchesAfterSlugifying(): void
    {
        $basic = new ProductBundle('DENK_X', ['productName' => 'X', 'dosageForm' => 'film coated tablet'], [], []);
        $variant = new VariantBundle('DENK_X_1', ['dosageForm' => 'film-coated-tablet'], []);
        $variants = new ProductBundle('DENK_X', [], [], [$variant]);

        $product = $this->builder(['administration-form' => ['film-coated-tablet' => 'af-fct']])
            ->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        self::assertNotContains('dosageform-mismatch', array_map(static fn ($finding) => $finding->code, $product->findings));
    }

    /**
     * @test
     */
    public function flagsAnUnresolvedFormulationSubstanceAsUnresolvedTaxonomy(): void
    {
        $basic = new ProductBundle('DENK_X', ['productName' => 'X'], [], []);
        $variant = new VariantBundle('DENK_X_1', ['dosageForm' => 'tablet'], [
            ['formulationSubstance' => 'unobtainium', 'formulationQuantity' => '5', 'formulationUnit' => 'mg'],
        ]);
        $variants = new ProductBundle('DENK_X', [], [], [$variant]);

        $product = $this->builder([
            'administration-form' => ['tablet' => 'af-t'],
            'substance-unit' => ['mg' => 'u-mg'],
        ])->build($basic, $variants, ProductCategory::Medicines, 'en_GB');

        $ingredient = $product->administrations[0]->formulations[0]->ingredients[0];
        self::assertNull($ingredient->substance->nodeId);
        self::assertSame('unresolved-taxonomy', $ingredient->substance->finding->code);
        self::assertSame('u-mg', $ingredient->unit->nodeId);
    }

    /**
     * @test
     */
    public function pullsImageAndDownloadsFromTheBinaryLocator(): void
    {
        $locator = new BinaryLocator();
        $locator->addFile('DENK_2345.jpg');
        $locator->addFile('DENK_2345_1.pdf');

        $basic = new ProductBundle('DENK_2345', ['productName' => 'X'], [], []);
        $variant = new VariantBundle('DENK_2345_1', ['dosageForm' => 'tablet'], []);
        $variants = new ProductBundle('DENK_2345', [], [], [$variant]);

        $builder = new ModelBuilder(
            new InMemoryTaxonomyResolver(['administration-form' => ['tablet' => 'af-t']]),
            $locator,
        );
        $product = $builder->build($basic, $variants, ProductCategory::DietarySupplements, 'en_GB');

        self::assertSame('DENK_2345.jpg', $product->image);
        self::assertSame(['DENK_2345_1.pdf'], $product->administrations[0]->downloads);
    }
}
