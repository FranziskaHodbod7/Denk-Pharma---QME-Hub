<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\Parenthetical;
use Neos\Flow\Tests\UnitTestCase;

class ParentheticalTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     */
    public function fromSplitsTrailingParenthetical(string $value, string $base, ?string $note): void
    {
        $parenthetical = Parenthetical::from($value);

        self::assertSame($base, $parenthetical->base);
        self::assertSame($note, $parenthetical->note);
    }

    /**
     * @return array<string, array{0: string, 1: string, 2: ?string}>
     */
    public function examples(): array
    {
        return [
            'name and note' => ['Vitamin D3 (Cholecalciferol)', 'Vitamin D3', '(Cholecalciferol)'],
            'plain name'    => ['Vitamin C', 'Vitamin C', null],
            'trimmed'       => ['  Spaced  ', 'Spaced', null],
            'last group'    => ['Foo (bar) (baz)', 'Foo (bar)', '(baz)'],
            'only note'     => ['(only)', '', '(only)'],
            'unclosed'      => ['no close (paren', 'no close (paren', null],
            'empty parens'  => ['Empty parens ()', 'Empty parens', '()'],
        ];
    }
}
