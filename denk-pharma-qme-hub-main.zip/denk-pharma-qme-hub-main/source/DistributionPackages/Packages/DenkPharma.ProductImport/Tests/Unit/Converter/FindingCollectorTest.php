<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\FindingCollector;
use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class FindingCollectorTest extends UnitTestCase
{
    /**
     * @test
     */
    public function gathersFindingsFromEveryDepthIncludingUnresolvedReferences(): void
    {
        $product = new ImportProduct(
            sku: 'DENK_1',
            category: ProductCategory::Medicines,
            nodeId: 'p',
            uriPathSegment: TranslatedText::in('en_GB', 'p'),
            title: TranslatedText::in('en_GB', 'P'),
            shortDescription: null,
            longDescription: null,
            ingredients: null,
            storageInstructions: null,
            image: null,
            medications: [Reference::unresolved('Vit D', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no medications term'))],
            benefits: [],
            administrations: [
                new ImportAdministration('a', Reference::resolved('cream', 'af'), [], [
                    new ImportFormulation('f', 'DENK_1_1', null, null, [
                        new ImportIngredient(
                            'i',
                            Reference::unresolved('zinc', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no substance term')),
                            Reference::resolved('mg', 'u'),
                            '5',
                            [],
                        ),
                    ], []),
                ], []),
            ],
            compositions: [
                new ImportComposition('c', null, [
                    new ImportCompositionRow('r', null, TranslatedText::in('en_GB', 'C'), null, null, [
                        new Finding(Severity::Notice, 'substance-freeform', 'kept as free text'),
                    ]),
                ], []),
            ],
            findings: [new Finding(Severity::Error, 'missing-master', 'no master row')],
        );

        $findings = FindingCollector::collect(
            new ImportDocument([$product], [new Finding(Severity::Error, 'duplicate-identifier', 'seen twice')]),
        );

        $codes = array_map(static fn (Finding $finding): string => $finding->code, $findings);
        self::assertEqualsCanonicalizing(
            [
                'duplicate-identifier',
                'missing-master',
                'unresolved-taxonomy',
                'unresolved-taxonomy',
                'substance-freeform',
            ],
            $codes,
        );
    }
}
