<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Model;

use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class TranslatedTextTest extends UnitTestCase
{
    /**
     * @test
     */
    public function inStoresASingleLanguageValue(): void
    {
        $text = TranslatedText::in('en_GB', 'Hello');

        self::assertSame('Hello', $text->get('en_GB'));
        self::assertNull($text->get('fr_FR'));
    }

    /**
     * @test
     */
    public function withAddsATranslationImmutably(): void
    {
        $english = TranslatedText::in('en_GB', 'Hello');
        $both = $english->with('fr_FR', 'Bonjour');

        self::assertSame('Bonjour', $both->get('fr_FR'));
        self::assertSame('Hello', $both->get('en_GB'));
        self::assertNull($english->get('fr_FR'));
    }

    /**
     * @test
     */
    public function withOverridesTheSameLanguage(): void
    {
        $text = TranslatedText::in('en_GB', 'Hello')->with('en_GB', 'Hi');

        self::assertSame('Hi', $text->get('en_GB'));
    }
}
