<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\Text;
use Neos\Flow\Tests\UnitTestCase;

class TextTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     */
    public function singleLineCollapsesWhitespace(string $value, string $expected): void
    {
        self::assertSame($expected, Text::singleLine($value));
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public function examples(): array
    {
        return [
            'broken name'  => ["Amlodipin /\nValsartan Denk", 'Amlodipin / Valsartan Denk'],
            'extra spaces' => ['  spaced   out  ', 'spaced out'],
            'no change'    => ['no change', 'no change'],
            'tabs and nl'  => ["tabs\t\tand\nnewlines", 'tabs and newlines'],
            'empty'        => ['', ''],
        ];
    }
}
