<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Model;

use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use Neos\Flow\Tests\UnitTestCase;

class ReferenceTest extends UnitTestCase
{
    /**
     * @test
     */
    public function resolvedCarriesTheNodeIdAndNoFinding(): void
    {
        $reference = Reference::resolved('Magnesium', 'node-123');

        self::assertSame('Magnesium', $reference->value);
        self::assertSame('node-123', $reference->nodeId);
        self::assertNull($reference->finding);
    }

    /**
     * @test
     */
    public function unresolvedCarriesAFindingAndNoNodeId(): void
    {
        $finding = new Finding(Severity::Warning, 'unresolved-taxonomy');
        $reference = Reference::unresolved('Vitamine D', $finding);

        self::assertSame('Vitamine D', $reference->value);
        self::assertNull($reference->nodeId);
        self::assertSame($finding, $reference->finding);
    }
}
