<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\XmlReader;
use DenkPharma\ProductImport\Converter\XmlSerializer;
use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class XmlReaderTest extends UnitTestCase
{
    private function document(): ImportDocument
    {
        $product = new ImportProduct(
            sku: 'DENK_1',
            category: ProductCategory::Medicines,
            nodeId: 'p-node',
            uriPathSegment: TranslatedText::in('en_GB', 'amva-denk'),
            title: TranslatedText::in('en_GB', 'A & B Denk'),
            shortDescription: TranslatedText::in('en_GB', 'Short'),
            longDescription: null,
            ingredients: null,
            storageInstructions: null,
            image: 'DENK_1.jpg',
            medications: [
                Reference::resolved('antibiotics', 'tax-ab'),
                Reference::unresolved('Vitamine D', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no medications term')),
            ],
            benefits: [new ImportBenefit('b-node', TranslatedText::in('en_GB', 'Highly bioavailable'), [])],
            administrations: [
                new ImportAdministration('a-node', Reference::resolved('cream', 'af-cream'), ['DENK_1_1.pdf'], [
                    new ImportFormulation('f-node', 'DENK_1_1', Reference::resolved('tube-50', 'pkg-50'), TranslatedText::in('en_GB', 'Apply twice daily'), [
                        new ImportIngredient(
                            'i-node',
                            Reference::resolved('acyclovir', 's-acy'),
                            Reference::unresolved('mg', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no unit')),
                            '200',
                            [],
                        ),
                    ], []),
                ], []),
            ],
            compositions: [
                new ImportComposition('c-node', TranslatedText::in('en_GB', 'Per tablet'), [
                    new ImportCompositionRow('r-node', null, TranslatedText::in('en_GB', 'Vitamin C'), TranslatedText::in('en_GB', '40 mg'), TranslatedText::in('en_GB', '50'), [
                        new Finding(Severity::Notice, 'substance-freeform', "'Vitamin C' kept as free text"),
                    ]),
                ], []),
            ],
            findings: [new Finding(Severity::Error, 'duplicate-identifier', 'DENK_1 is used by 2 products; none are imported')],
        );

        return new ImportDocument([$product]);
    }

    /**
     * @test
     */
    public function roundTripsEverySerializedFieldThroughTheReader(): void
    {
        $serializer = new XmlSerializer();
        $xml = $serializer->serialize($this->document(), '2026-06-02T10:00:00Z', 'medicines.csv');

        $parsed = (new XmlReader())->read($xml);

        self::assertSame($xml, $serializer->serialize($parsed, '2026-06-02T10:00:00Z', 'medicines.csv'));
    }

    /**
     * @test
     */
    public function reconstructsValuesNodeIdsReferencesAssetsAndFindings(): void
    {
        $xml = (new XmlSerializer())->serialize($this->document());

        $product = (new XmlReader())->read($xml)->products[0];

        self::assertSame('DENK_1', $product->sku);
        self::assertSame(ProductCategory::Medicines, $product->category);
        self::assertSame('p-node', $product->nodeId);
        self::assertSame('A & B Denk', $product->title->get('en_GB'));
        self::assertNull($product->longDescription);
        self::assertSame('DENK_1.jpg', $product->image);

        self::assertSame('tax-ab', $product->medications[0]->nodeId);
        self::assertNull($product->medications[1]->nodeId);
        self::assertSame('Vitamine D', $product->medications[1]->value);

        $administration = $product->administrations[0];
        self::assertSame(['DENK_1_1.pdf'], $administration->downloads);
        $ingredient = $administration->formulations[0]->ingredients[0];
        self::assertSame('200', $ingredient->quantity);
        self::assertSame('s-acy', $ingredient->substance->nodeId);
        self::assertNull($ingredient->unit->nodeId);

        self::assertSame('Vitamin C', $product->compositions[0]->rows[0]->substanceText->get('en_GB'));
        self::assertSame('duplicate-identifier', $product->findings[0]->code);
        self::assertSame(Severity::Error, $product->findings[0]->severity);
    }
}
