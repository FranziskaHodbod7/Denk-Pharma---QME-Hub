<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Loader;

use DenkPharma\ProductImport\Loader\ImportPlanner;
use DenkPharma\ProductImport\Loader\PlannedNode;
use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class ImportPlannerTest extends UnitTestCase
{
    private function product(string $sku, array $findings = []): ImportProduct
    {
        return new ImportProduct(
            sku: $sku,
            category: ProductCategory::Medicines,
            nodeId: 'p-' . $sku,
            uriPathSegment: TranslatedText::in('en_GB', strtolower($sku)),
            title: TranslatedText::in('en_GB', 'Product ' . $sku),
            shortDescription: null,
            longDescription: null,
            ingredients: null,
            storageInstructions: null,
            image: 'DENK.jpg',
            medications: [
                Reference::resolved('antibiotics', 'tax-ab'),
                Reference::unresolved('Vitamine D', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no term')),
            ],
            benefits: [new ImportBenefit('b-1', TranslatedText::in('en_GB', 'Bioavailable'), [])],
            administrations: [
                new ImportAdministration('a-1', Reference::resolved('cream', 'af-cream'), ['DENK_1.pdf'], [
                    new ImportFormulation('f-1', 'DENK_1_1', Reference::resolved('tube-50', 'pkg-50'), TranslatedText::in('en_GB', 'Twice daily'), [
                        new ImportIngredient(
                            'i-1',
                            Reference::resolved('acyclovir', 's-acy'),
                            Reference::unresolved('mg', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no unit')),
                            '12.5',
                            [],
                        ),
                    ], []),
                ], []),
            ],
            compositions: [
                new ImportComposition('c-1', TranslatedText::in('en_GB', 'Per tablet'), [
                    new ImportCompositionRow('r-1', Reference::resolved('zinc', 's-zinc'), null, TranslatedText::in('en_GB', '5 mg'), null, []),
                ], []),
            ],
            findings: $findings,
        );
    }

    /**
     * @return array<string, PlannedNode>
     */
    private function byId(array $operations): array
    {
        $map = [];
        foreach ($operations as $node) {
            $map[$node->nodeAggregateId] = $node;
        }

        return $map;
    }

    /**
     * @test
     */
    public function plansOneAggregatePerNodeParentsFirst(): void
    {
        $plan = (new ImportPlanner())->plan(new ImportDocument([$this->product('DENK_1')]));

        $types = array_map(static fn (PlannedNode $n): string => $n->nodeType, $plan->operations);
        self::assertSame([
            'DenkPharma.Product:Document.Product',
            'DenkPharma.Product:Content.Benefit',
            'DenkPharma.Product:Content.Administration',
            'DenkPharma.Product:Content.Administration.Formulation',
            'DenkPharma.Product:Content.Administration.Formulation.Ingredient',
            'DenkPharma.Product:Content.Composition',
            'DenkPharma.Product:Content.Composition.Row',
        ], $types);
    }

    /**
     * @test
     */
    public function setsCategoryResolvedReferencesAndAssetsButNotUnresolvedOnes(): void
    {
        $nodes = $this->byId((new ImportPlanner())->plan(new ImportDocument([$this->product('DENK_1')]))->operations);

        $product = $nodes['p-DENK_1'];
        self::assertSame('medicines', $product->category);
        self::assertSame(['tax-ab'], $product->references['medications']);
        self::assertSame(['DENK.jpg'], $product->assets['image']);
        self::assertArrayHasKey('title', $product->properties);

        $administration = $nodes['a-1'];
        self::assertSame(['af-cream'], $administration->references['administrationForm']);
        self::assertSame(['DENK_1.pdf'], $administration->assets['downloads']);
    }

    /**
     * @test
     */
    public function castsQuantityToFloatAndMapsTheUnitReferenceToSubstanceUnitOmittingTheUnresolvedOne(): void
    {
        $ingredient = $this->byId((new ImportPlanner())->plan(new ImportDocument([$this->product('DENK_1')]))->operations)['i-1'];

        self::assertSame('f-1', $ingredient->parentNodeAggregateId);
        self::assertSame(12.5, $ingredient->properties['quantity']);
        self::assertSame(['s-acy'], $ingredient->references['substance']);
        self::assertArrayNotHasKey('substance-unit', $ingredient->references);
    }

    /**
     * @test
     */
    public function placesChildrenUnderTheirParentAndTetheredCollection(): void
    {
        $nodes = $this->byId((new ImportPlanner())->plan(new ImportDocument([$this->product('DENK_1')]))->operations);

        self::assertSame('p-DENK_1', $nodes['b-1']->parentNodeAggregateId);
        self::assertSame('benefits', $nodes['b-1']->tetheredParentName);
        self::assertSame('p-DENK_1', $nodes['a-1']->parentNodeAggregateId);
        self::assertSame('administrations', $nodes['a-1']->tetheredParentName);
        self::assertSame('c-1', $nodes['r-1']->parentNodeAggregateId);
        self::assertNull($nodes['r-1']->tetheredParentName);
    }

    /**
     * @test
     */
    public function skipsProductsWhoseSubtreeCarriesAnError(): void
    {
        $bad = $this->product('DENK_2', [new Finding(Severity::Error, 'duplicate-identifier', 'used twice')]);

        $plan = (new ImportPlanner())->plan(new ImportDocument([$this->product('DENK_1'), $bad]));

        self::assertCount(1, $plan->skipped);
        self::assertSame('DENK_2', $plan->skipped[0]->sku);
        self::assertSame(['duplicate-identifier: used twice'], $plan->skipped[0]->reasons);
        foreach ($plan->operations as $node) {
            self::assertStringStartsNotWith('p-DENK_2', $node->nodeAggregateId);
        }
    }
}
