<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Util;

use DenkPharma\ProductImport\Util\Slug;
use Neos\Flow\Tests\UnitTestCase;

class SlugTest extends UnitTestCase
{
    /**
     * @test
     * @dataProvider examples
     */
    public function fromTitleProducesAUriPathSegment(string $title, string $expected): void
    {
        self::assertSame($expected, Slug::fromTitle($title));
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public function examples(): array
    {
        return [
            'simple'            => ['arthro active Denk', 'arthro-active-denk'],
            'with digit'        => ['Denk Vitamin D3', 'denk-vitamin-d3'],
            'slash and spaces'  => ['Amlodipin / Valsartan Denk', 'amlodipin-valsartan-denk'],
            'surrounding space' => ['  Spaced Title  ', 'spaced-title'],
        ];
    }
}
