<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\XmlSerializer;
use DenkPharma\ProductImport\Model\Finding;
use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\Severity;
use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class XmlSerializerTest extends UnitTestCase
{
    private function xml(): string
    {
        $product = new ImportProduct(
            sku: 'DENK_1',
            category: ProductCategory::Medicines,
            nodeId: 'p-node',
            uriPathSegment: TranslatedText::in('en_GB', 'amva-denk'),
            title: TranslatedText::in('en_GB', 'A & B Denk'),
            shortDescription: null,
            longDescription: null,
            ingredients: null,
            storageInstructions: null,
            image: 'DENK_1.jpg',
            medications: [
                Reference::resolved('antibiotics', 'tax-ab'),
                Reference::unresolved('Vitamine D', new Finding(Severity::Warning, 'unresolved-taxonomy', 'no medications term')),
            ],
            benefits: [new ImportBenefit('b-node', TranslatedText::in('en_GB', 'Highly bioavailable'), [])],
            administrations: [
                new ImportAdministration('a-node', Reference::resolved('cream', 'af-cream'), ['DENK_1_1.pdf'], [
                    new ImportFormulation('f-node', 'DENK_1_1', null, null, [
                        new ImportIngredient('i-node', Reference::resolved('acyclovir', 's-acy'), Reference::resolved('mg', 'u-mg'), '200', []),
                    ], []),
                ], []),
            ],
            compositions: [
                new ImportComposition('c-node', null, [
                    new ImportCompositionRow(
                        'r-node',
                        null,
                        TranslatedText::in('en_GB', 'Vitamin C'),
                        TranslatedText::in('en_GB', '40 mg'),
                        TranslatedText::in('en_GB', '50'),
                        [new Finding(Severity::Notice, 'substance-freeform', "'Vitamin C' kept as free text")],
                    ),
                ], []),
            ],
            findings: [new Finding(Severity::Error, 'duplicate-identifier', 'DENK_1 seen twice')],
        );

        return (new XmlSerializer())->serialize(new ImportDocument([$product]), '2026-06-02T10:00:00Z', 'medicines.csv');
    }

    /**
     * @test
     */
    public function declaresBothNamespacesAndTheSummaryCounts(): void
    {
        $xml = $this->xml();

        self::assertStringContainsString('xmlns:m="urn:denkpharma:import:resolution"', $xml);
        self::assertStringContainsString('xmlns:v="urn:denkpharma:import:validation"', $xml);
        self::assertStringContainsString('generatedAt="2026-06-02T10:00:00Z"', $xml);
        self::assertStringContainsString('<v:summary products="1" errors="1" warnings="1" notices="1"', $xml);
    }

    /**
     * @test
     */
    public function serializesProductFieldsReferencesAndEscapesText(): void
    {
        $xml = $this->xml();

        self::assertStringContainsString('sku="DENK_1"', $xml);
        self::assertStringContainsString('category="medicines"', $xml);
        self::assertStringContainsString('m:nodeId="p-node"', $xml);
        self::assertStringContainsString('<t lang="en_GB">A &amp; B Denk</t>', $xml);
        self::assertStringContainsString('<medication m:ref="tax-ab">antibiotics</medication>', $xml);
        self::assertStringContainsString('<medication v:status="unresolved-taxonomy">Vitamine D</medication>', $xml);
        self::assertStringContainsString('<t lang="en_GB">Highly bioavailable</t>', $xml);
    }

    /**
     * @test
     */
    public function serializesIngredientsCompositionsAndFindings(): void
    {
        $xml = $this->xml();

        self::assertStringContainsString('quantity="200"', $xml);
        self::assertStringContainsString('<substance m:ref="s-acy">acyclovir</substance>', $xml);
        self::assertStringContainsString('<t lang="en_GB">Vitamin C</t>', $xml);
        self::assertStringContainsString('<v:issue severity="notice" code="substance-freeform"', $xml);
        self::assertStringContainsString('<v:issue severity="error" code="duplicate-identifier"', $xml);
    }

    /**
     * @test
     */
    public function serializesImageAndDownloadSources(): void
    {
        $xml = $this->xml();

        self::assertStringContainsString('<image m:src="DENK_1.jpg"/>', $xml);
        self::assertStringContainsString('<download m:src="DENK_1_1.pdf"/>', $xml);
    }

    /**
     * @test
     */
    public function producesWellFormedXml(): void
    {
        self::assertNotFalse(simplexml_load_string($this->xml()));
    }

    /**
     * @test
     */
    public function serializesDocumentLevelFindings(): void
    {
        $document = new ImportDocument([], [new Finding(Severity::Error, 'duplicate-identifier', 'DENK_1 appears in 2 products')]);

        $xml = (new XmlSerializer())->serialize($document);

        self::assertStringContainsString('<v:summary products="0" errors="1"', $xml);
        self::assertStringContainsString('<v:issue severity="error" code="duplicate-identifier"', $xml);
    }
}
