<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Converter;

use DenkPharma\ProductImport\Converter\Segmenter;
use Neos\Flow\Tests\UnitTestCase;

class SegmenterTest extends UnitTestCase
{
    /**
     * @test
     */
    public function basicProductCollectsItsSubRows(): void
    {
        $product = ['productIdentifier' => 'DENK_2345', 'productName' => 'arthro active Denk', 'compositionNutrient' => ''];
        $row1 = ['productIdentifier' => '', 'productName' => '', 'compositionNutrient' => 'Vitamin C'];
        $row2 = ['productIdentifier' => '', 'productName' => '', 'compositionNutrient' => 'Vitamin K'];
        $separator = ['productIdentifier' => '', 'productName' => '', 'compositionNutrient' => ''];
        $product2 = ['productIdentifier' => 'DENK_2346', 'productName' => 'brain active Denk', 'compositionNutrient' => ''];

        $bundles = Segmenter::segment([$product, $row1, $row2, $separator, $product2]);

        self::assertCount(2, $bundles);
        self::assertSame('DENK_2345', $bundles[0]->identifier);
        self::assertSame($product, $bundles[0]->leadRow);
        self::assertSame([$row1, $row2], $bundles[0]->subRows);
        self::assertSame([], $bundles[0]->variants);
        self::assertSame('DENK_2346', $bundles[1]->identifier);
        self::assertSame([], $bundles[1]->subRows);
    }

    /**
     * @test
     */
    public function variantsNestUnderTheProductWithTheirSubRows(): void
    {
        $header = ['productIdentifier' => 'DENK_1234', 'productName' => 'Acyclovir Denk', 'formulationSubstance' => ''];
        $variant1 = ['productIdentifier' => 'DENK_1234_1', 'dosageForm' => 'cream', 'formulationSubstance' => ''];
        $variant1Ingredient = ['productIdentifier' => '', 'dosageForm' => '', 'formulationSubstance' => 'Acyclovir'];
        $variant2 = ['productIdentifier' => 'DENK_1234_2', 'dosageForm' => 'tablet', 'formulationSubstance' => ''];
        $variant2Ingredient = ['productIdentifier' => '', 'dosageForm' => '', 'formulationSubstance' => 'Acyclovir'];

        $bundles = Segmenter::segment([$header, $variant1, $variant1Ingredient, $variant2, $variant2Ingredient]);

        self::assertCount(1, $bundles);
        self::assertSame('DENK_1234', $bundles[0]->identifier);
        self::assertSame([], $bundles[0]->subRows);
        self::assertCount(2, $bundles[0]->variants);
        self::assertSame('DENK_1234_1', $bundles[0]->variants[0]->identifier);
        self::assertSame($variant1, $bundles[0]->variants[0]->leadRow);
        self::assertSame([$variant1Ingredient], $bundles[0]->variants[0]->subRows);
        self::assertSame('DENK_1234_2', $bundles[0]->variants[1]->identifier);
        self::assertSame([$variant2Ingredient], $bundles[0]->variants[1]->subRows);
    }

    /**
     * @test
     */
    public function subRowBeforeAnyVariantAttachesToTheProduct(): void
    {
        $header = ['productIdentifier' => 'DENK_1236', 'dosageForm' => ''];
        $beforeVariant = ['productIdentifier' => '', 'dosageForm' => 'cream'];
        $variant = ['productIdentifier' => 'DENK_1236_1', 'dosageForm' => 'tablet'];
        $ingredient = ['productIdentifier' => '', 'dosageForm' => ''];

        // give the ingredient row a non-empty cell so it is not treated as a separator
        $ingredient['formulationSubstance'] = 'Amlodipin';

        $bundles = Segmenter::segment([$header, $beforeVariant, $variant, $ingredient]);

        self::assertSame([$beforeVariant], $bundles[0]->subRows);
        self::assertCount(1, $bundles[0]->variants);
        self::assertSame([$ingredient], $bundles[0]->variants[0]->subRows);
    }

    /**
     * @test
     */
    public function fullyBlankRowsAreSeparatorsNotSubRows(): void
    {
        $product = ['productIdentifier' => 'DENK_1', 'productName' => 'X'];
        $blank = ['productIdentifier' => '', 'productName' => ''];
        $subRow = ['productIdentifier' => '', 'productName' => 'note'];

        $bundles = Segmenter::segment([$product, $blank, $subRow]);

        self::assertSame([$subRow], $bundles[0]->subRows);
    }

    /**
     * @test
     */
    public function variantWithoutAProductSynthesizesItsParent(): void
    {
        $variant = ['productIdentifier' => 'DENK_9999_1', 'dosageForm' => 'tablet'];

        $bundles = Segmenter::segment([$variant]);

        self::assertCount(1, $bundles);
        self::assertSame('DENK_9999', $bundles[0]->identifier);
        self::assertSame([], $bundles[0]->leadRow);
        self::assertCount(1, $bundles[0]->variants);
        self::assertSame('DENK_9999_1', $bundles[0]->variants[0]->identifier);
    }

    /**
     * @test
     */
    public function subRowsWithNoProductContextAreDropped(): void
    {
        $stray = ['productIdentifier' => '', 'productName' => 'junk'];
        $product = ['productIdentifier' => 'DENK_1', 'productName' => 'X'];

        $bundles = Segmenter::segment([$stray, $product]);

        self::assertCount(1, $bundles);
        self::assertSame('DENK_1', $bundles[0]->identifier);
        self::assertSame([], $bundles[0]->subRows);
    }
}
