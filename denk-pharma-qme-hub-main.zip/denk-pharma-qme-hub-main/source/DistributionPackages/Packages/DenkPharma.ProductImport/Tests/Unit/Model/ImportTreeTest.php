<?php

declare(strict_types=1);

namespace DenkPharma\ProductImport\Tests\Unit\Model;

use DenkPharma\ProductImport\Model\ImportAdministration;
use DenkPharma\ProductImport\Model\ImportBenefit;
use DenkPharma\ProductImport\Model\ImportComposition;
use DenkPharma\ProductImport\Model\ImportCompositionRow;
use DenkPharma\ProductImport\Model\ImportDocument;
use DenkPharma\ProductImport\Model\ImportFormulation;
use DenkPharma\ProductImport\Model\ImportIngredient;
use DenkPharma\ProductImport\Model\ImportProduct;
use DenkPharma\ProductImport\Model\ProductCategory;
use DenkPharma\ProductImport\Model\Reference;
use DenkPharma\ProductImport\Model\TranslatedText;
use Neos\Flow\Tests\UnitTestCase;

class ImportTreeTest extends UnitTestCase
{
    /**
     * @test
     */
    public function aProductWithBenefitsAndMedicationsAssembles(): void
    {
        $product = new ImportProduct(
            sku: 'DENK_2345',
            category: ProductCategory::DietarySupplements,
            nodeId: 'node-1',
            uriPathSegment: TranslatedText::in('en_GB', 'arthro-active-denk'),
            title: TranslatedText::in('en_GB', 'arthro active Denk'),
            shortDescription: null,
            longDescription: null,
            ingredients: null,
            storageInstructions: null,
            image: null,
            medications: [Reference::resolved('minerals-and-vitamins', 'tax-1')],
            benefits: [new ImportBenefit('node-b', TranslatedText::in('en_GB', 'Highly bioavailable'), [])],
            administrations: [],
            compositions: [],
            findings: [],
        );
        $document = new ImportDocument([$product]);

        self::assertCount(1, $document->products);
        self::assertSame('DENK_2345', $document->products[0]->sku);
        self::assertSame('arthro active Denk', $document->products[0]->title->get('en_GB'));
        self::assertSame('tax-1', $document->products[0]->medications[0]->nodeId);
        self::assertSame('Highly bioavailable', $document->products[0]->benefits[0]->description->get('en_GB'));
    }

    /**
     * @test
     */
    public function anAdministrationSubtreeAssembles(): void
    {
        $ingredient = new ImportIngredient('n-ing', Reference::resolved('Vitamin D3', 't-s'), Reference::resolved('µg', 't-u'), '25', []);
        $formulation = new ImportFormulation('n-f', 'DENK_1236_1', null, null, [$ingredient], []);
        $administration = new ImportAdministration('n-a', Reference::resolved('tablet', 't-a'), [], [$formulation], []);

        self::assertSame('25', $administration->formulations[0]->ingredients[0]->quantity);
        self::assertSame('Vitamin D3', $administration->formulations[0]->ingredients[0]->substance->value);
    }

    /**
     * @test
     */
    public function aCompositionRowCarriesBothSubstanceAndText(): void
    {
        $row = new ImportCompositionRow(
            'n-r',
            Reference::resolved('Vitamin D3', 't'),
            TranslatedText::in('en_GB', '(Cholecalciferol)'),
            TranslatedText::in('en_GB', '25 µg'),
            TranslatedText::in('en_GB', '500%'),
            [],
        );
        $composition = new ImportComposition('n-c', null, [$row], []);

        self::assertSame('Vitamin D3', $composition->rows[0]->substance->value);
        self::assertSame('(Cholecalciferol)', $composition->rows[0]->substanceText->get('en_GB'));
    }
}
