<?php

declare(strict_types=1);

namespace DenkPharma\Core\Infrastructure\Property\Normalizer;

use Neos\Utility\TypeHandling;
use Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

/**
 * Replaces Neos\ContentRepository\Core\Infrastructure\Property\Normalizer\ScalarNormalizer
 */
final class ScalarNormalizer implements NormalizerInterface, DenormalizerInterface
{
    /**
     * @param array<string,mixed> $context
     * @return int|float|bool|string
     */
    public function normalize($object, ?string $format = null, array $context = []): mixed
    {
        return $object;
    }

    public function supportsNormalization($data, ?string $format = null): bool
    {
        $type = TypeHandling::getTypeForValue($data);
        return TypeHandling::isSimpleType($type) && !TypeHandling::isCollectionType($type);
    }

    /**
     * @param array<string,mixed> $context
     */
    public function denormalize($data, $type, ?string $format = null, array $context = []): mixed
    {
        return match ($type) {
            'float', 'double' => (float) $data,
            'int', 'integer' => (int) $data,
            'bool', 'boolean' => (bool) $data,
            'string' => (string) $data,
            default => $data,
        };
    }

    public function supportsDenormalization($data, $type, ?string $format = null): bool
    {
        return TypeHandling::isSimpleType($type) && !TypeHandling::isCollectionType($type);
    }
}
