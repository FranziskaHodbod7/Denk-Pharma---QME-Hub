<?php

declare(strict_types=1);

namespace DenkPharma\Core\Service;

use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\Subtree;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Sitegeist\Taxonomy\Service\TaxonomyService;

#[Flow\Scope('singleton')]
final class TaxonomyResolver
{
    #[Flow\Inject(lazy: false)]
    protected TaxonomyService $taxonomyService;

    /** @return list<Node> */
    public function listAll(ContentSubgraphInterface $subgraph, string $vocabularyName): array
    {
        $vocabulary = $this->taxonomyService->findVocabularyByName($subgraph, $vocabularyName);
        if (!$vocabulary instanceof Node) {
            return [];
        }
        $subtree = $this->taxonomyService->findSubtree($vocabulary);
        if (!$subtree instanceof Subtree) {
            return [];
        }
        return $this->flattenSubtree($subtree);
    }

    /**
     * @param list<NodeAggregateId> $ids
     * @return array<string, Node> keyed by aggregate-ID string, in input order; unknowns dropped
     */
    public function resolveByIds(ContentSubgraphInterface $subgraph, string $vocabularyName, array $ids): array
    {
        $byId = [];
        foreach ($this->listAll($subgraph, $vocabularyName) as $node) {
            $byId[$node->aggregateId->value] = $node;
        }
        $resolved = [];
        foreach ($ids as $id) {
            $key = $id->value;
            if (isset($byId[$key])) {
                $resolved[$key] = $byId[$key];
            }
        }
        return $resolved;
    }

    /** @return list<Node> */
    private function flattenSubtree(Subtree $subtree): array
    {
        $nodes = [];
        foreach ($subtree->children as $child) {
            $nodes[] = $child->node;
            array_push($nodes, ...$this->flattenSubtree($child));
        }
        return $nodes;
    }
}
