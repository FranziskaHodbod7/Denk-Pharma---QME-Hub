<?php

declare(strict_types=1);

namespace DenkPharma\Core\Eel;

use Neos\ContentRepository\Core\NodeType\NodeTypeName;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\Subtree;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;
use Sitegeist\Taxonomy\Service\TaxonomyService;

class TaxonomyHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject(lazy: false)]
    protected TaxonomyService $taxonomyService;

    /**
     * Per-vocabulary term ordering: vocabularyName => (termName => priority).
     * Higher priority sorts earlier; unlisted terms default to 0.
     *
     * @phpstan-var array<string, array<string, int>>
     */
    #[Flow\InjectConfiguration(path: 'Taxonomy.ordering', package: 'DenkPharma.Core')]
    protected array $ordering = [];

    public function getVocabulary(Node $contextNode, string $vocabularyName): ?Node
    {
        $subgraph = $this->taxonomyService->getSubgraphForNode($contextNode);
        return $this->taxonomyService->findVocabularyByName($subgraph, $vocabularyName) ?: null;
    }

    /**
     * Returns all taxonomy nodes for the given vocabulary name, in canonical
     * order (configured priority descending, then title ascending).
     *
     * @return list<Node>
     */
    public function getOptions(Node $contextNode, string $vocabularyName): array
    {
        $subgraph = $this->taxonomyService->getSubgraphForNode($contextNode);
        $vocabulary = $this->taxonomyService->findVocabularyByName($subgraph, $vocabularyName);
        if (!$vocabulary instanceof Node) {
            return [];
        }
        $subtree = $this->taxonomyService->findSubtree($vocabulary);
        if (!$subtree instanceof Subtree) {
            return [];
        }
        return $this->applyOrdering($vocabularyName, $this->flattenSubtree($subtree));
    }

    /**
     * Resolves a list of node aggregate-ID strings to their taxonomy nodes, filtering out unknowns.
     *
     * @param list<string> $ids aggregate-ID strings
     * @return array<string, Node> keyed by aggregate-ID string, in input order, with unknowns dropped
     */
    public function resolveByIds(Node $contextNode, string $vocabularyName, array $ids): array
    {
        $byId = [];
        foreach ($this->getOptions($contextNode, $vocabularyName) as $node) {
            $byId[$node->aggregateId->value] = $node;
        }
        $resolved = [];
        foreach ($ids as $id) {
            if (isset($byId[$id])) {
                $resolved[$id] = $byId[$id];
            }
        }
        return $resolved;
    }

    /**
     * Returns the slash-separated path by traversing upward through ancestors
     * to the vocabulary root.
     */
    public function getPathForNode(Node $contextNode, Node $termNode): string
    {
        $subgraph = $this->taxonomyService->getSubgraphForNode($contextNode);
        $parts = [$termNode->name?->value ?? ''];
        $current = $termNode;

        $runAway = 10000;
        while (true && ($runAway-- > 0)) {
            $parent = $subgraph->findParentNode($current->aggregateId);
            if (!$parent instanceof Node) {
                break;
            }
            if ($parent->nodeTypeName->equals(NodeTypeName::fromString('Sitegeist.Taxonomy:Vocabulary'))) {
                break;
            }
            array_unshift($parts, $parent->name?->value ?? '');
            $current = $parent;
        }
        return implode('/', $parts);
    }

    /** @return list<Node> */
    protected function flattenSubtree(Subtree $subtree): array
    {
        $nodes = [];
        foreach ($subtree->children as $child) {
            $nodes[] = $child->node;
            array_push($nodes, ...$this->flattenSubtree($child));
        }
        return $nodes;
    }

    /**
     * @param list<Node> $nodes
     * @return list<Node>
     */
    protected function applyOrdering(string $vocabularyName, array $nodes): array
    {
        $priorities = $this->ordering[$vocabularyName] ?? [];
        usort($nodes, static function (Node $a, Node $b) use ($priorities): int {
            $priorityA = $priorities[$a->name?->value] ?? 0;
            $priorityB = $priorities[$b->name?->value] ?? 0;
            if ($priorityA !== $priorityB) {
                return $priorityB <=> $priorityA;
            }
            return strcasecmp((string)$a->getProperty('title'), (string)$b->getProperty('title'));
        });
        return $nodes;
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
