<?php

declare(strict_types=1);

namespace FormatD\NodeTypeSubtreeTag\Exception;

class NodeTypeNotFound extends \Exception
{
}
