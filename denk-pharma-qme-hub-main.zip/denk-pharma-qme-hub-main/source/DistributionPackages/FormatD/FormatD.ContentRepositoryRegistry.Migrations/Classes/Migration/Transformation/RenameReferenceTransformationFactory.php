<?php

declare(strict_types=1);

namespace DenkPharma\ContentRepositoryRegistry\Migrations\Migration\Transformation;

use Neos\ContentRepository\Core\ContentRepository;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePointSet;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Command\SetNodeReferences;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesForName;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesToWrite;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferenceToWrite;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\ReferenceName;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepository\NodeMigration\Transformation\NodeBasedTransformationInterface;
use Neos\ContentRepository\NodeMigration\Transformation\GlobalTransformationInterface;
use Neos\ContentRepository\NodeMigration\Transformation\NodeAggregateBasedTransformationInterface;
use Neos\ContentRepository\NodeMigration\Transformation\TransformationFactoryInterface;
use Neos\ContentRepository\NodeMigration\Transformation\TransformationStep;

class RenameReferenceTransformationFactory implements TransformationFactoryInterface
{
    /**
     * @param array<string,string> $settings
     */
    public function build(
        array $settings,
        ContentRepository $contentRepository,
    ): GlobalTransformationInterface|NodeAggregateBasedTransformationInterface|NodeBasedTransformationInterface {
        return new class (
            $settings['from'],
            $settings['to'],
            $contentRepository,
        ) implements NodeBasedTransformationInterface {
            public function __construct(
                protected readonly string $from,
                protected readonly string $to,
                protected readonly ContentRepository $contentRepository,
            ) {
            }

            public function execute(
                Node $node,
                DimensionSpacePointSet $coveredDimensionSpacePoints,
                WorkspaceName $workspaceNameForWriting,
            ): TransformationStep {
                $subgraph = $this->contentRepository
                    ->getContentGraph($node->workspaceName)
                    ->getSubgraph($node->dimensionSpacePoint, $node->visibilityConstraints);

                $existingReferences = $subgraph->findReferences(
                    $node->aggregateId,
                    FindReferencesFilter::create(referenceName: $this->from),
                );

                if ($existingReferences->count() === 0) {
                    return TransformationStep::createEmpty();
                }

                $referencesToWrite = array_map(
                    static fn ($reference) => NodeReferenceToWrite::fromTarget($reference->node->aggregateId),
                    iterator_to_array($existingReferences),
                );

                return TransformationStep::fromCommand(
                    SetNodeReferences::create(
                        $workspaceNameForWriting,
                        $node->aggregateId,
                        $node->originDimensionSpacePoint,
                        NodeReferencesToWrite::create(
                            NodeReferencesForName::fromReferences(
                                ReferenceName::fromString($this->to),
                                $referencesToWrite,
                            ),
                            NodeReferencesForName::createEmpty(
                                ReferenceName::fromString($this->from),
                            ),
                        ),
                    )
                );
            }
        };
    }
}
