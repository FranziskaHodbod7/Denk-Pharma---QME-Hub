<?php

declare(strict_types=1);

namespace FormatD\ReferencedTaxonomies\Eel;

use Neos\ContentRepository\Core\Projection\ContentGraph\AbsoluteNodePath;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindReferencesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindSubtreeFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\Subtree;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;
use Sitegeist\Taxonomy\Service\TaxonomyService;

class UIHelper implements ProtectedContextAwareInterface
{
	#[Flow\Inject(lazy: false)]
	protected ContentRepositoryRegistry $contentRepositoryRegistry;

	#[Flow\Inject]
	protected TaxonomyService $taxonomyService;

	public function buildReferencesFormData(?Node $node): array
	{
		if ($node === null) {
			return [];
		}

		$subgraph = $this->taxonomyService->getSubgraphForNode($node);

		$referencesConfiguration = $this->getReferencesConfigurationFromNodeType($node);

		$formData = [];

		foreach ($referencesConfiguration as $referenceName => $_) {
			$references = $subgraph->findReferences(
				$node->aggregateId,
				FindReferencesFilter::create(referenceName: $referenceName)
			);

			$formData[$referenceName] = array_map(fn($r) => $r->node->aggregateId->value, $references->references);
		}

		return $formData;
	}

	/**
	 * @return ?array<string, mixed>
	 */
	public function getReferencesUIData(?Node $node): ?array
	{
		if ($node === null) {
			return null;
		}

		$referencesConfiguration = $this->getReferencesConfigurationFromNodeType($node);
		if ($referencesConfiguration === null) {
			return null;
		}

		$subgraph = $this->taxonomyService->getDefaultSubgraph();
		$data = [];

		foreach ($referencesConfiguration as $referenceName => $referenceConfiguration) {
			$referenceUIData = [];
			$referenceUIData['label'] = $referenceConfiguration['ui']['label'] ?? $referenceName;

			$startingPoint = $referenceConfiguration['ui']['inspector']['editorOptions']['startingPoint'] ?? null;

			$referenceUIData['taxons'] = [];
			if ($startingPoint !== null) {
				$startingNode = $subgraph->findNodeByAbsolutePath(AbsoluteNodePath::fromString($startingPoint));

				if ($startingNode !== null) {
					$subtree = $subgraph->findSubtree($startingNode->aggregateId, FindSubtreeFilter::create());
					$referenceUIData['taxons'] = $subtree ? [...$this->flattenTaxons($subtree)] : [];
				}
			}

			$data[$referenceName] = $referenceUIData;
		}

		ksort($data);

		return $data;
	}

	/**
	 * @return iterable<array{id: string, label: string}>
	 */
	protected function flattenTaxons(Subtree $subtree, string $prefix = ''): iterable
	{
		foreach ($subtree->children as $child) {
			$node = $child->node;
			$title = $node->getProperty('title');
			$label = \is_string($title) && $title !== ''
				? $title
				: ($node->name?->value ?? $node->aggregateId->value);

			$displayLabel = $prefix === '' ? $label : $prefix.' / '.$label;

			yield ['id' => $node->aggregateId->value, 'label' => $displayLabel];

			yield from $this->flattenTaxons($child, $displayLabel);
		}
	}

	protected function getReferencesConfigurationFromNodeType(Node $node): ?array
	{
		$contentRepository = $this->contentRepositoryRegistry->get($node->contentRepositoryId);
		$nodeTypeManager = $contentRepository->getNodeTypeManager();
		$nodeType = $nodeTypeManager->getNodeType($node->nodeTypeName);

		return $nodeType?->getReferences() ?? null;
	}

	public function allowsCallOfMethod($methodName): bool
	{
		return true;
	}
}
