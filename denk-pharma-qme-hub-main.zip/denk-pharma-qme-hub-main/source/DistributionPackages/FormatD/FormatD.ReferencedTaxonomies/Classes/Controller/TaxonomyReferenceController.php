<?php

declare(strict_types=1);

namespace FormatD\ReferencedTaxonomies\Controller;

use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Command\SetNodeReferences;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesForName;
use Neos\ContentRepository\Core\Feature\NodeReferencing\Dto\NodeReferencesToWrite;
use Neos\ContentRepository\Core\Feature\NodeVariation\Command\CreateNodeVariant;
use Neos\ContentRepository\Core\Feature\NodeVariation\Exception\DimensionSpacePointIsAlreadyOccupied;
use Neos\ContentRepository\Core\Feature\Security\Exception\AccessDenied;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateIds;
use Neos\ContentRepository\Core\SharedModel\Node\ReferenceName;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Mvc\Exception\ForwardException;
use Neos\Flow\Mvc\Exception\InvalidActionNameException;
use Neos\Flow\Mvc\Exception\InvalidArgumentNameException;
use Neos\Flow\Mvc\Exception\InvalidArgumentTypeException;
use Neos\Flow\Mvc\Exception\InvalidControllerNameException;
use Neos\Flow\Persistence\Exception\UnknownObjectException;
use Sitegeist\Taxonomy\Service\TaxonomyService;

/**
 * Wraps Sitegeist.Taxonomy's updateTaxonomyAction to also persist references,
 * which the upstream controller does not handle (only SetNodeProperties).
 */
class TaxonomyReferenceController extends ActionController
{
	#[Flow\Inject]
	protected TaxonomyService $taxonomyService;

	/**
	 * @param string $taxonomyNodeAddress
	 * @param array<string, list<string>> $references map of referenceName => [targetNodeAggregateId, ...]
	 * @throws AccessDenied
	 * @throws ForwardException
	 * @throws InvalidActionNameException
	 * @throws InvalidArgumentNameException
	 * @throws InvalidArgumentTypeException
	 * @throws InvalidControllerNameException
	 * @throws UnknownObjectException
	 */
	public function updateTaxonomyAction(
		string $taxonomyNodeAddress,
		array  $references = []
	): void {
		$taxonomyNode = $this->taxonomyService->getNodeByNodeAddress($taxonomyNodeAddress);
		$originDimensionSpacePoint = $this->resolveOriginDimensionSpacePoint($taxonomyNode);

		if ($references !== []) {
			$contentRepository = $this->taxonomyService->getContentRepository();

			foreach ($references as $referenceName => $targetIds) {
				$contentRepository->handle(
					SetNodeReferences::create(
						$taxonomyNode->workspaceName,
						$taxonomyNode->aggregateId,
						$originDimensionSpacePoint,
						NodeReferencesToWrite::create(
							NodeReferencesForName::fromTargets(
								ReferenceName::fromString($referenceName),
								NodeAggregateIds::fromArray($this->normalizeTargetIds($targetIds)),
							)
						)
					)
				);
			}
		}

		$this->forward(
			'updateTaxonomy',
			'TaxonomyModule',
			'DenkPharma.Design',
			array_diff_key($this->request->getArguments(), ['references' => true])
		);
	}

	protected function resolveOriginDimensionSpacePoint(Node $node): OriginDimensionSpacePoint
	{
		$desiredOrigin = OriginDimensionSpacePoint::fromDimensionSpacePoint($node->dimensionSpacePoint);

		if ($desiredOrigin->equals($node->originDimensionSpacePoint)) {
			return $desiredOrigin;
		}

		$contentRepository = $this->taxonomyService->getContentRepository();
		try {
			$contentRepository->handle(
				CreateNodeVariant::create(
					WorkspaceName::forLive(),
					$node->aggregateId,
					$node->originDimensionSpacePoint,
					$desiredOrigin
				)
			);
		} catch (DimensionSpacePointIsAlreadyOccupied) {
			// variant already exists — nothing to do
		}

		return $desiredOrigin;
	}

	/**
	 * @return list<string>
	 */
	private static function normalizeTargetIds(mixed $targetIds): array
	{
		if (is_string($targetIds)) {
			$targetIds = array_map(trim(...), explode(',', $targetIds));
		}

		return is_array($targetIds)
			? array_values(array_filter($targetIds, static fn($id): bool => is_string($id) && $id !== ''))
			: [];
	}
}
