# FormatD.Neos.FoundTranslation

Provider-based automatic translation for Neos CMS content dimensions. Translates node properties from a source language dimension to target dimensions via a pluggable provider backend — works reliably even when content dimension fallback is configured.

## Requirements

- Neos CMS 9.x / Flow 9.x
- DeepL API key (free or pro tier) — or a custom translation provider

## Installation

```bash
composer require formatd/neos-found-translation
```

After installation, flush caches and run `./flow flow:package:rescan`.

## How It Works

1. An editor opens a document node in a non-source language dimension in the Neos UI.
2. A **Translate** button appears in the node toolbar.
3. Clicking it sends the current node (and all its descendants) to the backend, which:
   - Creates explicit dimension variants where none exist yet.
   - Reads translatable properties from the source dimension.
   - Sends them to the configured translation provider (DeepL by default).
   - Writes the translated values back to the content repository.
4. The UI canvas reloads with the translated content.

## Configuration

### API Key

Set your DeepL API key via environment variable (recommended):

```bash
DEEPL_API_KEY=your-api-key-here
```

Or directly in `Settings.yaml`:

```yaml
FormatD:
  Neos:
    FoundTranslation:
      deepl:
        apiKey: 'your-api-key-here'
```

Free-tier keys end with `:fx` and are routed automatically to `api-free.deepl.com`.

### Dimensions

Configure which dimension is the translation source and which are the targets:

```yaml
FormatD:
  Neos:
    FoundTranslation:
      sourceDimension: 'en_GB'
      targetDimensions:
        de_DE: 'German'
        fr_FR: 'French'
        es_ES: 'Spanish'
```

### Language Code Mapping

Map Neos locale codes to the language codes expected by DeepL:

```yaml
FormatD:
  Neos:
    FoundTranslation:
      deepl:
        sourceLangMap:
          en_GB: 'EN'
          de_DE: 'DE'
        targetLangMap:
          en_GB: 'EN-GB'
          de_DE: 'DE'
          fr_FR: 'FR'
          pt_PT: 'PT-PT'
          pt_BR: 'PT-BR'
```

## Marking Properties for Translation

By default only properties explicitly marked are translated. Use node type configuration:

```yaml
'Your.Package:SomeNodeType':
  properties:
    headline:
      options:
        automaticTranslation: true
    bodyText:
      ui:
        inlineEditable: true   # inlineEditable properties are included automatically
    internalRef:
      options:
        automaticTranslation: false  # explicitly exclude
```

**Inclusion rules (all must pass):**

- The node type must not have `automaticTranslation: false` at node level.
- The property name must not start with `_`.
- The property type must be `string`.
- The value must not be empty.
- The property must either have `inlineEditable: true` **or** `automaticTranslation: true`.

HTML content (detected automatically) is sent to DeepL with `tag_handling: html` to preserve markup.

## Node Types Included

The package ships with translation configuration for common Neos node types out of the box:

| Mixin / Node Type | Properties |
|---|---|
| `Neos.Neos:Document` | `title`, `titleOverride`, `metaDescription`, `metaKeywords` |
| `Neos.Neos:ImageMixin` | `alternativeText`, `title` |
| SEO / OG mixins | `openGraphTitle`, `openGraphDescription` |
| Neos Form Builder | labels, placeholders, submit labels, form text |

## Custom Translation Provider

Implement `FormatD\Neos\FoundTranslation\Provider\TranslationProviderInterface` and wire it in `Objects.yaml`:

```yaml
FormatD\Neos\FoundTranslation\Provider\TranslationProviderInterface:
  className: 'Your\Package\Provider\MyTranslationProvider'
```

A `TestingTranslationProvider` is included — it prefixes translated text with the target language tag instead of calling any external API, useful during development:

```yaml
FormatD\Neos\FoundTranslation\Provider\TranslationProviderInterface:
  className: 'FormatD\Neos\FoundTranslation\Provider\TestingTranslationProvider'
```

## Custom Language Resolver

If your dimension values don't map directly to provider language codes (e.g. `de_formal_DE` → `de_DE`), implement `FormatD\Neos\FoundTranslation\Language\LanguageResolverInterface` and register it in `Objects.yaml`:

```yaml
FormatD\Neos\FoundTranslation\Language\LanguageResolverInterface:
  className: 'Your\Package\Language\MyLanguageResolver'
```

## Logging

Translations are logged to a dedicated file:

```
FLOW_PATH_DATA/Logs/Translation.log
```

In development context the log level is lowered to `DEBUG`, which includes per-node details and DeepL request/response excerpts.

## Security

- The translate endpoint requires the `Neos.Neos:Editor` role.
- CSRF protection is enforced via `X-Flow-Csrftoken`.
- The translate button is only rendered when the editor is not in the source dimension.

## UI Development

The toolbar button is a React/TypeScript plugin bundled with esbuild.

```bash
cd Resources/Private/JavaScript
npm install
npm run build   # one-off build
npm run watch   # watch mode
```

The compiled output lands in `Resources/Public/JavaScript/Plugin.js`.