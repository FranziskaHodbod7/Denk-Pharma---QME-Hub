"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@neos-project/neos-ui-extensibility/dist/readFromConsumerApi.js
  function readFromConsumerApi(key) {
    return (...args) => {
      if (window["@Neos:HostPluginAPI"] && window["@Neos:HostPluginAPI"][`@${key}`]) {
        return window["@Neos:HostPluginAPI"][`@${key}`](...args);
      }
      throw new Error("You are trying to read from a consumer api that hasn't been initialized yet!");
    };
  }
  var init_readFromConsumerApi = __esm({
    "node_modules/@neos-project/neos-ui-extensibility/dist/readFromConsumerApi.js"() {
      "use strict";
    }
  });

  // node_modules/@neos-project/neos-ui-extensibility/dist/shims/vendor/react/index.js
  var require_react = __commonJS({
    "node_modules/@neos-project/neos-ui-extensibility/dist/shims/vendor/react/index.js"(exports, module) {
      "use strict";
      init_readFromConsumerApi();
      module.exports = readFromConsumerApi("vendor")().React;
    }
  });

  // node_modules/@neos-project/neos-ui-extensibility/dist/shims/neosProjectPackages/react-ui-components/index.js
  var require_react_ui_components = __commonJS({
    "node_modules/@neos-project/neos-ui-extensibility/dist/shims/neosProjectPackages/react-ui-components/index.js"(exports, module) {
      "use strict";
      init_readFromConsumerApi();
      module.exports = readFromConsumerApi("NeosProjectPackages")().ReactUiComponents;
    }
  });

  // node_modules/@neos-project/neos-ui-extensibility/dist/shims/neosProjectPackages/neos-ui-redux-store/index.js
  var require_neos_ui_redux_store = __commonJS({
    "node_modules/@neos-project/neos-ui-extensibility/dist/shims/neosProjectPackages/neos-ui-redux-store/index.js"(exports, module) {
      "use strict";
      init_readFromConsumerApi();
      module.exports = readFromConsumerApi("NeosProjectPackages")().NeosUiReduxStore;
    }
  });

  // node_modules/@neos-project/neos-ui-extensibility/plugin-api.js
  init_readFromConsumerApi();
  var manifest = readFromConsumerApi("manifest");
  var plugin_api_default = manifest;
  var { SynchronousRegistry, SynchronousMetaRegistry } = readFromConsumerApi("NeosProjectPackages")().NeosUiRegistry;

  // src/manifest.tsx
  var import_react2 = __toESM(require_react());

  // src/TranslateButton.tsx
  var import_react = __toESM(require_react());
  var import_react_ui_components = __toESM(require_react_ui_components());
  var import_neos_ui_redux_store = __toESM(require_neos_ui_redux_store());
  var TranslateButton = ({
    className,
    sourceDimension,
    dispatch
  }) => {
    const [isTranslating, setIsTranslating] = (0, import_react.useState)(false);
    const [showConfirm, setShowConfirm] = (0, import_react.useState)(false);
    const focusedNode = (0, import_neos_ui_redux_store.useSelector)(import_neos_ui_redux_store.selectors.CR.Nodes.focusedSelector);
    const activeDimensions = (0, import_neos_ui_redux_store.useSelector)(import_neos_ui_redux_store.selectors.CR.ContentDimensions.active);
    if (!focusedNode)
      return null;
    const nodeAddress = parseNodeAddress(focusedNode.contextPath);
    const currentDimension = nodeAddress?.dimensionSpacePoint?.language ?? activeDimensions?.language?.[0];
    if (!currentDimension || !nodeAddress)
      return null;
    if (currentDimension === sourceDimension)
      return null;
    const doTranslate = async () => {
      setShowConfirm(false);
      setIsTranslating(true);
      dispatch(import_neos_ui_redux_store.actions.UI.FlashMessages.add(
        "FoundTranslation-progress",
        "Translation in progress\u2026",
        "success",
        0
      ));
      const csrfToken = document.getElementById("appContainer")?.dataset?.csrfToken ?? "";
      try {
        const response = await fetch("/neos/found-translation/translate-node", {
          method: "POST",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
            "X-Flow-Csrftoken": csrfToken
          },
          body: JSON.stringify({
            nodeAggregateId: nodeAddress.nodeAggregateId,
            workspaceName: nodeAddress.workspaceName,
            contentRepositoryId: nodeAddress.contentRepositoryId,
            sourceDimension,
            targetDimension: currentDimension
          })
        });
        const data = await response.json();
        if (data.success) {
          dispatch(import_neos_ui_redux_store.actions.UI.FlashMessages.add(
            "FoundTranslation-progress",
            "Translation complete",
            "success",
            5e3
          ));
          dispatch(import_neos_ui_redux_store.actions.UI.ContentCanvas.reload(null));
          try {
            const wsData = await window.neos?.endpoints?.getWorkspaceInfo();
            if (wsData) {
              dispatch(import_neos_ui_redux_store.actions.CR.Workspaces.update(wsData));
            }
          } catch {
          }
        } else {
          dispatch(import_neos_ui_redux_store.actions.UI.FlashMessages.add(
            "FoundTranslation-progress",
            `Translation failed: ${data.message}`,
            "error",
            0
          ));
        }
      } catch (e) {
        dispatch(import_neos_ui_redux_store.actions.UI.FlashMessages.add(
          "FoundTranslation-progress",
          `Translation error: ${String(e)}`,
          "error",
          0
        ));
      } finally {
        setIsTranslating(false);
      }
    };
    const sourceName = localeDisplayName(sourceDimension);
    const targetName = localeDisplayName(currentDimension);
    return /* @__PURE__ */ import_react.default.createElement(import_react.default.Fragment, null, /* @__PURE__ */ import_react.default.createElement(
      import_react_ui_components.Button,
      {
        id: "neos-FoundTranslation-TranslateButton",
        className,
        disabled: isTranslating,
        onClick: () => setShowConfirm(true),
        hoverStyle: "brand",
        style: "transparent",
        size: "small",
        title: `Translate to ${targetName}`
      },
      /* @__PURE__ */ import_react.default.createElement(import_react_ui_components.Icon, { icon: "language" })
    ), /* @__PURE__ */ import_react.default.createElement(
      import_react_ui_components.Dialog,
      {
        isOpen: showConfirm,
        title: `${sourceName} \u2192 ${targetName}`,
        onRequestClose: () => setShowConfirm(false),
        style: "narrow",
        actions: [
          /* @__PURE__ */ import_react.default.createElement(import_react_ui_components.Button, { onClick: () => setShowConfirm(false), style: "lighter", hoverStyle: "brand" }, "Cancel"),
          /* @__PURE__ */ import_react.default.createElement(import_react_ui_components.Button, { onClick: doTranslate, style: "warn", hoverStyle: "warn" }, "Translate")
        ]
      },
      /* @__PURE__ */ import_react.default.createElement("p", null, "Translates all content on this page to ", /* @__PURE__ */ import_react.default.createElement("strong", null, targetName), " via DeepL. Existing translations will be overwritten.")
    ));
  };
  function localeDisplayName(locale) {
    try {
      const tag = locale.replace("_", "-");
      return new Intl.DisplayNames(["en"], { type: "language" }).of(tag) ?? locale;
    } catch {
      return locale;
    }
  }
  function parseNodeAddress(contextPath) {
    try {
      const p = JSON.parse(contextPath);
      if (p?.aggregateId && p?.workspaceName) {
        return {
          contentRepositoryId: p.contentRepositoryId ?? "default",
          workspaceName: p.workspaceName,
          nodeAggregateId: p.aggregateId,
          dimensionSpacePoint: p.dimensionSpacePoint ?? {}
        };
      }
    } catch {
    }
    return null;
  }

  // src/manifest.tsx
  plugin_api_default("FormatD.Neos.FoundTranslation", {}, (globalRegistry, { frontendConfiguration, store }) => {
    console.log("[FoundTranslation] manifest init", { frontendConfiguration });
    const sourceDimension = frontendConfiguration?.["FormatD.Neos.FoundTranslation"]?.sourceDimension ?? "en_GB";
    console.log("[FoundTranslation] sourceDimension:", sourceDimension);
    const BoundTranslateButton = (props) => /* @__PURE__ */ import_react2.default.createElement(TranslateButton, { ...props, sourceDimension, dispatch: store.dispatch });
    const guestFrameRegistry = globalRegistry.get("@neos-project/neos-ui-guest-frame");
    console.log("[FoundTranslation] guestFrameRegistry:", guestFrameRegistry);
    if (!guestFrameRegistry) {
      console.error("[FoundTranslation] guestFrameRegistry not found \u2014 button will not appear");
      return;
    }
    guestFrameRegistry.set(
      "NodeToolbar/ContextButtons/FormatD.Neos.FoundTranslation:TranslateButton",
      BoundTranslateButton
    );
    console.log("[FoundTranslation] TranslateButton registered at NodeToolbar/ContextButtons");
  });
})();
