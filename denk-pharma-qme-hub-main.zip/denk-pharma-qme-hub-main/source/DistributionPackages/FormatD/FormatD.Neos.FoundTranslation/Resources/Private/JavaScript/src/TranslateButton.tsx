import React, { useState } from 'react'
import { Button, Icon, Dialog } from '@neos-project/react-ui-components'
import { useSelector, selectors, actions } from '@neos-project/neos-ui-redux-store'

export interface TranslateButtonProps {
    className?: string
    sourceDimension: string
    dispatch: (action: unknown) => void
}

export const TranslateButton: React.FC<TranslateButtonProps> = ({
    className,
    sourceDimension,
    dispatch,
}) => {
    const [isTranslating, setIsTranslating] = useState(false)
    const [showConfirm, setShowConfirm] = useState(false)

    const focusedNode = useSelector(selectors.CR.Nodes.focusedSelector)
    const activeDimensions = useSelector(selectors.CR.ContentDimensions.active)

    if (!focusedNode) return null

    const nodeAddress = parseNodeAddress(focusedNode.contextPath)
    const currentDimension = nodeAddress?.dimensionSpacePoint?.language
        ?? (activeDimensions as any)?.language?.[0]

    if (!currentDimension || !nodeAddress) return null
    if (currentDimension === sourceDimension) return null

    const doTranslate = async () => {
        setShowConfirm(false)
        setIsTranslating(true)

        dispatch(actions.UI.FlashMessages.add(
            'FoundTranslation-progress',
            'Translation in progress…',
            'success',
            0
        ))

        const csrfToken =
            (document.getElementById('appContainer') as HTMLElement | null)?.dataset?.csrfToken ?? ''

        try {
            const response = await fetch('/neos/found-translation/translate-node', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Flow-Csrftoken': csrfToken,
                },
                body: JSON.stringify({
                    nodeAggregateId: nodeAddress.nodeAggregateId,
                    workspaceName: nodeAddress.workspaceName,
                    contentRepositoryId: nodeAddress.contentRepositoryId,
                    sourceDimension,
                    targetDimension: currentDimension,
                }),
            })

            const data = await response.json()

            if (data.success) {
                dispatch(actions.UI.FlashMessages.add(
                    'FoundTranslation-progress',
                    'Translation complete',
                    'success',
                    5000
                ))
                dispatch(actions.UI.ContentCanvas.reload(null))
                try {
                    const wsData = await (window as any).neos?.endpoints?.getWorkspaceInfo()
                    if (wsData) {
                        dispatch((actions.CR.Workspaces as any).update(wsData))
                    }
                } catch {
                    // workspace refresh failed — non-fatal, publish button stays stale
                }
            } else {
                dispatch(actions.UI.FlashMessages.add(
                    'FoundTranslation-progress',
                    `Translation failed: ${data.message}`,
                    'error',
                    0
                ))
            }
        } catch (e) {
            dispatch(actions.UI.FlashMessages.add(
                'FoundTranslation-progress',
                `Translation error: ${String(e)}`,
                'error',
                0
            ))
        } finally {
            setIsTranslating(false)
        }
    }

    const sourceName = localeDisplayName(sourceDimension)
    const targetName = localeDisplayName(currentDimension)

    return (
        <>
            <Button
                id="neos-FoundTranslation-TranslateButton"
                className={className}
                disabled={isTranslating}
                onClick={() => setShowConfirm(true)}
                hoverStyle="brand"
                style="transparent"
                size="small"
                title={`Translate to ${targetName}`}
            >
                <Icon icon="language" />
            </Button>

            <Dialog
                isOpen={showConfirm}
                title={`${sourceName} → ${targetName}`}
                onRequestClose={() => setShowConfirm(false)}
                style="narrow"
                actions={[
                    <Button onClick={() => setShowConfirm(false)} style="lighter" hoverStyle="brand">
                        Cancel
                    </Button>,
                    <Button onClick={doTranslate} style="warn" hoverStyle="warn">
                        Translate
                    </Button>,
                ]}
            >
                <p>Translates all content on this page to <strong>{targetName}</strong> via DeepL. Existing translations will be overwritten.</p>
            </Dialog>
        </>
    )
}

interface NodeAddress {
    contentRepositoryId: string
    workspaceName: string
    nodeAggregateId: string
    dimensionSpacePoint: Record<string, string>
}

function localeDisplayName(locale: string): string {
    try {
        const tag = locale.replace('_', '-')
        return new Intl.DisplayNames(['en'], { type: 'language' }).of(tag) ?? locale
    } catch {
        return locale
    }
}

/** Neos 9 contextPath JSON: {"contentRepositoryId":"...","workspaceName":"...","aggregateId":"...","dimensionSpacePoint":{...}} */
function parseNodeAddress(contextPath: string): NodeAddress | null {
    try {
        const p = JSON.parse(contextPath)
        if (p?.aggregateId && p?.workspaceName) {
            return {
                contentRepositoryId: p.contentRepositoryId ?? 'default',
                workspaceName: p.workspaceName,
                nodeAggregateId: p.aggregateId,
                dimensionSpacePoint: p.dimensionSpacePoint ?? {},
            }
        }
    } catch {
        // ignore malformed contextPath
    }
    return null
}
