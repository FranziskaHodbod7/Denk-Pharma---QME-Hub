const esbuild = require('esbuild')
const extensibilityMap = require('@neos-project/neos-ui-extensibility/extensibilityMap.json')

const isWatch = process.argv.includes('--watch')

/** @type {import('esbuild').BuildOptions} */
const options = {
    logLevel: 'info',
    bundle: true,
    target: 'es2020',
    entryPoints: { Plugin: 'src/manifest.tsx' },
    outdir: '../../Public/JavaScript',
    tsconfig: './tsconfig.json',
    // Maps every package in the list (react, @neos-project/neos-ui-redux-store, …)
    // to a shim that reads from window.NeosUiPluginApi at runtime.
    // The Neos UI host guarantees those values are present when the plugin loads.
    alias: extensibilityMap,
}

if (isWatch) {
    esbuild.context(options).then((ctx) => ctx.watch())
} else {
    esbuild.build(options)
}
