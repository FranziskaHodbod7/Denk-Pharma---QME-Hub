import manifest from '@neos-project/neos-ui-extensibility'
import React from 'react'
import { TranslateButton, TranslateButtonProps } from './TranslateButton'

manifest('FormatD.Neos.FoundTranslation', {}, (globalRegistry, { frontendConfiguration, store }: any) => {
    console.log('[FoundTranslation] manifest init', { frontendConfiguration })

    const sourceDimension: string =
        (frontendConfiguration as any)?.['FormatD.Neos.FoundTranslation']?.sourceDimension ?? 'en_GB'

    console.log('[FoundTranslation] sourceDimension:', sourceDimension)

    const BoundTranslateButton = (props: Omit<TranslateButtonProps, 'sourceDimension' | 'dispatch'>) =>
        <TranslateButton {...props} sourceDimension={sourceDimension} dispatch={store.dispatch} />

    const guestFrameRegistry = globalRegistry.get('@neos-project/neos-ui-guest-frame')
    console.log('[FoundTranslation] guestFrameRegistry:', guestFrameRegistry)

    if (!guestFrameRegistry) {
        console.error('[FoundTranslation] guestFrameRegistry not found — button will not appear')
        return
    }

    guestFrameRegistry.set(
        'NodeToolbar/ContextButtons/FormatD.Neos.FoundTranslation:TranslateButton',
        BoundTranslateButton
    )
    console.log('[FoundTranslation] TranslateButton registered at NodeToolbar/ContextButtons')
})
