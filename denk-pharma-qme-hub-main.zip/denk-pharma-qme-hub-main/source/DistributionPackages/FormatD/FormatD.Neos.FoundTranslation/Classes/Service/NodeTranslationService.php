<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Service;

use FormatD\Neos\FoundTranslation\Language\LanguageResolverInterface;
use FormatD\Neos\FoundTranslation\Provider\TranslationProviderInterface;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeModification\Command\SetNodeProperties;
use Neos\ContentRepository\Core\Feature\NodeModification\Dto\PropertyValuesToWrite;
use Neos\ContentRepository\Core\Feature\NodeVariation\Command\CreateNodeVariant;
use Neos\ContentRepository\Core\NodeType\NodeType;
use Neos\ContentRepository\Core\Projection\ContentGraph\ContentSubgraphInterface;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindChildNodesFilter;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateClassification;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Psr\Log\LoggerInterface;

/**
 * @Flow\Scope("singleton")
 */
class NodeTranslationService
{
    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected TranslationProviderInterface $translationProvider;

    #[Flow\Inject]
    protected LanguageResolverInterface $languageResolver;

    #[Flow\Inject(name: 'FormatD.Neos.FoundTranslation:TranslationLogger', lazy: false)]
    protected LoggerInterface $translationLogger;

    /**
     * Translates a node and all its descendants from sourceDimension to targetDimension.
     * Creates dimension variants where they do not yet exist, writes translated properties
     * to the CR, and returns the translated data for the frontend to reflect without a reload.
     *
     * @return list<array{contextPath: string, properties: array<string, string>}>
     */
    public function translateNodeRecursively(
        string $nodeAggregateIdString,
        string $workspaceNameString,
        string $sourceDimension,
        string $targetDimension,
        string $contentRepositoryId = 'default'
    ): array {
        $crId = ContentRepositoryId::fromString($contentRepositoryId);
        $contentRepository = $this->contentRepositoryRegistry->get($crId);

        $workspaceName = WorkspaceName::fromString($workspaceNameString);
        $nodeAggregateId = NodeAggregateId::fromString($nodeAggregateIdString);

        $sourceDsp = DimensionSpacePoint::fromArray(['language' => $sourceDimension]);
        $targetDsp = DimensionSpacePoint::fromArray(['language' => $targetDimension]);
        $sourceOrigin = OriginDimensionSpacePoint::fromDimensionSpacePoint($sourceDsp);
        $targetOrigin = OriginDimensionSpacePoint::fromDimensionSpacePoint($targetDsp);

        $contentGraph = $contentRepository->getContentGraph($workspaceName);
        $sourceSubgraph = $contentGraph->getSubgraph($sourceDsp, VisibilityConstraints::withoutRestrictions());
        $targetSubgraph = $contentGraph->getSubgraph($targetDsp, VisibilityConstraints::withoutRestrictions());

        $sourceLang = $this->languageResolver->resolveLanguage($sourceDimension);
        $targetLang = $this->languageResolver->resolveLanguage($targetDimension);

        $this->translationLogger->info('FoundTranslation: starting translation', [
            'rootNodeAggregateId' => $nodeAggregateIdString,
            'workspace' => $workspaceNameString,
            'source' => $sourceDimension,
            'target' => $targetDimension,
        ]);

        $results = $this->collectTranslations(
            $crId,
            $workspaceName,
            $nodeAggregateId,
            $sourceSubgraph,
            $targetSubgraph,
            $sourceOrigin,
            $targetOrigin,
            $sourceLang,
            $targetLang,
            $targetDimension,
            $contentRepository->getNodeTypeManager()
        );

        $this->translationLogger->info('FoundTranslation: translation complete', [
            'nodesTranslated' => count($results),
        ]);

        return $results;
    }

    /**
     * @return list<array{contextPath: string, properties: array<string, string>}>
     */
    protected function collectTranslations(
        ContentRepositoryId $crId,
        WorkspaceName $workspaceName,
        NodeAggregateId $nodeAggregateId,
        ContentSubgraphInterface $sourceSubgraph,
        ContentSubgraphInterface $targetSubgraph,
        OriginDimensionSpacePoint $sourceOrigin,
        OriginDimensionSpacePoint $targetOrigin,
        string $sourceLang,
        string $targetLang,
        string $targetDimension,
        $nodeTypeManager
    ): array {
        $contentRepository = $this->contentRepositoryRegistry->get($crId);

        $sourceNode = $sourceSubgraph->findNodeById($nodeAggregateId);
        if ($sourceNode === null) {
            return [];
        }

        $nodeAggregate = $contentRepository->getContentGraph($workspaceName)->findNodeAggregateById($nodeAggregateId);
        $isTethered = $nodeAggregate?->classification === NodeAggregateClassification::CLASSIFICATION_TETHERED;

        $targetNode = $targetSubgraph->findNodeById($nodeAggregateId);
        $hasExplicitVariant = $targetNode !== null
            && $targetNode->originDimensionSpacePoint->equals($targetOrigin);

        $skipNodeTranslation = false;

        if (!$hasExplicitVariant) {
            if ($isTethered) {
                // Tethered nodes cannot be varied directly — skip property translation for
                // this node, but still recurse so its regular children get translated.
                $skipNodeTranslation = true;
            } else {
                $contentRepository->handle(CreateNodeVariant::create(
                    $workspaceName,
                    $nodeAggregateId,
                    $sourceOrigin,
                    $targetOrigin
                ));
            }
        }

        $this->translationLogger->debug('FoundTranslation: processing node', [
            'nodeAggregateId' => $nodeAggregateId->value,
            'nodeType' => (string)$sourceNode->nodeTypeName,
            'hasExplicitVariant' => $hasExplicitVariant,
            'isTethered' => $isTethered,
            'skipNodeTranslation' => $skipNodeTranslation,
        ]);

        $nodeType = $nodeTypeManager->getNodeType((string)$sourceNode->nodeTypeName);
        $translatedProperties = $skipNodeTranslation ? [] : $this->buildTranslatedProperties(
            $sourceNode,
            $nodeType,
            $sourceLang,
            $targetLang
        );

        $results = [];

        if (!empty($translatedProperties)) {
            $contentRepository->handle(SetNodeProperties::create(
                $workspaceName,
                $nodeAggregateId,
                $targetOrigin,
                PropertyValuesToWrite::fromArray($translatedProperties)
            ));

            $contextPath = json_encode([
                'contentRepositoryId' => $crId->value,
                'workspaceName' => $workspaceName->value,
                'aggregateId' => $nodeAggregateId->value,
                'dimensionSpacePoint' => ['language' => $targetDimension],
            ]);
            $results[] = ['contextPath' => $contextPath, 'properties' => $translatedProperties];
        }

        $childNodes = $sourceSubgraph->findChildNodes(
            $nodeAggregateId,
            FindChildNodesFilter::create()
        );

        foreach ($childNodes as $child) {
            $childResults = $this->collectTranslations(
                $crId,
                $workspaceName,
                $child->aggregateId,
                $sourceSubgraph,
                $targetSubgraph,
                $sourceOrigin,
                $targetOrigin,
                $sourceLang,
                $targetLang,
                $targetDimension,
                $nodeTypeManager
            );
            $results = array_merge($results, $childResults);
        }

        return $results;
    }

    protected function buildTranslatedProperties(
        Node $sourceNode,
        NodeType $nodeType,
        string $sourceLang,
        string $targetLang
    ): array {
        if (($nodeType->getOptions()['automaticTranslation'] ?? true) === false) {
            return [];
        }

        $result = [];

        foreach ($nodeType->getProperties() as $propertyName => $config) {
            if (str_starts_with($propertyName, '_')) {
                continue;
            }
            if (($config['type'] ?? 'string') !== 'string') {
                continue;
            }

            $isInlineEditable = (bool)($config['ui']['inlineEditable'] ?? false);
            $automaticTranslation = $config['options']['automaticTranslation'] ?? null;

            // Explicit opt-out always wins
            if ($automaticTranslation === false) {
                continue;
            }
            // Include if inline-editable or explicitly opted in
            if (!$isInlineEditable && $automaticTranslation !== true) {
                continue;
            }

            $value = $sourceNode->properties->offsetGet($propertyName);
            if (!is_string($value) || empty(trim(strip_tags($value)))) {
                continue;
            }

            if ($this->containsHtml($value)) {
                $result[$propertyName] = $this->translationProvider->translateHtml($value, $sourceLang, $targetLang);
            } else {
                $result[$propertyName] = $this->translationProvider->translatePlainText($value, $sourceLang, $targetLang);
            }
        }

        return $result;
    }

    protected function containsHtml(string $value): bool
    {
        return $value !== strip_tags($value);
    }
}
