<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Controller;

use FormatD\Neos\FoundTranslation\Service\NodeTranslationService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Mvc\View\JsonView;

/**
 * REST endpoint called by the Neos UI translation plugin.
 * Requires Neos.Neos:Editor role (enforced via Policy.yaml).
 */
class TranslationController extends ActionController
{
    protected $defaultViewObjectName = JsonView::class;

    #[Flow\Inject]
    protected NodeTranslationService $nodeTranslationService;

    public function initializeAction(): void
    {
        $this->response->setContentType('application/json');
    }

    /**
     * Translates a node and all its descendants from sourceDimension to targetDimension.
     *
     * Expected POST body (JSON):
     * {
     *   "nodeAggregateId":     "3a9517c0-...",
     *   "workspaceName":       "user-admin",
     *   "sourceDimension":     "en_GB",
     *   "targetDimension":     "fr_FR",
     *   "contentRepositoryId": "default"   // optional
     * }
     */
    public function translateNodeAction(
        string $nodeAggregateId,
        string $workspaceName,
        string $sourceDimension,
        string $targetDimension,
        string $contentRepositoryId = 'default'
    ): void {
        try {
            $translations = $this->nodeTranslationService->translateNodeRecursively(
                $nodeAggregateId,
                $workspaceName,
                $sourceDimension,
                $targetDimension,
                $contentRepositoryId
            );

            $this->view->assign('value', [
                'success' => true,
                'translations' => $translations,
            ]);
        } catch (\Throwable $e) {
            $this->response->setStatusCode(500);
            $this->view->assign('value', [
                'success' => false,
                'message' => $e->getMessage(),
            ]);
        }
    }
}
