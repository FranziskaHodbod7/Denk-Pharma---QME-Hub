<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Language;

interface LanguageResolverInterface
{
    /**
     * Resolves a Neos content dimension value to a normalised language code
     * that is passed to translation providers.
     *
     * e.g. "en_GB" → "en_GB"  (DimensionLanguageResolver, default)
     *      "de_formal_DE" → "de_DE"  (a hypothetical custom resolver)
     */
    public function resolveLanguage(string $dimensionValue): string;
}
