<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Language;

use Neos\Flow\Annotations as Flow;

/**
 * Default resolver: passes the Neos dimension value through unchanged.
 *
 * "en_GB" → "en_GB", "fr_FR" → "fr_FR", etc.
 *
 * Translation providers receive these codes and are responsible for any
 * service-specific mapping they need (e.g. DeepL uses "EN-GB" for targets).
 *
 * @Flow\Scope("singleton")
 */
class DimensionLanguageResolver implements LanguageResolverInterface
{
    public function resolveLanguage(string $dimensionValue): string
    {
        return $dimensionValue;
    }
}
