<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Provider;

use Neos\Flow\Annotations as Flow;

/**
 * Dummy provider for development and testing.
 *
 * Prefixes every string with the target language tag instead of calling an
 * external API, so translation results are immediately visible without
 * spending API credits.
 *
 * Activate via Objects.yaml:
 *   FormatD\Neos\FoundTranslation\Provider\TranslationProviderInterface:
 *     className: FormatD\Neos\FoundTranslation\Provider\TestingTranslationProvider
 *
 * @Flow\Scope("singleton")
 */
class TestingTranslationProvider implements TranslationProviderInterface
{
    public function translatePlainText(string $text, string $sourceLang, string $targetLang): string
    {
        if (empty(trim($text))) {
            return $text;
        }
        return '[' . $targetLang . '] ' . $text;
    }

    public function translateHtml(string $html, string $sourceLang, string $targetLang): string
    {
        if (empty(trim(strip_tags($html)))) {
            return $html;
        }
        return '[' . $targetLang . '] ' . $html;
    }
}
