<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Provider;

interface TranslationProviderInterface
{
    /**
     * Translates a plain-text string.
     *
     * @param string $sourceLang Normalised language code from LanguageResolverInterface (e.g. "en_GB")
     * @param string $targetLang Normalised language code from LanguageResolverInterface (e.g. "fr_FR")
     */
    public function translatePlainText(string $text, string $sourceLang, string $targetLang): string;

    /**
     * Translates an HTML string, preserving markup.
     *
     * @param string $sourceLang Normalised language code from LanguageResolverInterface (e.g. "en_GB")
     * @param string $targetLang Normalised language code from LanguageResolverInterface (e.g. "fr_FR")
     */
    public function translateHtml(string $html, string $sourceLang, string $targetLang): string;
}
