<?php
declare(strict_types=1);

namespace FormatD\Neos\FoundTranslation\Provider;

use Neos\Flow\Annotations as Flow;
use Psr\Log\LoggerInterface;

/**
 * Translation provider backed by the DeepL REST API v2.
 * No external PHP SDK required — uses curl directly.
 *
 * Free-tier keys (ending in ":fx") are automatically routed to api-free.deepl.com.
 *
 * @Flow\Scope("singleton")
 */
class DeepLTranslationProvider implements TranslationProviderInterface
{
    // false when %env:DEEPL_API_KEY% is not set — Flow returns false for missing env vars
    #[Flow\InjectConfiguration(path: 'deepl.apiKey', package: 'FormatD.Neos.FoundTranslation')]
    protected string|false $apiKey = false;

    #[Flow\InjectConfiguration(path: 'deepl.sourceLangMap', package: 'FormatD.Neos.FoundTranslation')]
    protected array $sourceLangMap = [];

    #[Flow\InjectConfiguration(path: 'deepl.targetLangMap', package: 'FormatD.Neos.FoundTranslation')]
    protected array $targetLangMap = [];

    #[Flow\Inject(name: 'FormatD.Neos.FoundTranslation:TranslationLogger', lazy: false)]
    protected LoggerInterface $translationLogger;

    public function translatePlainText(string $text, string $sourceLang, string $targetLang): string
    {
        if (empty(trim($text))) {
            return $text;
        }
        return $this->translate($text, $sourceLang, $targetLang);
    }

    public function translateHtml(string $html, string $sourceLang, string $targetLang): string
    {
        if (empty(trim(strip_tags($html)))) {
            return $html;
        }
        return $this->translate($html, $sourceLang, $targetLang, tagHandling: 'html');
    }

    protected function translate(
        string $text,
        string $sourceLang,
        string $targetLang,
        string $tagHandling = ''
    ): string {
        $payload = [
            'text'        => [$text],
            'target_lang' => $this->toDeepLTargetCode($targetLang),
        ];

        $sourceLangCode = $this->toDeepLSourceCode($sourceLang);
        if ($sourceLangCode !== null) {
            $payload['source_lang'] = $sourceLangCode;
        }
        if ($tagHandling !== '') {
            $payload['tag_handling'] = $tagHandling;
        }

        $textExcerpt = mb_substr(strip_tags($text), 0, 120);
        $this->translationLogger->debug('FoundTranslation: DeepL request', [
            'source_lang' => $payload['source_lang'] ?? '(auto)',
            'target_lang' => $payload['target_lang'],
            'tag_handling' => $tagHandling ?: 'none',
            'text_excerpt' => $textExcerpt,
        ]);

        $data = $this->post('/translate', $payload);

        $result = $data['translations'][0]['text'] ?? $text;
        $detectedLang = $data['translations'][0]['detected_source_language'] ?? 'unknown';

        $this->translationLogger->debug('FoundTranslation: DeepL response', [
            'detected_source_language' => $detectedLang,
            'result_excerpt' => mb_substr(strip_tags($result), 0, 120),
            'unchanged' => ($result === $text),
        ]);

        return $result;
    }

    /**
     * @throws \RuntimeException on connection error or non-2xx response
     */
    protected function post(string $path, array $payload): array
    {
        if ($this->apiKey === false || $this->apiKey === '') {
            throw new \RuntimeException(
                'DeepL API key is not configured. Set the DEEPL_API_KEY environment variable or FormatD.Neos.FoundTranslation.deepl.apiKey in Settings.yaml.'
            );
        }

        $url = $this->getBaseUrl() . $path;
        $body = json_encode($payload, JSON_THROW_ON_ERROR);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: DeepL-Auth-Key ' . $this->apiKey,
                'Content-Type: application/json',
            ],
        ]);

        $response = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $this->translationLogger->error('FoundTranslation: DeepL curl error', ['error' => $curlError]);
            throw new \RuntimeException('DeepL API request failed: ' . $curlError);
        }
        if ($statusCode < 200 || $statusCode >= 300) {
            $this->translationLogger->error('FoundTranslation: DeepL HTTP error', [
                'status' => $statusCode,
                'body' => $response,
            ]);
            throw new \RuntimeException(sprintf('DeepL API returned HTTP %d: %s', $statusCode, $response));
        }

        return json_decode($response, true, flags: JSON_THROW_ON_ERROR);
    }

    protected function getBaseUrl(): string
    {
        // Free-tier keys end with ":fx"
        if (str_ends_with($this->apiKey, ':fx')) {
            return 'https://api-free.deepl.com/v2';
        }
        return 'https://api.deepl.com/v2';
    }

    protected function toDeepLSourceCode(string $lang): ?string
    {
        return $this->sourceLangMap[$lang] ?? null;
    }

    protected function toDeepLTargetCode(string $lang): string
    {
        return $this->targetLangMap[$lang] ?? strtoupper(substr($lang, 0, 2));
    }
}
