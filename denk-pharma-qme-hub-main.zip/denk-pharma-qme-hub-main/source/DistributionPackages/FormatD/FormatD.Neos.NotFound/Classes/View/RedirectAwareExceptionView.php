<?php

declare(strict_types=1);

namespace FormatD\Neos\NotFound\View;

use Neos\Neos\View\FusionExceptionView;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamInterface;

/**
 * Neos\Flow\Error\AbstractExceptionHandler unwraps the ResponseInterface returned by the
 * configured exception view down to its body, discarding status code and headers, because
 * it already sent the original exception's status line via header() before rendering the view.
 * This subclass re-applies status code and headers itself when the rendered Fusion "error"
 * path produced a redirect (e.g. Root.fusion's 4xxNotAuthenticated branch), so that a redirect
 * built in Fusion actually reaches the browser.
 */
class RedirectAwareExceptionView extends FusionExceptionView
{
    public function render(): ResponseInterface|StreamInterface
    {
        $result = parent::render();

        if ($result instanceof ResponseInterface && $result->getStatusCode() >= 300 && $result->getStatusCode() < 400 && !headers_sent()) {
            header(\sprintf('HTTP/1.1 %d %s', $result->getStatusCode(), $result->getReasonPhrase()));
            foreach ($result->getHeaders() as $name => $values) {
                header($name . ': ' . implode(', ', $values), false);
            }
        }

        return $result;
    }
}
