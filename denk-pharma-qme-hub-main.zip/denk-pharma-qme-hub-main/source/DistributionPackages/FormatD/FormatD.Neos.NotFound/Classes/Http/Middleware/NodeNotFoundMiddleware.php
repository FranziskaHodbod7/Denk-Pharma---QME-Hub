<?php

declare(strict_types=1);

namespace FormatD\Neos\NotFound\Http\Middleware;

use Neos\ContentRepository\Core\Feature\SubtreeTagging\Dto\SubtreeTags;
use Neos\ContentRepository\Core\Projection\ContentGraph\VisibilityConstraints;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Http\ServerRequestAttributes;
use Neos\Flow\Property\Exception\TargetNotFoundException;
use Neos\Neos\Domain\SubtreeTagging\NeosSubtreeTag;
use Neos\Neos\FrontendRouting\Exception\NodeNotFoundException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Neos\Flow\Annotations as Flow;

class NodeNotFoundMiddleware implements MiddlewareInterface
{
	// #[Flow\Inject]
	// protected ContentRepositoryRegistry $contentRepositoryRegistry;

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
	{
		try {
			return $handler->handle($request);
		} catch (NodeNotFoundException $e) {
			throw new TargetNotFoundException($e->getMessage(), $e->getCode());
		}
	}

	// TODO: add ability to detect if its a 404 or 403
	// protected function checkIfNodeWouldExist(ServerRequestInterface $request)
	// {
	// 	$routingResult = $request->getAttribute(ServerRequestAttributes::ROUTING_RESULTS, default: null);
	// 	if ($routingResult === null) {
	// 		return;
	// 	}

	// 	$nodeAddressJson = $routingResult["node"] ?? null;
	// 	if ($nodeAddressJson === null) {
	// 		return;
	// 	}

	// 	$nodeAddress = NodeAddress::fromJsonString($nodeAddressJson);

	// 	if (!$nodeAddress->workspaceName->isLive()) {
	// 		return;
	// 	}

	// 	$contentRepository = $this->contentRepositoryRegistry->get($nodeAddress->contentRepositoryId);

	// 	$contentGraph = $contentRepository->getContentGraph($nodeAddress->workspaceName);
	// 	$subGraph = $contentGraph->getSubgraph(
	// 		$nodeAddress->dimensionSpacePoint,
	// 		VisibilityConstraints::excludeSubtreeTags(SubtreeTags::create(NeosSubtreeTag::disabled(), NeosSubtreeTag::removed()))
	// 	);

	// 	$node = $subGraph->findNodeById($nodeAddress->aggregateId);
	// }
}
