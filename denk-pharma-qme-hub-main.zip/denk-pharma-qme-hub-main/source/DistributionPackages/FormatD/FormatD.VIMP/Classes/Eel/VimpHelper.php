<?php

declare(strict_types=1);

namespace FormatD\VIMP\Eel;

use FormatD\VIMP\Api\MediaApi;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class VimpHelper implements ProtectedContextAwareInterface
{
    #[Flow\Inject]
    protected MediaApi $mediaApi;

    #[Flow\InjectConfiguration(path: 'api.baseUrl', package: 'FormatD.VIMP')]
    protected string $apiBaseUrl = '';

    /**
     * Thumbnail image URL for a media key.
     *
     * Constructed from the key by default; pass viaApi=true to resolve it through getMedium.
     */
    public function thumbnailUrl(string $key, bool $viaApi = false): ?string
    {
        if ($key === '') {
            return null;
        }
        if ($viaApi) {
            return $this->mediaApi->getMedium($key)->thumbnail;
        }
        return sprintf('%s/getPicture?type=medium&key=%s', rtrim($this->apiBaseUrl, '/'), $key);
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
