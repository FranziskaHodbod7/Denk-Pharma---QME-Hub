<?php

declare(strict_types=1);

namespace FormatD\VIMP\Command;

use FormatD\VIMP\Api\CategoryApi;
use FormatD\VIMP\Api\ChannelApi;
use FormatD\VIMP\Api\LanguageApi;
use FormatD\VIMP\Api\MediaApi;
use FormatD\VIMP\Api\Request;
use FormatD\VIMP\Api\SearchApi;
use FormatD\VIMP\Api\SystemApi;
use FormatD\VIMP\Api\TransportInterface;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;

class VimpCommandController extends CommandController
{
    #[Flow\Inject]
    protected TransportInterface $transport;

    #[Flow\Inject]
    protected SystemApi $systemApi;

    #[Flow\Inject]
    protected CategoryApi $categoryApi;

    #[Flow\Inject]
    protected ChannelApi $channelApi;

    #[Flow\Inject]
    protected MediaApi $mediaApi;

    #[Flow\Inject]
    protected SearchApi $searchApi;

    #[Flow\Inject]
    protected LanguageApi $languageApi;

    /**
     * Send a raw request to any endpoint and dump the JSON response
     *
     * @param string $endpoint API endpoint, e.g. "getCategories"
     * @param string $params Optional parameters as JSON, e.g. '{"limit":5}'
     */
    public function requestCommand(string $endpoint, string $params = '{}'): void
    {
        $result = $this->transport->send(new Request($endpoint, json_decode($params, true) ?? []));
        $this->outputLine(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * Show VIMP API version info
     */
    public function versionCommand(): void
    {
        $result = $this->systemApi->version();
        $this->outputLine(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * List categories
     *
     * @param int|null $parentId Filter by parent category ID
     * @param int $limit Maximum number of results
     */
    public function categoriesCommand(?int $parentId = null, int $limit = 20): void
    {
        $categories = $this->categoryApi->getCategories(parentId: $parentId, limit: $limit);

        if (empty($categories)) {
            $this->outputLine('No categories found.');
            return;
        }

        $this->outputLine('%-6s %-8s %s', ['ID', 'Parent', 'Name']);
        $this->outputLine(str_repeat('-', 50));
        foreach ($categories as $category) {
            $this->outputLine('%-6d %-8s %s', [
                $category->cid,
                $category->parent ?? '-',
                $category->name,
            ]);
        }
        $this->outputLine("\n%d categories.", [count($categories)]);
    }

    /**
     * Show a single category by ID
     *
     * @param int $categoryId Category ID
     */
    public function categoryCommand(int $categoryId): void
    {
        $category = $this->categoryApi->getCategory($categoryId);

        $this->outputLine('ID:          %d', [$category->cid]);
        $this->outputLine('Name:        %s', [$category->name]);
        $this->outputLine('Parent:      %s', [$category->parent ?? '-']);
        $this->outputLine('Status:      %d', [$category->status]);
        $this->outputLine('Weight:      %d', [$category->weight]);
        $this->outputLine('Description: %s', [$category->description ?? '-']);
        $this->outputLine('Created:     %s', [$category->createdAt?->format('Y-m-d H:i:s') ?? '-']);
    }

    /**
     * List media
     *
     * @param string|null $search Search term
     * @param int|null $categoryId Filter by category ID
     * @param string $orderBy Order by field (created, uploaded, updated, name)
     * @param int $limit Maximum number of results
     */
    public function mediaCommand(
        ?string $search = null,
        ?int $categoryId = null,
        string $orderBy = 'created',
        int $limit = 20,
    ): void {
        $media = $this->mediaApi->getMedia(
            search: $search,
            filterByCategory: $categoryId,
            orderBy: $orderBy,
            sortDirection: 'desc',
            limit: $limit,
        );

        if (empty($media)) {
            $this->outputLine('No media found.');
            return;
        }

        $this->outputLine('%-8s %-6s %-10s %s', ['ID', 'Type', 'Views', 'Title']);
        $this->outputLine(str_repeat('-', 60));
        foreach ($media as $medium) {
            $this->outputLine('%-8s %-6d %-10d %s', [
                $medium->mediakey,
                $medium->mediatype,
                $medium->countViews,
                mb_strimwidth($medium->title, 0, 35, '…'),
            ]);
        }
        $this->outputLine("\n%d items.", [count($media)]);
    }

    /**
     * Show a single medium by ID or media key
     *
     * @param string $mediumId Medium ID or media key
     */
    public function mediumCommand(string $mediumId): void
    {
        $medium = $this->mediaApi->getMedium($mediumId);

        $this->outputLine('ID:          %d', [$medium->mid]);
        $this->outputLine('Key:         %s', [$medium->mediakey]);
        $this->outputLine('Title:       %s', [$medium->title]);
        $this->outputLine('Type:        %d', [$medium->mediatype]);
        $this->outputLine('Status:      %d', [$medium->status]);
        $this->outputLine('Hidden:      %s', [$medium->hidden ? 'yes' : 'no']);
        $this->outputLine('Duration:    %s', [$medium->duration !== null ? $medium->duration . 's' : '-']);
        $this->outputLine('Views:       %d', [$medium->countViews]);
        $this->outputLine('Rating:      %.2f (%d)', [$medium->sumRating, $medium->countRating]);
        $this->outputLine('Owner:       %s (uid %d)', [$medium->username, $medium->uid]);
        $this->outputLine('Created:     %s', [$medium->createdAt?->format('Y-m-d H:i:s') ?? '-']);

        if (!empty($medium->categories)) {
            $names = array_map(fn($c) => $c->name, $medium->categories);
            $this->outputLine('Categories:  %s', [implode(', ', $names)]);
        }
        if (!empty($medium->tags)) {
            $names = array_map(fn($t) => $t->name, $medium->tags);
            $this->outputLine('Tags:        %s', [implode(', ', $names)]);
        }
    }

    /**
     * Get a single medium with all fields and optional API parameters
     *
     * @param string $mediumId Medium ID or media key
     * @param string|null $thumbsize Thumbnail size, e.g. "320x240"
     * @param bool $chapters Include chapter data
     * @param bool $responsive Include responsive embed code
     * @param string|null $language Language code for localised fields
     * @param string|null $mediaPermissions Media permissions filter
     * @param bool|null $hidden Include hidden media
     * @param bool $json Output raw JSON instead of formatted fields
     */
    public function getmediaCommand(
        string $mediumId,
        ?string $thumbsize = null,
        bool $chapters = false,
        bool $responsive = false,
        ?string $language = null,
        ?string $mediaPermissions = null,
        ?bool $hidden = null,
        bool $json = false,
    ): void {
        $medium = $this->mediaApi->getMedium(
            mediumId: $mediumId,
            thumbsize: $thumbsize,
            chapters: $chapters ?: null,
            responsive: $responsive ?: null,
            language: $language,
            mediaPermissions: $mediaPermissions,
            hidden: $hidden,
        );

        if ($json) {
            $this->outputLine(json_encode([
                'mid'              => $medium->mid,
                'mediakey'         => $medium->mediakey,
                'title'            => $medium->title,
                'description'      => $medium->description,
                'mediatype'        => $medium->mediatype,
                'status'           => $medium->status,
                'hidden'           => $medium->hidden,
                'featured'         => $medium->featured,
                'first'            => $medium->first,
                'culture'          => $medium->culture,
                'duration'         => $medium->duration,
                'medium'           => $medium->medium,
                'thumbnail'        => $medium->thumbnail,
                'source'           => $medium->source,
                'embedCode'        => $medium->embedCode,
                'uid'              => $medium->uid,
                'username'         => $medium->username,
                'countViews'       => $medium->countViews,
                'sumRating'        => $medium->sumRating,
                'countRating'      => $medium->countRating,
                'countFavorites'   => $medium->countFavorites,
                'countComments'    => $medium->countComments,
                'countFlags'       => $medium->countFlags,
                'startdate'        => $medium->startdate?->format('Y-m-d H:i:s'),
                'enddate'          => $medium->enddate?->format('Y-m-d H:i:s'),
                'createdAt'        => $medium->createdAt?->format('Y-m-d H:i:s'),
                'updatedAt'        => $medium->updatedAt?->format('Y-m-d H:i:s'),
                'convertedAt'      => $medium->convertedAt?->format('Y-m-d H:i:s'),
                'metaTitle'        => $medium->metaTitle,
                'metaDescription'  => $medium->metaDescription,
                'metaKeywords'     => $medium->metaKeywords,
                'metaAuthor'       => $medium->metaAuthor,
                'metaCopyright'    => $medium->metaCopyright,
                'conversionNotice' => $medium->conversionNotice,
                'properties'       => $medium->properties,
                'categories'       => array_map(fn($c) => ['cid' => $c->cid, 'name' => $c->name], $medium->categories),
                'tags'             => array_map(fn($t) => ['name' => $t->name], $medium->tags),
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            return;
        }

        $this->outputLine('ID:               %d', [$medium->mid]);
        $this->outputLine('Key:              %s', [$medium->mediakey]);
        $this->outputLine('Title:            %s', [$medium->title]);
        $this->outputLine('Description:      %s', [$medium->description ?? '-']);
        $this->outputLine('Type:             %s', [$medium->mediatype]);
        $this->outputLine('Status:           %s', [$medium->status]);
        $this->outputLine('Hidden:           %s', [$medium->hidden ? 'yes' : 'no']);
        $this->outputLine('Featured:         %s', [$medium->featured ? 'yes' : 'no']);
        $this->outputLine('First:            %s', [$medium->first ? 'yes' : 'no']);
        $this->outputLine('Culture:          %s', [$medium->culture]);
        $this->outputLine('Duration:         %s', [$medium->duration !== null ? $medium->duration . 's' : '-']);
        $this->outputLine('Thumbnail:        %s', [$medium->thumbnail ?? '-']);
        $this->outputLine('Source:           %s', [$medium->source ?? '-']);
        if (!empty($medium->medium)) {
            $this->outputLine('');
            $this->outputLine('--- Media URLs ---');
            foreach ($medium->medium as $url) {
                $this->outputLine('  %s', [$url]);
            }
        }
        $this->outputLine('Owner:            %s (uid %d)', [$medium->username, $medium->uid]);
        $this->outputLine('Views:            %d', [$medium->countViews]);
        $this->outputLine('Rating:           %.2f (%d votes)', [$medium->sumRating, $medium->countRating]);
        $this->outputLine('Favorites:        %d', [$medium->countFavorites]);
        $this->outputLine('Comments:         %d', [$medium->countComments]);
        $this->outputLine('Flags:            %d', [$medium->countFlags]);
        $this->outputLine('Start Date:       %s', [$medium->startdate?->format('Y-m-d H:i:s') ?? '-']);
        $this->outputLine('End Date:         %s', [$medium->enddate?->format('Y-m-d H:i:s') ?? '-']);
        $this->outputLine('Created:          %s', [$medium->createdAt?->format('Y-m-d H:i:s') ?? '-']);
        $this->outputLine('Updated:          %s', [$medium->updatedAt?->format('Y-m-d H:i:s') ?? '-']);
        $this->outputLine('Converted:        %s', [$medium->convertedAt?->format('Y-m-d H:i:s') ?? '-']);

        if ($medium->metaTitle || $medium->metaDescription || $medium->metaKeywords || $medium->metaAuthor || $medium->metaCopyright) {
            $this->outputLine('');
            $this->outputLine('--- Meta ---');
            $this->outputLine('Meta Title:       %s', [$medium->metaTitle ?? '-']);
            $this->outputLine('Meta Description: %s', [$medium->metaDescription ?? '-']);
            $this->outputLine('Meta Keywords:    %s', [$medium->metaKeywords ?? '-']);
            $this->outputLine('Meta Author:      %s', [$medium->metaAuthor ?? '-']);
            $this->outputLine('Meta Copyright:   %s', [$medium->metaCopyright ?? '-']);
        }

        if ($medium->conversionNotice) {
            $this->outputLine('');
            $this->outputLine('Conversion Notice: %s', [$medium->conversionNotice]);
        }

        if (!empty($medium->properties)) {
            $this->outputLine('');
            $this->outputLine('--- Properties ---');
            foreach ($medium->properties as $key => $value) {
                $this->outputLine('  %-20s %s', [$key . ':', $value]);
            }
        }

        if (!empty($medium->categories)) {
            $this->outputLine('');
            $this->outputLine('--- Categories ---');
            foreach ($medium->categories as $category) {
                $this->outputLine('  [%d] %s', [$category->cid, $category->name]);
            }
        }

        if (!empty($medium->tags)) {
            $this->outputLine('');
            $this->outputLine('--- Tags ---');
            $names = array_map(fn($t) => $t->name, $medium->tags);
            $this->outputLine('  %s', [implode(', ', $names)]);
        }

        if ($medium->embedCode) {
            $this->outputLine('');
            $this->outputLine('--- Embed Code ---');
            $this->outputLine('%s', [$medium->embedCode]);
        }
    }

    /**
     * List channels
     *
     * @param int $limit Maximum number of results
     */
    public function channelsCommand(int $limit = 20): void
    {
        $channels = $this->channelApi->getChannels(limit: $limit);

        if (empty($channels)) {
            $this->outputLine('No channels found.');
            return;
        }

        $this->outputLine('%-6s %-20s %s', ['ID', 'Owner', 'Title']);
        $this->outputLine(str_repeat('-', 60));
        foreach ($channels as $channel) {
            $this->outputLine('%-6d %-20s %s', [
                $channel->chid,
                $channel->username,
                $channel->title,
            ]);
        }
        $this->outputLine("\n%d channels.", [count($channels)]);
    }

    /**
     * Search for media
     *
     * @param string $keyword Search keyword
     */
    public function searchCommand(string $keyword): void
    {
        $result = $this->searchApi->search($keyword);
        $this->outputLine(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * List installed languages
     */
    public function languagesCommand(): void
    {
        $result = $this->languageApi->getInstalledLanguages(enabled: true);
        $this->outputLine(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

}
