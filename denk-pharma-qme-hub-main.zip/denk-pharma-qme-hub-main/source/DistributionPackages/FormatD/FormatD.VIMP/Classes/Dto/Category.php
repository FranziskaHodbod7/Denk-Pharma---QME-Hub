<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class Category
{
    protected function __construct(
        public readonly int $cid,
        public readonly ?int $parent,
        public readonly string $culture,
        public readonly string $name,
        public readonly ?string $description,
        public readonly string $categorytype,
        public readonly string $status,
        public readonly ?string $picture,
        public readonly int $weight,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
    ) {}

    public static function create(
        int $cid,
        ?int $parent,
        string $culture,
        string $name,
        ?string $description,
        string $categorytype,
        string $status,
        ?string $picture,
        int $weight,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
    ): self {
        return new self($cid, $parent, $culture, $name, $description, $categorytype, $status, $picture, $weight, $createdAt, $updatedAt);
    }
}
