<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class Tag
{
    protected function __construct(
        public readonly int $tid,
        public readonly string $culture,
        public readonly string $name,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
    ) {}

    public static function create(
        int $tid,
        string $culture,
        string $name,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
    ): self {
        return new self($tid, $culture, $name, $createdAt, $updatedAt);
    }
}
