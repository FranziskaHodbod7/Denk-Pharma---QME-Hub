<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class Channel
{
    protected function __construct(
        public readonly int $chid,
        public readonly string $status,
        public readonly int $uid,
        public readonly string $username,
        public readonly ?string $picture,
        public readonly ?string $pictureMenu,
        public readonly string $culture,
        public readonly string $title,
        public readonly ?string $description,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
    ) {}

    public static function create(
        int $chid,
        string $status,
        int $uid,
        string $username,
        ?string $picture,
        ?string $pictureMenu,
        string $culture,
        string $title,
        ?string $description,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
    ): self {
        return new self($chid, $status, $uid, $username, $picture, $pictureMenu, $culture, $title, $description, $createdAt, $updatedAt);
    }
}
