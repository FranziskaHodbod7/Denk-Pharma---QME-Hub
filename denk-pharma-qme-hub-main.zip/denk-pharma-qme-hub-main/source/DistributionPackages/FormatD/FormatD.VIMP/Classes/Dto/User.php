<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class User
{
    protected function __construct(
        public readonly int $uid,
        public readonly int $status,
        public readonly string $username,
        public readonly string $email,
        public readonly ?string $avatar,
        public readonly ?string $cover,
        public readonly ?string $firstname,
        public readonly ?string $lastname,
        public readonly ?string $city,
        public readonly ?string $country,
        public readonly ?\DateTimeInterface $birthday,
        public readonly ?int $gender,
        public readonly ?string $about,
        public readonly ?\DateTimeInterface $lastLoginAt,
        public readonly ?\DateTimeInterface $lastAccessAt,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
    ) {}

    public static function create(
        int $uid,
        int $status,
        string $username,
        string $email,
        ?string $avatar,
        ?string $cover,
        ?string $firstname,
        ?string $lastname,
        ?string $city,
        ?string $country,
        ?\DateTimeInterface $birthday,
        ?int $gender,
        ?string $about,
        ?\DateTimeInterface $lastLoginAt,
        ?\DateTimeInterface $lastAccessAt,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
    ): self {
        return new self(
            $uid, $status, $username, $email, $avatar, $cover, $firstname, $lastname,
            $city, $country, $birthday, $gender, $about, $lastLoginAt, $lastAccessAt,
            $createdAt, $updatedAt,
        );
    }
}
