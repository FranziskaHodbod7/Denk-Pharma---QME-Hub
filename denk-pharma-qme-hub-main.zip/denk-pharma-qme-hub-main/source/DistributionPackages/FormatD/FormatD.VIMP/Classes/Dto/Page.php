<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class Page
{
    protected function __construct(
        public readonly int $wid,
        public readonly int $status,
        public readonly string $culture,
        public readonly string $title,
        public readonly ?string $description,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
    ) {}

    public static function create(
        int $wid,
        int $status,
        string $culture,
        string $title,
        ?string $description,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
    ): self {
        return new self($wid, $status, $culture, $title, $description, $createdAt, $updatedAt);
    }
}
