<?php

declare(strict_types=1);

namespace FormatD\VIMP\Dto;

use Neos\Flow\Annotations as Flow;

#[Flow\Proxy(enabled: false)]
class Media
{
    protected function __construct(
        public readonly int $mid,
        public readonly int $uid,
        public readonly string $username,
        public readonly string $mediakey,
        public readonly string $mediatype,
        public readonly bool $first,
        public readonly bool $hidden,
        public readonly string $status,
        public readonly bool $featured,
        public readonly string $culture,
        public readonly array $properties,
        public readonly string $title,
        public readonly ?string $description,
        public readonly ?int $duration,
        public readonly array $medium,
        public readonly ?string $thumbnail,
        public readonly ?string $source,
        public readonly ?\DateTimeInterface $startdate,
        public readonly ?\DateTimeInterface $enddate,
        public readonly ?string $metaTitle,
        public readonly ?string $metaDescription,
        public readonly ?string $metaKeywords,
        public readonly ?string $metaAuthor,
        public readonly ?string $metaCopyright,
        public readonly ?string $conversionNotice,
        public readonly float $sumRating,
        public readonly int $countViews,
        public readonly int $countRating,
        public readonly int $countFavorites,
        public readonly int $countComments,
        public readonly int $countFlags,
        public readonly ?\DateTimeInterface $createdAt,
        public readonly ?\DateTimeInterface $updatedAt,
        public readonly ?\DateTimeInterface $convertedAt,
        public readonly array $categories,
        public readonly array $tags,
        public readonly ?string $embedCode,
    ) {}

    /**
     * @param string[] $properties
     * @param Category[] $categories
     * @param Tag[] $tags
     */
    public static function create(
        int $mid,
        int $uid,
        string $username,
        string $mediakey,
        string $mediatype,
        bool $first,
        bool $hidden,
        string $status,
        bool $featured,
        string $culture,
        array $properties,
        string $title,
        ?string $description,
        ?int $duration,
        array $medium,
        ?string $thumbnail,
        ?string $source,
        ?\DateTimeInterface $startdate,
        ?\DateTimeInterface $enddate,
        ?string $metaTitle,
        ?string $metaDescription,
        ?string $metaKeywords,
        ?string $metaAuthor,
        ?string $metaCopyright,
        ?string $conversionNotice,
        float $sumRating,
        int $countViews,
        int $countRating,
        int $countFavorites,
        int $countComments,
        int $countFlags,
        ?\DateTimeInterface $createdAt,
        ?\DateTimeInterface $updatedAt,
        ?\DateTimeInterface $convertedAt,
        array $categories,
        array $tags,
        ?string $embedCode,
    ): self {
        return new self(
            $mid, $uid, $username, $mediakey, $mediatype, $first, $hidden, $status, $featured,
            $culture, $properties, $title, $description, $duration, $medium, $thumbnail, $source,
            $startdate, $enddate, $metaTitle, $metaDescription, $metaKeywords, $metaAuthor,
            $metaCopyright, $conversionNotice, $sumRating, $countViews, $countRating,
            $countFavorites, $countComments, $countFlags, $createdAt, $updatedAt, $convertedAt,
            $categories, $tags, $embedCode,
        );
    }
}
