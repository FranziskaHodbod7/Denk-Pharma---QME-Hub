<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

class LanguageApi extends AbstractApi
{
    public function getLanguages(): array
    {
        return $this->transport->send(new Request('getLanguages'));
    }

    public function getInstalledLanguages(?bool $enabled = null): array
    {
        return $this->transport->send(new Request('getInstalledLanguages', $this->params([
            'enabled' => $enabled !== null ? $this->boolParam($enabled) : null,
        ])));
    }
}
