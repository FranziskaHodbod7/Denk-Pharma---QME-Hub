<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use FormatD\VIMP\Dto\Category;
use FormatD\VIMP\Dto\Media;

class CategoryApi extends AbstractApi
{
    /** @return Category[] */
    public function getCategories(
        ?int $parentId = null,
        ?string $filterByName = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $thumbsize = null,
        ?string $language = null,
    ): array {
        $response = $this->transport->send(new Request('getCategories', $this->params([
            'parentid' => $parentId,
            'filterbyname' => $filterByName,
            'offset' => $offset,
            'limit' => $limit,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapCategories($response['categories']['category'] ?? []);
    }

    public function getCategory(
        int $categoryId,
        ?string $thumbsize = null,
        ?string $language = null,
    ): Category {
        $response = $this->transport->send(new Request('getCategory', $this->params([
            'categoryid' => $categoryId,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapCategory($response['categories']['category'][0]);
    }

    /** @return Media[] */
    public function getCategoryMedia(
        int $categoryId,
        ?string $token = null,
        ?string $filterByName = null,
        ?int $filterByType = null,
        ?int $filterByCategory = null,
        ?string $filterByFilter = null,
        ?string $orderBy = null,
        ?string $sortDirection = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $thumbsize = null,
        ?string $language = null,
    ): array {
        $response = $this->transport->send(new Request('getCategoryMedia', $this->params([
            'categoryid' => $categoryId,
            'token' => $token,
            'filterbyname' => $filterByName,
            'filterbytype' => $filterByType,
            'filterbycategory' => $filterByCategory,
            'filterbyfilter' => $filterByFilter,
            'orderby' => $orderBy,
            'sortdirection' => $sortDirection,
            'offset' => $offset,
            'limit' => $limit,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapMediaList($response['media']['medium'] ?? []);
    }

    public function createCategory(
        string $token,
        string $name,
        int $weight,
        ?string $description = null,
        ?int $parentId = null,
        ?string $picture = null,
    ): array {
        return $this->transport->send(new Request('createCategory', $this->params([
            'token' => $token,
            'name' => $name,
            'weight' => $weight,
            'description' => $description,
            'parentid' => $parentId,
            'picture' => $picture,
        ])));
    }

    public function editCategory(
        string $token,
        int $categoryId,
        ?string $name = null,
        ?int $weight = null,
        ?string $description = null,
        ?int $parentId = null,
        ?string $picture = null,
    ): array {
        return $this->transport->send(new Request('editCategory', $this->params([
            'token' => $token,
            'categoryid' => $categoryId,
            'name' => $name,
            'weight' => $weight,
            'description' => $description,
            'parentid' => $parentId,
            'picture' => $picture,
        ])));
    }

    public function deleteCategory(
        string $token,
        int $categoryId,
        ?bool $subcategories = null,
    ): array {
        return $this->transport->send(new Request('deleteCategory', $this->params([
            'token' => $token,
            'categoryid' => $categoryId,
            'subcategories' => $subcategories !== null ? $this->boolParam($subcategories) : null,
        ])));
    }

    public function purgeCategory(
        string $token,
        int $categoryId,
        ?bool $subcategories = null,
    ): array {
        return $this->transport->send(new Request('purgeCategory', $this->params([
            'token' => $token,
            'categoryid' => $categoryId,
            'subcategories' => $subcategories !== null ? $this->boolParam($subcategories) : null,
        ])));
    }
}
