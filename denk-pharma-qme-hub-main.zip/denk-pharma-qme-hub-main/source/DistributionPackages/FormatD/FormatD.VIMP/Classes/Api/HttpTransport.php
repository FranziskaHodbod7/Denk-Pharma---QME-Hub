<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;
use Neos\Flow\Annotations as Flow;

class HttpTransport implements TransportInterface
{
    protected ClientInterface $httpClient;

    #[Flow\InjectConfiguration(path: 'api.baseUrl', package: 'FormatD.VIMP')]
    protected string $baseUrl = '';

    #[Flow\InjectConfiguration(path: 'apiKey', package: 'FormatD.VIMP')]
    protected string $apiKey = '';

    public function __construct(?ClientInterface $httpClient = null)
    {
        $this->httpClient = $httpClient ?? new Client();
    }

    public function send(Request $request): array
    {
        $response = $this->httpClient->request(
            'GET',
            rtrim($this->baseUrl, '/') . '/' . $request->endpoint,
            [
                'query' => array_merge(
                    ['apikey' => $this->apiKey, 'format' => 'json'],
                    $request->parameters
                ),
            ]
        );
        return json_decode((string)$response->getBody(), true) ?? [];
    }
}
