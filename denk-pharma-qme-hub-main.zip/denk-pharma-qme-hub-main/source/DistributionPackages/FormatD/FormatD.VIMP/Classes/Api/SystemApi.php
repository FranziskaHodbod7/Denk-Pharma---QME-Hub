<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

class SystemApi extends AbstractApi
{
    public function version(): array
    {
        return $this->transport->send(new Request('version'));
    }

    public function config(string $name, string $token): array
    {
        return $this->transport->send(new Request('config', [
            'name' => $name,
            'token' => $token,
        ]));
    }

}
