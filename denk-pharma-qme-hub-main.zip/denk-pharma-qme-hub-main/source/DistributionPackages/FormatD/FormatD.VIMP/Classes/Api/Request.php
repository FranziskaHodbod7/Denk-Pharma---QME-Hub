<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

class Request
{
    public function __construct(
        public readonly string $endpoint,
        public readonly array $parameters = [],
    ) {}
}
