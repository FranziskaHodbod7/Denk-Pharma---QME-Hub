<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use FormatD\VIMP\Dto\Category;
use FormatD\VIMP\Dto\Channel;
use FormatD\VIMP\Dto\Media;
use FormatD\VIMP\Dto\Page;
use FormatD\VIMP\Dto\Tag;

class ResponseMapper
{
    public function mapCategory(array $data): Category
    {
        return Category::create(
            cid: (int)$data['cid'],
            parent: isset($data['parent']) ? (int)$data['parent'] : null,
            culture: (string)($data['culture'] ?? ''),
            name: (string)($data['name'] ?? ''),
            description: $data['description'] ?? null,
            categorytype: (string)($data['categorytype'] ?? ''),
            status: (string)($data['status'] ?? ''),
            picture: $data['picture'] ?? null,
            weight: (int)($data['weight'] ?? 0),
            createdAt: $this->parseDate($data['created_at'] ?? null),
            updatedAt: $this->parseDate($data['updated_at'] ?? null),
        );
    }

    /** @return Category[] */
    public function mapCategories(array $items): array
    {
        return array_map(fn(array $item) => $this->mapCategory($item), $items);
    }

    public function mapTag(array $data): Tag
    {
        return Tag::create(
            tid: (int)$data['tid'],
            culture: (string)($data['culture'] ?? ''),
            name: (string)($data['name'] ?? ''),
            createdAt: $this->parseDate($data['created_at'] ?? null),
            updatedAt: $this->parseDate($data['updated_at'] ?? null),
        );
    }

    /** @return Tag[] */
    public function mapTags(array $items): array
    {
        return array_map(fn(array $item) => $this->mapTag($item), $items);
    }

    public function mapChannel(array $data): Channel
    {
        return Channel::create(
            chid: (int)$data['chid'],
            status: (string)($data['status'] ?? ''),
            uid: (int)($data['uid'] ?? 0),
            username: (string)($data['username'] ?? ''),
            picture: $data['picture'] ?? null,
            pictureMenu: $data['picture_menu'] ?? null,
            culture: (string)($data['culture'] ?? ''),
            title: (string)($data['title'] ?? ''),
            description: $data['description'] ?? null,
            createdAt: $this->parseDate($data['created_at'] ?? null),
            updatedAt: $this->parseDate($data['updated_at'] ?? null),
        );
    }

    /** @return Channel[] */
    public function mapChannels(array $items): array
    {
        return array_map(fn(array $item) => $this->mapChannel($item), $items);
    }

    public function mapMedia(array $data): Media
    {
        return Media::create(
            mid: (int)$data['mid'],
            uid: (int)($data['uid'] ?? 0),
            username: (string)($data['username'] ?? ''),
            mediakey: (string)($data['mediakey'] ?? ''),
            mediatype: (string)($data['mediatype'] ?? ''),
            first: (bool)($data['first'] ?? false),
            hidden: (bool)($data['hidden'] ?? false),
            status: (string)($data['status'] ?? ''),
            featured: (bool)($data['featured'] ?? false),
            culture: (string)($data['culture'] ?? ''),
            properties: (array)($data['properties'] ?? []),
            title: (string)($data['title'] ?? ''),
            description: $data['description'] ?? null,
            duration: isset($data['duration']) ? (int)$data['duration'] : null,
            medium: (array)($data['medium'] ?? []),
            thumbnail: $data['thumbnail'] ?? null,
            source: $data['source'] ?? null,
            startdate: $this->parseDate($data['startdate'] ?? null),
            enddate: $this->parseDate($data['enddate'] ?? null),
            metaTitle: $data['meta_title'] ?? null,
            metaDescription: $data['meta_description'] ?? null,
            metaKeywords: $data['meta_keywords'] ?? null,
            metaAuthor: $data['meta_author'] ?? null,
            metaCopyright: $data['meta_copyright'] ?? null,
            conversionNotice: $data['conversion_notice'] ?? null,
            sumRating: (float)($data['sum_rating'] ?? 0.0),
            countViews: (int)($data['count_views'] ?? 0),
            countRating: (int)($data['count_rating'] ?? 0),
            countFavorites: (int)($data['count_favorites'] ?? 0),
            countComments: (int)($data['count_comments'] ?? 0),
            countFlags: (int)($data['count_flags'] ?? 0),
            createdAt: $this->parseDate($data['created_at'] ?? null),
            updatedAt: $this->parseDate($data['updated_at'] ?? null),
            convertedAt: $this->parseDate($data['converted_at'] ?? null),
            categories: isset($data['categories']['category']) && is_array($data['categories']['category']) ? $this->mapCategories($this->normalizeList($data['categories']['category'])) : [],
            tags: isset($data['tags']['tag']) && is_array($data['tags']['tag']) ? $this->mapTags($this->normalizeList($data['tags']['tag'])) : [],
            embedCode: $data['embed_code'] ?? null,
        );
    }

    /** @return Media[] */
    public function mapMediaList(array $items): array
    {
        return array_map(fn(array $item) => $this->mapMedia($item), $items);
    }

    public function mapPage(array $data): Page
    {
        return Page::create(
            wid: (int)$data['wid'],
            status: (int)($data['status'] ?? 0),
            culture: (string)($data['culture'] ?? ''),
            title: (string)($data['title'] ?? ''),
            description: $data['description'] ?? null,
            createdAt: $this->parseDate($data['created_at'] ?? null),
            updatedAt: $this->parseDate($data['updated_at'] ?? null),
        );
    }

    /** @return Page[] */
    public function mapPages(array $items): array
    {
        return array_map(fn(array $item) => $this->mapPage($item), $items);
    }

    /**
     * VIMP returns a single child element as an associative array rather than a one-item list.
     * This normalises both cases to a list so mappers can always expect array<int, array>.
     */
    protected function normalizeList(array $data): array
    {
        return array_is_list($data) ? $data : [$data];
    }

    protected function parseDate(?string $value): ?\DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return new \DateTimeImmutable($value);
        } catch (\Exception) {
            return null;
        }
    }
}
