<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use FormatD\VIMP\Dto\Media;

class MediaApi extends AbstractApi
{
    /** @return Media[] */
    public function getMedia(
        ?string $token = null,
        ?string $filterByName = null,
        ?int $filterByType = null,
        ?int $filterByCategory = null,
        ?string $filterByFilter = null,
        ?string $search = null,
        ?string $orderBy = null,
        ?string $sortDirection = null,
        ?string $includeStatus = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $thumbsize = null,
        ?bool $hidden = null,
        ?bool $private = null,
        ?bool $chapters = null,
        ?bool $responsive = null,
        ?string $language = null,
        ?bool $ownMediaOnly = null,
    ): array {
        $response = $this->transport->send(new Request('getMedia', $this->params([
            'token' => $token,
            'filterbyname' => $filterByName,
            'filterbytype' => $filterByType,
            'filterbycategory' => $filterByCategory,
            'filterbyfilter' => $filterByFilter,
            'search' => $search,
            'orderby' => $orderBy,
            'sortdirection' => $sortDirection,
            'include_status' => $includeStatus,
            'offset' => $offset,
            'limit' => $limit,
            'thumbsize' => $thumbsize,
            'hidden' => $hidden !== null ? $this->boolParam($hidden) : null,
            'private' => $private !== null ? $this->boolParam($private) : null,
            'chapters' => $chapters !== null ? $this->boolParam($chapters) : null,
            'responsive' => $responsive !== null ? $this->boolParam($responsive) : null,
            'language' => $language,
            'ownmediaonly' => $ownMediaOnly !== null ? $this->boolParam($ownMediaOnly) : null,
        ])));
        return $this->mapper->mapMediaList($response['media']['medium'] ?? []);
    }

    public function getMedium(
        string|int $mediumId,
        ?string $token = null,
        ?string $password = null,
        ?string $thumbsize = null,
        ?bool $chapters = null,
        ?bool $responsive = null,
        ?string $language = null,
        ?string $mediaPermissions = null,
        ?bool $hidden = null,
    ): Media {
        $response = $this->transport->send(new Request('getMedium', $this->params([
            'mediumid' => $mediumId,
            'token' => $token,
            'password' => $password,
            'thumbsize' => $thumbsize,
            'chapters' => $chapters !== null ? $this->boolParam($chapters) : null,
            'responsive' => $responsive !== null ? $this->boolParam($responsive) : null,
            'language' => $language,
            'mediapermissions' => $mediaPermissions,
            'hidden' => $hidden !== null ? $this->boolParam($hidden) : null,
        ])));

        $data = $response['medium'] ?? $response['media']['medium'][0] ?? null;
        if ($data === null) {
            throw new \RuntimeException(sprintf('Medium "%s" not found or unexpected response structure.', $mediumId));
        }

        return $this->mapper->mapMedia($data);
    }

    public function getCustomMediaFields(
        ?int $status = null,
        ?string $filterByName = null,
        ?int $offset = null,
        ?int $limit = null,
    ): array {
        return $this->transport->send(new Request('getCustomMediaFields', $this->params([
            'status' => $status,
            'filterbyname' => $filterByName,
            'offset' => $offset,
            'limit' => $limit,
        ])));
    }

    public function uploadMedium(
        string $token,
        string $title,
        string $description,
        string $tags,
        string $categories,
        string $sourceUrl,
        ?int $hidden = null,
        ?int $acceptComment = null,
        ?string $metaTitle = null,
        ?string $metaDescription = null,
        ?string $metaKeywords = null,
        ?string $metaAuthor = null,
        ?string $metaCopyright = null,
        ?string $mediaPermissions = null,
        ?int $paymentWithCosts = null,
        ?string $paymentPrize = null,
        ?int $customPreview = null,
        ?string $previewUrl = null,
        ?string $gmLocation = null,
        ?string $gmLongitude = null,
        ?string $gmLatitude = null,
        ?int $gmZoom = null,
        ?int $priorityTranscode = null,
        ?string $thumbnail = null,
        ?string $uploaded = null,
        ?string $created = null,
        ?string $startdate = null,
        ?string $enddate = null,
        ?string $language = null,
        ?int $uid = null,
    ): array {
        return $this->transport->send(new Request('uploadMedium', $this->params([
            'token' => $token,
            'title' => $title,
            'description' => $description,
            'tags' => $tags,
            'categories' => $categories,
            'source_url' => $sourceUrl,
            'hidden' => $hidden,
            'accept_comment' => $acceptComment,
            'meta_title' => $metaTitle,
            'meta_description' => $metaDescription,
            'meta_keywords' => $metaKeywords,
            'meta_author' => $metaAuthor,
            'meta_copyright' => $metaCopyright,
            'mediapermissions' => $mediaPermissions,
            'payment_withcosts' => $paymentWithCosts,
            'payment_prize' => $paymentPrize,
            'custom_preview' => $customPreview,
            'preview_url' => $previewUrl,
            'gm_location' => $gmLocation,
            'gm_longitude' => $gmLongitude,
            'gm_latitude' => $gmLatitude,
            'gm_zoom' => $gmZoom,
            'priority_transcode' => $priorityTranscode,
            'thumbnail' => $thumbnail,
            'uploaded' => $uploaded,
            'created' => $created,
            'startdate' => $startdate,
            'enddate' => $enddate,
            'language' => $language,
            'uid' => $uid,
        ])));
    }

    public function mediaImport(string $importPath): array
    {
        return $this->transport->send(new Request('mediaimport', [
            'importpath' => $importPath,
        ]));
    }

    public function editMedium(
        string $token,
        string|int $mediumId,
        ?string $title = null,
        ?string $description = null,
        ?string $tags = null,
        ?string $categories = null,
        ?string $thumbnail = null,
        ?int $hidden = null,
        ?int $acceptComment = null,
        ?string $metaTitle = null,
        ?string $metaDescription = null,
        ?string $metaKeywords = null,
        ?string $metaAuthor = null,
        ?string $metaCopyright = null,
        ?string $mediaPermissions = null,
        ?int $paymentWithCosts = null,
        ?string $paymentPrize = null,
        ?int $customPreview = null,
        ?string $previewUrl = null,
        ?string $gmLocation = null,
        ?string $gmLongitude = null,
        ?string $gmLatitude = null,
        ?int $gmZoom = null,
        ?int $priorityTranscode = null,
        ?string $uploaded = null,
        ?string $created = null,
        ?string $startdate = null,
        ?string $enddate = null,
        ?string $language = null,
        ?int $uid = null,
        ?string $sourceUrl = null,
    ): array {
        return $this->transport->send(new Request('editMedium', $this->params([
            'token' => $token,
            'mediumid' => $mediumId,
            'title' => $title,
            'description' => $description,
            'tags' => $tags,
            'categories' => $categories,
            'thumbnail' => $thumbnail,
            'hidden' => $hidden,
            'accept_comment' => $acceptComment,
            'meta_title' => $metaTitle,
            'meta_description' => $metaDescription,
            'meta_keywords' => $metaKeywords,
            'meta_author' => $metaAuthor,
            'meta_copyright' => $metaCopyright,
            'mediapermissions' => $mediaPermissions,
            'payment_withcosts' => $paymentWithCosts,
            'payment_prize' => $paymentPrize,
            'custom_preview' => $customPreview,
            'preview_url' => $previewUrl,
            'gm_location' => $gmLocation,
            'gm_longitude' => $gmLongitude,
            'gm_latitude' => $gmLatitude,
            'gm_zoom' => $gmZoom,
            'priority_transcode' => $priorityTranscode,
            'uploaded' => $uploaded,
            'created' => $created,
            'startdate' => $startdate,
            'enddate' => $enddate,
            'language' => $language,
            'uid' => $uid,
            'source_url' => $sourceUrl,
        ])));
    }

    public function mediumRemoveEditLock(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('mediumRemoveEditLock', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function getMediumTranscodingProgress(string|int $mediumId): array
    {
        return $this->transport->send(new Request('getMediumTranscodingProgress', [
            'mediumid' => $mediumId,
        ]));
    }

    public function addMediumCount(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('addMediumCount', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function lockMedium(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('lockMedium', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function unlockMedium(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('unlockMedium', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function getPicture(
        string $type,
        string|int $keyOrId,
        ?int $size = null,
        ?bool $noFramework = null,
    ): array {
        return $this->transport->send(new Request('getPicture', $this->params([
            'type' => $type,
            'id' => $keyOrId,
            'size' => $size,
            'noframework' => $noFramework !== null ? (int)$noFramework : null,
        ])));
    }

    public function deleteMedium(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('deleteMedium', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function reportMedium(string $token, string|int $mediumId, string $reason): array
    {
        return $this->transport->send(new Request('reportMedium', [
            'token' => $token,
            'mediumid' => $mediumId,
            'reason' => $reason,
        ]));
    }

    public function getMediumComments(
        string|int $mediumId,
        ?string $token = null,
        ?int $offset = null,
        ?int $limit = null,
    ): array {
        return $this->transport->send(new Request('getMediumComments', $this->params([
            'mediumid' => $mediumId,
            'token' => $token,
            'offset' => $offset,
            'limit' => $limit,
        ])));
    }

    public function addMediumComment(string $token, string|int $mediumId, string $comment): array
    {
        return $this->transport->send(new Request('addMediumComment', [
            'token' => $token,
            'mediumid' => $mediumId,
            'comment' => $comment,
        ]));
    }

    public function deleteMediumComment(string $token, string|int $mediumId, int $commentId): array
    {
        return $this->transport->send(new Request('deleteMediumComment', [
            'token' => $token,
            'mediumid' => $mediumId,
            'commentid' => $commentId,
        ]));
    }

    public function addMediumRating(string $token, string|int $mediumId, int $rating): array
    {
        return $this->transport->send(new Request('addMediumRating', [
            'token' => $token,
            'mediumid' => $mediumId,
            'rating' => $rating,
        ]));
    }

    public function addMediumLike(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('addMediumLike', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function deleteMediumLike(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('deleteMediumLike', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function addMediumFavorite(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('addMediumFavorite', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function deleteMediumFavorite(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('deleteMediumFavorite', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function addSubtitle(
        string $token,
        string|int $mediumId,
        string $subtitleFile,
        string $subtitleLanguage,
        string $fileFormat,
    ): array {
        return $this->transport->send(new Request('addSubtitle', [
            'token' => $token,
            'mediumid' => $mediumId,
            'subtitlefile' => $subtitleFile,
            'subtitlelanguage' => $subtitleLanguage,
            'fileformat' => $fileFormat,
        ]));
    }

    public function removeSubtitle(
        string $token,
        string|int $mediumId,
        string $subtitleFile,
        string $subtitleLanguage,
    ): array {
        return $this->transport->send(new Request('removeSubtitle', [
            'token' => $token,
            'mediumid' => $mediumId,
            'subtitlefile' => $subtitleFile,
            'subtitlelanguage' => $subtitleLanguage,
        ]));
    }

    public function removeSubtitles(string $token, string|int $mediumId): array
    {
        return $this->transport->send(new Request('removeSubtitles', [
            'token' => $token,
            'mediumid' => $mediumId,
        ]));
    }

    public function getMediumChapters(string|int $mediumId, ?string $languageCode = null): array
    {
        return $this->transport->send(new Request('getMediumChapters', $this->params([
            'mediumid' => $mediumId,
            'languageCode' => $languageCode,
        ])));
    }

    public function addMediumChapter(
        string $token,
        string|int $mediumId,
        string $title,
        int $time,
        string $languageCode,
    ): array {
        return $this->transport->send(new Request('addMediumChapter', [
            'token' => $token,
            'mediumid' => $mediumId,
            'title' => $title,
            'time' => $time,
            'languageCode' => $languageCode,
        ]));
    }

    public function editMediumChapter(
        string $token,
        string|int $mediumId,
        int $chapterId,
        ?string $title = null,
        ?int $time = null,
        ?string $languageCode = null,
    ): array {
        return $this->transport->send(new Request('editMediumChapter', $this->params([
            'token' => $token,
            'mediumid' => $mediumId,
            'chapterid' => $chapterId,
            'title' => $title,
            'time' => $time,
            'languageCode' => $languageCode,
        ])));
    }

    public function addMediumAdditionalOwner(
        string $token,
        string|int $mediumId,
        int $additionalOwnerId,
        int $privilege,
        ?int $inheritancePriority = null,
    ): array {
        return $this->transport->send(new Request('addMediumAdditionalOwner', $this->params([
            'token' => $token,
            'mediumid' => $mediumId,
            'additionalownerid' => $additionalOwnerId,
            'privilege' => $privilege,
            'inheritance_priority' => $inheritancePriority,
        ])));
    }

    public function editMediumAdditionalOwner(
        string $token,
        string|int $mediumId,
        int $additionalOwnerId,
        ?int $privilege = null,
        ?int $inheritancePriority = null,
    ): array {
        return $this->transport->send(new Request('editMediumAdditionalOwner', $this->params([
            'token' => $token,
            'mediumid' => $mediumId,
            'additionalownerid' => $additionalOwnerId,
            'privilege' => $privilege,
            'inheritance_priority' => $inheritancePriority,
        ])));
    }

    public function deleteMediumAdditionalOwner(
        string $token,
        string|int $mediumId,
        int $additionalOwnerId,
    ): array {
        return $this->transport->send(new Request('deleteMediumAdditionalOwner', [
            'token' => $token,
            'mediumid' => $mediumId,
            'additionalownerid' => $additionalOwnerId,
        ]));
    }

    public function purgeMediumAdditionalOwner(
        string $token,
        string|int $mediumId,
        int $additionalOwnerId,
    ): array {
        return $this->transport->send(new Request('purgeMediumAdditionalOwner', [
            'token' => $token,
            'mediumid' => $mediumId,
            'additionalownerid' => $additionalOwnerId,
        ]));
    }

    public function oembed(
        string $url,
        ?int $startTime = null,
        ?int $width = null,
        ?int $height = null,
        ?bool $autoplay = null,
        ?bool $related = null,
        ?bool $loadOnClick = null,
        ?bool $responsive = null,
    ): array {
        return $this->transport->send(new Request('oembed', $this->params([
            'url' => $url,
            't' => $startTime,
            'width' => $width,
            'height' => $height,
            'autoplay' => $autoplay !== null ? $this->boolParam($autoplay) : null,
            'related' => $related !== null ? $this->boolParam($related) : null,
            'loadonclick' => $loadOnClick !== null ? $this->boolParam($loadOnClick) : null,
            'responsive' => $responsive !== null ? $this->boolParam($responsive) : null,
        ])));
    }
}
