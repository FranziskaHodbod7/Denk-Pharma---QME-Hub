<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

class SearchApi extends AbstractApi
{
    public function search(
        string $keyword,
        ?string $token = null,
        ?bool $hidden = null,
        ?string $language = null,
        ?string $mediaPermissions = null,
    ): array {
        return $this->transport->send(new Request('search', $this->params([
            'keyword' => $keyword,
            'token' => $token,
            'hidden' => $hidden !== null ? $this->boolParam($hidden) : null,
            'language' => $language,
            'mediapermissions' => $mediaPermissions,
        ])));
    }

    public function extendedSearch(
        string $title,
        ?string $token = null,
        ?string $description = null,
        ?string $tags = null,
        ?string $searchRange = null,
        ?string $groups = null,
        ?string $channels = null,
        ?string $categories = null,
        ?bool $hidden = null,
        ?bool $private = null,
        ?int $duration = null,
        ?string $uploaded = null,
        ?string $created = null,
        ?string $language = null,
        ?string $mediaPermissions = null,
        ?int $userId = null,
        ?string $createdMin = null,
        ?string $createdMax = null,
        ?int $durationMin = null,
        ?int $durationMax = null,
        ?int $viewsMin = null,
        ?int $viewsMax = null,
    ): array {
        return $this->transport->send(new Request('extendedSearch', $this->params([
            'title' => $title,
            'token' => $token,
            'description' => $description,
            'tags' => $tags,
            'searchrange' => $searchRange,
            'groups' => $groups,
            'channels' => $channels,
            'categories' => $categories,
            'hidden' => $hidden !== null ? $this->boolParam($hidden) : null,
            'private' => $private !== null ? $this->boolParam($private) : null,
            'duration' => $duration,
            'uploaded' => $uploaded,
            'created' => $created,
            'language' => $language,
            'mediapermissions' => $mediaPermissions,
            'userid' => $userId,
            'created_min' => $createdMin,
            'created_max' => $createdMax,
            'duration_min' => $durationMin,
            'duration_max' => $durationMax,
            'views_min' => $viewsMin,
            'views_max' => $viewsMax,
        ])));
    }
}
