<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use FormatD\VIMP\Dto\Channel;
use FormatD\VIMP\Dto\Media;

class ChannelApi extends AbstractApi
{
    /** @return Channel[] */
    public function getChannels(
        ?string $filterByName = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $thumbsize = null,
        ?string $language = null,
    ): array {
        $response = $this->transport->send(new Request('getChannels', $this->params([
            'filterbyname' => $filterByName,
            'offset' => $offset,
            'limit' => $limit,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapChannels($response['channels']['channel'] ?? []);
    }

    public function getChannel(
        int $channelId,
        ?string $thumbsize = null,
        ?string $language = null,
    ): Channel {
        $response = $this->transport->send(new Request('getChannel', $this->params([
            'channelid' => $channelId,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapChannel($response['channels']['channel'][0]);
    }

    /** @return Media[] */
    public function getChannelMedia(
        int $channelId,
        ?string $token = null,
        ?string $filterByName = null,
        ?int $filterByType = null,
        ?int $filterByCategory = null,
        ?string $filterByFilter = null,
        ?string $orderBy = null,
        ?string $sortDirection = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $thumbsize = null,
        ?string $language = null,
    ): array {
        $response = $this->transport->send(new Request('getChannelMedia', $this->params([
            'channelid' => $channelId,
            'token' => $token,
            'filterbyname' => $filterByName,
            'filterbytype' => $filterByType,
            'filterbycategory' => $filterByCategory,
            'filterbyfilter' => $filterByFilter,
            'orderby' => $orderBy,
            'sortdirection' => $sortDirection,
            'offset' => $offset,
            'limit' => $limit,
            'thumbsize' => $thumbsize,
            'language' => $language,
        ])));
        return $this->mapper->mapMediaList($response['media']['medium'] ?? []);
    }

    public function addMediumChannel(string $token, string|int $mediumId, int $channelId): array
    {
        return $this->transport->send(new Request('addMediumChannel', [
            'token' => $token,
            'mediumid' => $mediumId,
            'channelid' => $channelId,
        ]));
    }

    public function removeMediumChannel(string $token, string|int $mediumId, int $channelId): array
    {
        return $this->transport->send(new Request('removeMediumChannel', [
            'token' => $token,
            'mediumid' => $mediumId,
            'channelid' => $channelId,
        ]));
    }
}
