<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

use FormatD\VIMP\Dto\Page;

class PageApi extends AbstractApi
{
    /** @return Page[] */
    public function getPages(
        ?string $filterByName = null,
        ?int $offset = null,
        ?int $limit = null,
        ?string $language = null,
    ): array {
        $response = $this->transport->send(new Request('getPages', $this->params([
            'filterbyname' => $filterByName,
            'offset' => $offset,
            'limit' => $limit,
            'language' => $language,
        ])));
        return $this->mapper->mapPages($response['pages']['page'] ?? []);
    }

    public function getPage(int $pageId, ?string $language = null): Page
    {
        $response = $this->transport->send(new Request('getPage', $this->params([
            'pageid' => $pageId,
            'language' => $language,
        ])));
        return $this->mapper->mapPage($response['pages']['page'][0]);
    }
}
