<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

abstract class AbstractApi
{
    public function __construct(
        protected readonly TransportInterface $transport,
        protected readonly ResponseMapper $mapper,
    ) {}

    protected function params(array $params): array
    {
        return array_filter($params, fn($v) => $v !== null);
    }

    protected function boolParam(bool $value): string
    {
        return $value ? 'true' : 'false';
    }
}
