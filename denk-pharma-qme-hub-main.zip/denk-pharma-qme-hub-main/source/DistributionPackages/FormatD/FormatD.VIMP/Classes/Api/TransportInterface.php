<?php

declare(strict_types=1);

namespace FormatD\VIMP\Api;

interface TransportInterface
{
    /** @return array<string, mixed> */
    public function send(Request $request): array;
}
