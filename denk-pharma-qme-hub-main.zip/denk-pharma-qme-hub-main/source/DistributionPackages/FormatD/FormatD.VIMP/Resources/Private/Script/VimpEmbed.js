
const container = document.getElementById(elementId);
if (container) {
    const observer = new MutationObserver((mutations, obs) => {
        const video = container.querySelector('video');
        if (video) {
            if (typeof _paq !== 'undefined') {
                _paq.push(['MediaAnalytics::scanForMedia']);
            }
            obs.disconnect(); 
        }
    });
    observer.observe(container, { childList: true, subtree: true });
}

document.addEventListener('VimpMediaEmbedInit', () => new VimpMediaEmbed(
    elementId,
    embedKey,
    options
));
