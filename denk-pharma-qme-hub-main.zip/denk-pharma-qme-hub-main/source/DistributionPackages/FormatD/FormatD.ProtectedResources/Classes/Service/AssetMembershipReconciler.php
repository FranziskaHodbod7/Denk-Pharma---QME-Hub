<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Service;

use FormatD\ProtectedResources\Domain\Service\ProtectedAssetCollectionService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\ResourceManagement\ResourceManager;
use Neos\Flow\ResourceManagement\Target\Exception;
use Neos\Flow\ResourceManagement\Target\TargetInterface;
use Neos\Media\Domain\Model\AssetInterface;

#[Flow\Scope('singleton')]
final class AssetMembershipReconciler
{
    /**
     * @var array<string, array{target: class-string<TargetInterface>, targetOptions?: array<string, mixed>}>
     */
    #[Flow\InjectConfiguration(path: 'resource.targets', package: 'Neos.Flow')]
    protected array $targetsConfig;

    #[Flow\InjectConfiguration(path: 'publicTargetName')]
    protected ?string $publicTargetName;

    #[Flow\Inject]
    protected ProtectedAssetCollectionService $service;

    #[Flow\Inject]
    protected ResourceManager $resourceManager;

    protected ?TargetInterface $publicTarget = null;

	/**
	 * @throws Exception
	 */
	public function reconcileOnAssetUpdated(AssetInterface $asset): void
    {
        $resource = $asset->getResource();
        if ($resource === null) {
            return;
        }

        $collection = $this->resourceManager->getCollection($resource->getCollectionName());
        if ($collection === null) {
            return;
        }

        if ($this->service->isAssetProtected($asset)) {
            $this->publicTarget()->unpublishResource($resource);
        } else {
            $this->publicTarget()->publishResource($resource, $collection);
        }
    }

    protected function publicTarget(): TargetInterface
    {
        if ($this->publicTarget !== null) {
            return $this->publicTarget;
        }
        $targetName = $this->publicTargetName ?? 'localWebDirectoryPersistentResourcesTarget';
        $definition = $this->targetsConfig[$targetName] ?? null;
        if ($definition === null || !isset($definition['target'])) {
            throw new \RuntimeException(sprintf(
                'AssetMembershipReconciler cannot find target "%s" in Neos.Flow.resource.targets configuration.',
                $targetName
            ), 1748000001);
        }
        $class = $definition['target'];
        $targetOptions = $definition['targetOptions'] ?? [];
        $target = new $class($targetName, $targetOptions);
        \assert($target instanceof TargetInterface);
        return $this->publicTarget = $target;
    }
}
