<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Aspect;

use FormatD\ProtectedResources\Domain\Service\ProtectedAssetCollectionService;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Aop\JoinPointInterface;
use Neos\Flow\Mvc\Controller\ActionController;
use Neos\Flow\Mvc\Exception\NoSuchArgumentException;
use Neos\Media\Domain\Model\AssetCollection;

#[Flow\Aspect]
#[Flow\Scope('singleton')]
final class ProtectedAssetCollectionAspect
{
    #[Flow\Inject]
    protected ProtectedAssetCollectionService $service;

	#[Flow\Before('method(Neos\Media\Browser\Controller\AssetController->updateAssetCollectionAction())')]
    public function syncProtectionFlag(JoinPointInterface $joinPoint): void
    {
        $assetCollection = $joinPoint->getMethodArgument('assetCollection');
        if (!$assetCollection instanceof AssetCollection) {
            return;
        }

        $controller = $joinPoint->getProxy();
        \assert($controller instanceof ActionController);

        $request = $controller->getControllerContext()->getRequest();
        if (!$request->hasArgument('isProtected')) {
            return;
        }

        $isProtected = filter_var($request->getArgument('isProtected'), FILTER_VALIDATE_BOOL);
        if ($isProtected) {
            $this->service->markProtected($assetCollection);
        } else {
            $this->service->unmarkProtected($assetCollection);
        }
    }
}
