<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\ViewHelpers;

use FormatD\ProtectedResources\Domain\Service\ProtectedAssetCollectionService;
use Neos\Flow\Annotations as Flow;
use Neos\FluidAdaptor\Core\ViewHelper\AbstractViewHelper;
use Neos\Media\Domain\Model\AssetCollection;

final class IsProtectedViewHelper extends AbstractViewHelper
{
    #[Flow\Inject]
    protected ProtectedAssetCollectionService $service;

    public function initializeArguments(): void
    {
        $this->registerArgument('assetCollection', AssetCollection::class, 'The collection to check', true);
    }

    public function render(): bool
    {
        $assetCollection = $this->arguments['assetCollection'];
        \assert($assetCollection instanceof AssetCollection);
        return $this->service->isProtected($assetCollection);
    }
}
