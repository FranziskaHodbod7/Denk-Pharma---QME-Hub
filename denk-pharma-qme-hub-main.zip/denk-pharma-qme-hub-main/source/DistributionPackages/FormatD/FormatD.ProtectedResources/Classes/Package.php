<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources;

use FormatD\ProtectedResources\Service\AssetMembershipReconciler;
use Neos\Flow\Core\Bootstrap;
use Neos\Flow\Package\Package as BasePackage;
use Neos\Media\Domain\Service\AssetService;

final class Package extends BasePackage
{
    public function boot(Bootstrap $bootstrap): void
    {
        $dispatcher = $bootstrap->getSignalSlotDispatcher();
        $dispatcher->connect(
            AssetService::class,
            'assetUpdated',
            AssetMembershipReconciler::class,
            'reconcileOnAssetUpdated'
        );
    }
}
