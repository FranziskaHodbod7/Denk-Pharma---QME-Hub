<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Domain\Model;

use Doctrine\ORM\Mapping as ORM;
use Neos\Flow\Annotations as Flow;
use Neos\Media\Domain\Model\AssetCollection;

#[Flow\Entity]
#[ORM\Table(name: 'formatd_protectedresources_collectionmarker')]
class ProtectedAssetCollectionMarker
{
    #[ORM\OneToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    protected AssetCollection $assetCollection;

    public function __construct(AssetCollection $assetCollection)
    {
        $this->assetCollection = $assetCollection;
    }

    public function getAssetCollection(): AssetCollection
    {
        return $this->assetCollection;
    }
}
