<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Domain\Service;

use FormatD\ProtectedResources\Domain\Model\ProtectedAssetCollectionMarker;
use FormatD\ProtectedResources\Domain\Repository\ProtectedAssetCollectionMarkerRepository;
use Neos\Flow\Annotations as Flow;
use Neos\Media\Domain\Model\AssetCollection;
use Neos\Media\Domain\Model\AssetInterface;

#[Flow\Scope('singleton')]
final class ProtectedAssetCollectionService
{
    #[Flow\Inject]
    protected ProtectedAssetCollectionMarkerRepository $markerRepository;

    public function isProtected(AssetCollection $assetCollection): bool
    {
        return $this->markerRepository->findOneByAssetCollection($assetCollection) !== null;
    }

    public function isAssetProtected(AssetInterface $asset): bool
    {
        foreach ($asset->getAssetCollections() as $collection) {
            if ($this->isProtected($collection)) {
                return true;
            }
        }
        return false;
    }

    public function markProtected(AssetCollection $assetCollection): void
    {
        if ($this->isProtected($assetCollection)) {
            return;
        }
        $this->markerRepository->add(new ProtectedAssetCollectionMarker($assetCollection));
    }

    public function unmarkProtected(AssetCollection $assetCollection): void
    {
        $marker = $this->markerRepository->findOneByAssetCollection($assetCollection);
        if ($marker !== null) {
            $this->markerRepository->remove($marker);
        }
    }
}
