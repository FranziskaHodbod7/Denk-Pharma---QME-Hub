<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Domain\Repository;

use FormatD\ProtectedResources\Domain\Model\ProtectedAssetCollectionMarker;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Persistence\Repository;
use Neos\Media\Domain\Model\AssetCollection;

/**
 * @method ProtectedAssetCollectionMarker|null findOneByAssetCollection(AssetCollection $assetCollection)
 */
#[Flow\Scope('singleton')]
class ProtectedAssetCollectionMarkerRepository extends Repository
{
}
