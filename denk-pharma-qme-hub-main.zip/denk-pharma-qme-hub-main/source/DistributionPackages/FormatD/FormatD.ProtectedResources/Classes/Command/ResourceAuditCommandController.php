<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Command;

use Doctrine\ORM\EntityManagerInterface;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Cli\CommandController;
use Neos\Flow\Persistence\PersistenceManagerInterface;
use Neos\Flow\ResourceManagement\PersistentResource;
use Neos\Flow\ResourceManagement\ResourceManager;
use Neos\Flow\ResourceManagement\ResourceRepository;

final class ResourceAuditCommandController extends CommandController
{
    #[Flow\Inject]
    protected ResourceRepository $resourceRepository;

    #[Flow\Inject]
    protected ResourceManager $resourceManager;

    #[Flow\Inject]
    protected PersistenceManagerInterface $persistenceManager;

    #[Flow\Inject]
    protected EntityManagerInterface $entityManager;

    /**
     * Compare stored fileSize against actual storage size.
     *
     * @param string $collectionName Only audit this collection (empty = all)
     * @param int $limit Stop after N resources (0 = no limit)
     * @param bool $fixDrift Write the actual size back to the row when drift is detected
     */
    public function auditCommand(string $collectionName = '', int $limit = 0, bool $fixDrift = false): void
    {
        if ($fixDrift) {
            $this->outputLine('<comment>fix-drift mode: drift rows will be updated in the database.</comment>');
            $this->outputLine();
        }

        $updateSql = null;
        if ($fixDrift) {
            $metadata = $this->entityManager->getClassMetadata(PersistentResource::class);
            $updateSql = sprintf(
                'UPDATE %s SET %s = :size WHERE persistence_object_identifier = :id',
                $metadata->getTableName(),
                $metadata->getColumnName('fileSize')
            );
        }

        $checked = 0;
        $drift = 0;
        $fixed = 0;
        $missing = 0;
        $unreadable = 0;

        foreach ($this->resourceRepository->findAllIterator() as $resource) {
            \assert($resource instanceof PersistentResource);

            if ($collectionName !== '' && $resource->getCollectionName() !== $collectionName) {
                continue;
            }

            $checked++;

            $stream = $this->resourceManager->getStreamByResource($resource);
            if ($stream === false) {
                $missing++;
                $this->outputLine('MISSING     %s  %s  (collection=%s)', [
                    $resource->getSha1(),
                    $resource->getFilename(),
                    $resource->getCollectionName(),
                ]);
            } else {
                $actual = $this->measureStream($stream);
                fclose($stream);

                if ($actual === null) {
                    $unreadable++;
                    $this->outputLine('UNREADABLE  %s  %s', [
                        $resource->getSha1(),
                        $resource->getFilename(),
                    ]);
                } else {
                    $stored = (int)$resource->getFileSize();
                    if ($actual !== $stored) {
                        $drift++;
                        $label = 'DRIFT      ';
                        if ($fixDrift) {
                            $this->entityManager->getConnection()->executeStatement(
                                $updateSql,
                                [
                                    'size' => $actual,
                                    'id' => $this->persistenceManager->getIdentifierByObject($resource),
                                ]
                            );
                            $fixed++;
                            $label = 'FIXED      ';
                        }
                        $this->outputLine(
                            '%s %s  %s  stored=%d actual=%d delta=%+d',
                            [
                                $label,
                                $resource->getSha1(),
                                $resource->getFilename(),
                                $stored,
                                $actual,
                                $actual - $stored,
                            ]
                        );
                    }
                }
            }

            if ($limit > 0 && $checked >= $limit) {
                break;
            }
        }

        $this->outputLine();
        $this->outputLine('Checked:    %d', [$checked]);
        $this->outputLine('Drift:      %d', [$drift]);
        if ($fixDrift) {
            $this->outputLine('Fixed:      %d', [$fixed]);
        }
        $this->outputLine('Missing:    %d', [$missing]);
        $this->outputLine('Unreadable: %d', [$unreadable]);
    }

    /**
     * @param resource $stream
     */
    private function measureStream($stream): ?int
    {
        $meta = stream_get_meta_data($stream);
        if (!empty($meta['seekable']) && fseek($stream, 0, SEEK_END) === 0) {
            $size = ftell($stream);
            return $size === false ? null : $size;
        }

        $size = 0;
        while (!feof($stream)) {
            $chunk = fread($stream, 1 << 16);
            if ($chunk === false) {
                return null;
            }
            $size += strlen($chunk);
        }
        return $size;
    }
}
