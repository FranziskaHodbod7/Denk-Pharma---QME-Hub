<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Http\Middleware;

use Neos\Flow\Annotations as Flow;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final class ProtectedResourceInlineDispositionMiddleware implements MiddlewareInterface
{
    /**
     * @var string[]
     */
    #[Flow\InjectConfiguration(path: 'inlineContentTypePrefixes')]
    protected array $inlineContentTypePrefixes;

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $response = $handler->handle($request);

        if (!isset($request->getQueryParams()['__protectedResource'])) {
            return $response;
        }

        $contentType = $response->getHeaderLine('Content-Type');
        $contentTypeIsInlineable = false;
        foreach ($this->inlineContentTypePrefixes as $prefix) {
            if (str_starts_with($contentType, $prefix)) {
                $contentTypeIsInlineable = true;
                break;
            }
        }
        if (!$contentTypeIsInlineable) {
            return $response;
        }

        $disposition = $response->getHeaderLine('Content-Disposition');
        if (!str_starts_with($disposition, 'attachment')) {
            return $response;
        }

        return $response->withHeader(
            'Content-Disposition',
            'inline' . substr($disposition, strlen('attachment'))
        );
    }
}
