<?php

declare(strict_types=1);

namespace FormatD\ProtectedResources\Http\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final class ProtectedResourceContentLengthMiddleware implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $response = $handler->handle($request);

        if (!isset($request->getQueryParams()['__protectedResource'])) {
            return $response;
        }

        $body = $response->getBody();
        if (!$body->isSeekable()) {
            return $response;
        }

        try {
            $body->seek(0, SEEK_END);
            $actualSize = $body->tell();
            $body->rewind();
        } catch (\RuntimeException) {
            return $response;
        }

        return $response->withHeader('Content-Length', (string)$actualSize);
    }
}
