<?php

declare(strict_types=1);

namespace Neos\Flow\Persistence\Doctrine\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20260526112334 extends AbstractMigration
{
	public function getDescription(): string
	{
		return 'Adds auxiliary table for collection markers';
	}

	public function up(Schema $schema): void
	{
		$this->addSql('CREATE TABLE formatd_protectedresources_collectionmarker (persistence_object_identifier VARCHAR(40) NOT NULL, assetcollection VARCHAR(40) NOT NULL, UNIQUE INDEX UNIQ_F1983A455CEB2C15 (assetcollection), PRIMARY KEY(persistence_object_identifier)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
		$this->addSql('ALTER TABLE formatd_protectedresources_collectionmarker ADD CONSTRAINT FK_F1983A455CEB2C15 FOREIGN KEY (assetcollection) REFERENCES neos_media_domain_model_assetcollection (persistence_object_identifier) ON DELETE CASCADE');
	}

	public function down(Schema $schema): void
	{
		$this->addSql('ALTER TABLE formatd_protectedresources_collectionmarker DROP FOREIGN KEY FK_F1983A455CEB2C15');
		$this->addSql('DROP TABLE formatd_protectedresources_collectionmarker');
	}
}
