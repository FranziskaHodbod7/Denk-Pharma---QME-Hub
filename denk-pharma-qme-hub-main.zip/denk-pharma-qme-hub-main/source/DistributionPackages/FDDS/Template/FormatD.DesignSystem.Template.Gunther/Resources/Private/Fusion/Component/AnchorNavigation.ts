// @ts-ignore
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class AnchorNavigationComponentManager extends AbstractComponentManager {

  initialize(domSection: HTMLElement) {

  }

}
