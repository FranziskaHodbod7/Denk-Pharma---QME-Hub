import {AbstractComponentManager} from '../../../JavaScript/ComponentLoader/AbstractComponentManager';

export enum classNames {
	WRAPPER = '.dimension-menu',
	TOGGLE_HANDLER = '.current',
	MENU_OPENED = 'open'
}

export default class DimensionMenu extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		const dimensionMenus = this.getDimensionMenus(domSection);

		dimensionMenus.forEach(function(menu) {
			const toggleDimensionButton = <HTMLElement>menu.querySelector(classNames.TOGGLE_HANDLER);

			toggleDimensionButton.addEventListener('click', () => menu.classList.toggle(classNames.MENU_OPENED));

			window.addEventListener('click', (event) => {
				const eventTarget = <HTMLElement>event.target;
				if (menu.classList.contains(classNames.MENU_OPENED) && !eventTarget.closest(classNames.WRAPPER)) {
					menu.classList.toggle(classNames.MENU_OPENED);
				}
			});
		});
	}

	getDimensionMenus(domSection: HTMLElement): NodeListOf<HTMLElement> {
		return domSection.querySelectorAll(classNames.WRAPPER);
	}
}
