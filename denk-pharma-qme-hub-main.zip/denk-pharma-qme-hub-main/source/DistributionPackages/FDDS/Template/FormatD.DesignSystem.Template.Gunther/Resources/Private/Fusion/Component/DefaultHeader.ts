import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class HeaderComponentManager extends AbstractComponentManager {

	initialize(domSection) {
		const nav = domSection.querySelector('nav');
		if(!nav) {
			return
		}

		const mobileMenuToggle = this.getMobileMenuToggleElement(nav)
		const mobileMenu = this.getMobileMenuElement(nav)

		mobileMenuToggle.addEventListener('click', () => {
			this.mobileMenuToggleClickEventHandler(mobileMenuToggle, mobileMenu)
		});
	}

	getMobileMenuToggleElement(nav: HTMLElement) {
		return <HTMLElement>nav.querySelector('button')
	}

	getMobileMenuElement(nav: HTMLElement) {
		return <HTMLElement>nav.querySelector('#mobile-menu')
	}

	mobileMenuToggleClickEventHandler(mobileMenuToggle: HTMLElement, mobileMenu: HTMLElement) {
		const hiddenClass = this.getHiddenClass()
		mobileMenuToggle.querySelector('.open-icon').classList.toggle(hiddenClass);
		mobileMenuToggle.querySelector('.close-icon').classList.toggle(hiddenClass);
		mobileMenu.classList.toggle(hiddenClass);
	}

	getHiddenClass = () => 'hidden'

}
