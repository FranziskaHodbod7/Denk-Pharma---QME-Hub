
const AttachedEventName = (name) => 'DesignSystem:Attached:'+name

declare global {
	interface Window {
		//@todo: sis
		fdds: {
			Context: {
				isBackend: () => boolean,
				isProduction: boolean,
				isDevelopment: boolean
			},
			ComponentRegistry: {
				components: [],
				register: (...names) => void
			}
		}
	}
}

export class DesignSystem {
	static OBJECT_ATTACHMENT_NAME = '__fdds'

	static AttachToElement(element: HTMLElement, name: string, data: any) {
		if(!element[this.OBJECT_ATTACHMENT_NAME]) {
			element[this.OBJECT_ATTACHMENT_NAME] = {}
		}
		element[this.OBJECT_ATTACHMENT_NAME][name] = data
		element.dispatchEvent(new Event(AttachedEventName(name)))
	}

	static GetFromElement(element: HTMLElement, name: string) {
		if(element[this.OBJECT_ATTACHMENT_NAME] === undefined) {
			return undefined
		}
		return element[this.OBJECT_ATTACHMENT_NAME][name]
	}

	constructor() {
		return undefined
	}
}
