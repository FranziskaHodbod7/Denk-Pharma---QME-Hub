<?php

namespace FormatD\DesignSystem\Core\Eel\Helper;


use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper with utilities
 */
class UtilityHelper implements ProtectedContextAwareInterface
{

	/**
	 * @param mixed $prototypeName
	 * @return string
	 * @throws \ReflectionException
	 */
	public function getPrototypeName($prototypeName)
	{
		throw new \Exception("`FDDS.Utility.getPrototypeName` is no longer Supported. Use `FD.ComponentLoader.getFusionObjectName` instead.");
		die();
	}

	public function throwException(string $message)
	{
		throw new \Exception($message);
		die();
	}

	/**
	 * @param string $prefix
	 * @return string
	 */
	public function uniqueId($prefix = '')
	{
		return uniqid($prefix);
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName)
	{
		return true;
	}
}
