<?php
namespace FormatD\DesignSystem\Core\DataSource;

use Neos\Eel\FlowQuery\FlowQuery;
use Neos\Flow\Annotations as Flow;
use Neos\Neos\Service\DataSource\AbstractDataSource;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Neos\Domain\NodeLabel\NodeLabelGeneratorInterface;

class ContentSectionsDataSource extends AbstractDataSource {

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-content-sections';

	/**
	 * @var string
	 */
	protected static $icon = 'icon-columns';

    #[Flow\Inject]
    protected NodeLabelGeneratorInterface $nodeLabelGenerator;

	/**
	 * @param Node|null $node
	 * @param array $arguments
	 * @return array|mixed
	 * @throws \Neos\Eel\Exception
	 */
	public function getData(Node $node = null, array $arguments = []) {
		$parentContentCollectionPath = $arguments['parentContentCollectionPath'] ?? 'main';
		$q = new FlowQuery([$node]);
		$sectionNodes = $q
			->closest('[instanceof Neos.Neos:Document]')
			->children($parentContentCollectionPath)
			->children('[instanceof FormatD.DesignSystem.Components.Structural:Content.Section][title][title != ""]')
			->get();

		$data = [];
		foreach ($sectionNodes as $sectionNode) {
			$data[] = [
				'label' => $this->nodeLabelGenerator->getLabel($sectionNode),
				'value' => $sectionNode->aggregateId,
				'icon' => static::$icon
			];
		}

		return $data;
	}
}
