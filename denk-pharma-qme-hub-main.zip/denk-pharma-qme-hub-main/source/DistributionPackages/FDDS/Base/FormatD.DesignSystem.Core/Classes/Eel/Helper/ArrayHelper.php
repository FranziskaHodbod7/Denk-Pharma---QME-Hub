<?php
namespace FormatD\DesignSystem\Core\Eel\Helper;

use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper for arrays
 */
class ArrayHelper implements ProtectedContextAwareInterface {

	/**
	 * @param array $array
	 * @return array
	 */
	public function values($array) {
		return array_values($array);
	}

	/**
	* @param array $a
	* @param array $b
	* @return array|null
	*/
	public function merge($a, $b): ?array
	{
        return ($a !== null && $b !== null) ? [...$a, ...$b] : null;
	}

    /**
     * @param array $array
     * @param integer $firstChunk
     * @param integer $secondChunk
     * @return array
     */
    public function chunk($array, $firstChunk, $secondChunk)
    {
        $chunks = [];
        $i = 1;
        while (count($array)) {
            $chunks[] = array_splice($array, 0, $i % $secondChunk !== 0 ? $firstChunk + ($i % $secondChunk) : 0, []);
            $i++;
        }

        return $chunks;
    }

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName) {
		return true;
	}
}
