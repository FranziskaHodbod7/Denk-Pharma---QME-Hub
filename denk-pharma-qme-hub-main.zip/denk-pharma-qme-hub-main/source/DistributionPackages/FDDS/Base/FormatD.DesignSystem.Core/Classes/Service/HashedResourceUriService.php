<?php

namespace FormatD\DesignSystem\Core\Service;

use Neos\Flow\Annotations as Flow;
use Neos\Cache\Frontend\StringFrontend;
use Neos\Flow\Core\Bootstrap;
use Neos\Flow\Package\PackageManager;
use Neos\Flow\ResourceManagement\ResourceManager;

/**
 * Service for using hashed css ot js assets for cache busting purposes
 *
 * @Flow\Scope("singleton")
 */
class HashedResourceUriService {

    /**
     * @Flow\Inject
     * @var StringFrontend
     */
    protected $cacheFrontend;

    #[Flow\Inject] protected PackageManager $packageManager;

    #[Flow\Inject] protected ResourceManager $resourceManager;

    #[Flow\Inject] protected Bootstrap $bootstrap;

    #[Flow\InjectConfiguration(type: "Settings", package: "FormatD.DesignSystem")]
    protected array $settings;

	/**
	 * This method takes a path to a static css or js resource
     * and searches for a matching file with a hash. If found it replaces it.
	 *
	 * @param string $path
	 * @param string $packageKey
	 * @return string
	 * @throws \FormatD\DesignSystem\Exception
	 * @throws \Neos\Cache\Exception\InvalidDataException
	 */
	public function getHashedResourceUri($path, $packageKey) {

		if ($this->bootstrap->getContext()->isProduction()) {

			$cacheIdentifier = md5('hashed--' . $packageKey . '--' . $path);

			if (!$this->cacheFrontend->has($cacheIdentifier)) {

				if (!$packageKey || !$path) {
					throw new \FormatD\DesignSystem\Exception("Missing information for Eel-Helper getHashedResourceUri: path and packageKey");
				}

				$absolutePath = $this->packageManager->getPackage($packageKey)->getPackagePath() . 'Resources/Public/' . $path;
				$directoryPath = dirname($absolutePath);
				$basename = basename($absolutePath);
				$fileExtension = pathinfo($basename, PATHINFO_EXTENSION);
				$filename = pathinfo($basename, PATHINFO_FILENAME);
				$cacheBusterHashLength = $this->settings['cacheBuster']['hashLength'];

				$files = \Neos\Utility\Files::readDirectoryRecursively($directoryPath, $fileExtension);

				foreach ($files as $filePath) {
					if (preg_match('#^.*/' . $filename . '\-[0-9a-z]{' . $cacheBusterHashLength . '}\.' . $fileExtension . '$#', $filePath)) {
						$path = preg_replace('#' . $basename . '$#', basename($filePath), $path);
					}
				}

				$this->cacheFrontend->set($cacheIdentifier, $path);
			} else {
				$path = $this->cacheFrontend->get($cacheIdentifier);
			}
		}

		return $this->resourceManager->getPublicPackageResourceUri($packageKey, $path);
	}
}
