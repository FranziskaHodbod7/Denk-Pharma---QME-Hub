<?php
namespace FormatD\DesignSystem\Core\Eel\Helper;

/*
 * This file is part of the FormatD.DesignSystem package.
 */

use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Media\Domain\Model\Asset;
use Neos\Media\Domain\Model\ImageInterface;
use Neos\Media\Domain\Repository\AssetRepository;
use Neos\Media\Domain\Service\ThumbnailService;
use Neos\Media\Exception\ThumbnailServiceException;
use Neos\Utility\Files;

/**
 * AssetHelper
 */
class AssetHelper implements ProtectedContextAwareInterface {

	/**
	 * @Flow\Inject
	 * @var AssetRepository
	 */
	protected $assetRepository;

	/**
	 * @Flow\Inject
	 * @var ThumbnailService
	 */
	protected $thumbnailService;

	/**
	 * @param $fileSize
	 * @return string
	 */
	public function getReadableFileSize($fileSize)
	{
		return Files::bytesToSizeString($fileSize, 2);
	}

	/**
	 * @param Asset $asset
	 * @return ImageInterface|void|null
	 * @throws ThumbnailServiceException
	 */
	public function getThumbnail($asset){
		if(!$asset) {
			return;
		}

		$thumbnail = $this->thumbnailService->getThumbnail($asset, $this->thumbnailService->getThumbnailConfigurationForPreset('FormatD.DesignSystem.Core:DocumentThumbnail'));;

		return $thumbnail;
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName) {
		return true;
	}
}
