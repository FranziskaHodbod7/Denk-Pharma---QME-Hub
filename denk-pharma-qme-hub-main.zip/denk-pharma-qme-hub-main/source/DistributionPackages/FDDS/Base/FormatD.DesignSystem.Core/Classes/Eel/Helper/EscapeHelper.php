<?php

namespace FormatD\DesignSystem\Core\Eel\Helper;

use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper with escape functions
 */
class EscapeHelper implements ProtectedContextAwareInterface
{

	/**
	 * @param string $string
	 * @return string
	 */
	public function text($string)
	{
		return htmlspecialchars((string)$string, ENT_COMPAT | ENT_HTML401, 'UTF-8', false);
	}

	/**
	 * @param int $int
	 * @return int
	 */
	public function int($int)
	{
		return intval($int);
	}

	/**
	 * @param string $string
	 * @return string
	 */
	public function uuid($string)
	{
		return preg_match('#^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}$#', $string) ? $string : null;
	}

    /**
     * @param array $array
     * @return array
     */
    public function uuidArray($array)
    {
        return array_filter($array, function($item) {
            return $this->uuid($item) !== null;
        });
    }

    /**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName)
	{
		return true;
	}

}
