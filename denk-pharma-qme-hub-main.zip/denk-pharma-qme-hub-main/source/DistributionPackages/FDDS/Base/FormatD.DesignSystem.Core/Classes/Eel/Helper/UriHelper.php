<?php

namespace FormatD\DesignSystem\Core\Eel\Helper;

use FormatD\DesignSystem\Core\Service\HashedResourceUriService;
use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper for uri related stuff
 */
class UriHelper implements ProtectedContextAwareInterface
{

    #[Flow\Inject] protected HashedResourceUriService $hashedResourceUriService;

	/**
     * Get hashed css ot js asset uris for cache busting purposes
     *
	 * @param string $path
	 * @param string $packageKey
     * @return string
     */
    public function hashedResource($path, $packageKey) {
        return $this->hashedResourceUriService->getHashedResourceUri($path, $packageKey);
    }

    /**
     * All methods are considered safe
     *
     * @param string $methodName
     * @return boolean
     */
    public function allowsCallOfMethod($methodName) {
        return true;
    }
}
