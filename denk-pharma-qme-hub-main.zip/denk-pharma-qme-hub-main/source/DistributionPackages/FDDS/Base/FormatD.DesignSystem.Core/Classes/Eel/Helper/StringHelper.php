<?php
namespace FormatD\DesignSystem\Core\Eel\Helper;

use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;
use Cocur\Slugify\Slugify;

/**
 * Helper for strings
 */
class StringHelper implements ProtectedContextAwareInterface {

	/**
	 * @param string $string
	 * @return string
	 */
	public function nl2br($string) {
		return nl2br($string);
	}

    /**
     * @param string $string
     * @return string
     */
    public function br2nl($string) {
        return preg_replace('#<br */?>#', "\r\n", $string);
    }

	/**
	 * @param string $string
	 * @return mixed
	 */
	public function slugify(?string $string) {
        if(!$string) return;

		$slugify = new Slugify();
		return $slugify->slugify($string);
	}

    public function htmlspecialcharsDecode(?string $string, int $flags = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401): string
    {
		if ($string === null) return "";
        return htmlspecialchars_decode($string, $flags);
    }

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName) {
		return true;
	}
}
