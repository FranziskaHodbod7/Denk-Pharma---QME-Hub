<?php

namespace FormatD\DesignSystem\Core\Eel\Helper;

use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper with debug utilities
 */
class DebugHelper implements ProtectedContextAwareInterface {

	/**
	 * @param mixed $value
	 * @return void
	 */
	public function dumpDie($value) {
		\Neos\Flow\var_dump($value);
		die();
	}

	/**
	 * @param mixed $value
	 * @return void
	 */
	public function dump($value) {
		\Neos\Flow\var_dump($value);
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName) {
		return true;
	}
}
