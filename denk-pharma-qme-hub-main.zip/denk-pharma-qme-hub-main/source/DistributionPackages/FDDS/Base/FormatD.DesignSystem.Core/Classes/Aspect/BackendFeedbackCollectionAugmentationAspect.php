<?php
namespace FormatD\DesignSystem\Core\Aspect;

use Neos\Flow\Annotations as Flow;
use Neos\Flow\Aop\JoinPointInterface;
use Neos\Neos\Ui\Domain\Model\FeedbackInterface;
use Neos\Neos\Ui\Domain\Model\Feedback\Operations\ReloadDocument;
use Neos\Neos\Ui\Domain\Model\Feedback\Operations\ReloadContentOutOfBand;
use Neos\Neos\Ui\Domain\Model\Feedback\Operations\RenderContentOutOfBand;
use Neos\Neos\Ui\Domain\Model\Feedback\Operations\RemoveNode;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\ContentRepository\Core\SharedModel\ContentRepository\ContentRepositoryId;

/**
 * @Flow\Scope("singleton")
 * @Flow\Aspect
 */
class BackendFeedbackCollectionAugmentationAspect
{

    /**
     * @Flow\Inject
     * @var ContentRepositoryRegistry
     */
    protected $contentRepositoryRegistry;

    /**
     * @Flow\Around("method(Neos\Neos\Ui\Domain\Model\FeedbackCollection->add())")
     * @param JoinPointInterface $joinPoint The current join point
     * @return mixed
     */
    public function replacePartialReloadsInCertainConditions(JoinPointInterface $joinPoint)
    {
        /**
         * @var FeedbackInterface $feedback
         */
        $feedback = $joinPoint->getMethodArgument('feedback');


        $contentRepositoryId = ContentRepositoryId::fromString('default');
        $contentRepository = $this->contentRepositoryRegistry->get($contentRepositoryId);
        $nodeTypeManager = $contentRepository->getNodeTypeManager();

        if ($feedback instanceof ReloadContentOutOfBand || $feedback instanceof RenderContentOutOfBand) {
            $node = $feedback->getNode();
            $nodeType = $nodeTypeManager->getNodeType($node->nodeTypeName);

            // check whether the node or one of the parents up until the document has the option reloadPageIfChanged set
            // if so replace the given feedback with ReloadDocument feedback
            while ($node && !$nodeType->isOfType('Neos.Neos:Document')) {
                if ($nodeType->getConfiguration('options.reloadPageIfChanged') === true) {
                    $alternateFeedback = new ReloadDocument();
                    $joinPoint->setMethodArgument('feedback', $alternateFeedback);
                    break;
                }

                $subgraph = $this->contentRepositoryRegistry->subgraphForNode($node);
                $node = $subgraph->findParentNode($node->aggregateId);
            }
        }

        if ($feedback instanceof RemoveNode) {
            $node = $feedback->getNode();
            $nodeType = $nodeTypeManager->getNodeType($node->nodeTypeName);

            // check whether the node or one of the parents up until the document has the option reloadPageIfChanged set
            // if so add ReloadDocument feedback
            while ($node && !$nodeType->isOfType('Neos.Neos:Document')) {
                if ($nodeType->getConfiguration('options.reloadPageIfChanged') === true) {
                    $additionalFeedback = new ReloadDocument();
                    $joinPoint->setMethodArgument('feedback', $feedback);
                    $joinPoint->getProxy()->add($additionalFeedback);
                    break;
                }

                $subgraph = $this->contentRepositoryRegistry->subgraphForNode($node);
                $node = $subgraph->findParentNode($node->aggregateId);
            }
        }
        return $joinPoint->getAdviceChain()->proceed($joinPoint);
    }

}
