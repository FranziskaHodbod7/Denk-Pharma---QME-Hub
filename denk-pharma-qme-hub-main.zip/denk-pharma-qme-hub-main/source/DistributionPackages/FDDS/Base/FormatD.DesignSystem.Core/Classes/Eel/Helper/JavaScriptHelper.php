<?php

namespace FormatD\DesignSystem\Core\Eel\Helper;

use FormatD\DesignSystem\Service\IconService;
use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Exception;

/**
 * Helper for loading svg icons from filesystem and modifying them
 */
class JavaScriptHelper implements ProtectedContextAwareInterface
{
	/**
	 * @param $methodName
	 * @return true
	 */
    public function allowsCallOfMethod($methodName)
    {
        return true;
    }
}
