<?php
namespace FormatD\DesignSystem\Core\DataSource;

use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Configuration\ConfigurationManager;
use Neos\Neos\Service\DataSource\AbstractDataSource;

abstract class AbstractSettingsDataSource extends AbstractDataSource {

	/**
	 * @Flow\Inject
	 * @var ConfigurationManager
	 */
	protected $configurationManager;

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-settings';

	/**
	 * Get data
	 *
	 * The return value must be JSON serializable data structure.
	 *
	 * @param Node $node The node that is currently edited (optional)
	 * @param array $arguments Additional arguments (key / value)
	 * @return mixed JSON serializable data
	 * @api
	 */
	public function getData(Node $node = null, array $arguments = []) {
		$settings = $this->configurationManager->getConfiguration(ConfigurationManager::CONFIGURATION_TYPE_SETTINGS, $this->getConfigurationPath());
		$category = $this->getCategory();
		$data = [];
		foreach ($settings as $key => $value) {
		    if (!$value) continue;
			if ($category && $value['presetCategory'] && $value['presetCategory'] !== $category) continue;
			$data[$key] = ['label' => $value['presetLabel'], 'value' => $key];
		}
		return $data;
	}

	/**
	 * @return string
	 */
	abstract protected function getConfigurationPath();

	/**
	 * @return string
	 */
	abstract protected function getCategory();

}
