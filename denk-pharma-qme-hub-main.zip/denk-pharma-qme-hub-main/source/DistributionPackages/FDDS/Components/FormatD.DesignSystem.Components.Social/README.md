# FormatD.DesignSystem.Components.Social

A social share-bar component for Neos CMS. The package renders one Fusion component with a row of share buttons: Facebook, Twitter, Pinterest, LinkedIn, Xing, WhatsApp, mail, and a copy-link action. At runtime, a TypeScript component manager attaches the [Shariff](https://github.com/heiseonline/shariff) library to each share button and wires up the copy-link click handler.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base configuration of the design system |
| `FormatD.ComponentLoader` | Registers the rendered ShareBar markup so its TypeScript manager can attach to it |
| `Neos.Fusion` | Rendering with AFX |

The package also bundles the `shariff` npm library. The TypeScript component manager (`ShareBar.ts`) imports it directly; the package does not load it from a CDN.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Fusion interface: `Molecule.ShareBar`

`Molecule.ShareBar` extends `FormatD.ComponentLoader:Component`. This base prototype adds a `<script data-register-component>` tag after the rendered markup. The tag lets the component loader find the share bar in the DOM and initialize `ShareBarComponentManager` on it.

```fusion
FormatD.DesignSystem.Components.Social:Molecule.ShareBar {
    url      = ''      # URL to share (required)
    language = ${Array.first(node.context.dimensions.language)}   # language code passed to Shariff
    title    = ''       # used as the mail subject
    imageUri = null     # image URL passed to Shariff as data-media-url

    showShareText = true              # show or hide the text label
    shareText     = 'Artikel teilen via'

    enableFacebook  = false
    enableTwitter   = false
    enablePinterest = false
    enableLinkedIn  = false
    enableXing      = false
    enableWhatsapp  = false
    enableMail      = false
    enableCopyLink  = false
}
```

Each `enable*` property is a boolean flag. It shows or hides its matching list item with an `@if` condition in the AFX renderer. No NodeType uses this prototype directly; the calling Fusion code sets every property.

### How the package renders each button

The renderer builds one `<li>` per enabled network. Each `<li>` (except the copy-link item) carries `data-fdds-handle="shariff"` plus `data-url`, `data-lang`, `data-media-url`, `data-services`, and `data-button-style` attributes. `ShareBarComponentManager.initialize()` selects all elements with `data-fdds-handle="shariff"` and creates one `Shariff` instance per element with these data attributes as configuration.

### The copy-link button

When `enableCopyLink` is `true`, the renderer adds an `<li class="secondary">` with a hidden text input that holds `props.url` and a tooltip span. `ShareBarComponentManager` attaches a click handler to this item. The handler selects the input, calls `document.execCommand("copy")`, and shows the tooltip for two seconds.

> [!warning]
> `document.execCommand("copy")` is deprecated in modern browsers. The copy-link button may need an update to the Clipboard API in the future.

---

## Worked example

```fusion
FormatD.DesignSystem.Components.Social:Molecule.ShareBar {
    url = ${q(node).property('uri')}
    title = ${node.properties.title}
    showShareText = true
    enableFacebook = true
    enableWhatsapp = true
    enableMail = true
    enableCopyLink = true
}
```
