// @ts-ignore
import Shariff from 'shariff';
import Logger from "@distributionPackages/FDDS/Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

declare global {
	interface HTMLElement {
		shariff: Shariff
	}
}

export interface Configuration {
	url?: string
}

export default class ShareBarComponentManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {

		const logger = new Logger('ShareBar');
		logger.log('Init'); // @todo: implement logger as member variable and log more

		for(const shariffElement of this.getElements(domSection)) {
			if (!shariffElement.hasOwnProperty('shariff')) {
				const initConfig: Configuration = {};
				if (!shariffElement.dataset.url) {
					initConfig.url = window.location.href;
				}
				logger.log('Attaching to ', shariffElement);
				this.attachShariffToElement(shariffElement, initConfig)
			}
		}

		for(const copyLinkElement of this.getCopyLinkElements(domSection)) {
			const hiddenInput = this.getHiddenInputFromItem(copyLinkElement);
			copyLinkElement.addEventListener('click', () => {
				this.itemClickEventHandler(copyLinkElement, hiddenInput)
			});
		}
	}

	getElements(domSection: HTMLElement): NodeListOf<HTMLElement> {
		return domSection.querySelectorAll('[data-fdds-handle="shariff"]')
	}

	attachShariffToElement(shariffElement: HTMLElement, initConfig: {[key: string]: any}) {
		shariffElement.shariff = new Shariff(shariffElement, initConfig);
	}

	getCopyLinkElements(domSection: HTMLElement): NodeListOf<HTMLElement> {
		return domSection.querySelectorAll('.copy-link')
	}

	getHiddenInputFromItem(item: HTMLElement): HTMLInputElement {
		return item.querySelector('.input-url')
	}

	itemClickEventHandler(item: HTMLElement, hiddenInput: HTMLInputElement) {
		hiddenInput.select();
		document.execCommand("copy");
		this.toggleTooltipWithTimeout(item)
	}

	toggleTooltipWithTimeout(item: HTMLElement) {
		const tooltip = item.querySelector('.tooltip')
		if(!tooltip) {
			return
		}
		tooltip.classList.add('js--show');
		setTimeout(() => {
			tooltip.classList.remove('js--show');
		}, 2000);
	}
}
