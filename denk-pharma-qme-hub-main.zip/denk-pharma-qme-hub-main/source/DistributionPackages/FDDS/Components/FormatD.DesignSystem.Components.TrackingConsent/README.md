# FormatD.DesignSystem.Components.TrackingConsent

Cookie consent and Google Tag Manager integration for Neos CMS. The package injects the CookieHub loader configuration and GTM snippets into the page. It provides a NodeType editors can place to open the CookieHub settings dialog. A frontend script loads CookieHub and toggles consent-gated video playback in the `FormatD.DesignSystem.Components.Video` package.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `Mixin.OptionsGroup` |
| `Neos.Neos` | `Content`, `ContentComponent` base prototypes, `Editable` |
| `Neos.Fusion` | `Component` base prototype, AFX rendering, the `Configuration` and `Json` Eel helpers |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Settings

```yaml
# Settings.yaml
FormatD:
  DesignSystem:
    Components:
      TrackingConsent:
        cookieHub:
          devModeId: 'XXXXXXXX'
          domains:
            -
              domain: www.domain.com
              id: 'XXXXXXXX'
            -
              domain: www.domain.de
              id: 'XXXXXXXX'
```

`domains` maps a hostname to its CookieHub domain ID. `devModeId` is a fallback ID for local or staging domains that have no entry in `domains`.

> [!warning] Configuration path does not match the consumer
> `Component.CookueHubBodyScripts` (see below) reads `Configuration.setting('FormatD.DesignSystem.cookieHub.id')` and `'FormatD.DesignSystem.cookieHub.domains'`. This package's own `Settings.yaml` sets `FormatD.DesignSystem.Components.TrackingConsent.cookieHub.devModeId` and `.domains`. The setting path and the key name (`devModeId` versus `id`) do not line up, so the shipped default does not reach the Fusion component as written. A project that wants to configure CookieHub must set the value at the exact path `FormatD.DesignSystem.cookieHub.id` and `FormatD.DesignSystem.cookieHub.domains` for the component to pick it up.
>
> The frontend script `CookieConsent.ts` (see below) reads the global variables `cookieHubDevModeId` and `cookieHubDomains`. `Component.CookueHubBodyScripts` only defines `cookieHubId` and `cookieHubDomains` as globals. No file in the codebase defines a `cookieHubDevModeId` global, so the dev-mode fallback in `CookieConsent.ts` cannot get a value from this component as written.

---

## Fusion components

| Prototype | Purpose |
|---|---|
| `Component.CookueHubBodyScripts` | Renders two inline `<script>` tags that set the `cookieHubId` and `cookieHubDomains` JavaScript globals CookieHub needs |
| `Component.GoogleTagManager` | Renders the standard GTM `<script>` snippet for a given container ID |
| `Component.GoogleTagManagerNoScript` | Renders the matching GTM `<noscript>` iframe fallback |

```fusion
FormatD.DesignSystem.Components.TrackingConsent:Component.GoogleTagManager {
    gtmId      = 'GTM-XXXXXXX'                     # required
    comment    = '<!-- Google Tag Manager -->'      # optional, HTML comment before the script
    commentEnd = '<!-- End Google Tag Manager -->'  # optional, HTML comment after the script
}

FormatD.DesignSystem.Components.TrackingConsent:Component.GoogleTagManagerNoScript {
    gtmId = 'GTM-XXXXXXX'   # required
}
```

> [!warning] Prototype name has a typo
> The prototype name is `Component.CookueHubBodyScripts`, not `CookieHubBodyScripts`, even though the file is named `CookieHubBodyScripts.fusion`. The site's Gunther template package includes it under this exact, misspelled name. Use the name as it is, or the include fails.

---

## NodeType: `Content.CookieSettingsLink`

A link or button that lets the visitor reopen the CookieHub settings dialog. The package does not restrict this NodeType to any parent (`constraints.nodeTypes.'*'` is `false`).

| Property | Type | Values |
|---|---|---|
| `mode` | string | `link` (default) or `button` |
| `alignment` | string | `left` (default), `center`, `right` — only used, and only shown in the inspector, when `mode` is `button` |
| `label` | string | Inline-editable link or button text |

```fusion
prototype(FormatD.DesignSystem.Components.TrackingConsent:Content.CookieSettingsLink) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.TrackingConsent:Molecule.CookieSettingsLink {
        alignment = ${node.properties.alignment}
        mode      = ${node.properties.mode}
        label     = Neos.Neos:Editable { property = 'label' }
    }
}
```

### Fusion interface: `Molecule.CookieSettingsLink`

```fusion
prototype(FormatD.DesignSystem.Components.TrackingConsent:Molecule.CookieSettingsLink) {
    label     = ''         # link or button text
    mode      = 'link'     # 'link' | 'button'
    alignment = 'left'     # 'left' | 'center' | 'right'
}
```

This package only declares `@propTypes` for `Molecule.CookieSettingsLink`; it has no `renderer`. As with the Text package's Molecule prototypes, the site's theme package supplies the actual markup and the actual call that opens the CookieHub dialog.

---

## JavaScript

| File | Role |
|---|---|
| `CookieConsent.ts` | Default-exports a function that loads the CookieHub script for the current hostname (or the dev-mode ID inside an iframe check) and wires CookieHub's `onInitialise`/`onStatusChange`/`onAllow`/`onRevoke` callbacks to `VideoCookieHintHandlingService` in the Video package, so consent-gated videos start or stop |
| `DataLayerPopulator.ts` | A singleton that listens for the `fdds.populateDataLayer` DOM event and pushes `{event, type, url}` onto `window.dataLayer` for GTM |

> [!warning] `CookieConsent.ts` is not called anywhere
> No file elsewhere in the codebase imports the default export of `CookieConsent.ts`. The function exists and is exported, but nothing invokes it on the page.
