

export interface PopulateDataLayerEventDetail {
	event: string
	type: string
	url: string
}

export class PopulateDataLayerEvent extends CustomEvent<PopulateDataLayerEventDetail> {
    constructor(event: string, type: string, url: string) {
        super(DataLayerPopulator.EVENT_POPULATE, { cancelable: true, detail: {event, type, url} } );
    }
}


class DataLayerPopulator {
	static EVENT_POPULATE = 'fdds.populateDataLayer'

	constructor () {
		window.dataLayer = window.dataLayer || [];
		window.addEventListener(DataLayerPopulator.EVENT_POPULATE, this.handleTrackingEvent);
	};

	handleTrackingEvent = (event: PopulateDataLayerEvent) => {
		window.dataLayer.push({
			event: event.detail.event,
			type: event.detail.type,
			url: event.detail.url
		});
	};
}

const DataLayerPopulatorInstance = new DataLayerPopulator()

export {DataLayerPopulator as DataLayerPopulatorClass, DataLayerPopulatorInstance as DataLayerPopulator}
