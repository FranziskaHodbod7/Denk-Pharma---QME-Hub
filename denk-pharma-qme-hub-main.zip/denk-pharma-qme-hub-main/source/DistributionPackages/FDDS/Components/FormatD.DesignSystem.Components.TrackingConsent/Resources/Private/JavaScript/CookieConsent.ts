import {VideoCookieHintHandlingService} from "@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Video/Resources/Private/JavaScript/VideoCookieHintHandlingService";

export default function cookieConsent() {
	const currentLanguage = document.documentElement.lang;
	const domainEntry = cookieHubDomains?.find(e => e?.domain === window.location.hostname);

	if (window.self !== window.top || cookieHubDevModeId === '') {
		// no id or domain configured
		// no cookie consent for iframes
		return;
	}

	let scriptSrc;

	if (domainEntry) {
		scriptSrc = 'https://cdn.cookiehub.eu/c2/' + domainEntry.id + '.js';
	} else {
		scriptSrc = 'https://dash.cookiehub.com/dev/' + cookieHubDevModeId + '.js';
	}

	loadScript(scriptSrc, currentLanguage);

}

/**
* @param scriptSrc
* @param currentLanguage
*/
function loadScript(scriptSrc, currentLanguage) {
	const cpm = {
		language: currentLanguage ? currentLanguage : 'de',
		onInitialise: function(status) {
			VideoCookieHintHandlingService.getVideoElement(this.hasConsented("analytics"));
		},
		onStatusChange: function(status, previousStatus)
		{
			VideoCookieHintHandlingService.getVideoElement(this.hasConsented("analytics"));
		},
		onAllow: function(category) {
			if (category == 'analytics') {
				VideoCookieHintHandlingService.getVideoElement(true);
			}
		},
		onRevoke: function(category) {
			if (category == 'analytics') {
				VideoCookieHintHandlingService.getVideoElement(false);
			}
		},
	};

	(function (h, u, b) {
		const d = h.getElementsByTagName("script")[0], e = h.createElement("script");

		e.async = true;
		e.src = scriptSrc;
		e.onload = function () {
			u.cookiehub.load(b);
		}
		d.parentNode.insertBefore(e, d);

	})(document, window, cpm);

}
