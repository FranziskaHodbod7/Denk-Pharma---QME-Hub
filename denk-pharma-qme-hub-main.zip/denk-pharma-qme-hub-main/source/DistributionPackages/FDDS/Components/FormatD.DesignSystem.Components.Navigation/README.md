# FormatD.DesignSystem.Components.Navigation

A navigation component set for Neos CMS: header and footer menus, an anchor navigation for on-page sections, and a scroll-to-top button. The header and footer aggregators walk up the document tree, so a subpage without its own header or footer content inherits the items from an ancestor page.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base design system configuration, `Mixin.OptionsGroup` / `Mixin.InspectorTitle` mixins, `FDDS.String` / `FDDS.Escape` Eel helpers |
| `Neos.Neos` | `MenuItems`, `NodeLink`, `ContentComponent` |
| `Neos.Fusion` | `Case`, `Map`, `Loop`, `Component`, `DataStructure`, AFX rendering |
| `FormatD.DesignSystem.Components.Icons` | `Atom.Icon`, used by `Component.MenuLink` |

The package's `composer.json` only declares `formatd/designsystem-core`. The other packages are used by its Fusion but are not declared as a `composer.json` requirement.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeType mixins

| Mixin | Applied to (in this package) | Purpose |
|---|---|---|
| `Mixin.MainNavigationRoot` | `Neos.Neos:Site` | Abstract marker. `Component.MainNavigationItemAggregator` climbs to the nearest ancestor document with this mixin when the current document has no own header items. |
| `Mixin.FooterNavigationRoot` | `Neos.Neos:Site` | The same pattern, for footer items. |

Both mixins are `abstract: true` and add no properties of their own. Add one to a NodeType to make it a navigation root:

```yaml
'My.Package:Document.Page':
  superTypes:
    'FormatD.DesignSystem.Components.Navigation:Mixin.MainNavigationRoot': true
```

---

## NodeType: `Content.ScrollToTop`

A button element that scrolls the page to the top.

| Property | Type | Default | Notes |
|---|---|---|---|
| `title` | string | `'Scroll'` | Button label |
| `style` | string (select box) | `'default'` | `default`, `icon-only`, or `text-only` |

```fusion
prototype(FormatD.DesignSystem.Components.Navigation:Content.ScrollToTop) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Navigation:Molecule.ScrollToTop {
        content = ${node.properties.title}
        style   = ${node.properties.style}
    }
}
```

---

## Fusion components

### `Component.MainNavigationItemAggregator` and `Component.FooterItemAggregator`

Both are `Neos.Fusion:Case` prototypes. They return the array of items to render as menu entries.

```fusion
prototype(FormatD.DesignSystem.Components.Navigation:Component.MainNavigationItemAggregator) {
    // 1. the current document has a 'header' ContentCollection with children → use them
    // 2. else, walk up to the nearest ancestor with Mixin.MainNavigationRoot and recurse
    // 3. else, return an empty array
}
```

`Component.FooterItemAggregator` follows the same three steps for a `footer` collection and `Mixin.FooterNavigationRoot`, except that it searches all ancestors (`parents()`), not only the direct parent.

Both aggregators return an array of plain nodes, not `Neos.Neos:MenuItems` entries. Feed the result into `Neos.Neos:ContentCollectionRenderer`, or into a renderer that reads plain node properties, not into `Component.MenuLink`.

### `Component.MenuItems`

```fusion
FormatD.DesignSystem.Components.Navigation:Component.MenuItems {
    items = <Neos.Neos:MenuItems array>   # required; default value uses Neos.Neos:MenuItems with maximumLevels = 1
}
```

Renders a `<ul>` with a `level-<n>` class and, for every item, an `<li>` with an `item-<cycle>` class. It calls itself for `item.subItems`, so it renders nested menu levels.

### `Component.MenuLink`

```fusion
FormatD.DesignSystem.Components.Navigation:Component.MenuLink {
    item            = null       # required; one Neos.Neos:MenuItems entry
    defaultIconName = ''         # icon name to use when the node has no own 'icon' property
    iconSize        = 'medium'   # passed to FormatD.DesignSystem.Components.Icons:Atom.Icon
    showIcon        = true       # set to false to never render an icon
}
```

It renders a `Neos.Neos:NodeLink`. It adds the item's active/current state as a CSS class. When `showIcon` is true and the node has an `icon` property, or `defaultIconName` is set, it renders `FormatD.DesignSystem.Components.Icons:Atom.Icon` before the label. The link text passes through `FDDS.Escape.text`.

### `Component.AnchorNavigationItems`

```fusion
FormatD.DesignSystem.Components.Navigation:Component.AnchorNavigationItems
```

Reads the document node's `contentSections` references (from the Core package's `Mixin.ContentSections`) and returns a list of `{ title, uri }` entries, where `uri` is `'#' + FDDS.String.slugify(title)`. Use this for a same-page anchor menu that jumps to content sections.

### `Molecule.ScrollToTop`

```fusion
prototype(FormatD.DesignSystem.Components.Navigation:Molecule.ScrollToTop) {
    @propTypes {
        content = ${PropTypes.string}
        style   = ${PropTypes.oneOf(['default', 'icon-only', 'text-only'])}
    }
}
```

This package only declares the prop-type contract for `Molecule.ScrollToTop`. It does not define a base prototype or a renderer here. A site template package supplies the actual AFX markup (for example an icon plus a label, styled by `style`). Check the active site template package for the concrete rendering.

The bundled client script (`Presentation/Molecule/ScrollToTop.ts`) controls the button. It adds a `js--visible` class once the page scrolls past a threshold: 400px on mobile user agents, 800px on other user agents. A click on the button then scrolls the page to the top, with a smooth animation.

---

## Worked examples

The Footer of the bundled site template renders `Component.FooterItemAggregator` directly as `Neos.Neos:ContentCollectionRenderer` items, so each footer child node renders with its own NodeType template:

```fusion
prototype(My.Package:Document.AbstractPage.Body.Footer) < prototype(Neos.Fusion:Component) {
    renderer = Neos.Neos:ContentCollectionRenderer {
        items = FormatD.DesignSystem.Components.Navigation:Component.FooterItemAggregator
    }
}
```

The main header, in contrast, uses `Component.MenuItems` with its own default value (`Neos.Neos:MenuItems`, based on the current document), not `Component.MainNavigationItemAggregator`:

```fusion
<FormatD.DesignSystem.Components.Navigation:Component.MenuItems />
```

> `Component.MainNavigationItemAggregator` and `Mixin.MainNavigationRoot` exist in this package, but the bundled site template does not wire them into the rendered header. Only the footer path (`Component.FooterItemAggregator` / `Mixin.FooterNavigationRoot`) is in active use there.
