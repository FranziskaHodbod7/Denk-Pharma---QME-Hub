import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
export default class ScrollToTopComponentManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		const scrollToTop = this.getScrollToTopElement(domSection)
		if (!scrollToTop) {
			return; // do not initialize if no scroll-to-top element is found
		}

		let toggleY = this.getToggleY(domSection)

		window.addEventListener('scroll', event => {
			this.scrollEventHandler(scrollToTop, toggleY)
		}, { passive: true });

		scrollToTop.addEventListener('click', event => {
			this.scrollToTopElementClickHandler(event)
		});

		this.scrollEventHandler(scrollToTop, toggleY);
	}

	getScrollToTopElement(domSection: HTMLElement): HTMLElement {
		return domSection.querySelector('.scroll-to-top')
	}

	isMobile(domSection: HTMLElement) {
		return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
	}

	scrollToTopElementClickHandler(event: Event) {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

	scrollEventHandler(scrollToTop: HTMLElement, toggleY: number) {
		scrollToTop.classList.toggle('js--visible', window.scrollY > toggleY)
	}

	getToggleY(domSection: HTMLElement) {
		return this.isMobile(domSection) ? 400 : 800
	}
}
