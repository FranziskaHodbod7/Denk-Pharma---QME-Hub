# FormatD.DesignSystem.Components.Video

A video content element for Neos CMS. It plays a YouTube video, a Vimeo video, or an uploaded video asset through the Plyr player. It supports presets for controls, autoplay, and loop, and it gates playback of embedded videos behind cookie consent.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `Mixin.InspectorTitle`, `Mixin.OptionsGroup` |
| `Neos.Neos` | `Content`, `ContentComponent` base prototypes, `ImageUri` |
| `Neos.Fusion` | `ResourceUri`, AFX rendering |
| `Sitegeist.Kaleidoscope` | `AssetImageSource`, used to render the cookie thumbnail image |

> [!warning] Undeclared dependency
> `NodeTypes/Content/Video.fusion` uses the prototype `Sitegeist.Kaleidoscope:AssetImageSource` for the `cookieThumbnail` property. `composer.json` does not list `sitegeist/kaleidoscope` (or any package other than `formatd/designsystem-core`) in `require`. The package only works if the site installs `Sitegeist.Kaleidoscope` separately.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Settings: video presets

The package ships four presets under `FormatD.DesignSystem.Components.Video.presets`. The Fusion layer reads the preset the editor picks and merges it into the player configuration that is passed to Plyr.

```yaml
# Settings.yaml
FormatD:
  DesignSystem:
    Components:
      Video:
        presets:
          default:
            label: 'Default'
            loop:
              active: false
            controls: ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions', 'settings', 'fullscreen']
            vimeo:
              dnt: true
              controls: false
            youtube:
              noCookie: true
              controls: 0
              rel: 0
          hideControls:
            label: 'Hide Controls'
            hideControls: 'always'
            clickToPlay: true
            # ... loop, vimeo, youtube as above
          autoplay:
            label: 'Autoplay'
            autoplay: true
            muted: true
            hideControls: 'always'
            loop:
              active: true
            # ... vimeo, youtube as above
          hero:
            label: 'Hero'
            autoplay: true
            muted: true
            hideControls: 'always'
            loop:
              active: true
```

Add a new preset as a new key under `presets`. Give it a `label`; the label appears in the `preset` select box on `Content.Video`.

---

## NodeTypes

### `Mixin.Video`

An abstract mixin with the source properties, shared with `Content.Video`.

| Property | Type | Purpose |
|---|---|---|
| `videoSourceType` | string | `videoUri` (embed a YouTube/Vimeo URL) or `videoAsset` (play an uploaded file). Required. |
| `videoUri` | string | The YouTube or Vimeo URL. Shown only when `videoSourceType` is `videoUri`. |
| `videoAsset` | asset | An MP4 or WebM file. Constrained to `video/mp4` in the editor. Shown only when `videoSourceType` is `videoAsset`. |

### `Content.Video`

Extends `Mixin.Video`, `Mixin.InspectorTitle`, and `Mixin.OptionsGroup`.

| Property | Type | Purpose |
|---|---|---|
| `title` | string | Optional title, shown above the player |
| `aspectRatio` | string | `16:9` or `auto` |
| `cookieThumbnail` | image | Thumbnail shown before consent is given, for `videoUri` sources. Forced 16:9 crop. |
| `thumbnail` | image | Poster image for `videoAsset` sources. Forced 16:9 crop. |
| `preset` | string | One of the keys under `FormatD.DesignSystem.Components.Video.presets` |

```fusion
prototype(FormatD.DesignSystem.Components.Video:Content.Video) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Video:Molecule.Video {
        title         = ${node.properties.title}
        preset        = ${node.properties.preset}
        videoUri      = ${node.properties.videoUri}
        videoAssetUri = Neos.Fusion:ResourceUri { resource = ${node.properties.videoAsset.resource} }
        aspectRatio   = ${node.properties.aspectRatio}
        thumbnail       = Neos.Neos:ImageUri { asset = ${node.properties.thumbnail} }
        cookieThumbnail = Sitegeist.Kaleidoscope:AssetImageSource { asset = ${node.properties.cookieThumbnail} }
    }
}
```

---

## Fusion interface: `Molecule.Video`

```fusion
prototype(FormatD.DesignSystem.Components.Video:Molecule.Video) {
    title           = ''     # optional headline above the player
    preset          = ''     # a key from the presets setting
    videoUri        = ''     # YouTube or Vimeo URL
    videoAssetUri   = ''     # public URL of an uploaded video asset
    aspectRatio     = ''     # '16:9' | 'auto'
    thumbnail       = null   # poster image for videoAssetUri
    cookieThumbnail = null   # thumbnail shown before cookie consent, for videoUri
}
```

This package only declares `@propTypes` for `Molecule.Video`; it has no `renderer`. As with the Text package's Molecule prototypes, the site's theme package extends `Molecule.Video` and adds the actual markup. That markup does the following:

1. Detects a Vimeo or YouTube ID from `videoUri`, with a regular expression.
2. Builds the `data-plyr-*` attributes.
3. Renders the cookie hint overlay, with its own text and button.

---

## Frontend behavior

`Resources/Private/Fusion/Presentation/Molecule/Video.ts` defines `VideoComponentManager`, a component controller that:

1. Reads the player configuration from the `data-video` JSON attribute the theme's renderer writes on each `.js--video-plyr` element.
2. Creates a Plyr instance immediately for video assets, or waits for a `cookieConsentOnStatusChange` DOM event before creating it for embedded (`videoUri`) sources.
3. Starts muted, looping autoplay when the preset sets `autoplay`.
4. Toggles a clicked/paused CSS class on the wrapper element to support custom play/pause styling.

The `cookieConsentOnStatusChange` event is dispatched by `VideoCookieHintHandlingService` (also in this package), which the `FormatD.DesignSystem.Components.TrackingConsent` package's `CookieConsent.ts` calls whenever the visitor allows or revokes the `analytics` cookie category. Embedded videos in this package do not play until that consent event fires.

Translation keys in `Resources/Private/Translations/{de,en}/Video.xlf` (`cookieHint.text`, `cookieHint.button`) hold the cookie hint's default text and button label; the theme's `Molecule.Video` renderer looks these up with `Translation.translate`.
