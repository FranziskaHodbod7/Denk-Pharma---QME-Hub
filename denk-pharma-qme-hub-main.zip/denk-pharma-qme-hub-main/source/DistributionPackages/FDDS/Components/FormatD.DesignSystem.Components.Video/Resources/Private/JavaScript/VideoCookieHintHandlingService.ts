class VideoCookieHintHandlingService {
	public getVideoElement(isAllowed: boolean) {
		const contentWrappers = document.querySelectorAll('.video-content-wrapper');
		if (contentWrappers.length === 0) {
			return;
		}

		const event = new CustomEvent("cookieConsentOnStatusChange", {
			detail: {
				hasConsented: isAllowed
			}
		});
		document.dispatchEvent(event);

		for (const contentWrapper of contentWrappers) {
			contentWrapper.dataset.cookie = isAllowed;
		}
	}
}

const videoCookieHintHandlingServiceInstance = new VideoCookieHintHandlingService()
export {videoCookieHintHandlingServiceInstance as VideoCookieHintHandlingService}
