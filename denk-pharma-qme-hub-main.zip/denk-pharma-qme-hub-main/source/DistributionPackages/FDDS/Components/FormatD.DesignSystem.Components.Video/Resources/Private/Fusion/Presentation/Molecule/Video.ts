// @ts-ignore
import Plyr from 'plyr';
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class VideoComponentManager extends AbstractComponentManager {

	initialize(domSection: HTMLElement) {
		for (const plyrElement of <NodeListOf<HTMLElement>>domSection.querySelectorAll('.js--video-plyr')) {
			const configuration = this.getConfigurationFromElement(plyrElement)

			if (configuration.hideControls && configuration.hideControls === 'always') {
				plyrElement.classList.add('js-controls-hidden');
			}

			if (plyrElement.classList.contains('video-uri')) {
				document.addEventListener('cookieConsentOnStatusChange', (payload) => {
					if (payload.detail.hasConsented) {
						this.videoHandler(plyrElement, configuration);
					}
				});
			} else {
				this.videoHandler(plyrElement, configuration);
			}

		}
	}

    getConfigurationFromElement(plyrElement: HTMLElement) {
        return Object.assign({}, JSON.parse(plyrElement.dataset.video));
    }

	videoHandler(plyrElement, configuration) {
        const player: Plyr = new Plyr(plyrElement.querySelector('.js--video'), configuration);
        const parentWrapper: HTMLElement =  plyrElement.closest('.js--plyr-wrapper');

		if (configuration.autoplay === true) {
            player.on('ready', event => {
                player.play();
                player.muted = true;
                player.loop = true;
            });
        }

        if (parentWrapper) {
            let plyrStatus: HTMLElement;
            let plyrControls: HTMLElement;
            let plyrPaused: HTMLElement;
            const clickedClass = 'js--plyr-wrapper-clicked';
            const pausedClass = 'plyr__control--pressed';

            player.on('ready', event => {
                plyrStatus = parentWrapper.querySelector('.plyr');
                plyrControls = parentWrapper.querySelector('.plyr__controls');
                plyrPaused = parentWrapper.querySelector('button.plyr__controls__item[aria-label=Play]');

                parentWrapper.addEventListener('click', event => {
                    switch (plyrStatus.contains(event.target)) {
                        case (plyrControls.contains(event.target) && !plyrPaused.classList.contains(pausedClass)) :
                            parentWrapper.classList.toggle(clickedClass, false);
                            break;
                        case (plyrControls.contains(event.target) && plyrPaused.classList.contains(pausedClass)) :
                            parentWrapper.classList.toggle(clickedClass, true);
                            break;
                        case (!plyrControls.contains(event.target)) :
                            parentWrapper.classList.toggle(clickedClass);
                            break;
                        default :
                            console.error('Video click error!');
                    }
                });
            });

            player.on('ended', event => {
                parentWrapper.classList.toggle(clickedClass, false);
            });
        }
	}
}
