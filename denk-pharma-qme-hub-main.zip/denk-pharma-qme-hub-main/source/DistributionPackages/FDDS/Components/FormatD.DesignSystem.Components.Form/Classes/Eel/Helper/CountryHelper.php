<?php

namespace FormatD\DesignSystem\Components\Form\Eel\Helper;


use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\I18n\Cldr\CldrRepository;
use Neos\Flow\I18n\Service;

/**
 * Helper to get country labels from iso codes
 */
class CountryHelper implements ProtectedContextAwareInterface
{

	/**
	 * @Flow\Inject
	 * @var CldrRepository
	 */
	protected $cldrRepository;

	/**
	 * @Flow\Inject
	 * @var Service
	 */
	protected $localizationService;

	/**
	 * @param string $isoCode
	 * @return string
	 */
	public function getLabel($isoCode)
	{
		$model = $this->cldrRepository->getModelForLocale($this->localizationService->getConfiguration()->getCurrentLocale());
		return $model->getElement('localeDisplayNames/territories/territory[@type="'.$isoCode.'"]');
	}

	public function getCountries()
	{
		$data = [];
		$model = $this->cldrRepository->getModelForLocale($this->localizationService->getConfiguration()->getCurrentLocale());
		$territories = $model->findNodesWithinPath('localeDisplayNames/territories', 'territory');

		foreach ($territories as $key => $value) {
			$type = $model->getAttributeValue($key, 'type');
			if (!is_numeric($type) && $type !== 'ZZ' && !isset($data[$type])) {
				$countryName = $model->getElement('localeDisplayNames/territories/territory[@type="'.$type.'"]');
				$data[$type] = ['label' => $countryName, 'value' => $type, 'id' => $type];
			}
		}
		asort($data);

		return array_merge([['label' => '', 'value' => '', 'id' => '']], array_values($data));
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName)
	{
		return true;
	}
}
