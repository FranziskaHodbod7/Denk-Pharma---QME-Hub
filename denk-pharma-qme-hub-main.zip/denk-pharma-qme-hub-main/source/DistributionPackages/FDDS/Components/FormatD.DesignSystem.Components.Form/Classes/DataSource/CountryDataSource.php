<?php

namespace FormatD\DesignSystem\Components\Form\DataSource;

use FormatD\DesignSystem\Components\Form\Service\CountryService;
use Neos\Flow\Annotations as Flow;
use Neos\Neos\Service\DataSource\AbstractDataSource;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;

class CountryDataSource extends AbstractDataSource
{
    /**
     * @Flow\Inject
     * @var CountryService
     */
    protected $countryService;

    /**
     * @var string
     */
    protected static $identifier = 'formatd-designsystem-country';

    /**
     * @var string
     */
    protected static $icon = 'icon-flag';

    /**
     * Get country's ISO codes and names from cldr
     *
     * The return value must be JSON serializable data structure.
     *
     * @param Node $node The node that is currently edited (optional)
     * @param array $arguments Additional arguments (key / value)
     * @return mixed JSON serializable data
     * @api
     */
    public function getData(Node $node = null, array $arguments = [])
    {
        return array_map(function ($country) {
            return [
                'label' => $country['label'],
                'value' => $country['code'],
                'icon' => static::$icon
            ];
        },
            $this->countryService
                ->locale($arguments['locale'] ?? null)
                ->all()
        );
    }

}
