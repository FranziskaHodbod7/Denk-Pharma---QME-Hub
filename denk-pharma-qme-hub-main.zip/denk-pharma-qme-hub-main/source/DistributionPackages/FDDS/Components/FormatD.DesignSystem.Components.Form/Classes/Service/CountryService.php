<?php

namespace FormatD\DesignSystem\Components\Form\Service;

use Neos\Flow\Annotations as Flow;
use Neos\Flow\I18n\Cldr\CldrRepository;
use Neos\Flow\I18n\Locale;
use Neos\Flow\I18n\Service;

/**
 * Service for handling Icons
 *
 * @Flow\Scope("singleton")
 */
class CountryService
{
    /**
     * @Flow\Inject
     * @var CldrRepository
     */
    protected $cldrRepository;

    /**
     * @Flow\Inject
     * @var Service
     */
    protected $localizationService;

    /**
     * @var Locale
     */
    protected $locale;

    /** @var array */
    protected $countries = [];

    public function initializeObject()
    {
        $this->locale();
    }

    protected function fetchCountries(): array
    {
        $model = $this->cldrRepository->getModelForLocale($this->locale);
        $territories = $model->findNodesWithinPath('localeDisplayNames/territories', 'territory');

        foreach ($territories as $key => $value) {
            $type = $model->getAttributeValue($key, 'type');
            if (!is_numeric($type) && $type !== 'ZZ') {
                $countryName = $model->getElement('localeDisplayNames/territories/territory[@type="' . $type . '"]');
                $this->countries[] = ['label' => $countryName, 'code' => $type];
            }
        }

        asort($this->countries);
        return array_reverse($this->countries, true);
    }

    protected function setLocale(Locale $locale): self
    {
        $this->locale = $locale;
        $this->countries = [];
        return $this;
    }

    /**
     * @param null|string|Locale $locale
     * @return $this
     * @throws \Neos\Flow\I18n\Exception\InvalidLocaleIdentifierException
     */
    public function locale($locale = null): self
    {
        if ($locale === null) {
            return $this->setLocale($this->localizationService->getConfiguration()->getCurrentLocale());
        }

        if (is_string($locale)) {
            return $this->setLocale(new Locale($locale));
        }

        if ($locale instanceof Locale) {
            return $this->setLocale($locale);
        }

        throw new \InvalidArgumentException('CountryService::locale(null|string|Locale $locale)');
    }

    public function all(): array
    {
        if (empty($this->countries)) {
            $this->fetchCountries();
        }

        return $this->countries;
    }

    public function byLabel(string $label): array
    {
        foreach ($this->all() as $country) {
            if ($country['label'] !== $label) {
                continue;
            }

            return $country;
        }

        throw new \Exception("Country '$label' does not exist.");
    }

    public function byCode(string $code)
    {
        foreach ($this->all() as $country) {

            if ($country['code'] !== strtoupper($code)) {
                continue;
            }

            return $country;
        }

        return false;
    }
}
