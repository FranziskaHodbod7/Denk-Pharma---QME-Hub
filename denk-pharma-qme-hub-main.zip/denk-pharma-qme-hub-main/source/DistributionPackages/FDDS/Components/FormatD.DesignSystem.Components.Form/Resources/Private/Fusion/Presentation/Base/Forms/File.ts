import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";


export default class FileUploadWatcherComponentManager extends AbstractComponentManager {

	initialize(domSection: HTMLElement) {
		const inputs = this.getInputs(domSection)
		inputs.forEach(input => this.attachChangeListenerToInput(input));
	}

	attachChangeListenerToInput(input: HTMLInputElement) {
		input.addEventListener('change', event => this.onInputChanged(input, event));

		if (input.files.length !== 0) {
			input.classList.add('not-empty');
		}
	}

	onInputChanged(input: HTMLInputElement, event: Event) {
		input.classList.toggle('not-empty', input.files.length != 0);
	}

	getInputs(domSection: HTMLElement): HTMLInputElement[] {
		return Array.from(domSection.querySelectorAll('input[type=file]'));
	}
}
