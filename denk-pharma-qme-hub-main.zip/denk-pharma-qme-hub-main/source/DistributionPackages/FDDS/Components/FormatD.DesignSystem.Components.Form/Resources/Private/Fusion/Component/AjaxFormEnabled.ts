import Logger from "@distributionPackages/FDDS/Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"
import { PopulateDataLayerEvent } from "@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.TrackingConsent/Resources/Private/JavaScript/DataLayerPopulator"
import { ComponentLoaderReloadEvent } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/Events";
import { componentLoader } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/ComponentLoader";

/**
 * This converts nested forms into ajax forms
 */
export default function (domSection: HTMLElement) {

	const ajaxFormEnabledContainers = domSection.querySelectorAll<HTMLFormElement>('[data-component="ajax-form-enabled"]');
	if (ajaxFormEnabledContainers.length < 1) return;

	const logger = new Logger('AjaxForm');
	logger.log('AjaxFormContainers', ajaxFormEnabledContainers);

	for(const container of ajaxFormEnabledContainers) {
		logger.log('AjaxFormInitializing', container);

		const ajaxEnabledForms = Array.from(container.querySelectorAll('form'))

		// if container itself is form
		if (container.nodeName === 'FORM') {
			ajaxEnabledForms.unshift(container)
		}

		for(const form of ajaxEnabledForms) {
			logger.log('AjaxFormItem', form);
			ajaxEnableForm(form, container);
		}
	}

	/**
	 * @param form
	 * @param container
	 */
	function ajaxEnableForm(form, container) {

		form.addEventListener('submit', async function (event) {
			event.preventDefault();
			const uri = this.getAttribute('action');
			const containerId = container.dataset.ajaxEnabledId;
			const formData = new FormData(form);

			// Add loading to submit button
			const submitButton = this.querySelector('button[type="submit"]');
			submitButton.classList.add('loading');
			submitButton.disabled = true;

			formData.append('--' + form.id + '[__currentPage]', "1");

			try {
				const response = await fetch(uri, {
					method: 'post',
					body: formData,
				})
				const text = await response.text()

				const parser = new DOMParser();
				const htmlDocument = parser.parseFromString(text, "text/html");
				const content = htmlDocument.documentElement.querySelector<HTMLElement>('[data-ajax-enabled-id="' + containerId + '"]');
				logger.log('AjaxFormContent', content);
				container.replaceWith(content);

				logger.log('AjaxFormPosition', content.getBoundingClientRect().top);
				window.scrollBy({ top: content.getBoundingClientRect().top - 200 });

				componentLoader.initializeComponentsByDataAttribute(content)

				document.dispatchEvent(new ComponentLoaderReloadEvent(<HTMLElement>content.parentNode));
				window.dispatchEvent(new PopulateDataLayerEvent('ajaxFormSubmission', 'ajaxEnabledForm', uri))

			} catch (error) {
				logger.log('AjaxFormFetchingError', error);
			}


		});
	}
}
