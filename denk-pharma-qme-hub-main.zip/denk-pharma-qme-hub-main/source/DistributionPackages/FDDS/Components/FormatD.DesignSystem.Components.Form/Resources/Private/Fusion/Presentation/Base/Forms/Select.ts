import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class SelectWatcherComponentManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		const selects = this.getSelects(domSection)
		selects.forEach(select => this.attachChangeListenerToSelect(select));
	}

	attachChangeListenerToSelect(select: HTMLSelectElement) {
		select.addEventListener('change', event => this.onSelectChanged(select, event));

		if (select.value.trim() !== '') {
			select.classList.add('not-empty');
		}
	}

	onSelectChanged(select: HTMLSelectElement, event: Event) {
		select.classList.toggle('not-empty', select.value.trim() !== '');
	}

	getSelects(domSection: HTMLElement): HTMLSelectElement[] {
		return Array.from(domSection.querySelectorAll('select'));
	}
}
