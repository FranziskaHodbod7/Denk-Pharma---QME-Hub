# FormatD.DesignSystem.Components.Form

A design-system layer on top of Neos Form Builder. The package restyles the built-in form elements with custom CSS classes. It adds a Country Select form element. It also adds an optional ajax submit mode for node-based forms.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base settings and Fusion conventions shared across the design system |
| `neos/form-builder` | The form editing and NodeType layer this package overrides |
| `neos/form-fusionrenderer` | The Fusion renderer prototypes this package overrides |
| `cocur/slugify` | Slug generation (declared as a dependency; not called directly by this package's own code) |

The package also uses `FormatD.DesignSystem.Components.Icons:Mixin.Icon` and `FormatD.DesignSystem.Components.Icons:Atom.Icon`, and `FormatD.ComponentLoader:Component`. Neither `formatd/designsystem-components-icons` nor the component-loader package appears in `composer.json`.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Settings

### Form element presets

`Configuration/Settings.Neos.Form.yaml` extends the default Neos Form preset. It sets a CSS class on most form elements (inputs, sections, checkboxes, file uploads, and so on), and configures the file-upload element:

```yaml
Neos:
  Form:
    presets:
      default:
        formElementTypes:
          'Neos.Form:FileUpload':
            properties:
              resourceCollection: 'persistent'
              createLinkToFilePreview: true
              allowedExtensions:
                - pdf
                - xls
                - xlsx
                - doc
                - odt
                - docx
                - csv
                - jpg
                - jpeg
                - png
                - gif
                - tiff
```

It also registers finisher presets for `Closure`, `Confirmation`, `Email`, `FlashMessage`, and `Redirect`, each with empty default options.

### Eel default context

`Configuration/Settings.Neos.Fusion.yaml` registers the Country Eel helper under the name `FDDS.Form.Country`:

```yaml
Neos:
  Fusion:
    defaultContext:
      'FDDS.Form.Country': 'FormatD\DesignSystem\Components\Form\Eel\Helper\CountryHelper'
```

---

## NodeTypes

### Custom form elements

| NodeType | Purpose |
|---|---|
| `FormatD.DesignSystem.Components.Form:CountrySelect` | A country dropdown, mapped to `Neos.Form:SingleSelectDropdown` |

```yaml
'FormatD.DesignSystem.Components.Form:CountrySelect':
  superTypes:
    'Neos.Form.Builder:FormElement': true
  ui:
    label: 'Country Select'
    group: 'form.custom'
```

### Overrides of Form Builder NodeTypes

| NodeType | Added or changed properties |
|---|---|
| `Neos.Form.Builder:NodeBasedForm` | `submitLabel` (string), `submitAlignment` (`left` \| `center` \| `right`, default `left`), `ajaxEnabled` (boolean, default `false`) |
| `Neos.Form.Builder:Section` | `columns` (`col-full` \| `cols-2` \| `cols-3` \| `cols-4`), `columnLayout` (five preset column-width layouts) |
| `Neos.Form.Builder:SingleLineText` | Adds the Icon mixin, plus `iconPosition` (`icon-right` \| `icon-left`) |
| `Neos.Form.Builder:SingleSelectRadiobuttons` | `inline` (boolean), lays out radio buttons in one row when true |
| `Neos.Form.Builder:SelectOption` | Removes the default validation on the `value` property |
| `Neos.Form.Builder:FileUpload` | Adds icons and readable labels to each entry in `allowedExtensions` |

---

## Eel helpers

| Method | Signature | Description |
|---|---|---|
| `getLabel` | `getLabel(string $isoCode): string` | Returns the localized country name for one ISO code, from the CLDR repository |
| `getCountries` | `getCountries(): array` | Returns every country as `{label, value, id}`, sorted by label, with one leading empty entry |

Both methods live on `CountryHelper`, registered in Fusion as `FDDS.Form.Country`. `CountryHelper` reads directly from `CldrRepository` for the current locale. It does not use `CountryService`, even though `CountryService` exists in the same package and implements a similar `all()` method.

---

## DataSource

`FormatD.DesignSystem.Components.Form\DataSource\CountryDataSource` (identifier `formatd-designsystem-country`) returns `{label, value, icon}` entries for every country. It uses `CountryService::all()`, which reads the CLDR repository for a given locale and caches the list on the singleton service. No NodeType property in this package references `formatd-designsystem-country` as a `dataSourceIdentifier` — the Country Select NodeType instead calls `FDDS.Form.Country.getCountries()` directly from Fusion.

---

## Fusion prototypes and overrides

### Country Select

```fusion
prototype(FormatD.DesignSystem.Components.Form:CountrySelect.Definition) < prototype(Neos.Form.Builder:FormElement.Definition) {
    formElementType = 'Neos.Form:SingleSelectDropdown'  # reuses the built-in dropdown renderer
    properties {
        options = Neos.Form.Builder:SelectOptionCollection {
            items = ${FDDS.Form.Country.getCountries()}  # list of {label, value} from the Eel helper
        }
    }
}
```

### Ajax form submit

```fusion
prototype(FormatD.DesignSystem.Components.Form:Component.AjaxFormEnabled) < prototype(FormatD.ComponentLoader:Component) {
    id      = ''    # unique DOM id for the wrapping element (required)
    content = null  # rendered form markup (string)
}
```

When `node.properties.ajaxEnabled` is true, `Neos.Form.Builder:NodeBasedForm` wraps its rendered form in this component. A matching TypeScript component manager intercepts the `submit` event, posts the form data with `fetch`, and replaces the wrapper with the response markup. It then re-initializes component loader components inside the new markup and scrolls the page to the form.

### Element restyling

The remaining Fusion files under `Resources/Private/Fusion/Overrides/Neos.Form.FusionRenderer/` add CSS classes and icons to the stock renderer prototypes: `Form`, `FormElement`, `FormNavigation`, `Section`, `Page`, `Checkbox`, `FileUpload`, `MultiLineText`, `SingleLineText`, `SingleSelectDropdown`, `SingleSelectRadiobuttons`, and `StaticText`. `SingleLineText` and `SingleSelectDropdown` render an icon inside the field container with `FormatD.DesignSystem.Components.Icons:Atom.Icon`, using the `icon` property added by the Icon mixin.

---

## Worked example

```fusion
prototype(Neos.Form.Builder:NodeBasedForm) {
    @process.enableAjax = Neos.Fusion:Case {
        isAjaxForm {
            condition = ${node.properties.ajaxEnabled}
            renderer = FormatD.DesignSystem.Components.Form:Component.AjaxFormEnabled {
                content = ${value}
                id = ${String.md5(node.aggregateId)}
            }
        }
        default {
            condition = ${true}
            renderer = ${value}
        }
    }
}
```

This is the actual override that turns on ajax submission. Enable it per form by setting the `ajaxEnabled` checkbox in the form's inspector panel.
