# FormatD.DesignSystem.Components.ContentPanels

A set of collapsible and switchable content containers for Neos CMS: Accordion, Tab, and Tab Area. The Accordion opens and closes single panels in place. The Tab Area groups Tab nodes and renders them as a tabbed slider.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base mixins (`InspectorTitle`, `OptionsGroup`) and the `Content.ContentCollection` base prototype |

The Tab Area also renders through `FormatD.DesignSystem.Components.Slider:Organism.Slider` and reads its option presets from the Slider package's settings. That dependency is not declared in `composer.json`.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeTypes

| NodeType | Purpose |
|---|---|
| `FormatD.DesignSystem.Components.ContentPanels:Content.Accordion` | A content collection of panels that open and close, using the Handorgel library |
| `FormatD.DesignSystem.Components.ContentPanels:Content.Tab` | A single tab panel, with a title, an optional icon, and its own child content |
| `FormatD.DesignSystem.Components.ContentPanels:Content.TabArea` | A content collection that only accepts `Content.Tab` children and renders them as a slider |

```yaml
# Configuration/NodeTypes.yaml
'MyPackage:Content.MyAccordion':
  superTypes:
    'FormatD.DesignSystem.Components.ContentPanels:Content.Accordion': true
```

### Accordion

The Accordion is a `Neos.Neos:ContentCollection`. Its creation dialog requires a non-empty `title`. Changing the title reloads the page, because the property has `reloadPageIfChanged: true`.

### Tab

A Tab is also a `Neos.Neos:ContentCollection`. It uses `FormatD.DesignSystem.Components.Icons:Mixin.Icon` for its icon, and adds:

| Property | Type | Default | Notes |
|---|---|---|---|
| `title` | string | `'New Tab'` | Required, maximum 25 characters |
| `hideIcon` | boolean | – | Hides the tab icon in the tab title |

### Tab Area

A Tab Area only accepts `Content.Tab` children (`constraints.nodeTypes` disallows every other type). It has:

| Property | Type | Default | Notes |
|---|---|---|---|
| `preset` | string | `'tab-area-default'` | Selected through the `formatd-designsystem-tab-area-presets` DataSource |
| `navigation` | string | `'default'` | `'default'` \| `'enabled'` \| `'disabled'` |

> [!warning]
> Changing `preset` or `navigation` reloads the whole page (`reloadPageIfChanged: true` at the NodeType level). This is a hard page reload, not a live inspector preview.

---

## Fusion prototypes

```fusion
prototype(FormatD.DesignSystem.Components.ContentPanels:Molecule.Accordion) {
    title   = ''  # accordion panel title (string)
    content = ''  # rendered child content collection (string)
}

prototype(FormatD.DesignSystem.Components.ContentPanels:Molecule.Tab) {
    content    = ''  # rendered child content collection (string)
    identifier = ''  # tab slug, derived from the title (string)
}

prototype(FormatD.DesignSystem.Components.ContentPanels:Molecule.TabTitle) {
    title    = ''     # tab title (string)
    iconName = ''     # icon file name (string)
    hideIcon = false  # hides the icon when true (boolean)
}
```

`Content.Tab` derives `identifier` from the title with `FDDS.String.slugify(node.properties.title)`. `Content.TabArea` renders its children through `Neos.Neos:ContentCollectionRenderer`. It wraps each item in a `swiper-slide` div. It also builds a separate thumbs strip of `Molecule.TabTitle` components, for the tab navigation.

---

## DataSource

`FormatD.DesignSystem.Components.ContentPanels\DataSource\TabAreaPresetsDataSource` (identifier `formatd-designsystem-tab-area-presets`) feeds the Tab Area `preset` select box. It reads the Slider package's `FormatD.DesignSystem.Components.Slider.presets` settings and returns only entries whose `presetCategory` is `tab-area`. This package itself defines no presets in its own `Configuration/Settings.yaml` — the actual preset list lives in `FormatD.DesignSystem.Components.Slider`'s settings file.

---

## Worked example

```fusion
prototype(FormatD.DesignSystem.Components.ContentPanels:Content.TabArea) < prototype(FormatD.DesignSystem.Core:Content.ContentCollection) {
    renderer = FormatD.DesignSystem.Components.Slider:Organism.Slider {
        type    = 'tab-area'
        preset  = ${node.properties.preset}
        navigation = ${node.properties.navigation}
        content = Neos.Neos:ContentCollectionRenderer {
            itemRenderer.@process.wrapWithContainer = ${'<div class="swiper-slide">' + value + '</div>'}
        }
    }
}
```

This is a shortened version of the actual `Content.TabArea` prototype. It shows that the Tab Area's rendering logic lives in the Slider package, not in this one.
