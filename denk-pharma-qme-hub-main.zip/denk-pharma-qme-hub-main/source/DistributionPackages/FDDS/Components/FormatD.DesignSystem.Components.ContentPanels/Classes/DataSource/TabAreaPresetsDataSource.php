<?php
namespace FormatD\DesignSystem\Components\ContentPanels\DataSource;

use Neos\Flow\Annotations as Flow;
use FormatD\DesignSystem\Core\DataSource\AbstractSettingsDataSource;

class TabAreaPresetsDataSource extends AbstractSettingsDataSource {

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-tab-area-presets';

	/**
	 * @return string
	 */
	protected function getConfigurationPath() {
		return 'FormatD.DesignSystem.components.slider.presets';
	}

	/**
	 * @return string
	 */
	protected function getCategory() {
		return 'tab-area';
	}

}
