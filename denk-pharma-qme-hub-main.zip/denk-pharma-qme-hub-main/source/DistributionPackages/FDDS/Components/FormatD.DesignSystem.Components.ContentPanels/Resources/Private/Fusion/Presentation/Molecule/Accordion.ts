// @ts-ignore
import Handorgel from 'handorgel'
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class AccordionComponentManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		for(const item of <NodeListOf<HTMLElement>>domSection.querySelectorAll('.handorgel')) {
			this.createAccordion(item);
		}
	}

	createAccordion(item: HTMLElement) {
		return new Handorgel(item);
	}
}
