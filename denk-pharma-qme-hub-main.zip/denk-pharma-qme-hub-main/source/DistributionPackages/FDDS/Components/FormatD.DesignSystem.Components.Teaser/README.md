# FormatD.DesignSystem.Components.Teaser

Text-and-image teaser components for Neos CMS: `TextWithImageContent` and `TextWithImageTeaser`. Each component defines a NodeType with an image, a child content collection, and a Fusion prototype that maps node properties to a `Molecule` component. The package declares only the prop contract of each `Molecule` component. A design or template package supplies the actual markup.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `OptionsGroup` and `PositionedImageMixin` mixins |
| `sitegeist/kaleidoscope` | `AssetImageSource`, used by both NodeTypes to build the image for their Fusion renderer |
| `Neos.Neos` | `ContentComponent`, `ContentCollection`, `Editable`, inspector select-box editors |
| `Neos.NodeTypes.BaseMixins` | `ImageMixin` and `ImageCaptionMixin`, used by `Content.TextWithImageContent` |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## How the package fits together

Each NodeType folder under `NodeTypes/Content/` has a matching `.yaml` and `.fusion` file. Neos loads the Fusion file through the `nodetypes://` include in `Root.fusion`. The Fusion prototype maps node properties to a `Molecule.*` component.

The `Molecule.*` prototypes live under `Resources/Private/Fusion/Presentation/Molecule/`. Each one declares only a `@propTypes` block. Neither sets a `renderer`. This package leaves the actual AFX markup to a downstream design or template package (for example `DenkPharma.Design` or `FormatD.DesignSystem.Template.Gunther` in this repository), which redeclares the same prototype name with `< prototype(Neos.Fusion:Component)` and adds the `renderer`.

---

## NodeTypes

### `Content.TextWithImageContent`

`Content.TextWithImageContent` extends `Neos.Neos:Content`, `Neos.NodeTypes.BaseMixins:ImageMixin`, `Neos.NodeTypes.BaseMixins:ImageCaptionMixin`, and `FormatD.DesignSystem.Core:Mixin.OptionsGroup`. It has a child collection node named `content`, restricted to `Headline`, `Text`, `ButtonArea`, `Image`, and `ImageArea` content from the `Text` and `Media` component packages.

| Property | Type | Values | Purpose |
|---|---|---|---|
| `style` | string | `left`, `right`, `top-left`, `top-center`, `top-right`, `bottom-left`, `bottom-center`, `bottom-right` | Position of the image relative to the text |
| `maxWidth` | string | free text (pixel value) | Maximum image width |
| `imageAlwaysTopOnMobile` | boolean | — | Forces the image above the text on small screens |

`image`, `alternativeText`, `caption`, and `hasCaption` come from `ImageMixin` and `ImageCaptionMixin`.

The Fusion prototype maps `style`, `maxWidth`, and `imageAlwaysTopOnMobile` to `Molecule.TextWithImageContent`. It builds `imageSource` from `Sitegeist.Kaleidoscope:AssetImageSource`. It renders `caption` as an editable field: if the node has its own caption text, the field shows that text; otherwise it falls back to `node.properties.image.caption`, the caption stored on the asset itself.

### `Content.TextWithImageTeaser`

`Content.TextWithImageTeaser` extends `Neos.Neos:Content`, `FormatD.DesignSystem.Core:Mixin.PositionedImageMixin`, and `Mixin.OptionsGroup`. It has the same restricted `content` child collection as `Content.TextWithImageContent`.

| Property | Type | Values | Purpose |
|---|---|---|---|
| `style` | string | `image-left`, `image-right` | Side of the image |
| `imageAlwaysTopOnMobile` | boolean | — | Forces the image above the text on small screens |

`image`, `alternativeText`, `horizontalPosition`, and `verticalPosition` come from `PositionedImageMixin`.

The Fusion prototype maps `style`, `horizontalPosition`, `verticalPosition`, and `imageAlwaysTopOnMobile` to `Molecule.TextWithImageTeaser`. It builds `imageSource` from `Sitegeist.Kaleidoscope:AssetImageSource`, the same way `Content.TextWithImageContent` does. `Content.TextWithImageTeaser` has no caption support; `Content.TextWithImageContent` is the only one of the two with a caption.

---

## Fusion interface

```fusion
FormatD.DesignSystem.Components.Teaser:Molecule.TextWithImageContent {
    content = ''         # rendered child content
    style = null          # 'left' | 'right' | 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right'
    imageSource = null     # Sitegeist.Kaleidoscope image source
    imageAlt = ''          # image alt text
    maxWidth = ''           # maximum image width in pixels
    imageAlwaysTopOnMobile = false
    hasCaption = false
    caption = ''           # rendered caption text
}

FormatD.DesignSystem.Components.Teaser:Molecule.TextWithImageTeaser {
    content = ''         # rendered child content
    style = null          # 'image-left' | 'image-right'
    horizontalPosition = null   # 'left' | 'center' | 'right'
    verticalPosition = null      # 'top' | 'center' | 'bottom'
    imageAlwaysTopOnMobile = false
    imageSource = null      # Sitegeist.Kaleidoscope image source
    imageAlt = ''           # image alt text
}
```

Both prototypes declare `@strict = true` on their `@propTypes`. Fusion raises an error if the calling code sets a property that is not in this list, or a value that does not match the declared type.

---

## Worked example

```yaml
'My.Package:Content.MyTeaser':
  superTypes:
    'FormatD.DesignSystem.Components.Teaser:Content.TextWithImageTeaser': true
  ui:
    label: 'My custom teaser'
```

A project can add its own properties to a subtype of `Content.TextWithImageTeaser` or `Content.TextWithImageContent` without changing the Fusion prototype, as long as the extra properties are not read by `Molecule.TextWithImageTeaser` or `Molecule.TextWithImageContent`.
