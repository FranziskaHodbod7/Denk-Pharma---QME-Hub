# FormatD.DesignSystem.Components.Hero

A hero banner content component for Neos CMS. The package adds the `Content.HeroSegment` NodeType. An editor fills the hero with a background image or an MP4 video, a title, a text, and buttons. The package also maps the node to a Fusion prototype that carries the resolved props. It does not render the final HTML itself — see the note in the Fusion section below.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Position and overlay-opacity mixins, the "Options" inspector group |
| `sitegeist/kaleidoscope` | `AssetImageSource` for the hero background image |
| `formatd/designsystem-components-video` | MP4 hero video support |
| `Neos.Neos` | `ContentComponent`, inspector editors |
| `Neos.Fusion` | AFX rendering, `PropTypes` |

> [!warning] Declared but unused in this package
> `composer.json` requires `formatd/designsystem-components-video`. Nothing in this package's own Fusion or TypeScript uses a video prototype. The dependency only pays off when a site theme package renders `Molecule.HeroSegment` and embeds a video component there (see the note below).

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeType: `Content.HeroSegment`

```yaml
'FormatD.DesignSystem.Components.Hero:Content.HeroSegment':
  superTypes:
    'Neos.Neos:Content': true
    'FormatD.DesignSystem.Core:Mixin.PositionedImageMixin': true
    'FormatD.DesignSystem.Core:Mixin.OverlayOpacity': true
    'FormatD.DesignSystem.Core:Mixin.OptionsGroup': true
```

The `PositionedImageMixin` adds the background image, plus `horizontalPosition` and `verticalPosition` select boxes. The `OverlayOpacity` mixin adds an `overlayOpacity` range editor (0–100%, default 80%). The NodeType also adds these own properties.

| Property | Type | Notes |
|---|---|---|
| `style` | string, default `cover` | Select box: `cover`, `cover-fullscreen`, `cover-small` |
| `videoAsset` | `Neos\Media\Domain\Model\Asset` | Optional MP4 video asset; upload is disabled, only `video/mp4` is accepted |
| `title` | inherited | Re-declared with no extra options |

A `content` child node holds a `Neos.Neos:ContentCollection`. It only accepts these node types:

- `FormatD.DesignSystem.Components.Text:Content.Headline`
- `FormatD.DesignSystem.Components.Text:Content.Text`
- `FormatD.DesignSystem.Components.Text:Content.ButtonArea`

> [!warning] Gap: `hideOverlay` has no NodeType property
> The Fusion mapping below reads `node.properties.hideOverlay`. No property named `hideOverlay` exists on `Content.HeroSegment` or on any of its mixins. At runtime this value resolves to `null`. A site theme sets its own default for `hideOverlay` when it renders `Molecule.HeroSegment`, so the missing property has no visible effect there, but it means the CMS inspector has no editor for it.

---

## Fusion prototypes

### `Content.HeroSegment` (NodeType renderer)

```fusion
prototype(FormatD.DesignSystem.Components.Hero:Content.HeroSegment) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Hero:Molecule.HeroSegment {
        content = Neos.Neos:ContentCollection            # renders the 'content' child collection
        imageSource = Sitegeist.Kaleidoscope:AssetImageSource  # from node.properties.image
        imageAlt = ${node.properties.alternativeText}
        horizontalPosition = ${node.properties.horizontalPosition}
        verticalPosition = ${node.properties.verticalPosition}
        videoAssetUri = Neos.Fusion:ResourceUri            # from node.properties.videoAsset.resource
        style = ${node.properties.style}
        hideOverlay = ${node.properties.hideOverlay}       # always null, see gap above
        overlayOpacity = ${node.properties.overlayOpacity}
    }
}
```

### `Molecule.HeroSegment`

```fusion
prototype(FormatD.DesignSystem.Components.Hero:Molecule.HeroSegment) {
    @propTypes {
        @strict = true
        imageSource = ${PropTypes.any}
        imageAlt = ${PropTypes.string}
        horizontalPosition = ${PropTypes.oneOf(['left', 'center', 'right'])}
        verticalPosition = ${PropTypes.oneOf(['top', 'center', 'bottom'])}
        videoAssetUri = ${PropTypes.string}
        content = ${PropTypes.string}
        style = ${PropTypes.oneOf(['cover', 'cover-fullscreen', 'cover-small'])}
        hideOverlay = ${PropTypes.boolean}
        overlayOpacity = ${PropTypes.integer}
    }
}
```

> [!warning] No renderer in this package
> This package declares only the strict prop-type contract for `Molecule.HeroSegment`. It has no `renderer` and no AFX markup. A site theme package must add the `renderer` to produce HTML, for example by extending `FormatD.ComponentLoader:Component` and returning an AFX template that reads `props.imageSource`, `props.style`, and the other listed props. Without such an override, the hero renders empty content.

---

## Frontend behavior

`Resources/Private/Fusion/Presentation/Molecule/HeroSegment.ts` exports `HeroSegmentComponentManager`, a component manager for `FormatD.ComponentLoader`. It looks for an element with class `hero-scroll-down` inside the component's DOM section. If found, it does the following:

1. It reads the current window height as the hero segment height.
2. It updates that height on `orientationchange`.
3. On click of the scroll-down arrow, it scrolls the window to that height.

This manager only runs where a theme's markup contains a `.hero-scroll-down` element, so it depends on the theme package that supplies the `Molecule.HeroSegment` renderer.
