import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class HeroSegmentComponentManager extends AbstractComponentManager {
	initialize(domSection: HTMLElement) {
		const scrollDownArrow = this.getScrollDownArrowElement(domSection)
		if (!scrollDownArrow) {
			return;
		}

		let heroSegmentHeight = window.innerHeight;

		window.addEventListener("orientationchange", () => {
			heroSegmentHeight = window.outerHeight;
		}, false);

		scrollDownArrow.addEventListener('click', () => {
			window.scrollTo(0, heroSegmentHeight);
		});
	}

	getScrollDownArrowElement(domSection: HTMLElement) {
		return domSection.querySelector('.hero-scroll-down')
	}
}
