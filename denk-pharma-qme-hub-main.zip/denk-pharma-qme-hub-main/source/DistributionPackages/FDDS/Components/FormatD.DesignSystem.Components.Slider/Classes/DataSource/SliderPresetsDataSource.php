<?php
namespace FormatD\DesignSystem\Components\Slider\DataSource;

use Neos\Flow\Annotations as Flow;
use FormatD\DesignSystem\Core\DataSource\AbstractSettingsDataSource;

class SliderPresetsDataSource extends AbstractSettingsDataSource {

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-slider-presets';

	/**
	 * @return string
	 */
	protected function getConfigurationPath() {
		return 'FormatD.DesignSystem.Components.Slider.presets';
	}

	/**
	 * @return string
	 */
	protected function getCategory() {
		return 'slider';
	}

}
