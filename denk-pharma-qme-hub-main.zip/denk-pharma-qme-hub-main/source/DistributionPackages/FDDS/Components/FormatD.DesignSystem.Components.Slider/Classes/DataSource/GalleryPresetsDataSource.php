<?php
namespace FormatD\DesignSystem\Components\Slider\DataSource;

use Neos\Flow\Annotations as Flow;
use FormatD\DesignSystem\Core\DataSource\AbstractSettingsDataSource;

class GalleryPresetsDataSource extends AbstractSettingsDataSource {

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-gallery-presets';

	/**
	 * @return string
	 */
	protected function getConfigurationPath() {
		return 'FormatD.DesignSystem.components.slider.presets';
	}

	/**
	 * @return string
	 */
	protected function getCategory() {
		return 'gallery';
	}

}
