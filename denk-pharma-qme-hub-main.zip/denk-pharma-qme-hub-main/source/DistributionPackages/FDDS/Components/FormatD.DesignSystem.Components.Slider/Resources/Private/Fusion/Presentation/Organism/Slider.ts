// @ts-ignore
import Swiper from 'swiper';
import * as swiperModules from 'swiper/modules';

// @ts-ignore
import Logger from "../../../../../../../Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";


export interface SwiperConfigurationPagination {
	el?: string|HTMLElement
}

export interface SwiperConfigurationBreakpoints {
	[key: string]: any
}

export interface SwiperConfiguration {
	initialSlide?: number
	modules: any[]
	breakpointOverrides: {[key: string]: {conditions: {[key: string]: any}, breakpoints: SwiperConfigurationBreakpoints}}
	simulateTouch: boolean
	navigation?: {nextEl?: string|HTMLElement, prevEl?: string|HTMLElement}
	thumbs?: {swiper?: {el?: string, modules: any[], pagination?: SwiperConfigurationPagination}}
	pagination?: SwiperConfigurationPagination

	breakpoints: SwiperConfigurationBreakpoints
}

export type BreakpointOverrideCondition = (type: string, value: any, slideCount: number) => boolean

export class Slider {
	protected logger: Logger
	protected modules: any[]

	protected breakpointOverrideConditions: {[key: string]: BreakpointOverrideCondition} = {
		'slideCountLowerThen': (type, value , slideCount) => slideCount < (typeof value === "number" ? value : parseInt(String(value)))
	}

	constructor(logger: Logger, modules: any[]) {
		this.logger = logger
		this.modules = modules
	}

	initialize(domSection) {
		this.logger.log('initialized for: ', domSection);

		for(const sliderElement of domSection.querySelectorAll('.slider-swiper')) {
			const configuration = <SwiperConfiguration>Object.assign({}, JSON.parse(sliderElement.dataset.swiper));
			configuration.modules = [...this.modules]
			this.logger.log('init slider for: ', sliderElement, configuration);
			this.applyConfigurationModifications(sliderElement, configuration)

			const swiper = new Swiper(sliderElement.querySelector('.swiper'), configuration);

			window.addEventListener("hashchange", (event) => {
				this.hashChangeEventListener(sliderElement, swiper, event)
			});
		}
	}

	applyConfigurationModifications(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		this.applyConfigurationForInitialSlide(sliderElement, configuration)
		this.applyConfigurationForBackend(sliderElement, configuration)
		this.applyConfigurationForNavigation(sliderElement, configuration)
		this.applyConfigurationForPagination(sliderElement, configuration)
		this.applyConfigurationForBreakpointOverrides(sliderElement, configuration)
		this.applyConfigurationForThumbs(sliderElement, configuration)
	}

	applyConfigurationForInitialSlide(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		const initialSlideIndex = this.getInitialSlideByUriHash(sliderElement, window.location.hash);
		if (initialSlideIndex !== null) {
			configuration.initialSlide = initialSlideIndex;
			window.scrollTo({top: sliderElement.getBoundingClientRect().top-200});
			this.logger.log('initial slide is: ' + initialSlideIndex);
		}
	}

	applyConfigurationForBackend(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		if (window.fdds.Context.isBackend()) {
			this.logger.log('simulateTouch disabled in backend (to prevent interference with inline editing)');
			configuration.simulateTouch = false;
			if (configuration.thumbs && configuration.thumbs.swiper && configuration.thumbs.swiper.el) {
				// Deactivated because we usually dont want the thumbs to be selectable and editable but only be used as navigation
				//configuration.thumbs.swiper.simulateTouch = false;
			}
		}
	}

	applyConfigurationForNavigation(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		if (typeof configuration.navigation === 'object') {
			if (typeof configuration.navigation.nextEl === "string" && configuration.navigation.nextEl) configuration.navigation.nextEl = <HTMLElement>sliderElement.querySelector(configuration.navigation.nextEl);
			if (typeof configuration.navigation.prevEl  === "string" && configuration.navigation.prevEl) configuration.navigation.prevEl = <HTMLElement>sliderElement.querySelector(configuration.navigation.prevEl);
		}
	}

	applyConfigurationForPagination(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		if (typeof configuration.pagination === 'object') {
			if (typeof configuration.pagination.el === "string" && configuration.pagination.el) configuration.pagination.el = <HTMLElement>sliderElement.querySelector(configuration.pagination.el);
		}
	}

	applyConfigurationForThumbs(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		if (typeof configuration.thumbs !== 'object' || typeof configuration.thumbs.swiper !== 'object') {
			return
		}
		if (configuration.thumbs.swiper.el) {
			const thumbsDescendants = Array.from<HTMLElement>(sliderElement.querySelectorAll(configuration.thumbs.swiper.el));
			const thumbsEl = thumbsDescendants.length < 2 ? thumbsDescendants[0] :
				thumbsDescendants.map(elem => this.traverseParentsToItem(elem, sliderElement))
					.reduce((sum, elem) => sum.level > elem.level ? elem : sum, {elem: null, level: Infinity})
					.elem;

			this.logger.log('slider has thumbs: ', thumbsEl);
			configuration.thumbs.swiper.el = null;
			configuration.thumbs.swiper.modules = [...this.modules];
			if (typeof configuration.thumbs.swiper.pagination === 'object') {
				if (typeof configuration.thumbs.swiper.pagination.el === "string") configuration.thumbs.swiper.pagination.el = <HTMLElement>sliderElement.querySelector(configuration.thumbs.swiper.pagination.el);
			}
			configuration.thumbs.swiper = new Swiper(thumbsEl, configuration.thumbs.swiper);
		}
	}

	applyConfigurationForBreakpointOverrides(sliderElement: HTMLElement, configuration: SwiperConfiguration) {
		if (typeof configuration.breakpointOverrides !== 'object') {
			return
		}
		const slideCount = sliderElement.querySelector('.swiper-wrapper').children.length;

		for (const [_, breakpointOverride] of Object.entries(configuration.breakpointOverrides)) {
			let useOverride = true;
			for (const [conditionType, conditionValue] of Object.entries(breakpointOverride.conditions)) {
				this.logger.log(conditionType, conditionValue);
				useOverride = this.isConditionFulfilled(conditionType, conditionValue, slideCount)
				if (!useOverride) {
					break; // if one condition does not match do not override
				}
			}
			if (useOverride) {
				configuration.breakpoints = {
					...configuration.breakpoints,
					...breakpointOverride.breakpoints
				}
				this.logger.log('Overriding breakpoint config:', configuration.breakpoints);
			}
		}
	}

	isConditionFulfilled(type: string, value: any, slideCount: number) {
		if(type in this.breakpointOverrideConditions) {
			return this.breakpointOverrideConditions[type](type, value, slideCount)
		}
		return false
	}

	getInitialSlideByUriHash(sliderElement: HTMLElement, hash: string): number|null {
		let initialSlideIndex: null|number = null;

		// generic deeplink to tab or slide by position:
		// @todo: make slider identifiable if more are on one page
		const genericRegEx = /^#(tab|slide)-([0-9]+)$/;
		if (hash.match(genericRegEx)) {
			initialSlideIndex = parseInt(hash.replace(genericRegEx, '$2')) - 1;
			this.logger.log('Initial slide loaded from position anchor: ', initialSlideIndex);
			return initialSlideIndex;
		}

		// deeplink to named tab:
		const tabNamedRegEx = /^#(tab|slide)-([a-zA-Z0-9_-]+)$/;
		if (hash.match(tabNamedRegEx)) {
			const tabName = hash.replace(tabNamedRegEx, '$2');
			const targetTabElement = <HTMLElement>sliderElement.querySelector(`[data-swiper-tab-identifier="${tabName}"]`);

			if (targetTabElement) {
				initialSlideIndex = 0;
				let tab = targetTabElement.parentNode;
				while( (tab = <HTMLElement>tab.previousSibling) != null ) {
					initialSlideIndex++;
				}
				this.logger.log('Initial slide loaded from named anchor: ', initialSlideIndex);
				return initialSlideIndex;
			}
		}

		return initialSlideIndex;
	}

	hashChangeEventListener(sliderElement: HTMLElement, swiper: Swiper, event: HashChangeEvent) {
		const slide = this.getInitialSlideByUriHash(sliderElement, window.location.hash);
		if(slide !== undefined) {
			swiper.slideTo(slide);
			this.logger.log(sliderElement.getBoundingClientRect().top);
			window.scrollBy({top: sliderElement.getBoundingClientRect().top-200});
		}
	}

	traverseParentsToItem(element: HTMLElement, item: HTMLElement, level = 0) {
		return element.parentElement === item ? {element: element, level: level} : this.traverseParentsToItem(element.parentElement, item, level+1)
	}
}

export default class SliderComponentManager extends AbstractComponentManager {
	initialize(domSection) {
		const logger = new Logger('Slider');
		const slider = new Slider(logger, [
			swiperModules.Navigation,
			swiperModules.Pagination,
			swiperModules.Scrollbar,
			swiperModules.FreeMode,
			swiperModules.Autoplay,
			swiperModules.Thumbs,
			swiperModules.EffectFade,
		])
		slider.initialize(domSection)
	}
}
