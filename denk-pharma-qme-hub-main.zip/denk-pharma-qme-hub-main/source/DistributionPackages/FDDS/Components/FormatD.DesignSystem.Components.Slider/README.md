# FormatD.DesignSystem.Components.Slider

A slider and image-gallery component set for Neos CMS, built on the Swiper JavaScript library. The package provides two content NodeTypes (`Content.Slider` and `Content.Gallery`), a set of named Swiper configuration presets in `Settings.yaml`, two DataSources that expose the presets to the backend inspector, and the client-side Swiper initialization script.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `Content.ContentCollection` base prototype, `Mixin.OptionsGroup` mixin, `AbstractSettingsDataSource` base class |
| `Neos.Neos` | `ContentCollectionRenderer`, inspector `SelectBoxEditor` |
| `FormatD.DesignSystem.Components.Media` | `Content.Image`, used for gallery thumbnails |
| `swiper` (npm) | The JavaScript slider library the client script initializes |

The package's `composer.json` only declares `formatd/designsystem-core`.

> `Content.Gallery`'s NodeType constraint allows only child nodes of type `FormatD.DesignSystem.Components.Slider:Content.Image`. No NodeType with that name exists anywhere in this codebase; the constraint currently allows no child at all unless another package defines it.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Swiper presets (`Settings.yaml`)

The package reads named presets from `FormatD.DesignSystem.Components.Slider.presets`. Each preset is a plain Swiper configuration object, plus a `presetLabel` and a `presetCategory` used by the backend inspector.

```yaml
FormatD:
  DesignSystem:
    Components:
      Slider:
        presets:
          my-preset:
            presetLabel: 'My preset'
            presetCategory: 'slider'   # 'slider' or 'gallery'; groups the preset in its DataSource
            loop: true
            autoplay:
              delay: 5000
            navigation:
              nextEl: '.swiper-button-next'
              prevEl: '.swiper-button-prev'
            breakpoints:
              320:
                slidesPerView: 1
                spaceBetween: 0
```

The package ships four presets: `default` and `offsetBefore` (category `slider`), `gallery-default` (category `gallery`), and `tab-area-default` (category `tab-area`, used outside this package). Any other Swiper option is valid inside a preset; the client script passes the resolved object straight to `new Swiper(...)`.

---

## NodeTypes

### `Content.Slider`

A `ContentCollection`. Each child node becomes one slide.

| Property | Type | Default | Notes |
|---|---|---|---|
| `preset` | string (select box) | `'default'` | Options come from the `formatd-designsystem-slider-presets` DataSource |
| `navigation` | string (select box) | `'default'` | `default`, `enabled`, or `disabled`; overrides the preset's navigation arrows |
| `pagination` | string (select box) | `'default'` | `default`, `enabled`, or `disabled` |
| `autoplay` | string (select box) | `'default'` | `default`, `enabled`, or `disabled` |
| `autoplayDelay` | integer | `null` | Overrides the preset's autoplay delay, in milliseconds |
| `slidesPerView` | integer | `1` | 1 to 4; hidden in the inspector unless `preset` is `'default'` |
| `loop` | string (select box) | `'default'` | `default`, `enabled`, or `disabled` |

```fusion
prototype(FormatD.DesignSystem.Components.Slider:Content.Slider) < prototype(FormatD.DesignSystem.Core:Content.ContentCollection) {
    renderer = FormatD.DesignSystem.Components.Slider:Organism.Slider {
        preset        = ${node.properties.preset}
        navigation    = ${node.properties.navigation}
        pagination    = ${node.properties.pagination}
        autoplay      = ${node.properties.autoplay}
        autoplayDelay = ${node.properties.autoplayDelay}
        slidesPerView = ${node.properties.slidesPerView}
        loop          = ${node.properties.loop}
        content       = Neos.Neos:ContentCollectionRenderer {
            itemRenderer.@process.wrapWithContainer = ${'<div class="swiper-slide">' + value + '</div>'}
        }
    }
}
```

### `Content.Gallery`

A `ContentCollection` for image galleries with a thumbnail strip. Its constraints allow only `Content.Image` children (see the note above about the missing NodeType).

| Property | Type | Default | Notes |
|---|---|---|---|
| `preset` | string (select box) | `'gallery-default'` | Options come from the `formatd-designsystem-gallery-presets` DataSource |
| `navigation` | string (select box) | `'default'` | `default`, `enabled`, or `disabled` |
| `autoplay` | string (select box) | `'default'` | `default`, `enabled`, or `disabled` |
| `autoplayDelay` | integer | `null` | Overrides the preset's autoplay delay, in milliseconds |

`Content.Gallery` declares no `pagination` or `loop` property in its NodeType.

- Its Fusion renderer does not pass a `loop` prop to `Organism.Slider`. The slider falls back to the preset's own `loop` value.
- Its Fusion renderer does pass `pagination = ${node.properties.pagination}`. That property does not exist on the NodeType, so the value is always empty.

> [!warning] Always-empty `pagination` value
> An empty `pagination` value is not the same as an unset one. Check the active template's `Organism.Slider` renderer if pagination does not show as expected on a gallery.

```fusion
prototype(FormatD.DesignSystem.Components.Slider:Content.Gallery) < prototype(FormatD.DesignSystem.Core:Content.ContentCollection) {
    thumpItems = ${q(node).children()}

    renderer = FormatD.DesignSystem.Components.Slider:Organism.Slider {
        type          = 'gallery'
        preset        = ${node.properties.preset}
        navigation    = ${node.properties.navigation}
        pagination    = ${node.properties.pagination}
        autoplay      = ${node.properties.autoplay}
        autoplayDelay = ${node.properties.autoplayDelay}
        content       = Neos.Neos:ContentCollectionRenderer { /* one .swiper-slide per child */ }
        thumbsContent = /* one .swiper-slide per child, rendered with FormatD.DesignSystem.Components.Media:Content.Image */
    }
}
```

---

## Fusion interface: `Organism.Slider`

This package declares only the prop-type contract for `Organism.Slider`:

```fusion
prototype(FormatD.DesignSystem.Components.Slider:Organism.Slider) {
    @propTypes {
        content           = ${PropTypes.string}                                     # the slide markup, required
        thumbsContent     = ${PropTypes.string}                                     # thumbnail-strip markup, for galleries
        type              = ${PropTypes.string}                                     # a free-form label, for example 'slider' or 'gallery'
        preset            = ${PropTypes.string}                                     # preset name, looked up in Settings.yaml
        navigation        = ${PropTypes.oneOf(['default', 'enabled', 'disabled'])}
        pagination        = ${PropTypes.oneOf(['default', 'enabled', 'disabled'])}
        autoplay          = ${PropTypes.oneOf(['default', 'enabled', 'disabled'])}
        loop              = ${PropTypes.oneOf(['default', 'enabled', 'disabled'])}
        autoplayDelay     = ${PropTypes.integer}
        slidesPerView     = ${PropTypes.integer}
        configurationBase = ${PropTypes.arrayOf(PropTypes.any)}                     # the resolved preset object
    }
}
```

It does not set a base prototype or a `renderer` here. A site template package supplies the concrete base prototype (`FormatD.ComponentLoader:Component`) and the AFX renderer. That renderer does the following:

1. Resolves `configurationBase` from `Configuration.setting('FormatD.DesignSystem.Components.Slider.presets.' + preset)`.
2. Merges the `navigation`/`pagination`/`autoplay`/`loop`/`slidesPerView` overrides into it.
3. JSON-encodes the result into a `data-swiper` attribute.
4. Renders the `.slider-swiper` / `.swiper` / `.swiper-wrapper` markup, with `FormatD.DesignSystem.Components.Icons:Atom.Icon` navigation buttons.

Check the active site template package for the exact markup.

---

## JavaScript: Swiper initialization

`Presentation/Organism/Slider.ts` reads the `data-swiper` attribute of every `.slider-swiper` element and passes the parsed object to `new Swiper(...)`, together with the Navigation, Pagination, Scrollbar, FreeMode, Autoplay, Thumbs, and EffectFade Swiper modules. Before that, it:

1. Disables `simulateTouch` in the Neos backend, so the slider does not interfere with inline editing.
2. Reads an initial slide index from the URL hash, in the form `#slide-<n>` (1-based position) or `#slide-<name>` (matches `[data-swiper-tab-identifier]` inside the slider).
3. Resolves `navigation.nextEl` / `navigation.prevEl` / `pagination.el` from CSS selectors to elements, scoped to the slider.
4. Builds a second `Swiper` instance for the thumbnail strip, when `thumbs.swiper.el` is set.
5. Applies `breakpointOverrides`, when present: a set of alternative breakpoints, each gated by a condition. The only condition implemented today is `slideCountLowerThen`, which applies its breakpoints only when the slide count is below the given value.
6. Re-applies the initial-slide lookup on `hashchange` and scrolls to the new slide.

---

## DataSources

| Identifier | Configuration path read | Category filter |
|---|---|---|
| `formatd-designsystem-slider-presets` | `FormatD.DesignSystem.Components.Slider.presets` | `slider` |
| `formatd-designsystem-gallery-presets` | `FormatD.DesignSystem.components.slider.presets` | `gallery` |

Both classes extend `FormatD.DesignSystem.Core\DataSource\AbstractSettingsDataSource` and only override the configuration path and the category to filter by. The inspector's `SelectBoxEditor` for `Content.Slider.preset` and `Content.Gallery.preset` uses these DataSources through `editorOptions.dataSourceIdentifier`.

> `SliderPresetsDataSource::getConfigurationPath()` returns `'FormatD.DesignSystem.Components.Slider.presets'`, but `GalleryPresetsDataSource::getConfigurationPath()` returns `'FormatD.DesignSystem.components.slider.presets'` (lower-case `components.slider`). YAML keys are case-sensitive only in the package segment casing that `Configuration.setting` expects; this inconsistency exists in the source as shipped.
