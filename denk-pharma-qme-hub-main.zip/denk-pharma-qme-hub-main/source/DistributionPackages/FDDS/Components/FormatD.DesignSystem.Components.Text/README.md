# FormatD.DesignSystem.Components.Text

A set of text content elements for Neos CMS: Headline, Text, Quote, Alert, Button, Button Area, Icon Link, and Table. The package defines a NodeType and a Fusion prototype for each element. Most prototypes only declare a property contract (`@propTypes`). A design theme package (for example the site's `Design` package) supplies the actual HTML markup for these prototypes.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `Mixin.OptionsGroup`, `Mixin.NodeLink`, `Mixin.ContentSection`, `Mixin.InlineTitle`, `Mixin.HorizontalPosition`, `Mixin.InlineText`, `Content.ContentCollection` base prototype, `FDDS.String` Eel helper |
| `Neos.Neos` | `Content`, `ContentComponent`, `ContentCollection` base prototypes, `Editable`, `ConvertUris`, inspector editors |
| `Neos.NodeTypes.BaseMixins` | `TextMixin`, the base of `Mixin.TextStyles` |
| `FormatD.DesignSystem.Components.Icons` | `Mixin.Icon`, the icon picker on Button and Icon Link |
| `Neos.Fusion` | AFX rendering, the `String` Eel helper |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeTypes

| NodeType | Purpose | Key properties |
|---|---|---|
| `Content.Headline` | A heading with alignment and semantic level | `title`, `semanticHierarchy` (H1–H6 or none), `styleHierarchy` (visual style 1–6), `horizontalPosition` |
| `Content.Text` | A rich text block | `text` (formatted with `Mixin.TextStyles` paragraph styles, plus left/right/center alignment) |
| `Content.Quote` | A pull quote with an author line | `text`, `author` |
| `Content.Alert` | An info/warning/error/success message box | `type`, `style` (`default` or `bg-color`), `title`, `text` |
| `Content.Button` | A button that links to a page, asset, or content section | `title`, `link`, `contentSection`, `style` (`primary`/`standard`/`secondary`), `icon`, `iconPosition` |
| `Content.ButtonArea` | A `ContentCollection` that only accepts `Content.Button` children | `alignment` (`left`/`center`/`right`) |
| `Content.IconLink` | A link with an icon | `title`, `link`, `icon`, `style` (`vertical`/`horizontal`), `iconStyle` (`none`/`withBg`) |
| `Content.Table` | A rich text table | `table` (formatted text with the CKEditor `table` feature) |

### Mixin: `Mixin.TextStyles`

An abstract mixin that extends `Neos.NodeTypes.BaseMixins:TextMixin`. It adds four paragraph style definitions to the `text` property: Large, Default, Small, and Extra Small, plus a Numbered List style for `<li>` elements. `Content.Text` uses this mixin.

```yaml
'My.Package:Content.MyElement':
  superTypes:
    'FormatD.DesignSystem.Components.Text:Mixin.TextStyles': true
```

---

## Fusion interface

Each Content NodeType renders a matching Presentation prototype. `Content.Headline` renders `Atom.Headline`. All other Content NodeTypes render a `Molecule.*` prototype of the same name. `Content.Text` and `Content.Table` are the exception: they render their own markup directly, without a separate Presentation prototype.

```fusion
prototype(FormatD.DesignSystem.Components.Text:Atom.Headline) {
    content            = ''                                   # rendered title
    semanticHierarchy  = 0                                     # 0 (no tag) | 1-6 (renders h1-h6)
    styleHierarchy     = 3                                     # 1-6, visual style only
    horizontalPosition = 'left'                                # 'left' | 'center' | 'right'
}

prototype(FormatD.DesignSystem.Components.Text:Molecule.Quote) {
    content = ''    # quote text
    author  = ''    # author line
}

prototype(FormatD.DesignSystem.Components.Text:Molecule.Alert) {
    type    = 'info'      # 'info' | 'warning' | 'error' | 'success'
    style   = 'default'   # 'default' | 'bg-color'
    title   = ''
    content = ''
}

prototype(FormatD.DesignSystem.Components.Text:Molecule.Button) {
    content      = ''                          # button label
    uri          = ''                          # target link
    style        = 'primary'                   # 'standard' | 'primary' | 'secondary' | 'icon'
    iconName     = null                        # icon file name, or null for no icon
    iconPosition = null                        # 'left' | 'right'
    attributes   = Neos.Fusion:DataStructure    # extra HTML attributes, e.g. target
}

prototype(FormatD.DesignSystem.Components.Text:Molecule.ButtonArea) {
    content   = ''       # rendered Content.Button children
    alignment = 'left'   # 'left' | 'center' | 'right'
}

prototype(FormatD.DesignSystem.Components.Text:Molecule.IconLink) {
    title     = ''
    iconName  = ''
    uri       = ''
    style     = 'horizontal'   # 'vertical' | 'horizontal'
    iconStyle = 'none'         # 'none' | 'withBg'
}
```

> [!warning] Renderer lives in the theme package
> Inside this package, `Atom.Headline` and every `Molecule.*` prototype only declares `@propTypes`. Neither prototype has a `renderer`. A theme package, such as the site's `Design` package, extends the same prototype names and adds the `renderer` with the real AFX markup. Without such a theme package, these prototypes render nothing.

### `Content.Text` and `Content.Table`

These two NodeTypes render their editable property directly, wrapped in a `<div>`. They do not delegate to a separate Presentation prototype.

```fusion
prototype(FormatD.DesignSystem.Components.Text:Content.Text) < prototype(Neos.Neos:ContentComponent) {
    content = Neos.Neos:Editable {
        property = 'text'
    }
    renderer = afx`<div class="text-wrapper">{props.content}</div>`
}
```

---

## Worked examples

```fusion
'My.Package:Content.MyElement':
  superTypes:
    'Neos.Neos:Content': true
    'FormatD.DesignSystem.Components.Icons:Mixin.Icon': true
```

```fusion
prototype(My.Package:Content.MyElement) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Text:Molecule.IconLink {
        title    = Neos.Neos:Editable { property = 'title' }
        iconName = ${node.properties.icon}
        uri      = ${node.properties.link}
        style    = 'horizontal'
    }
}
```

`Content.Button` resolves its target from either a direct `link` property or a reference to a `contentSection` node. When a `contentSection` reference is set and no `link` is set, the button links to an in-page anchor built from the referenced section's title:

```fusion
uri.@process.replaceWithAnchorIfConfigured = ${contentSectionNode
    ? '#' + FDDS.String.slugify(contentSectionNode.properties.title)
    : value}
```
