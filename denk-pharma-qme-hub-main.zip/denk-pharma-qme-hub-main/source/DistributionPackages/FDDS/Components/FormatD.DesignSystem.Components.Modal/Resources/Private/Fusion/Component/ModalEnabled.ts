// @ts-ignore
import ModalManager from "../../JavaScript/ModalManager"
// @ts-ignore
import Logger from "../../../../../../Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";


export default class ModalEnabled extends AbstractComponentManager {
  initialize(domSection) {
    const modalEnabledContainers = <NodeListOf<HTMLElement>>domSection.querySelectorAll('[data-component="modal-enabled"]');
    if (modalEnabledContainers.length < 1) return;

    const logger = new Logger('ModalEnabled');
    const modalManager = this.buildModalManager();
    logger.log('ModalEnabled initialized for: ', domSection);

    for (const container of modalEnabledContainers) {
      logger.log('initializing modal-enabled container', container);

      // registering allowed uri patterns
      this.registerAllowedUriPattern(modalManager, container, container.dataset.modalAllowedUriPattern);

      // add custom class to default template when template is used
      this.addCustomClass(modalManager);

      // make all nested links modal enabled or the container if it is a link itself
      this.makeModalEnabled(modalManager, container, logger)

      modalManager.attach(container)
    }

    modalManager.run();
  }

  buildModalManager() {
    return new ModalManager();
  }

  registerAllowedUriPattern(modalManager, container, allowedUriPattern) {
    if (allowedUriPattern) {
      modalManager.registerModalPattern(container.dataset.modalType, container.dataset.modalAllowedUriPattern, container.dataset.modalSection, { modalClass: container.dataset.modalClass });
    }
  }

  addCustomClass(modalManager) {
    modalManager.registerTemplateModification(function (template, data) {
      if (data.additionalData.modalClass) {
        template.content.firstElementChild.classList.add(data.additionalData.modalClass);
      }
    });
  }

  makeModalEnabled(modalManager, container, logger) {
    const modalEnabledLinks = container.nodeName === 'A' ? [container] : container.querySelectorAll('a');

    for (const item of modalEnabledLinks) {
      logger.log('modal-enabled links:', item);
      modalManager.registerModalCall(container.dataset.modalType, item.getAttribute('href'), container.dataset.modalSection, { modalClass: container.dataset.modalClass });

      item.addEventListener('click', function (event) {
        event.preventDefault();

        switch (container.dataset.modalType) {
          case 'ajax':
            logger.log('Type: ajax', this.getAttribute('href'), event, container.dataset.modalSection);
            modalManager.openAjaxModal(this.getAttribute('href'), container.dataset.modalSection);
            break;
          case 'inline':
            logger.log('Type: inline', event, container.dataset.modalSection);
            modalManager.openInlineModal(container.dataset.modalSection);
            break;
          case 'iframe':
            logger.log('Type: iframe', this.getAttribute('href'), event);
            modalManager.openIframeModal(this.getAttribute('href'));
            break;
          default:
            logger.log('Modal Type not Implemented!');
            break;
        }
      });
    }
  }
}
