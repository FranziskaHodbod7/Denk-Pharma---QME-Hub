// @ts-ignore
import Logger from "../../../../../Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"

// @ts-ignore
import { DesignSystem } from "../../../../../Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/DesignSystem"
import { ComponentLoaderModalReloadEvent} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/Events";


export interface ModalManagerState {
	modalOpen: any,
	uri: string,
	modalSection: string,
	content: any,
	type: any
}

/**
 * @todo: prevent unwanted urls/sections from being loaded via deeplink
 *
 * Missing Features:
 * - Multiple ModalManagers per page
 */
export default class ModalManager {

	protected logger: Logger
	protected body: HTMLElement
	protected state: ModalManagerState = { modalOpen: null, uri: '', modalSection: '', content: null, type: null }

	protected registeredModalCalls: Map<any, any> = new Map();
	protected registeredModalPatterns: any[] = [];
	protected registeredTemplateModifications: any[] = [];
	protected enableDeeplinks: boolean = true;

	protected template: HTMLTemplateElement = <HTMLTemplateElement><unknown>undefined

	constructor() {
		this.logger = new Logger('ModalManager');
		this.body = document.querySelector('body');
	}

	/**
	 * @api
	 *
	 * This should be called after all configuration is done to make ModalManager handle modals
	 */
	run() {
		// init if initialUri is deeplink
		this.initDeeplinkModalCall();

		window.history.replaceState(this.state, null, "");
		this.updateModalState(this.state, true);

		window.addEventListener('popstate', this.onPopState);
	}

	/**
	 * @api
	 *
	 * Call this method to open an ajax modal
	 * @param {string} uri
	 * @param {string} modalSection QuerySelector to use for "cutting" out the content of the loaded paged
	 * @param {boolean} dispatchEvaluateJsEvent
	 */
	openAjaxModal(uri, modalSection, dispatchEvaluateJsEvent = true) {
		this.openModal(uri, modalSection, null, 'ajax', dispatchEvaluateJsEvent);
		window.history.pushState({ modalOpen: true, uri: uri, modalSection: modalSection, content: null, type: 'ajax' }, null, "#" + encodeURIComponent(modalSection) + '|' + encodeURIComponent(uri) + '|ajax');
	}

	/**
	 * @api
	 *
	 * Call this method to open an iframe modal
	 * @param {string} uri
	 */
	openIframeModal(uri) {
		this.openModal(uri, '', null, 'iframe');
		window.history.pushState({ modalOpen: true, uri: uri, modalSection: '', content: null, type: 'iframe' }, null, "#" + '|' + encodeURIComponent(uri) + '|iframe');
	}

	/**
	 * @api
	 *
	 * Call this method to open an inline modal (content is not loaded by ajax but taken from current page)
	 * @param {string} modalSection QuerySelector to use for "cutting" out the content of the current page
	 * @param {boolean} dispatchEvaluateJsEvent
	 */
	openInlineModal(modalSection, dispatchEvaluateJsEvent = true) {
		const uri = '';
		this.openModal(uri, modalSection, null, 'inline', dispatchEvaluateJsEvent);
		window.history.pushState({ modalOpen: true, uri: uri, modalSection: modalSection, content: null, type: 'inline' }, null, "#" + encodeURIComponent(modalSection) + '||inline');
	}

	/**
	 * @api
	 *
	 * Register url-section-type combinations to be callable via deeplink (prevent unwanted combinations)
	 */
	registerModalCall(type, uri, modalSection, additionalData) {
		this.logger.log('register modal call: ', type, uri, modalSection, additionalData);

		if (type === 'inline') {
			uri = '';
		}
		if (modalSection === undefined) {
			modalSection = '';
		}

		const hash = '#' + encodeURIComponent(modalSection) + '|' + encodeURIComponent(uri) + '|' + type;
		this.registeredModalCalls.set(hash, {modalSection: modalSection, uri: uri, type: type, additionalData: additionalData});
	}

	/**
	 * @api
	 *
	 * Register urlPattern-section-type combinations to be callable via deeplink (prevent unwanted combinations)
	 */
	registerModalPattern(type, uriPattern, modalSection, additionalData) {
		this.logger.log('register modal pattern: ', type, uriPattern, modalSection, additionalData);

		if (modalSection === undefined) {
			modalSection = '';
		}
		this.registeredModalPatterns.push({modalSection: modalSection, uriPattern: uriPattern, type: type, additionalData: additionalData});
	}

	/**
	 * @api
	 *
	 * Register function for modifying template clone right before usage (for example to add custom class)
	 */
	registerTemplateModification(callback) {
		this.registeredTemplateModifications.push(callback);
	}

	/**
	 * init deeplink
	 */
	initDeeplinkModalCall() {

		const initialUrl = new URL(decodeURI(window.location.href));
		if (initialUrl.hash && [...initialUrl.hash].filter(char => char === '|').length === 2) {
			let [modalSection, uri, type] = initialUrl.hash.substring(1).split('|').map(item => decodeURIComponent(item));

			// validate if deeplink is allowed:
			if (!this.enableDeeplinks) {
				this.logger.error('Deeplinking disabled!');
				return;
			}

			this.logger.log(this.registeredModalCalls);
			this.logger.log(initialUrl.hash);

			if (!this.registeredModalCalls.get(initialUrl.hash)) {

				let allowed = false;
				this.registeredModalPatterns.forEach(function(item) {
					if (item.modalSection == modalSection && item.type == type && (new RegExp(item.uriPattern)).test(uri)) {
						allowed = true;
					}
				});

				if (!allowed) {
					this.logger.error('disallowed deeplink', initialUrl.hash, modalSection, uri, type);
					return;
				}
			}

			this.logger.log('init deeeplink', initialUrl.hash, modalSection, uri, type);
			this.state = {...this.state, modalOpen: true, modalSection, uri, type}
		}

	}

	/**
	 * @api
	 *
	 * Sets the modal template to use
	 * @param {HTMLTemplateElement} template
	 */
	setTemplate(template) {
		this.template = template;
	}

	/**
	 * Opens or closes modal depending on history state
	 * @param {{modalSection: *, modalOpen: *, uri: *, content: *, type: *}} state
	 * @param {boolean} init
	 */
	updateModalState(state, init = false) {
		this.logger.log('updateModalState', state.modalOpen);
		if (state.modalOpen === true) {
			this.openModal(state.uri, state.modalSection, state.content, state.type);
		} else if (init === false) {
			this.closeModal()
		}
	}

	/**
	 * @param {string} uri
	 * @param {string} modalSection
	 * @param {Element} content
	 * @param {string} type
	 * @param {boolean} dispatchEvaluateJsEvent
	 */
	openModal(uri, modalSection, content, type, dispatchEvaluateJsEvent = true) {
		this.logger.log('openModal', uri, modalSection, content, type);
		const template = this.getTemplate();
		const additionalData = this.getAdditionalDataForModalCall(uri, modalSection, type);
		this.registeredTemplateModifications.forEach(item => item(template, {uri: uri, modalSection: modalSection, content: content, type: type, additionalData: additionalData}));

		const contentSection = template.content.querySelector('.modal .modal-content-section');

		let urlValidated = false;
		if (content) {
			contentSection.innerHTML = '';
			contentSection.appendChild(content);
		} else if (uri) {
			// allow only relative uris without hostname
			if (!this.isValidModalCall(uri, modalSection, type)) {
				contentSection.innerHTML = '';
				contentSection.appendChild(document.createElement('p').appendChild(document.createTextNode('ERROR: Content could not be loaded!')));
			} else {
				urlValidated = true;
				if (type === 'ajax') {
					fetch(uri)
						.then(response => response.text())
						.then(text => {
							const parser = new DOMParser();
							const htmlDocument = parser.parseFromString(text, "text/html");
							this.injectModalContent(htmlDocument.documentElement.querySelector(modalSection), dispatchEvaluateJsEvent);
						})
						.catch(e => {
							this.logger.log('ModalManagerFetchingError', e);
						});
				}
			}
		}

		template.content.querySelectorAll(".modal-close, .modal-overlay").forEach(
			closeButton => closeButton.addEventListener("click", this.onCloseClick)
		);

		document.addEventListener('keydown', this.onCloseKey);

		this.body.prepend(template.content);
		document.dispatchEvent(new Event('fdds.modal.opened'));

		// if there is no uri it is inline type => just load content from same page
		if (type === 'inline') {
			this.injectModalContent(this.body.querySelector(modalSection).cloneNode(true), dispatchEvaluateJsEvent);
		} else if (type === 'iframe' && urlValidated) {
			const container = document.createElement('div');
			container.classList.add('iframe-container');
			const iframe = document.createElement('iframe');
			iframe.src = uri;
			iframe.classList.add('modal-iframe');
			const spinner = document.createElement('div');
			spinner.classList.add('loading-spinner');
			iframe.addEventListener('load', (event) => spinner.remove());
			container.appendChild(iframe);
			container.appendChild(spinner);
			this.injectModalContent(container, false);

			ModalManager.FixChromeOniOSiFrameUri(iframe, uri)
		}
	}

	onPopState = function (event) {
		this.logger.log('onpopstate', event.state);
		if (event.state) {
			this.state = event.state;
			this.updateModalState(this.state);
		}
	}.bind(this);

	onCloseClick = function(event) {
		event.preventDefault();
		this.triggerModalClose();
	}.bind(this);

	onCloseKey = function(event) {
		let isEscape = false;
		if ("key" in event) {
			isEscape = (event.key === "Escape" || event.key === "Esc")
		} else {
			isEscape = (event.keyCode === 27)
		}
		if (isEscape) {
			this.triggerModalClose();
		}
	}.bind(this);

	triggerModalClose() {
		this.closeModal();
		const url = new URL(window.location.toString())
		url.hash = ''
		window.history.pushState({ displayModal: false, uri: '', modalSection: '', content: null, type: null }, null, url.toString());
	}

	/**
	 * Closes and removes modal
	 */
	closeModal() {
		this.logger.log('closeModal');
		this.body.querySelector('.modal').remove();
		document.removeEventListener('keydown', this.onCloseKey);
		document.dispatchEvent(new Event('fdds.modal.closed'));
	}

	/**
	 * Inject content into modal when it has been loaded by ajax (replacing the loader)
	 * @param {Element} content
	 * @param {boolean} dispatchEvaluateJsEvent
	 */
	injectModalContent(content, dispatchEvaluateJsEvent = true) {
		this.logger.log('Injecting modal content: ', content);
		const contentSection = <HTMLElement>this.body.querySelector('.modal .modal-content-section'),
			isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
		contentSection.innerHTML = '';
		contentSection.appendChild(content);

		// Workaround for bug in Safari where the images are not loaded
		if(isSafari) {
			contentSection.querySelectorAll('img').forEach(function(img) {
				img.outerHTML = img.outerHTML;
			});
		}

		// Allow closing from elements _inside_ the loaded content as well
		contentSection.querySelectorAll(".custom-modal-close").forEach(
			closeButton => closeButton.addEventListener("click", this.onCloseClick)
		);

		if (dispatchEvaluateJsEvent) {
			document.dispatchEvent(new ComponentLoaderModalReloadEvent(contentSection))
			// document.dispatchEvent(new CustomEvent('fdds.evaluateJs', {detail: {'domSection': contentSection}}));
		}
	}

	/**
	 * Validate if provided url can be loaded without security implications
	 *
	 * (There is additional validation if deeplink is used @see initDeeplinkModalCall)
	 *
	 * @param string uri
	 * @param string modalSection
	 * @param string type
	 * @returns {boolean}
	 */
	isValidModalCall(uri, modalSection, type) {

		let allowed = false;

		this.registeredModalCalls.forEach(function(item) {
			if (item.modalSection == modalSection && item.type == type && item.uri == uri) {
				allowed = true;
			}
		});
		this.registeredModalPatterns.forEach(function(item) {
			if (item.modalSection == modalSection && item.type == type && (new RegExp(item.uriPattern)).test(uri)) {
				allowed = true;
			}
		});

		if (allowed) {
			return true;
		}

		return false;
	}

	/**
	 * get additional data passed during registration of modal call
	 *
	 * @param string uri
	 * @param string modalSection
	 * @param string type
	 * @returns {object}
	 */
	getAdditionalDataForModalCall(uri, modalSection, type) {

		let additionalData = {};

		this.registeredModalPatterns.forEach(function(item) {
			if (item.modalSection == modalSection && item.type == type && (new RegExp(item.uriPattern)).test(uri)) {
				additionalData = item.additionalData;
			}
		});

		this.registeredModalCalls.forEach(function(item) {
			if (item.modalSection == modalSection && item.type == type && item.uri == uri) {
				additionalData = item.additionalData;
			}
		});

		return additionalData;
	}

	/**
	 * @api
	 *
	 * @returns {HTMLTemplateElement}
	 */
	getTemplate() {
		if (this.template) {
			return <HTMLTemplateElement>this.template.cloneNode(true);
		}

		// create default modal template if not set:
		const template = document.createElement('template');
		template.innerHTML = `<!--Modal-->
		<div class="modal">
			<div class="modal-overlay"></div>
			<div class="modal-container">
				<div class="modal-close">
					<svg class="icon-close" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
						<path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"></path>
					</svg>
					<span class="text-close">(Esc)</span>
				</div>

				<!-- Add margin if you want to see some of the overlay behind the modal-->
				<div class="modal-content">
					<div class="modal-close">
						<svg class="fill-current text-black" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
							<path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"></path>
						</svg>
					</div>

					<!--Body-->
					<div class="modal-content-section">
						<div class="loading-spinner"></div>
					</div>
				</div>
			</div>
		</div>`;

		return template;
	}

	/**
	 * @param {HTMLElement} element
	 */
	attach(element) {
		DesignSystem.AttachToElement(element, 'ModalManager', this)
	}

	/**
	 * @param {HTMLElement} element
	 * @return {undefined | ModalManager}
	 */
	static GetFromElement(element) {
		return DesignSystem.GetFromElement(element, 'ModalManager')
	}

	static FixChromeOniOSiFrameUri(iframe: HTMLIFrameElement, uri) {
		// Due to strange behavior in Chrome on iOS we have to set the URI again...
		// Looks bit like LoadMoreEnabled.fixSafariResponsiveImages
		iframe.src = uri
	}
}
