# FormatD.DesignSystem.Components.Modal

A modal-window system for Neos CMS. The package turns a link, or a block of content, into a trigger for a modal. It supports three modal types: ajax, iframe, and inline. It supports deep-linking to a modal through the URL hash. A JavaScript `ModalManager` class opens and closes the modal and reacts to browser history.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base design system configuration, `Logger` and `DesignSystem` JavaScript helpers |
| `FormatD.ComponentLoader` | `Component` Fusion base prototype, `AbstractComponentManager` JavaScript base class, automatic JavaScript loading for the component |
| `Neos.Fusion` | AFX rendering, `Neos.Fusion:Augmenter` |

The package pulls in `FormatD.ComponentLoader` through `formatd/designsystem-core`, not directly in its own `composer.json`.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Fusion interface: `Component.ModalEnabled`

The Fusion prototype marks a piece of content as a modal trigger. It does not render a link by itself. It wraps the given content with data attributes. The client-side `ModalManager` reads these attributes.

```fusion
FormatD.DesignSystem.Components.Modal:Component.ModalEnabled {
    content           = ''            # HTML to wrap with the modal-trigger attributes (required)
    type              = 'ajax'        # 'ajax' | 'iframe' | 'inline'
    section           = 'body'        # CSS selector that selects the content to show, for type 'ajax'
    modalClass        = 'modal-default'  # CSS class added to the root element of the modal template
    inlineContent     = ''            # content shown for type 'inline', before the modal opens (see below)
    inlineId          = <auto>        # unique id; set a fixed value to allow deep-linking to an inline modal
    allowedUriPattern = null          # regular expression string; allows deep-linking to a matching URL
    includeJs         = null          # declared prop; the renderer does not read it (see note below)
}
```

> The renderer picks a click target from `type`:
> - `inline` — targets `#<inlineId>`
> - `iframe` — targets nothing
> - every other type — targets `section`

> `includeJs` is part of the strict `@propTypes` block, but the renderer does not use its value. Treat it as reserved for now.

### Rendered HTML

```html
<span data-component="modal-enabled"
      data-modal-type="ajax"
      data-modal-section="body"
      data-modal-class="modal-default"
      data-modal-allowed-uri-pattern="">
    <!-- {content} -->
</span>
<div class="modal-enabled--inline-content" id="modal_xyz">
    <!-- {inlineContent}, only for type 'inline' with inlineContent set -->
</div>
```

`Neos.Fusion:Augmenter` adds the `data-*` attributes to the outermost element of `content`, or wraps `content` in a `<span>` when it has no single root element.

### Modal types

| `type` | Behavior |
|---|---|
| `ajax` | Loads the linked URL by `fetch`. Cuts out the element that matches `section` from the response. Injects it into the modal. |
| `iframe` | Loads the linked URL in an `<iframe>` inside the modal. |
| `inline` | Copies the element that matches `section` from the current page into the modal. Set `inlineContent` and a stable `inlineId` to mark that element. |

### Deep-linking

The package writes the open modal to `window.history` as a URL hash in the form `#<section>|<uri>|<type>`. A visitor can open a page directly into a modal state through this hash. `ModalManager` allows a hash only if:

1. It matches a call the page registered while rendering (`registerModalCall`), or
2. It matches a pattern set through `allowedUriPattern` (`registerModalPattern`).

Set `allowedUriPattern` on `Component.ModalEnabled` to allow deep-linking to more than one exact URL, for example a listing of similar ajax targets.

---

## Modal size and appearance

The bundled SCSS defines size classes for the `.modal` root element. Pass one of these values as `modalClass` to change the width of `.modal-container`.

| Class | `.modal-container` max width |
|---|---|
| `size-large` | 1280px |
| `size-default` | 1024px |
| `size-medium` | 768px |
| `size-small` | 640px |
| `size-extra-small` | 28rem (448px) |

Without one of these classes, `.modal-container` keeps its default max width of 1280px.

---

## JavaScript: `ModalManager`

`ModalManager` (`Resources/Private/JavaScript/ModalManager.ts`) is the class that opens, closes, and tracks the modal. `ModalEnabled.ts` is the component manager that the design system's component loader attaches to every `[data-component="modal-enabled"]` element. It builds one `ModalManager`, registers the allowed patterns and links found in the DOM section, and calls `run()`.

Public methods (marked `@api` in the source):

| Method | Signature | Description |
|---|---|---|
| `run` | `()` | Starts deep-link handling and listens for `popstate`. Call this once, after registration is done. |
| `openAjaxModal` | `(uri, modalSection, dispatchEvaluateJsEvent?)` | Opens a modal and loads `uri` by `fetch`, then shows the part that matches `modalSection`. |
| `openIframeModal` | `(uri)` | Opens a modal with `uri` in an `<iframe>`. |
| `openInlineModal` | `(modalSection, dispatchEvaluateJsEvent?)` | Opens a modal with the current page's element that matches `modalSection`. |
| `registerModalCall` | `(type, uri, modalSection, additionalData)` | Allows one exact type/uri/section combination for deep-linking. |
| `registerModalPattern` | `(type, uriPattern, modalSection, additionalData)` | Allows a family of URLs, matched by regular expression, for deep-linking. |
| `registerTemplateModification` | `(callback)` | Registers a function that can change the modal template clone before use, for example to add `modalClass`. |
| `setTemplate` | `(template)` | Replaces the default modal `<template>` markup. |
| `attach` / `GetFromElement` | `(element)` | Attaches the instance to a DOM element, or reads it back, through `DesignSystem.AttachToElement`. |

The manager dispatches two DOM events on `document`: `fdds.modal.opened` and `fdds.modal.closed`. It dispatches a `ComponentLoaderModalReloadEvent` (from `FormatD.ComponentLoader`) after it injects ajax content, so other components can re-run their JavaScript inside the new markup.

A link inside a `modal-enabled` container closes the modal when it has the class `custom-modal-close`. The default template's `.modal-close` and `.modal-overlay` elements, and the Escape key, do the same.
