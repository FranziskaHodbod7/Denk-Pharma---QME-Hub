# FormatD.DesignSystem.Components.Structural

Structural layout components for Neos CMS: `Section` and column-based content areas (`TwoColumns`, `ThreeColumns`, `FourColumns`). Each component defines a NodeType, a child `Neos.Neos:ContentCollection`, and a Fusion prototype that maps node properties to a `Molecule` component. The package declares only the prop contract of each `Molecule` component. A design or template package supplies the actual markup.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `Content.ContentCollection` base prototype, `OptionsGroup`, `PositionedImageMixin`, and `ImageOverlay` mixins |
| `Neos.Neos` | `ContentCollection` node type, inspector select-box editors |
| `Neos.Fusion` | Rendering with AFX |
| `Sitegeist.Kaleidoscope` | `AssetImageSource` used by `Content.Section` for its background image |

> [!warning]
> `composer.json` does not list `sitegeist/kaleidoscope` as a requirement, but `NodeTypes/Content/Section.fusion` uses `Sitegeist.Kaleidoscope:AssetImageSource`. A project that installs this package on its own, without the sibling `FormatD.DesignSystem.Components.Teaser` package or another package that pulls in Kaleidoscope, may see this prototype unresolved.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## How the package fits together

Each NodeType folder under `NodeTypes/Content/` has a matching `.yaml` and `.fusion` file. Neos loads the Fusion file through the `nodetypes://` include in `Root.fusion`. The Fusion prototype maps node properties to a `Molecule.*` component.

The `Molecule.*` prototypes live under `Resources/Private/Fusion/Presentation/Molecule/`. Each one declares only a `@propTypes` block. None of them sets a `renderer`. This package leaves the actual AFX markup to a downstream design or template package (for example `DenkPharma.Design` or `FormatD.DesignSystem.Template.Gunther` in this repository), which redeclares the same prototype name with `< prototype(Neos.Fusion:Component)` and adds the `renderer`.

```fusion
# supplied by a downstream design package, not by this package
prototype(FormatD.DesignSystem.Components.Structural:Molecule.Section) < prototype(Neos.Fusion:Component) {
    renderer = afx`
        <section>...</section>
    `
}
```

---

## NodeTypes

### `Content.Section`

`Content.Section` extends `Neos.Neos:ContentCollection`. It also extends the Core mixins `PositionedImageMixin`, `ImageOverlay`, and `OptionsGroup`. Only `TwoColumns`, `ThreeColumns`, and `FourColumns` can nest inside a `Section`; a `Section` cannot nest inside another `Section`.

| Property | Type | Values | Purpose |
|---|---|---|---|
| `title` | string | free text | Anchor target for a link (for example a button that jumps to this section) |
| `contentWidth` | string | `default`, `small`, `full` | Width of the content area |
| `contentHeight` | string | `default`, `full` | Height of the content area |
| `spacing` | string | `none`, `small`, `medium`, `large` | Top and bottom padding |
| `margin` | string | `none`, `small`, `medium`, `large` | Bottom margin |
| `style` | string | `light`, `dark` | Color theme |

The Fusion prototype maps `title`, `contentWidth`, `contentHeight`, `spacing`, `margin`, and `style` straight to `Molecule.Section`. It also builds `imageSource` from `Sitegeist.Kaleidoscope:AssetImageSource`, and maps `horizontalPosition`, `verticalPosition`, `overlayColor`, and `overlayOpacity` from the mixins.

### `Content.Columns` (abstract)

`Content.Columns` is the abstract base for the three column NodeTypes. It extends the `Mixin.ColumnGap` and `OptionsGroup` mixins. Its Fusion prototype counts the child nodes with `q(node).children().count()` and passes the result to `Molecule.Columns` as `colCount`.

### `Content.TwoColumns`, `Content.ThreeColumns`, `Content.FourColumns`

Each of these extends `Content.Columns` and adds two, three, or four `column0`…`column3` child nodes of type `Content.ColumnCollection`. `Content.TwoColumns` also extends `Mixin.ColumnLayout`, so it has a `layout` property. `Content.ThreeColumns` and `Content.FourColumns` do not have a `layout` property; the base `Molecule.Columns` renderer always reads `node.properties.layout ? node.properties.layout : 'even'`, so they render with `layout: 'even'`.

| NodeType | Column count | Extra mixin |
|---|---|---|
| `Content.TwoColumns` | 2 | `Mixin.ColumnLayout` (`layout` property) |
| `Content.ThreeColumns` | 3 | — |
| `Content.FourColumns` | 4 | — |

Each of the three NodeTypes also overrides the default image sizes for `FormatD.DesignSystem.Components.Media:Molecule.Image` inside its columns (`defaultSizes`). An image inside a two-, three-, or four-column layout then requests a size that matches its column width.

> [!warning]
> `Content.TwoColumns` fully replaces the `renderer` of `Content.Columns` and does not map `colGap` to `Molecule.Columns`. An editor can still set `colGap` in the inspector, because `Content.TwoColumns` inherits `Mixin.ColumnGap` through `Content.Columns`, but the value never reaches the renderer. `Content.ThreeColumns` and `Content.FourColumns` do not override the renderer, so their `colGap` value does reach `Molecule.Columns`.

### `Content.ColumnCollection`

`Content.ColumnCollection` is the child collection type used by every column slot (`column0`, `column1`, and so on). It extends `Neos.Neos:ContentCollection`. A `Content.Section` cannot nest inside a `Content.ColumnCollection`. Its Fusion prototype renders `Molecule.Column` and adds a cache entry tag for its parent node, so the cache for one column invalidates when the parent node changes.

---

## NodeType mixins

| Mixin | Property | Purpose |
|---|---|---|
| `Mixin.ColumnGap` | `colGap` (`none`, `small`, `medium`, `large`) | Gap between columns |
| `Mixin.ColumnLayout` | `layout` (`even`, `30-70`, `70-30`) | Width ratio between two columns |

```yaml
'My.Package:Content.MyElement':
  superTypes:
    'FormatD.DesignSystem.Components.Structural:Mixin.ColumnGap': true
    'FormatD.DesignSystem.Components.Structural:Mixin.ColumnLayout': true
```

---

## Fusion interface

```fusion
FormatD.DesignSystem.Components.Structural:Molecule.Section {
    title = ''                # heading / anchor text
    content = ''               # rendered child content
    contentWidth = null        # 'default' | 'small' | 'full'
    contentHeight = null       # 'default' | 'full'
    spacing = null             # 'none' | 'small' | 'medium' | 'large'
    margin = null              # 'none' | 'small' | 'medium' | 'large'
    style = null               # 'light' | 'dark'
    imageSource = null         # Sitegeist.Kaleidoscope image source
    imageAlt = ''              # image alt text
    horizontalPosition = null  # 'left' | 'center' | 'right'
    verticalPosition = null    # 'top' | 'center' | 'bottom'
    overlayColor = ''          # overlay color name
    overlayOpacity = null      # overlay opacity value
}

FormatD.DesignSystem.Components.Structural:Molecule.Columns {
    colCount = 0        # number of columns (required)
    content = null       # rendered child content
    layout = null        # 'even' | '70-30' | '30-70'
    colGap = null        # 'none' | 'small' | 'medium' | 'large'
}

FormatD.DesignSystem.Components.Structural:Molecule.Column {
    content = ''         # rendered content of one column
}
```

All three prototypes declare `@strict = true` on their `@propTypes`. Fusion raises an error if the calling code sets a property that is not in this list, or a value that does not match the declared type.
