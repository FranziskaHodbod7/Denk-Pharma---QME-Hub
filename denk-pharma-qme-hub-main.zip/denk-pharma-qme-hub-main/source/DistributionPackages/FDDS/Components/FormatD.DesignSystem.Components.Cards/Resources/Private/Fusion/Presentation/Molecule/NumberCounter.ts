import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";

export default class NumberCounterComponentManager extends AbstractComponentManager {
    initialize(domSection: HTMLElement) {
        const observer = this.createIntersectionObserver()

        const numberCountItems = this.getNumberCounterItems(domSection)
        numberCountItems.forEach((item) => {
            this.attachObserver(observer, item)
        });
    }

    getNumberCounterItems(domSection: HTMLElement): NodeListOf<HTMLElement> {
        return domSection.querySelectorAll('.number-counter')
    }

    attachObserver(observer: IntersectionObserver, item: HTMLElement) {
        observer.observe(item);
    }

    createIntersectionObserver() {
        return new IntersectionObserver((entries, observer) => {
            this.intersectionObserverCallback(entries, observer)
        }, {threshold: 0})
    }

    intersectionObserverCallback(entries: IntersectionObserverEntry[], observer: IntersectionObserver) {
        entries.forEach((entry) => {
            this.handleIntersectionObserverEntry(entry, observer)
        });
    }

    handleIntersectionObserverEntry(entry: IntersectionObserverEntry, observer: IntersectionObserver) {
        if(entry.isIntersecting && entry.intersectionRatio >= 0) {
            const item = entry.target;
            const countTo = parseInt(item.getAttribute('data-number'));
            this.animateValue(item.querySelector('.number-counter--number'), 0, countTo, 1500 + (0.8 * countTo));
        }
    }

    animateValue(obj, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            this.renderValue(obj, progress, start, end, duration)
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }

    renderValue(obj, progress, start, end, duration) {
        obj.innerHTML = Math.floor(progress * (end - start) + start);
    }
}
