# FormatD.DesignSystem.Components.Cards

A set of card content types for Neos CMS. The package defines five NodeTypes: Contact Card, Download Card, Icon Card, Image Card, and Number Counter. Each NodeType has a matching Fusion component. The Download Card also picks a fallback thumbnail image by file type when no asset preview exists.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Base mixins (`PositionedImageMixin`, `InlineTitle`, `InlineText`, `NodeLink`, `OptionsGroup`) and Eel helpers used by the card Fusion prototypes |
| `formatd/designsystem-components-icons` | Icon mixin and icon name property for the Icon Card |
| `sitegeist/kaleidoscope` | Image sources for card images and download thumbnails |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeTypes

| NodeType | Purpose |
|---|---|
| `FormatD.DesignSystem.Components.Cards:Content.ContactCard` | Card with a photo and contact details (phone, mobile, fax, e-mail, web, vCard asset) |
| `FormatD.DesignSystem.Components.Cards:Content.DownloadCard` | Card that links to one asset, with an automatic or custom thumbnail |
| `FormatD.DesignSystem.Components.Cards:Content.IconCard` | Card with an icon, a text, and an optional link |
| `FormatD.DesignSystem.Components.Cards:Content.ImageCard` | Teaser card with title, image, text, and button, usually linked to a document node |
| `FormatD.DesignSystem.Components.Cards:Content.NumberCounter` | Card with a number, a unit, and a count-up animation |

Each NodeType uses `FormatD.DesignSystem.Core:Mixin.OptionsGroup` for its inspector "Options" tab, and most add `Mixin.InlineTitle` for an inline-editable title.

```yaml
# Configuration/NodeTypes.yaml
'MyPackage:Content.MyCard':
  superTypes:
    'FormatD.DesignSystem.Components.Cards:Content.IconCard': true
```

### Style property

Contact Card, Download Card, and Image Card share a `style` property with the values `vertical`, `horizontal`, and `horizontal-small`. Image Card adds a fourth value, `cover`. Icon Card uses only `vertical` and `horizontal`.

### Download Card thumbnail

The Download Card picks a fallback image with a `Neos.Fusion:Case` block, based on the asset media type:

1. A custom `thumbnailImage` on the node, if the editor set one.
2. A bundled fallback SVG for PDF, ZIP, Word, Excel, and PowerPoint files (`Resources/Public/InternalImages/DownloadFallback*.svg`).
3. The asset thumbnail, for images and videos without a thumbnail.
4. The asset's own generated thumbnail as a last resort.

> [!warning]
> The asset media type check compares exact MIME-type lists (for example Word covers five specific MIME types). An unlisted MIME type falls through to the image, video, or default branch instead of failing.

---

## Fusion prototypes

Every NodeType renders through a `Content.*` prototype that extends `Neos.Neos:ContentComponent`. It maps node properties to a strict-typed `Molecule.*` presentation prototype.

```fusion
prototype(FormatD.DesignSystem.Components.Cards:Molecule.ContactCard) {
    title             = ''    # card title (string)
    jobTitle          = ''    # job title text (string)
    text              = ''    # rich text body (string)
    imageSource       = null  # Sitegeist.Kaleidoscope image source (any)
    imageAlt          = ''    # image alt text (string)
    style             = ''    # 'vertical' | 'horizontal' | 'horizontal-small'
    horizontalPosition = ''   # 'left' | 'center' | 'right'
    verticalPosition   = ''   # 'top' | 'center' | 'bottom'
    email             = ''    # e-mail address (string)
    phone             = ''    # phone number (string)
    mobile            = ''    # mobile number (string)
    fax               = ''    # fax number (string)
    web               = ''    # web domain label (string)
    webUri            = ''    # converted link URI (string)
    assetText         = ''    # label for the vCard download (string)
    assetUri          = null  # resource URI of the vCard asset (any)
}

prototype(FormatD.DesignSystem.Components.Cards:Molecule.DownloadCard) {
    title             = ''    # asset title, or file name if no title is set
    metaInfo          = ''    # asset caption (string)
    text              = ''    # rendered file-type and file-size metadata (string)
    uri               = ''    # resource URI of the asset (string)
    imageSource       = null  # thumbnail image source (any)
    imageSourceSrcset = ''    # thumbnail srcset (string, only set for a custom thumbnail)
    imageSourceSizes  = ''    # thumbnail sizes attribute (string, only set for a custom thumbnail)
    style             = ''    # 'vertical' | 'horizontal' | 'horizontal-small'
}

prototype(FormatD.DesignSystem.Components.Cards:Molecule.IconCard) {
    title      = ''  # card title (string)
    text       = ''  # rich text body (string)
    buttonText = ''  # optional button label (string)
    iconName   = ''  # icon file name from the Icon mixin (string)
    uri        = ''  # converted link URI (string)
    style      = ''  # 'vertical' | 'horizontal'
    iconStyle  = ''  # 'none' | 'withBg'
}

prototype(FormatD.DesignSystem.Components.Cards:Molecule.ImageCard) {
    title              = ''    # card title (string)
    metaInfo           = ''    # meta information text (string)
    text               = ''    # rich text body (string)
    buttonText         = ''    # optional button label (string)
    uri                = ''    # converted link URI (string)
    imageSource        = null  # Sitegeist.Kaleidoscope image source (any)
    imageAlt           = ''    # image alt text (string)
    horizontalPosition = ''    # 'left' | 'center' | 'right'
    verticalPosition   = ''    # 'top' | 'center' | 'bottom'
    style              = ''    # 'cover' | 'vertical' | 'horizontal' | 'horizontal-small'
}

prototype(FormatD.DesignSystem.Components.Cards:Molecule.NumberCounter) {
    title  = ''  # card title (string)
    number = ''  # number to count up to (string)
    unit   = ''  # unit label, for example 'Mio.' (string)
}
```

---

## Number Counter animation

The Number Counter Fusion component adds a `.number-counter` element with a `data-number` attribute. A TypeScript component manager (`Resources/Private/Fusion/Presentation/Molecule/NumberCounter.ts`) watches this element with an `IntersectionObserver`. When the element scrolls into view, the manager animates the displayed value from 0 to `data-number`. The animation takes roughly 1.5 seconds, plus extra time proportional to the target number.

---

## Worked example

```fusion
prototype(FormatD.DesignSystem.Components.Cards:Content.IconCard) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Cards:Molecule.IconCard {
        title      = Neos.Neos:Editable { property = 'title' }
        text       = Neos.Neos:Editable { property = 'text' }
        buttonText = Neos.Neos:Editable { property = 'buttonText', block = false }
        iconName   = ${node.properties.icon}
        uri        = ${node.properties.link}
        uri.@process.convertUris = Neos.Neos:ConvertUris { forceConversion = true }
        style      = ${node.properties.style}
        iconStyle  = ${node.properties.iconStyle}
    }
}
```

This is the actual `Content.IconCard` prototype. It shows the pattern every card in this package follows: editable properties feed a strict-typed Molecule component, and links go through `Neos.Neos:ConvertUris`.
