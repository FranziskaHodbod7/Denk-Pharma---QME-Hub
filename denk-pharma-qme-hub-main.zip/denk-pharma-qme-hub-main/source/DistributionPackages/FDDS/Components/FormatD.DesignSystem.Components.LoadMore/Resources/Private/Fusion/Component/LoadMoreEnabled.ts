import Logger from "../../../../../../Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"
import { AbstractComponentManager} from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
import { LoadMoreEnabled } from "../../JavaScript/LoadMoreEnabled";

export default class LoadMoreEnabledComponentManager extends AbstractComponentManager {
	protected loadMoreInstances: Map<HTMLFormElement, LoadMoreEnabled> = new Map()

	initialize(domSection: HTMLElement) {
		const loadMoreEnabledContainers = domSection.querySelectorAll('[data-component="load-more-enabled"]');
		if (loadMoreEnabledContainers.length < 1) return;

		const logger = new Logger('LoadMore');
		logger.log('LoadMoreContainers', loadMoreEnabledContainers);

		loadMoreEnabledContainers.forEach((container: HTMLFormElement) => {
			logger.log('LoadMoreInitializing', container);
			const loadMoreEnabled = new LoadMoreEnabled(container, logger)
			this.loadMoreInstances.set(container, loadMoreEnabled)
		});
	}
}
