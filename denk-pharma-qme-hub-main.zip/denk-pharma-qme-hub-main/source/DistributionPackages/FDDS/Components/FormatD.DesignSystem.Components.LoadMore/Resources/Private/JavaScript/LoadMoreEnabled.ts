import { ComponentLoaderReloadEvent } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/Events";
import { PopulateDataLayerEvent } from "@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.TrackingConsent/Resources/Private/JavaScript/DataLayerPopulator"
import Logger from "@distributionPackages/FDDS/Base/FormatD.DesignSystem.Core/Resources/Private/JavaScript/Logger"

export const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

export class TriggerResetEvent extends CustomEvent<{resetTrigger: true}> {
    constructor() {
        super('submit', { cancelable: true, detail: { resetTrigger: true } } );
    }
}

export class TriggerLoadMoreEvent extends CustomEvent<{loadMoreTrigger: true}> {
    constructor() {
        super('submit', { cancelable: true, detail: { loadMoreTrigger: true } } );
    }
}

export class LoadMoreEnabledEvent extends CustomEvent<{loadMoreEnabled: LoadMoreEnabled}> {
    constructor(type: string, loadMoreEnabled: LoadMoreEnabled) {
        super(type, { cancelable: true, detail: { loadMoreEnabled } } );
    }
}

export class LoadMoreEnabledReloadEvent extends LoadMoreEnabledEvent {
    static Type = "reload"
    constructor(loadMoreEnabled: LoadMoreEnabled) {
        super(LoadMoreEnabledReloadEvent.Type, loadMoreEnabled)
    }
}

export class LoadMoreEnabledReplaceEvent extends LoadMoreEnabledEvent {
    static Type = "replace"
    constructor(loadMoreEnabled: LoadMoreEnabled) {
        super(LoadMoreEnabledReplaceEvent.Type, loadMoreEnabled)
    }
}

export class LoadMoreEnabledErrorEvent extends LoadMoreEnabledEvent {
    static Type = "error"
    constructor(loadMoreEnabled: LoadMoreEnabled) {
        super(LoadMoreEnabledErrorEvent.Type, loadMoreEnabled)
    }
}

export class LoadMoreEnabled {
	protected container: HTMLFormElement
	protected logger: Logger
	protected lastClickedButton: null|HTMLButtonElement|{dataset: DOMStringMap}

	constructor(container: HTMLFormElement, logger: Logger) {
		this.container = container
		this.logger = logger

		this.init()
	}


	init() {
        let submitButtons = this.getAllSubmitButtonsAndAttachListener()

		this.container.addEventListener('submit', async (event: SubmitEvent|TriggerResetEvent|TriggerLoadMoreEvent) => {
			event.preventDefault();
			let uri = this.container.getAttribute('action');
			const containerId = this.container.dataset.loadMoreEnabledId;
			let formData = new FormData(this.container);

			// Check if loadmore-button was clicked or if the form has been submitted in other way (maybe by a filter)
			let mode = '';
			if (this.isLoadMoreTriggered(event)) {
				mode = 'loadMore'
			} else {
				mode = 'reload';
				if (this.isResetTriggered(event)) {
					uri = uri.substring(0, uri.indexOf('?'));
					formData = new FormData();
				}
				formData.set('page', '1');
			}

			this.lastClickedButton = null
			// Add loading to all submit buttons
			submitButtons.forEach(function(item) {
				item.classList.add('loading');
				item.disabled = true;
			});

			try {
                const response = await this.fetchMore(uri, formData)
                const htmlDocument = await this.getDocumentFromResponse(response)

                const ajaxLoadedContainer = htmlDocument.documentElement.querySelector(`[data-load-more-enabled-id="${containerId}"]`);
                const appendContent =  <HTMLElement>ajaxLoadedContainer.querySelector('.load-more-append-content');
                const replaceContent = <HTMLElement>ajaxLoadedContainer.querySelector('.load-more-replace-content');
                const replaceLoadMoreButton = <HTMLButtonElement>ajaxLoadedContainer.querySelector('.load-more-button');

                this.container.setAttribute('action', ajaxLoadedContainer.getAttribute('action'));

                this.replaceOrHideLoadMoreButton(replaceLoadMoreButton)

                if (replaceContent) {
                    this.replaceContent(replaceContent)
                    this.container.dispatchEvent(new LoadMoreEnabledReplaceEvent(this))
                }

                if (mode === 'reload') {
                    // clear all children of appendContent effectively making it a replace if mode is reload (for example when submitting a filter)
                    this.clearAppendContentContainer()
                    this.container.dispatchEvent(new LoadMoreEnabledReloadEvent(this))
                }

                this.appendContent(appendContent)

                window.dispatchEvent(new PopulateDataLayerEvent('loadMoreSubmission', 'loadMore', uri))

                submitButtons = this.getAllSubmitButtonsAndAttachListener()
            } catch(error) {
                this.logger.log('LoadMoreFetchingError', error);
            }
		});
	}

    getAllSubmitButtons(): Array<HTMLButtonElement|HTMLInputElement>{
        const buttons = [...<NodeListOf<HTMLButtonElement|HTMLInputElement>>this.container.querySelectorAll('input[type="submit"], input[type="button"], button')]
        const formId = this.container.id
        if(formId) {
            buttons.push(...<NodeListOf<HTMLButtonElement|HTMLInputElement>>document.querySelectorAll(`input[type="submit"][form="${formId}"], input[type="button"][form="${formId}"], button[form="${formId}"]`))
        }
        return buttons
    }

	getAllSubmitButtonsAndAttachListener() {
		const submitButtons = this.getAllSubmitButtons()
		submitButtons.forEach((button) => {
			button.addEventListener('click', () => {
				this.lastClickedButton = {
					dataset: {
						loadMoreTrigger: button.dataset.loadMoreTrigger,
						resetTrigger: button.dataset.resetTrigger
					}
				}
			})
		})
		return submitButtons
	}

	fetchMore(uri: string, formData: FormData): Promise<Response> {
		return fetch(uri, {method: 'post',body: formData,})
	}

    replaceOrHideLoadMoreButton(replaceLoadMoreButton: HTMLButtonElement = undefined) {
        const loadMoreButton = <HTMLButtonElement>this.container.querySelector('.load-more-button');
        if (loadMoreButton && replaceLoadMoreButton) {
            loadMoreButton.replaceWith(replaceLoadMoreButton);
        } else if (loadMoreButton) {
            loadMoreButton.style.display = "none";
        }
    }

    isLoadMoreTriggered(event: SubmitEvent|TriggerResetEvent|TriggerLoadMoreEvent) {
        return (this.lastClickedButton?.dataset.loadMoreTrigger) || ('detail' in event && 'loadMoreTrigger' in event.detail)
    }

    isResetTriggered(event: SubmitEvent|TriggerResetEvent|TriggerLoadMoreEvent) {
        return (this.lastClickedButton?.dataset.resetTrigger) || ('detail' in event && 'resetTrigger' in event.detail)
    }

    async getDocumentFromResponse(response: Response) {
        const text = await response.text()
        return (new DOMParser()).parseFromString(text, "text/html");
    }

    replaceContent(replaceContent: HTMLElement) {
        const replaceContentContainer = this.container.querySelector('.load-more-replace-content');
        replaceContentContainer.replaceWith(replaceContent);

        // Workaround for bug in Safari where the images are not loaded
        LoadMoreEnabled.fixSafariResponsiveImages(replaceContent);

        // evaluate JS explicitly only for replaced and appended content but not for the form (it has already the loadmore script applied)
        document.dispatchEvent(new ComponentLoaderReloadEvent(replaceContent))
    }

    appendContent(appendContent: HTMLElement) {
        const appendContentContainer = this.container.querySelector('.load-more-append-content');
        let currentChild = null;
        while (appendContent.childNodes.length > 0) {
            currentChild = appendContentContainer.appendChild(appendContent.childNodes[0]);

            // Workaround for bug in Safari where the images are not loaded
            LoadMoreEnabled.fixSafariResponsiveImages(currentChild);

            // evaluate JS explicitly only for replaced and appended content but not for the form (it has already the loadmore script applied)
            document.dispatchEvent(new ComponentLoaderReloadEvent(currentChild))
        }
    }

    clearAppendContentContainer() {
        const appendContentContainer = this.container.querySelector('.load-more-append-content');
        while (appendContentContainer.lastElementChild) {
            appendContentContainer.removeChild(appendContentContainer.lastElementChild);
        }
    }

	static fixSafariResponsiveImages(element: HTMLElement) {
	    if(isSafari) {
			element.querySelectorAll('img').forEach((img) => {
				img.outerHTML = img.outerHTML;
			});
		}
	}
}
