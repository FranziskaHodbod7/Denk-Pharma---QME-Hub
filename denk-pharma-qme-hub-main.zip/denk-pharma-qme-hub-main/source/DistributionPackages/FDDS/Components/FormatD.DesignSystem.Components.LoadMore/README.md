# FormatD.DesignSystem.Components.LoadMore

An AJAX "load more" container for Neos CMS. The package wraps a list of items in a `<form>`. A button in the form fetches more items without a full page reload. The package replaces or appends the returned HTML and toggles the button visibility. This package has no NodeType. Other Fusion code embeds `Component.LoadMoreEnabled` directly, typically around a list of content nodes.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Basic configuration of the design system |
| `Neos.Fusion` | AFX rendering, `PropTypes` |

> [!warning] Consumed but not declared in `composer.json`
> The Fusion renderer extends `FormatD.ComponentLoader:Component` and embeds `FormatD.DesignSystem.Components.Text:Molecule.Button`. Neither package is a `composer.json` requirement. The TypeScript also imports `PopulateDataLayerEvent` from `FormatD.DesignSystem.Components.TrackingConsent` and a `Logger` from `FormatD.DesignSystem.Core`. These imports work because the site builds all packages together with one bundler; they are not visible as PHP dependencies.

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## Fusion prototype: `Component.LoadMoreEnabled`

```fusion
FormatD.DesignSystem.Components.LoadMore:Component.LoadMoreEnabled {
    id = 'load-more-container'      # HTML id and data attribute for this instance
    hasMore = false                 # required boolean; true shows the button, false hides it
    loadUri = ''                    # URL used as the form action and as the fetch target

    content = ''                    # markup appended to the list on every load-more click
    replaceContent = ''             # markup that replaces the "replace" section on every response

    buttonStyle = 'standard'        # passed to Text:Molecule.Button
    buttonText = 'Mehr anzeigen'    # button label
    buttonIconName = 'system-down'  # icon name, passed to Text:Molecule.Button
    buttonIconPosition = 'right'    # 'left' or 'right'
}
```

The prototype extends `FormatD.ComponentLoader:Component`. This registers the rendered markup so `FormatD.ComponentLoader` initializes a matching JavaScript component manager for it.

### Rendered markup

The renderer produces one `<form>` with three marked sections:

```html
<form action="{loadUri}" method="get" class="load-more-enabled" data-component="load-more-enabled" data-load-more-enabled-id="{id}">
    <div class="load-more-replace-content">{replaceContent}</div>
    <div class="load-more-append-content">{content}</div>
    <div class="load-more-button" style="{hasMore ? '' : 'display: none;'}">
        <button type="submit" data-load-more-trigger="true" disabled="{!hasMore}">{buttonText}</button>
    </div>
</form>
```

The button uses `attributes.disabled.@if.hasNotMore={!props.hasMore}`, so the `disabled` attribute is only present when `hasMore` is `false`.

---

## Frontend behavior

`LoadMoreEnabledComponentManager` (`Resources/Private/Fusion/Component/LoadMoreEnabled.ts`) finds every `[data-component="load-more-enabled"]` element in a DOM section. It creates one `LoadMoreEnabled` instance (`Resources/Private/JavaScript/LoadMoreEnabled.ts`) per element.

Each `LoadMoreEnabled` instance listens for `submit` on its `<form>`. A submit happens in three cases:

1. A user clicks the load-more button (`data-load-more-trigger="true"`). The instance sets `mode` to `loadMore`.
2. A user submits the form another way, for example through a filter control. The instance sets `mode` to `reload` and resets the `page` field to `1`.
3. Code dispatches a `TriggerLoadMoreEvent` or `TriggerResetEvent` (both are `submit` events with a `detail` flag) directly on the form.

On submit, the instance does the following:

1. It disables all submit buttons in the form and adds a `loading` class to them.
2. It sends the form data with `fetch(uri, { method: 'post', body: formData })`.
3. It parses the HTML response with `DOMParser` and finds the matching container by `data-load-more-enabled-id`.
4. It updates the form's `action` attribute from the response.
5. It replaces or hides the load-more button, based on the response.
6. It replaces the `.load-more-replace-content` section, if the response has one.
7. In `reload` mode, it clears the `.load-more-append-content` section first.
8. It appends the new items from the response into `.load-more-append-content`.

After each replace or append, the instance re-runs a Safari workaround for `<img>` elements, and it dispatches a `ComponentLoaderReloadEvent` so `FormatD.ComponentLoader` re-initializes any components in the new markup. It also dispatches a `PopulateDataLayerEvent('loadMoreSubmission', 'loadMore', uri)` for tracking.

### Events dispatched on the container

| Event type | When |
|---|---|
| `replace` (`LoadMoreEnabledReplaceEvent`) | The response contained a `.load-more-replace-content` section |
| `reload` (`LoadMoreEnabledReloadEvent`) | The submit was a reload, not a load-more click |
| `error` (`LoadMoreEnabledErrorEvent`) | Not dispatched in the current code; the class only logs fetch errors with `Logger` |

### Styling

`LoadMoreEnabled.scss` centers `.load-more-button` with `display: flex; justify-content: center;` and adds a `3.5rem` bottom margin. It adds no other rules.
