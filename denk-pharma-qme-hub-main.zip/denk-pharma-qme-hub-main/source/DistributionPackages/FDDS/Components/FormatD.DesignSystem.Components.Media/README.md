# FormatD.DesignSystem.Components.Media

Image content components for Neos CMS. The package adds two NodeTypes: `Content.Image`, a single image with an optional caption and link, and `Content.ImageArea`, a content collection that only accepts `Content.Image` children. The package maps both to Fusion prototypes that carry the resolved props. It does not render the final HTML itself — see the note in the Fusion section below.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | `ContentCollection` base prototype, position and options mixins |
| `sitegeist/kaleidoscope` | `AssetImageSource` for the image asset |
| `moc/imageoptimizer` | Optimizes generated thumbnail images (jpg, png, gif, svg) for the web |
| `Neos.Neos` | `ContentComponent`, `Editable`, inspector editors |
| `Neos.Fusion` | AFX rendering, `PropTypes`, `Case` |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## NodeType: `Content.Image`

```yaml
'FormatD.DesignSystem.Components.Media:Content.Image':
  superTypes:
    'Neos.Neos:Content': true
    'Neos.NodeTypes.BaseMixins:ImageMixin': true
    'Neos.NodeTypes.BaseMixins:ImageCaptionMixin': true
    'Neos.NodeTypes.BaseMixins:LinkMixin': true
    'FormatD.DesignSystem.Core:Mixin.OptionsGroup': true
```

`ImageMixin` adds the `image`, `alternativeText`, and `title` properties. `ImageCaptionMixin` adds `hasCaption` and `caption`. `LinkMixin` adds `link`. The NodeType itself adds one more property.

| Property | Type | Notes |
|---|---|---|
| `maxWidth` | string | Label "Max-Width (px)"; shown in the "image" inspector group |

## NodeType: `Content.ImageArea`

```yaml
'FormatD.DesignSystem.Components.Media:Content.ImageArea':
  superTypes:
    'Neos.Neos:Content': true
    'Neos.Neos:ContentCollection': true
    'FormatD.DesignSystem.Core:Mixin.OptionsGroup': true
    'FormatD.DesignSystem.Core:Mixin.HorizontalPosition': true
    'FormatD.DesignSystem.Core:Mixin.VerticalPosition': true
  constraints:
    nodeTypes:
      '*': false
      'FormatD.DesignSystem.Components.Media:Content.Image': true
```

`Content.ImageArea` only accepts `Content.Image` child nodes. `HorizontalPosition` and `VerticalPosition` add the `horizontalPosition` (default `left`) and `verticalPosition` (default `top`) select boxes; `Content.ImageArea` overrides both defaults in its own `properties` block.

---

## Fusion prototypes

### `Content.Image` (NodeType renderer)

```fusion
prototype(FormatD.DesignSystem.Components.Media:Content.Image) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Media:Molecule.Image {
        imageSource = Sitegeist.Kaleidoscope:AssetImageSource   # from node.properties.image
        alternativeText = ${node.properties.alternativeText}
        title = ${node.properties.title ? node.properties.title : node.properties.image.title}  # falls back to the asset title
        hasCaption = ${node.properties.hasCaption}
        caption = Neos.Fusion:Case {
            # the asset's own caption wins over the node's editable caption property
        }
        uri = ${node.properties.link}
        maxWidth = ${node.properties.maxWidth}
    }
}
```

The `caption` prop resolves in this order:

1. If the image asset itself has a caption, the renderer uses that caption unchanged.
2. Otherwise, the renderer wraps the node's `caption` property in `Neos.Neos:Editable`, and strips HTML tags and whitespace from the fallback content shown before editing.

Both branches process the result with `Neos.Neos:ConvertUris`. The `uri` prop also runs through `Neos.Neos:ConvertUris` with `forceConversion = true`.

### `Molecule.Image`

```fusion
prototype(FormatD.DesignSystem.Components.Media:Molecule.Image) {
    @propTypes {
        @strict = true
        imageSource = ${PropTypes.any}
        alternativeText = ${PropTypes.string}
        title = ${PropTypes.string}
        hasCaption = ${PropTypes.boolean}
        caption = ${PropTypes.string}
        uri = ${PropTypes.string}
        maxWidth = ${PropTypes.string}
    }
}
```

### `Content.ImageArea` (NodeType renderer)

```fusion
prototype(FormatD.DesignSystem.Components.Media:Content.ImageArea) < prototype(FormatD.DesignSystem.Core:Content.ContentCollection) {
    renderer = FormatD.DesignSystem.Components.Media:Molecule.ImageArea {
        content = Neos.Neos:ContentCollectionRenderer
        verticalPosition = ${node.properties.verticalPosition}
        horizontalPosition = ${node.properties.horizontalPosition}
    }
}
```

### `Molecule.ImageArea`

```fusion
prototype(FormatD.DesignSystem.Components.Media:Molecule.ImageArea) {
    @propTypes {
        @strict = true
        content = ${PropTypes.string}
        horizontalPosition = ${PropTypes.oneOf(['left', 'center', 'right'])}
        verticalPosition = ${PropTypes.oneOf(['top', 'center', 'bottom'])}
    }
}
```

> [!warning] No renderer in this package
> `Molecule.Image` and `Molecule.ImageArea` declare only their strict prop-type contracts. Neither has a `renderer` or AFX markup in this package. A site theme package must add the `renderer` for each, for example to compose a `<picture>` element from `imageSource`. Without such an override, these components render empty content.

---

## Worked example

A theme's `Content.ImageArea` fills with images by nesting `Content.Image` nodes in the backend. Fusion code for a full-width gallery could look like this:

```fusion
prototype(My.Site:Content.Gallery) < prototype(Neos.Neos:ContentComponent) {
    renderer = FormatD.DesignSystem.Components.Media:Content.ImageArea
}
```

Because `Content.ImageArea` already restricts its children to `Content.Image`, no extra `nodeTypes` constraint is needed on the wrapping content type.
