<?php

namespace FormatD\DesignSystem\Components\Icons\Eel\Helper;


use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;

/**
 * Helper for loading svgs from filesystem and modifying them
 */
class SvgHelper implements ProtectedContextAwareInterface
{

	/**
	 * @param string $path
	 * @param array $markers
	 * @return string
	 */
	public function getContent($path, $markers)
	{
		$content = file_get_contents($path);

		$markerKeys = array_keys($markers);
		array_walk($markerKeys, function (&$item, $key) {
			$item = '###' . $item . '###';
		});
		$markerValues = array_values($markers);

		return str_replace($markerKeys, $markerValues, $content);
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName)
	{
		return true;
	}
}
