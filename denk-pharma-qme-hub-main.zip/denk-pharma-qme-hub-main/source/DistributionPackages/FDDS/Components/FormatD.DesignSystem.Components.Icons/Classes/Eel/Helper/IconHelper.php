<?php

namespace FormatD\DesignSystem\Components\Icons\Eel\Helper;


use FormatD\DesignSystem\Components\Icons\Service\IconService;
use Neos\Flow\Annotations as Flow;
use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Exception;
use Neos\Flow\ResourceManagement\ResourceManager;

/**
 * Helper for loading svg icons from filesystem and modifying them
 */
class IconHelper implements ProtectedContextAwareInterface
{

	/**
	 * @Flow\Inject
	 * @var IconService
	 */
	protected $iconService;

	/**
	 * @Flow\Inject
	 * @var ResourceManager
	 */
	protected $resourceManager;

	/**
	 * Returns the raw SVG content with accessibility attributes injected.
	 *
	 * @param string $name
	 * @param string|null $variant
	 * @return string
	 * @throws Exception
	 */
	public function getRawContent(string $name, ?string $variant): string
	{
		$icon = $this->iconService->getIcon($name, $variant);
		if (!$icon) {
			throw new Exception('Icon with name "' . $name . '" not found!', 1700000002);
		}
		$content = file_get_contents($icon['path']);
		return preg_replace('/<svg\b/', '<svg aria-hidden="true" focusable="false"', $content, 1);
	}

	/**
	 * Returns the resolved variant string for the given icon.
	 *
	 * @param string $name
	 * @param string|null $variant
	 * @return string
	 * @throws Exception
	 */
	public function getVariant(string $name, ?string $variant): string
	{
		$icon = $this->iconService->getIcon($name, $variant);
		if (!$icon) {
			throw new Exception('Icon with name "' . $name . '" not found!', 1700000003);
		}
		return $icon['variant'];
	}

	/**
	 * Returns the public URI for animated icons (for use in <img> tags).
	 * Derived from the configured iconCollections path – no hardcoded package name.
	 *
	 * @param string $name
	 * @param string|null $variant
	 * @return string|null
	 */
	public function getPath(string $name, ?string $variant): ?string
	{
		$icon = $this->iconService->getIcon($name, $variant);
		if (!$icon) {
			return null;
		}
		return $this->resourceManager->getPublicPackageResourceUriByPath($icon['path']);
	}

	/**
	 * Returns true if the icon is in the animated variant.
	 *
	 * @param string $name
	 * @param string|null $variant
	 * @return bool
	 */
	public function isAnimated(string $name, ?string $variant): bool
	{
		try {
			$icon = $this->iconService->getIcon($name, $variant);
		} catch (\Exception $e) {
			return false;
		}
		if (!$icon) {
			return false;
		}
		return $icon['variant'] === IconService::VARIANT_ANIMATED;
	}

	/**
	 * All methods are considered safe
	 *
	 * @param string $methodName
	 * @return boolean
	 */
	public function allowsCallOfMethod($methodName)
	{
		return true;
	}
}