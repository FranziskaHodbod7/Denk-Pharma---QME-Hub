<?php
namespace FormatD\DesignSystem\Components\Icons\Service;

use Neos\Flow\Annotations as Flow;
use Neos\Utility\Files;

/**
 * Service for handling Icons
 *
 * @Flow\Scope("singleton")
 */
class IconService {

	const VARIANT_STROKE    = 'stroke';
	const VARIANT_FILL      = 'fill';
	const VARIANT_MULTITONE = 'multitone';
	const VARIANT_ANIMATED  = 'animated';

	/**
	 * @Flow\InjectConfiguration(type="Settings", package="FormatD.DesignSystem.Components.Icons", path="iconCollections")
	 * @var array
	 */
	protected $iconCollectionSettings;

	/**
	 * @var array
	 */
	protected $icons = [];

	/**
	 * init icons collections
	 */
	public function initializeObject() {
		foreach ($this->iconCollectionSettings as $collectionName => $collectionConfig) {
            $collectionIconPaths = [];
		    if (is_array($collectionConfig['path'])) {
		        foreach ($collectionConfig['path'] as $collectionPath) {
                    $collectionIconPaths = array_merge($collectionIconPaths, Files::readDirectoryRecursively($collectionPath));
                }
            } else {
                $collectionIconPaths = Files::readDirectoryRecursively($collectionConfig['path']);
            }

			foreach ($collectionIconPaths as $iconPath) {
				$iconName = basename($iconPath, '.svg');
				$folderName = basename(substr($iconPath, 0, strrpos($iconPath, '/')));
				$variant = $folderName;

				if (!isset($this->icons[$collectionName])) {
					$this->icons[$collectionName] = [];
				}
				if (!isset($this->icons[$collectionName][$iconName])) {
					$this->icons[$collectionName][$iconName] = [
						'name' => $iconName,
						'variants' => []
					];
				}
				$this->icons[$collectionName][$iconName]['variants'][$variant] = [
					'path' => $iconPath,
				];
			}
		}
	}

	/**
	 * @param string $collectionName
	 * @return array
	 */
	public function getIcons($collectionName = null) {

		if ($collectionName) {
			return $this->icons[$collectionName];
		}

		$return = [];
		foreach ($this->icons as $icons) {
			$return = array_merge($return, $icons);
		}
		return $return;
	}

	/**
	 * @param string $name
	 * @param string|null $variant
	 * @param string|null $collectionName
	 * @return array|null
	 * @throws \Exception
	 */
	public function getIcon($name, $variant = null, $collectionName = null) {

		if ($collectionName) {
			$iconData = $this->icons[$collectionName][$name] ?? null;
		} else {
			// Scan all collections without breaking early.
			// Prefer single-variant entries; among equal quality candidates use the last one
			// so the resolution order matches getIcons() which uses array_merge (last wins).
			$iconData = null;
			foreach ($this->icons as $icons) {
				if (!isset($icons[$name])) {
					continue;
				}
				$candidate = $icons[$name];
				if ($iconData === null || count($candidate['variants']) === 1) {
					$iconData = $candidate;
				}
			}
		}

		if (!$iconData) {
			return null;
		}

		if ($variant !== null) {
			if (!isset($iconData['variants'][$variant])) {
				return null;
			}
			return [
				'name'    => $name,
				'variant' => $variant,
				'path'    => $iconData['variants'][$variant]['path'],
			];
		}

		$availableVariants = array_keys($iconData['variants']);
		if (count($availableVariants) === 1) {
			$resolvedVariant = $availableVariants[0];
			return [
				'name'    => $name,
				'variant' => $resolvedVariant,
				'path'    => $iconData['variants'][$resolvedVariant]['path'],
			];
		}

		throw new \Exception(
			"Icon '" . $name . "' exists in multiple variants [" . implode(', ', $availableVariants) . "] – please specify variant",
			1700000001
		);
	}

}