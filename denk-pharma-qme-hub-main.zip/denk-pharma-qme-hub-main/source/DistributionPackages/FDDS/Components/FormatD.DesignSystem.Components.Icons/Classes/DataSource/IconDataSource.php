<?php
namespace FormatD\DesignSystem\Components\Icons\DataSource;

use FormatD\DesignSystem\Components\Icons\Service\IconService;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\ResourceManagement\ResourceManager;
use Neos\Neos\Service\DataSource\AbstractDataSource;

class IconDataSource extends AbstractDataSource {

	/**
	 * @Flow\Inject
	 * @var ResourceManager
	 */
	protected $resourceManager;

	/**
	 * @Flow\Inject
	 * @var IconService
	 */
	protected $iconService;

	/**
	 * @var string
	 */
	protected static $identifier = 'formatd-designsystem-icons';

	/**
	 * Get data
	 *
	 * The return value must be JSON serializable data structure.
	 *
	 * @param Node $node The node that is currently edited (optional)
	 * @param array $arguments Additional arguments (key / value)
	 * @return mixed JSON serializable data
	 * @api
	 */
	public function getData(Node $node = null, array $arguments = []) {
		$collection = isset($arguments['collection']) && $arguments['collection'] ? $arguments['collection'] : null;
		$data = [];
		foreach ($this->iconService->getIcons($collection) as $iconName => $iconInfo)
		{
			$firstVariantPath = '';
			if (!empty($iconInfo['variants'])) {
				$firstVariant = reset($iconInfo['variants']);
				$firstVariantPath = $firstVariant['path'] ?? '';
			}
			$iconUri = $firstVariantPath ? $this->resourceManager->getPublicPackageResourceUriByPath($firstVariantPath) : '';
			$data[$iconName] = ['label' => $iconName, 'value' => $iconName, 'preview' => $iconUri];
		}
        ksort($data);
		return $data;
	}

}