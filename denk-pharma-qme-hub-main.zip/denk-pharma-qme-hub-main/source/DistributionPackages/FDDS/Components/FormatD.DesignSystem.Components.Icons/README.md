# FormatD.DesignSystem.Components.Icons

An SVG icon system for Neos CMS. The package reads icons from the file system at runtime. It renders each icon inline as a `<span>`. It renders animated icons as an `<img>`. CSS classes control the appearance.

---

## Dependencies

| Package | Purpose |
|---|---|
| `formatd/designsystem-core` | Basic configuration of the design system |
| `Neos.Neos` | DataSource API, inspector editors |
| `Neos.Fusion` | Rendering with AFX |

---

## Compatibility

This package has no independent version number. It ships as part of the denk-pharma-qme-hub monorepo.

| Package-Version | Neos Flow Version | Neos CMS Version |
|---|---|---|
| n/a (monorepo) | 9.1.x | 9.1.x |

---

## How to set up icon collections

The package organizes icons in **collections**. Each collection is one folder. The variant name is the name of the **direct parent folder** of the SVG file.

### Default collections (FDDS package)

```yaml
# Settings.yaml
FormatD:
  DesignSystem:
    Components:
      Icons:
        iconCollections:
          stroke:
            path: ['resource://FormatD.DesignSystem.Components.Icons/Public/Icons/stroke']
          fill:
            path: ['resource://FormatD.DesignSystem.Components.Icons/Public/Icons/fill']
          multitone:
            path: ['resource://FormatD.DesignSystem.Components.Icons/Public/Icons/multitone']
          animated:
            path: ['resource://FormatD.DesignSystem.Components.Icons/Public/Icons/animated']
```

### How to override collections in your project

```yaml
# Settings.yaml in the site package
FormatD:
  DesignSystem:
    Components:
      Icons:
        iconCollections:
          stroke:
            path: ['resource://My.SitePackage/Public/Icons/stroke']
          fill:
            path: ['resource://My.SitePackage/Public/Icons/fill']
```

> [!warning] Important
> The `path` value replaces the FDDS default path completely. The package does not append the new path to the default path. One collection can have more than one path:
> ```yaml
> stroke:
>   path:
>     - 'resource://My.SitePackage/Public/Icons/stroke'
>     - 'resource://Another.Package/Public/Icons/stroke'
> ```

### Folder structure

```
Resources/Public/Icons/
  stroke/
    arrow-down.svg      → variant: stroke
    search.svg          → variant: stroke
  fill/
    facebook.svg        → variant: fill
    instagram.svg       → variant: fill
  animated/
    loading.svg         → variant: animated  (the package renders this as <img>)
  multitone/
    logo.svg            → variant: multitone
```

The variant name is the name of the folder that contains the SVG file.

---

## Fusion interface: `Supplier.Icon`

```fusion
FormatD.DesignSystem.Components.Icons:Supplier.Icon {
    name    = ''          # icon file name without .svg  (required)
    variant = null        # 'fill' | 'stroke' | 'multitone' | 'animated' | null
    size    = 'small'     # 'xs' | 'small' | 'medium' | 'large'
    alt     = null        # string → sets role="img" and aria-label; null → sets aria-hidden="true"
}
```

### How the package resolves the variant

| Value of `variant` | Behavior |
|---|---|
| `null` (default) | The package gets the variant from the folder name. If the same icon name exists in more than one collection, the package prefers an entry that has only one variant. If more than one entry remains, the last match wins. This is the same order as the DataSource. |
| explicit string | The package uses this value. PHP then checks that the icon exists in this variant. |

### Rendered HTML

**Inline (stroke / fill / multitone):**
```html
<span class="svg-icon svg-stroke size-small" aria-hidden="true">
    <svg aria-hidden="true" focusable="false">...</svg>
</span>
```

**Animated:**
```html
<img class="svg-icon svg-animated size-small" src="/path/to/icon.svg" alt="" role="presentation">
```

### Examples

```fusion
// Simple use – the package gets the variant from the folder name
FormatD.DesignSystem.Components.Icons:Atom.Icon {
    name = 'arrow-down'
}

// Explicit variant
FormatD.DesignSystem.Components.Icons:Atom.Icon {
    name    = 'facebook'
    variant = 'fill'
    size    = 'medium'
}

// With accessibility text
FormatD.DesignSystem.Components.Icons:Atom.Icon {
    name = 'search'
    alt  = 'Open search'
}
```

---

## NodeType mixins

The package includes mixins for the Neos backend inspector. Each mixin adds a select-box editor. Each editor uses the related DataSource.

### `Mixin.Icon` — all collections

```yaml
'My.Package:Content.MyElement':
  superTypes:
    'FormatD.DesignSystem.Components.Icons:Mixin.Icon': true
```

This mixin shows all configured icons from all collections in the inspector. The package resolves the variant when it renders the icon.

### Mixins for one variant

| Mixin | Collection in the filter |
|---|---|
| `Mixin.VariantStrokeOnly` | `stroke` |
| `Mixin.VariantFillOnly` | `fill` |
| `Mixin.VariantMultitoneOnly` | `multitone` |
| `Mixin.VariantAnimatedOnly` | `animated` |

```yaml
'My.Package:Content.MyElement':
  superTypes:
    'FormatD.DesignSystem.Components.Icons:Mixin.VariantStrokeOnly': true
```

> Use a mixin for one variant if the editor must select icons of only one type. An example is fill icons for social media. Use `Mixin.Icon` if the editor must select both fill icons and stroke icons. In this case the server gets the variant class from the folder name.

### Property name in the NodeType

All mixins define a property with the name `icon`. The type of the property is `string`. Use this property in the Fusion mapping:

```fusion
prototype(My.Package:Content.MyElement) < prototype(Neos.Neos:ContentComponent) {
    renderer = My.Package:Molecule.MyElement {
        iconName = ${node.properties.icon}
    }
}
```

---

## Eel helpers

### `FDDS.Icons.Icon`

| Method | Signature | Description |
|---|---|---|
| `getVariant` | `(name, variant)` | Gives the resolved variant string (`stroke`, `fill`, and others) |
| `getRawContent` | `(name, variant)` | Gives the SVG source code. The method adds `aria-hidden`. |
| `getPath` | `(name, variant)` | Gives the public URL. Use this method for animated icons and `<img>`. |
| `isAnimated` | `(name, variant)` | Gives `true` if the resolved variant is `animated` |

### `FDDS.Icons.Svg`

| Method | Signature | Description |
|---|---|---|
| `getContent` | `(path, markers)` | Reads the SVG from an absolute path. The method replaces each `###MARKER###` placeholder. |

---

## DataSource

Identifier: `formatd-designsystem-icons`

The inspector editor of the mixins uses this DataSource automatically. You can add a filter with `dataSourceAdditionalData`:

```yaml
editorOptions:
  dataSourceIdentifier: formatd-designsystem-icons
  dataSourceAdditionalData:
    collection: 'stroke'   # show only the icons of this collection
```

If you do not set `dataSourceAdditionalData`, the editor shows the icons of all collections together.
