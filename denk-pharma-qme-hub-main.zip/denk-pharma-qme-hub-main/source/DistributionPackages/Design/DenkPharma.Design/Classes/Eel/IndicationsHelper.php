<?php

declare(strict_types=1);

namespace DenkPharma\Design\Eel;

use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;

class IndicationsHelper implements ProtectedContextAwareInterface
{
	/**
	 * @var array<string, array{theme: string, icon: string}>
	 */
	#[Flow\InjectConfiguration(path: 'UI.Indications', package: 'DenkPharma.Design')]
	protected array $indications = [];

	/**
	 * @return array{theme: string, icon: string}
	 */
	public function configFor(?string $name): array
	{
		return $this->indications[$name ?? ''] ?? ['theme' => '', 'icon' => ''];
	}

	public function allowsCallOfMethod($methodName): bool
	{
		return true;
	}
}
