<?php

declare(strict_types=1);

namespace DenkPharma\Design\Controller;

use Neos\ContentRepository\Core\DimensionSpace\OriginDimensionSpacePoint;
use Neos\ContentRepository\Core\Feature\NodeModification\Command\SetNodeProperties;
use Neos\ContentRepository\Core\Feature\NodeModification\Dto\PropertyValuesToWrite;
use Neos\ContentRepository\Core\Feature\NodeRenaming\Command\ChangeNodeAggregateName;
use Neos\ContentRepository\Core\Feature\NodeVariation\Command\CreateNodeVariant;
use Neos\ContentRepository\Core\Feature\NodeVariation\Exception\DimensionSpacePointIsAlreadyOccupied;
use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepository\Core\SharedModel\Node\NodeName;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Sitegeist\Taxonomy\Controller\ModuleController;
use Neos\Flow\Annotations as Flow;


class TaxonomyModuleController extends ModuleController
{
    #[Flow\InjectConfiguration(package: "Sitegeist.Taxonomy", path: "backendModule.additionalFusionIncludePathes")]
    protected mixed $additionalFusionIncludePathes;

    /**
     * @param array<string, string> $properties
     */
    public function updateVocabularyAction(string $vocabularyNodeAddress, string $name, array $properties): void
    {


        $vocabularyNode = $this->taxonomyService->getNodeByNodeAddress($vocabularyNodeAddress);
        $subgraph = $this->contentRepositoryRegistry->subgraphForNode($vocabularyNode);
        $rootNode = $this->taxonomyService->findOrCreateRoot($subgraph);

        $originDimensionSpacePoint = $this->resolveOriginDimensionSpacePoint($vocabularyNode);

        $this->contentRepository->handle(
            SetNodeProperties::create(
                $vocabularyNode->workspaceName,
                $vocabularyNode->aggregateId,
                $originDimensionSpacePoint,
                PropertyValuesToWrite::fromArray($properties)
            )
        );

        if ($name != $vocabularyNode->name?->value) {
            $this->contentRepository->handle(
                ChangeNodeAggregateName::create(
                    $vocabularyNode->workspaceName,
                    $vocabularyNode->aggregateId,
                    NodeName::transliterateFromString($name)
                )
            );
        }

        $this->rebaseCurrentUserWorkspace();

        $updatedVocabularyNode = $subgraph->findNodeById($vocabularyNode->aggregateId);

        if ($updatedVocabularyNode) {
            $this->addFlashMessage(
                sprintf('Updated vocabulary %s', $this->nodeLabelGenerator->getLabel($updatedVocabularyNode))
            );
        }

        $this->redirect('index', null, null, ['rootNodeAddress' => NodeAddress::fromNode($rootNode)->toJson()]);
    }

    /**
     * @param array<string, string> $properties
     */
    public function updateTaxonomyAction(string $taxonomyNodeAddress, string $name, array $properties): void
    {
        $taxonomyNode = $this->taxonomyService->getNodeByNodeAddress($taxonomyNodeAddress);
        $vocabularyNode = $this->taxonomyService->findVocabularyForNode($taxonomyNode);
        $subgraph = $this->taxonomyService->getSubgraphForNode($taxonomyNode);

        $originDimensionSpacePoint = $this->resolveOriginDimensionSpacePoint($taxonomyNode);

        $this->contentRepository->handle(
            SetNodeProperties::create(
                $taxonomyNode->workspaceName,
                $taxonomyNode->aggregateId,
                $originDimensionSpacePoint,
                PropertyValuesToWrite::fromArray($properties)
            )
        );

        if ($name != $taxonomyNode->name?->value) {
            $this->contentRepository->handle(
                ChangeNodeAggregateName::create(
                    $taxonomyNode->workspaceName,
                    $taxonomyNode->aggregateId,
                    NodeName::transliterateFromString($name)
                )
            );
        }

        $this->rebaseCurrentUserWorkspace();

        $updatedTaxonomyNode = $subgraph->findNodeById($vocabularyNode->aggregateId);

        if ($updatedTaxonomyNode) {
            $this->addFlashMessage(
                sprintf('Updated taxonomy %s', $this->nodeLabelGenerator->getLabel($updatedTaxonomyNode))
            );
        }

        $this->redirect('vocabulary', null, null, ['vocabularyNodeAddress' => NodeAddress::fromNode($vocabularyNode)->toJson()]);
    }

    /**
     * If the node is accessed via dimension fallback (dimensionSpacePoint != originDimensionSpacePoint),
     * create an explicit variant in the current dimension so changes are dimension-specific.
     */
    protected function resolveOriginDimensionSpacePoint(Node $node): OriginDimensionSpacePoint
    {
        $desiredOrigin = OriginDimensionSpacePoint::fromDimensionSpacePoint($node->dimensionSpacePoint);

        $this->logger->debug(sprintf(
            'TaxonomyModuleController::resolveOriginDimensionSpacePoint — dimensionSpacePoint=%s originDimensionSpacePoint=%s',
            json_encode($node->dimensionSpacePoint->coordinates),
            json_encode($node->originDimensionSpacePoint->coordinates)
        ));

        if ($desiredOrigin->equals($node->originDimensionSpacePoint)) {
            return $desiredOrigin;
        }

        try {
            $this->contentRepository->handle(
                CreateNodeVariant::create(
                    WorkspaceName::forLive(),
                    $node->aggregateId,
                    $node->originDimensionSpacePoint,
                    $desiredOrigin
                )
            );
            $this->logger->debug('TaxonomyModuleController — CreateNodeVariant succeeded');
        } catch (DimensionSpacePointIsAlreadyOccupied) {
            $this->logger->debug('TaxonomyModuleController — variant already exists, skipping CreateNodeVariant');
        }

        return $desiredOrigin;
    }
}
