import 'vite/modulepreload-polyfill';
import './DesignSystem.scss';

import { componentLoader } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/ComponentLoader";

// Gubther Default - JsEnabledComponents
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Modal:Component.ModalEnabled', () => import('../../../../../FDDS/Components/FormatD.DesignSystem.Components.Modal/Resources/Private/Fusion/Component/ModalEnabled'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Form:Component.AjaxFormEnabled', () => import('../../../../../../DistributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Form/Resources/Private/Fusion/Component/AjaxFormEnabled'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.LoadMore:Component.LoadMoreEnabled', () => import('../../../../../FDDS/Components/FormatD.DesignSystem.Components.LoadMore/Resources/Private/Fusion/Component/LoadMoreEnabled'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Slider:Organism.Slider', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Slider/Resources/Private/Fusion/Presentation/Organism/Slider'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Hero:Molecule.HeroSegment', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Hero/Resources/Private/Fusion/Presentation/Molecule/HeroSegment'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Video:Molecule.Video', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Video/Resources/Private/Fusion/Presentation/Molecule/Video'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Cards:Molecule.NumberCounter', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Cards/Resources/Private/Fusion/Presentation/Molecule/NumberCounter'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.ContentPanels:Molecule.Accordion', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.ContentPanels/Resources/Private/Fusion/Presentation/Molecule/Accordion'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Navigation:Molecule.ScrollToTop',() => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Navigation/Resources/Private/Fusion/Presentation/Molecule/ScrollToTop'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Social:Molecule.ShareBar',() => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Social/Resources/Private/Fusion/Presentation/Molecule/ShareBar'));
// CustomComponents
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Form#Form.Input.Select', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Form/Resources/Private/Fusion/Presentation/Base/Forms/Select'));
componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Form#Form.Input.File', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Form/Resources/Private/Fusion/Presentation/Base/Forms/File'));

componentLoader.addConditionalRegister(() => !!document.querySelector('form'), ['FormatD.DesignSystem.Components.Form#Form.Input.Select', 'FormatD.DesignSystem.Components.Form#Form.Input.File']);
componentLoader.addDefaultImport('FormatD.FlashMessages:Organism.FlashMessages', () => import('@packages/Application/FormatD.FlashMessages/Resources/Private/Fusion/Presentation/Organism/FlashMessages'));

export { componentLoader }
