<?php

declare(strict_types=1);

namespace DenkPharma\Hub\Http\Middleware;

use DenkPharma\User\Domain\Model\User as DenkPharmaUser;
use FormatD\UserManagement\Domain\Service\UserService;
use GuzzleHttp\Psr7\Response;
use Neos\ContentRepository\Core\DimensionSpace\DimensionSpacePoint;
use Neos\ContentRepository\Core\Projection\ContentGraph\Filter\FindDescendantNodesFilter;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAddress;
use Neos\ContentRepository\Core\SharedModel\Workspace\WorkspaceName;
use Neos\ContentRepositoryRegistry\ContentRepositoryRegistry;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Http\ServerRequestAttributes;
use Neos\Flow\Mvc\ActionRequest;
use Neos\Flow\Security\Context as SecurityContext;
use Neos\Neos\Domain\Service\NodeTypeNameFactory;
use Neos\Neos\FrontendRouting\NodeUriBuilderFactory;
use Neos\Neos\FrontendRouting\SiteDetection\SiteDetectionResult;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UriInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

class OnboardingRedirectMiddleware implements MiddlewareInterface
{
    #[Flow\Inject]
    protected SecurityContext $securityContext;

    #[Flow\Inject]
    protected UserService $userService;

    #[Flow\Inject]
    protected ContentRepositoryRegistry $contentRepositoryRegistry;

    #[Flow\Inject]
    protected NodeUriBuilderFactory $nodeUriBuilderFactory;

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
		if (str_starts_with($request->getUri()->getPath(), '/neos')) {
			return $handler->handle($request);
		}

		// Exempt the logout request (FormatD.UserManagementPlugin:Uri.Logout).
		$loginPluginArguments = $request->getQueryParams()['--fdUserManagementPluginLogin'] ?? null;
		if (is_array($loginPluginArguments) && ($loginPluginArguments['@action'] ?? null) === 'logout') {
			return $handler->handle($request);
		}

		if ($request->getMethod() !== 'GET') {
			return $handler->handle($request);
		}

		if (!$this->securityContext->canBeInitialized()) {
			return $handler->handle($request);
		}

		$user = $this->userService->getCurrentUser();
		if (!$user instanceof DenkPharmaUser) {
			return $handler->handle($request);
		}

		if ($user->isOnboardingComplete()) {
            return $handler->handle($request);
        }

        $onboardingUri = $this->resolveOnboardingUri($request);
        if ($onboardingUri === null) {
            return $handler->handle($request);
        }

        $currentPath = rtrim($request->getUri()->getPath(), '/');
        $targetPath = rtrim($onboardingUri->getPath(), '/');
        if ($currentPath === $targetPath) {
            return $handler->handle($request);
        }

        return (new Response(302))->withHeader('Location', (string)$onboardingUri);
    }

    protected function resolveDimensionSpacePoint(ActionRequest $actionRequest): DimensionSpacePoint
    {
        // Use the dimension the router resolved for the requested document (the 'node' route argument).
        if ($actionRequest->hasArgument('node')) {
            $node = $actionRequest->getArgument('node');
            if (is_string($node) && $node !== '') {
                try {
                    return NodeAddress::fromJsonString($node)->dimensionSpacePoint;
                } catch (\Throwable) {
                }
            }
        }

        // en_GB authoring default when no document node was resolved.
        return DimensionSpacePoint::fromArray(['language' => 'en_GB']);
    }

    protected function resolveOnboardingUri(ServerRequestInterface $request): ?UriInterface
    {
        $actionRequest = $request->getAttribute(ServerRequestAttributes::ACTION_REQUEST);
        if (!$actionRequest instanceof ActionRequest) {
            return null;
        }

        try {
            $siteDetectionResult = SiteDetectionResult::fromRequest($request);
        } catch (\Throwable) {
            return null;
        }

        $contentRepository = $this->contentRepositoryRegistry->get($siteDetectionResult->contentRepositoryId);
        $dimensionSpacePoint = $this->resolveDimensionSpacePoint($actionRequest);
        $subgraph = $contentRepository->getContentSubgraph(WorkspaceName::forLive(), $dimensionSpacePoint);

        $rootNode = $subgraph->findRootNodeByType(NodeTypeNameFactory::forSites());
        if ($rootNode === null) {
            return null;
        }

        $siteNode = $subgraph->findNodeByPath(
            $siteDetectionResult->siteNodeName->toNodeName(),
            $rootNode->aggregateId
        );
        if ($siteNode === null) {
            return null;
        }

        $onboardingNodes = $subgraph->findDescendantNodes(
            $siteNode->aggregateId,
            FindDescendantNodesFilter::create(nodeTypes: 'DenkPharma.User:Document.Onboarding')
        );

        $onboardingNode = $onboardingNodes->first();
        if ($onboardingNode === null) {
            return null;
        }

        try {
            return $this->nodeUriBuilderFactory
                ->forActionRequest($actionRequest)
                ->uriFor(NodeAddress::fromNode($onboardingNode));
        } catch (\Throwable) {
            return null;
        }
    }
}
