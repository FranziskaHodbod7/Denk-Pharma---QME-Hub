<?php

declare(strict_types=1);

namespace DenkPharma\Hub\Aspects;

use Neos\ContentRepository\Core\Projection\ContentGraph\Node;
use Neos\ContentRepository\Core\SharedModel\Node\NodeAggregateId;
use Neos\Flow\Annotations as Flow;
use Neos\Flow\Aop\JoinPointInterface;
use Neos\Neos\Fusion\MenuItem;
use Neos\Neos\Fusion\MenuItemState;

/**
 * Enhances MenuItems state for MenuLink shortcut nodes by comparing their resolved
 * target node with the current document node and setting STATE_CURRENT / STATE_ACTIVE accordingly.
 *
 * @Flow\Scope("singleton")
 * @Flow\Aspect
 */
class MenuLinkStateAspect
{
    /**
     * @Flow\Around("method(Neos\Neos\Fusion\MenuItemsImplementation->buildItems())")
     */
    public function enhanceMenuLinkState(JoinPointInterface $joinPoint): array
    {
        $items = $joinPoint->getAdviceChain()->proceed($joinPoint);
        $fusionContext = $joinPoint->getProxy()->getRuntime()->getCurrentContext();
        $currentNode = $fusionContext['documentNode'] ?? null;

        if (!$currentNode instanceof Node) {
            return $items;
        }

        return $this->processItemsRecursive($items, $currentNode);
    }

    /**
     * @param array<int,MenuItem> $items
     * @return array<int,MenuItem>
     */
    private function processItemsRecursive(array $items, Node $currentNode, bool &$foundCurrent = false): array
    {
        $foundCurrent = false;
        $result = [];

        foreach ($items as $item) {
            $foundCurrentInChildren = false;
            $children = !empty($item->children)
                ? $this->processItemsRecursive($item->children, $currentNode, $foundCurrentInChildren)
                : $item->children;

            $state = $item->state;

            if ($state === MenuItemState::NORMAL || $state === null) {
                $target = $item->node->getProperty('target');
                if (is_string($target) && str_starts_with($target, 'node://')) {
                    try {
                        $targetAggregateId = NodeAggregateId::fromString(substr($target, 7));
                        if ($targetAggregateId->equals($currentNode->aggregateId)) {
                            $state = MenuItemState::CURRENT;
                            $foundCurrent = true;
                        }
                    } catch (\InvalidArgumentException) {
                    }
                }
            }

            if ($foundCurrentInChildren && ($state === MenuItemState::NORMAL || $state === null)) {
                $state = MenuItemState::ACTIVE;
                $foundCurrent = true;
            }

            $result[] = new MenuItem(
                $item->node,
                $state,
                $item->label,
                $item->menuLevel,
                $children,
                $item->uri,
            );
        }

        return $result;
    }
}
