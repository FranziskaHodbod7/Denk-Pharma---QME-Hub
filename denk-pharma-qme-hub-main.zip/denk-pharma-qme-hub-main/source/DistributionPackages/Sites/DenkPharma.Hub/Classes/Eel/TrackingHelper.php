<?php

declare(strict_types=1);

namespace DenkPharma\Hub\Eel;

use Neos\Eel\ProtectedContextAwareInterface;
use Neos\Flow\Annotations as Flow;
use Psr\Http\Message\UriInterface;

class TrackingHelper implements ProtectedContextAwareInterface
{
    /**
     * @var string[]
     */
    #[Flow\InjectConfiguration(path: 'tracking.paramPrefixes', package: 'DenkPharma.Hub')]
    protected array $trackingParamPrefixes;

    /**
     * @var string[]
     */
    #[Flow\InjectConfiguration(path: 'tracking.paramExact', package: 'DenkPharma.Hub')]
    protected array $trackingParamExact;

    /**
     * Builds the arguments array for the login page NodeUri.
     *
     * Tracking parameters (utm_*, etcc_*, gclid, …) are extracted from the original
     * URI and added as top-level query parameters so that analytics tools (etracker,
     * LinkedIn, GA4, …) can read them directly from the login page URL.
     * The full original URI — including tracking parameters — is also kept inside
     * redirectUri so that it survives the post-login redirect to the target page.
     *
     * @param UriInterface|string $uri
     * @return array
     */
    public function buildLoginArguments(UriInterface|string $uri): array
    {
        $uriString = (string)$uri;
		$queryString = is_string($uri) ? (parse_url($uri, PHP_URL_QUERY) ?: '') : $uri->getQuery();

        $trackingParams = [];
        if ($queryString !== '') {
            parse_str($queryString, $allParams);
            foreach ($allParams as $key => $value) {
                if ($this->isTrackingParam($key)) {
                    $trackingParams[$key] = $value;
                }
            }
        }

        return array_merge(
            $trackingParams,
            ['--fdUserManagementPluginLogin' => ['redirectUri' => $uriString]]
        );
    }

    private function isTrackingParam(string $key): bool
    {
        if (in_array($key, $this->trackingParamExact, true)) {
            return true;
        }
        foreach ($this->trackingParamPrefixes as $prefix) {
            if (str_starts_with($key, $prefix)) {
                return true;
            }
        }
        return false;
    }

    public function allowsCallOfMethod($methodName): bool
    {
        return true;
    }
}
