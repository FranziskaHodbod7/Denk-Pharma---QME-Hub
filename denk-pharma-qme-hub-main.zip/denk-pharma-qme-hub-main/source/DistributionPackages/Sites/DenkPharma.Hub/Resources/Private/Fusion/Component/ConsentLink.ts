import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager';
import { type DomSection } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/ComponentLoader';

export default class ConsentLink extends AbstractComponentManager {
	initialize(domSection: DomSection): void {
		domSection.querySelectorAll<HTMLElement>('.consent-link').forEach(button => {
			button.addEventListener('click', () => {
				(window as any).et_showOptIn?.();
			});
		});
	}
}
