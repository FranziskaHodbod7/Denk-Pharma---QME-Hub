import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager';
import menuService from '@projectPrivate/TypeScript/MenuService';

export default class AccountMenuComponentManager extends AbstractComponentManager {
	private registrationId: string | null = null;

	initialize(domSection: HTMLElement): void {
		const wrapper = domSection.querySelector<HTMLElement>('.account-menu');
		const button = wrapper?.querySelector<HTMLButtonElement>('.account-btn');
		if (!wrapper || !button) return;

		if (this.registrationId) {
			menuService.unregister(this.registrationId);
			this.registrationId = null;
		}

		this.registrationId = menuService.register(
			'AccountMenu',
			() => {
				wrapper.classList.remove('open');
				button.setAttribute('aria-expanded', 'false');
			},
			wrapper
		);

		button.addEventListener('click', () => {
			const isOpen = wrapper.classList.contains('open');
			menuService.closeAll();
			if (!isOpen) {
				wrapper.classList.add('open');
				button.setAttribute('aria-expanded', 'true');
			}
		});
	}
}
