import '../TypeScript/userPreferencesSync'
import '../TypeScript/mobileNavHeight'
import '@distributionPackages/Packages/DenkPharma.Tracking/Resources/Private/TypeScript/registrationTracking'
import './HubDesign.scss';

import { componentLoader } from "@distributionPackages/Design/DenkPharma.Design/Resources/Private/Fusion/Root"

componentLoader.addDefaultImport('DenkPharma.Hub:Component.Menu', () => import('./Component/Menu'));
componentLoader.addDefaultImport('DenkPharma.Hub:Component.DimensionsMenu', () => import('./Component/DimensionsMenu'));
componentLoader.addDefaultImport('DenkPharma.Hub:Molecule.AccountMenu', () => import('./Presentation/Molecule/AccountMenu'));
componentLoader.addDefaultImport('DenkPharma.Bookmarks:Atom.BookmarkToggle', () => import('@distributionPackages/Packages/DenkPharma.Bookmarks/Resources/Private/Fusion/Presentation/Atom/BookmarkToggle'));
componentLoader.addDefaultImport('DenkPharma.Bookmarks:Component.BookmarkList', () => import('@distributionPackages/Packages/DenkPharma.Bookmarks/Resources/Private/Fusion/Component/BookmarkList'));
componentLoader.addDefaultImport('DenkPharma.Bookmarks:Component.BookmarkSlider', () => import('@distributionPackages/Packages/DenkPharma.Bookmarks/Resources/Private/Fusion/Component/BookmarkSlider'));
componentLoader.addDefaultImport('DenkPharma.Hub:Search.Products', () => import('@projectPrivate/Fusion/Search/ProductSearch'));
componentLoader.addDefaultImport('DenkPharma.Hub:Search.Studies', () => import('@projectPrivate/Fusion/Search/StudySearch'));
componentLoader.addDefaultImport('DenkPharma.Hub:Search.PastEvents', () => import('@projectPrivate/Fusion/Search/PastEventsSearch'));
componentLoader.addDefaultImport('DenkPharma.Hub:Search.Videos', () => import('@projectPrivate/Fusion/Search/VideoSearch'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Onboarding', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Onboarding'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Account.ProfessionalField', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Account/ProfessionalField'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Account.FieldsOfInterest', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Account/FieldsOfInterest'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Account.Profile', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Account/Profile'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Account.Password', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Account/Password'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Account.Notification', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Account/Notification'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Registration.FieldsOfInterest.Widget', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Registration/FieldsOfInterest'));
componentLoader.addDefaultImport('DenkPharma.User:Component.Registration.PhoneNumber.Widget', () => import('@distributionPackages/Packages/DenkPharma.User/Resources/Private/Fusion/Component/Registration/PhoneNumber'));
componentLoader.addDefaultImport('DenkPharma.Hub:Component.PasswordToggle', () => import('./Component/PasswordToggle'));
componentLoader.addDefaultImport('DenkPharma.Hub:Component.ConsentLink', () => import('./Component/ConsentLink'));
componentLoader.addDefaultImport('FormatD.Neos.Captcha.Altcha:Component.Widget', () => import('@packages/Application/FormatD.Neos.Captcha.Altcha/Resources/Private/Fusion/Component/Widget'));

// JsEnabledComponents
//componentLoader.addDefaultImport('FormatD.DesignSystem.Components.Modal:Component.ModalEnabled', () => import('@distributionPackages/FDDS/Components/FormatD.DesignSystem.Components.Modal/Resources/Private/Fusion/Component/ModalEnabled'));
componentLoader.initialize(async (domSection, reason) => {

});
