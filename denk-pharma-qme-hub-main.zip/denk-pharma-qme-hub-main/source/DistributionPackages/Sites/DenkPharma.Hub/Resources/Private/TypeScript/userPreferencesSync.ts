const COOKIE_KEY = 'dp_foi'
const STORAGE_KEY = 'dp_foi'

function readCookieValue(name: string): string | null {
    const match = document.cookie
        .split('; ')
        .find((row) => row.startsWith(`${name}=`))
    return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
}

function deleteCookie(name: string): void {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`
}

const raw = readCookieValue(COOKIE_KEY)
if (raw !== null) {
    try {
        const parsed: unknown = JSON.parse(raw)
        if (Array.isArray(parsed) && parsed.length === 0) {
            localStorage.removeItem(STORAGE_KEY)
        } else if (Array.isArray(parsed) && parsed.length > 0) {
            localStorage.setItem(STORAGE_KEY, raw)
        }
    } catch {
        // malformed cookie — ignore, do not touch localStorage
    }
    deleteCookie(COOKIE_KEY)
}
