import { mount, unmount } from "svelte";
import { AbstractComponentManager } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager";
import type { Translations } from "@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations";
import StudySearchApp from "./StudySearch.svelte";

export default class StudySearchManager extends AbstractComponentManager {
    protected app: ReturnType<typeof mount> | null = null;

    initialize(domSection: HTMLElement) {
        const el = domSection.querySelector<HTMLElement>('[data-search-app="studies"]');
        if (!el) return;

        if (this.app) {
            unmount(this.app);
            this.app = null;
        }

        this.app = mount(StudySearchApp, {
            target: el,
            props: {
                endpoint: el.dataset.endpoint ?? "",
                translations: JSON.parse(el.dataset.translations ?? "{}") as Translations,
            },
        });
    }
}
