<script lang="ts">
	import { createSearchAppState } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/createSearchAppState.svelte.js";
	import { ProductSearchService } from "@distributionPackages/Sites/DenkPharma.Hub/Resources/Private/TypeScript/Search/ProductSearchService";
	import { ComponentLoaderReloadEvent } from "@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/Events";
	import { TranslationService } from "@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations";
	import type { Translations } from "@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations";
	import FilterBar from "./Shared/FilterBar.svelte";
	import LazyLoader from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Utils/LazyLoader.svelte";

	interface Props {
		endpoint: string;
		translations: Translations;
	}

	let { endpoint, translations }: Props = $props();

	const t = $derived(new TranslationService(translations));
	const service = new ProductSearchService();
	const state = createSearchAppState({
		service,
		endpoint: () => endpoint,
	});

	function initBookmarks(node: HTMLElement) {
		document.dispatchEvent(new ComponentLoaderReloadEvent(node));
	}
</script>

<div class="search-app search-app--products">
	<FilterBar
		filterDefinitions={state.filterDefinitions}
		filterItems={state.result.filterItems}
		query={state.query}
		totalCount={state.result.total}
		{translations}
		onquerychange={state.handleQueryChange}
	/>

	{#if state.isLoading}
		<div class="search-app__loading" aria-live="polite">
			{t.translate("search.loading")}
		</div>
	{:else if state.visibleItems.length === 0}
		<div class="search-app__empty" aria-live="polite">
			{t.translate("search.noResults")}
		</div>
	{:else}
		<ul class="search-results-grid menu-grid three-grid">
			{#each state.visibleItems as item (item.identifier)}
				<li class="search-results-grid__item" use:initBookmarks>
					{@html item.data["card"]}
				</li>
			{/each}
		</ul>
		<LazyLoader hasMore={state.hasMore} onloadmore={state.handleLoadMore} />
	{/if}
</div>
