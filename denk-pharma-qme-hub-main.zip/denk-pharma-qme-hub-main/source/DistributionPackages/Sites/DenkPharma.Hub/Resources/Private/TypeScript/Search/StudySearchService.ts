import { TERM_FILTER_KEY } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/types"
import { AbstractSearchService } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/AbstractSearchService"
import { TermFilterType } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/TermFilterType"
import { LocalStorageArrayMatchFilterType } from "./LocalStorageArrayMatchFilterType"

export class StudySearchService extends AbstractSearchService {
    readonly filterTypes = {
        fieldOfInterest: new LocalStorageArrayMatchFilterType('dp_foi'),
        [TERM_FILTER_KEY]: new TermFilterType(),
    }
}
