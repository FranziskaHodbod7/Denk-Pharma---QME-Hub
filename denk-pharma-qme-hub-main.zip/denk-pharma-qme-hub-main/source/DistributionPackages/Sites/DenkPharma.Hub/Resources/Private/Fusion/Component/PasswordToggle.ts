import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager';

export default class PasswordToggle extends AbstractComponentManager {
    initialize(domSection: Document | HTMLElement): void {
        domSection.querySelectorAll<HTMLInputElement>('.password-field').forEach(input => {
            const toggle = input.nextElementSibling as HTMLElement;
            if (!toggle?.classList.contains('form--input-icon')) return;

            input.addEventListener('input', () => {
                toggle.classList.toggle('js--show-icon', input.value.length > 0);
                if (!input.value) {
                    toggle.classList.remove('js--show-password');
                    input.type = 'password';
                }
            });

            toggle.addEventListener('click', () => {
                const isPassword = input.type === 'password';
                input.type = isPassword ? 'text' : 'password';
                toggle.classList.toggle('js--show-password', isPassword);
            });
        });
    }
}
