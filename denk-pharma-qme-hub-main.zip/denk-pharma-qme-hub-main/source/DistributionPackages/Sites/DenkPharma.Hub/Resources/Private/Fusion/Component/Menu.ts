import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager';
import menuService from '@projectPrivate/TypeScript/MenuService';

export default class MenuComponentManager extends AbstractComponentManager {
	private registrationIds: string[] = [];
	private readonly BREAKPOINT = 1024;

	initialize(domSection: HTMLElement): void {
		const buttons = domSection.querySelectorAll<HTMLButtonElement>('.has-dropdown > button');
		if (buttons.length === 0) return;

		this.registrationIds.forEach((id) => menuService.unregister(id));
		this.registrationIds = [];

		buttons.forEach(button => {
			const wrapper = button.closest<HTMLElement>('.has-dropdown');
			if (!wrapper) return;

			const id = menuService.register(
				'NavDropdown',
				() => {
					wrapper.classList.remove('open');
					button.setAttribute('aria-expanded', 'false');
				},
				wrapper
			);
			this.registrationIds.push(id);

			button.addEventListener('click', () => {
				const isOpen = wrapper.classList.contains('open');
				menuService.closeAll();
				if (!isOpen) {
					wrapper.classList.add('open');
					button.setAttribute('aria-expanded', 'true');
					this.alignDropdown(wrapper);
				}
			});
		});
	}

	private alignDropdown(wrapper: HTMLElement): void {
		const dropdown = wrapper.querySelector<HTMLElement>('.menu-dropdown');
		if (!dropdown) return;

		if (window.innerWidth <= this.BREAKPOINT) {
			dropdown.style.left = '';
			dropdown.style.right = '';
			return;
		}

		dropdown.style.left = '0';
		dropdown.style.right = 'auto';

		const rect = dropdown.getBoundingClientRect();
		const overflow = rect.right - window.innerWidth + 16;
		if (overflow > 0) {
			dropdown.style.left = -overflow + 'px';
		}
	}
}
