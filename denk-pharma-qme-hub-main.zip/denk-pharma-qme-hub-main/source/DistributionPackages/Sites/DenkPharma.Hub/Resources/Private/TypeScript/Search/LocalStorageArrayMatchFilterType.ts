import { ArrayMatchFilterType } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/ArrayMatchFilterType"

export class LocalStorageArrayMatchFilterType extends ArrayMatchFilterType {
    constructor(protected readonly storageKey: string) {
        super()
    }

    getDefaultValues(): string[] {
        try {
            const stored = localStorage.getItem(this.storageKey)
            if (!stored) return []
            const parsed: unknown = JSON.parse(stored)
            return Array.isArray(parsed) ? parsed.map(String) : []
        } catch {
            return []
        }
    }
}
