interface RegisteredMenu {
    close: () => void;
    rootElement?: HTMLElement;
}

class MenuService {
    protected menus = new Map<string, RegisteredMenu>();
    protected counter = 0;
    protected handlersInitialized = false;

    register(name: string, close: () => void, rootElement?: HTMLElement): string {
        const id = `${name}-${++this.counter}`;
        this.menus.set(id, { close, rootElement });
        this.initGlobalHandlers();
        return id;
    }

    unregister(id: string): void {
        this.menus.delete(id);
    }

    closeAll(): void {
        this.menus.forEach(({ close }, id) => {
            try {
                close();
            } catch (error) {
                console.error(`MenuService: failed to close "${id}"`, error);
            }
        });
    }

    containsTarget(target: HTMLElement): boolean {
        return [...this.menus.values()].some(({ rootElement }) => rootElement?.contains(target));
    }

    protected initGlobalHandlers(): void {
        if (this.handlersInitialized) return;
        this.handlersInitialized = true;

        document.addEventListener(
            "click",
            (event) => {
                if (!this.containsTarget(event.target as HTMLElement)) {
                    this.closeAll();
                }
            },
            true,
        );

        document.addEventListener("keyup", (evt) => {
            if (evt.key === "Escape") this.closeAll();
        });

        let lastMode = window.innerWidth > 1024 ? "desktop" : "mobile";
        window.addEventListener(
            "resize",
            () => {
                const newMode = window.innerWidth > 1024 ? "desktop" : "mobile";
                if (newMode !== lastMode) {
                    lastMode = newMode;
                    this.closeAll();
                }
            },
            { passive: true },
        );
    }
}

export default new MenuService();
