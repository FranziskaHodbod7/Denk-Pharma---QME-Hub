<script lang="ts">
	import ResultsCount from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Display/ResultsCount.svelte'
	import ResetButton from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Controls/ResetButton.svelte'

	interface Props {
		activeFilterCount: number
		isOverlayOpen: boolean
		totalCount: number
		resultsLabel: string
		filterLabel: string
		resetLabel: string
		ontoggle: () => void
		onreset: () => void
	}

	let {
		activeFilterCount,
		isOverlayOpen,
		totalCount,
		resultsLabel,
		filterLabel,
		resetLabel,
		ontoggle,
		onreset,
	}: Props = $props()
</script>

<div class="search-filter-bar__collapsed-trigger">
	<button
		type="button"
		class="search-filter-bar__collapsed-trigger-button"
		onclick={ontoggle}
		aria-expanded={isOverlayOpen}
	>
		<span>{filterLabel}</span>
		{#if activeFilterCount > 0}
			<span class="search-filter-bar__collapsed-trigger-badge">{activeFilterCount}</span>
		{/if}
	</button>
	<div class="search-filter-bar__collapsed-trigger--sub-controls">
		<div class="reset-btn-wrapper">
			{#if activeFilterCount > 0 && !isOverlayOpen}
				<ResetButton label={resetLabel} {onreset} />
			{/if}
		</div>
		{#if !isOverlayOpen}
			<ResultsCount count={totalCount} label={resultsLabel} />
		{/if}
	</div>
</div>