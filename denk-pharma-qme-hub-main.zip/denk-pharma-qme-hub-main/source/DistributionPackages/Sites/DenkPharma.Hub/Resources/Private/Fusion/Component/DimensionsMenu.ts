import { AbstractComponentManager } from '@packages/Application/FormatD.ComponentLoader/Resources/Private/TypeScript/AbstractComponentManager';
import menuService from '@projectPrivate/TypeScript/MenuService';

export default class DimensionsMenuComponentManager extends AbstractComponentManager {
	private registrationId: string | null = null;

	initialize(domSection: HTMLElement): void {
		const menu = domSection.querySelector<HTMLElement>('.dimension-menu');
		const button = menu?.querySelector<HTMLButtonElement>('button.current');
		if (!menu || !button) return;

		if (this.registrationId) {
			menuService.unregister(this.registrationId);
			this.registrationId = null;
		}

		this.registrationId = menuService.register(
			'DimensionsMenu',
			() => {
				menu.classList.remove('open');
				button.setAttribute('aria-expanded', 'false');
			},
			menu
		);

		button.addEventListener('click', () => {
			const isOpen = menu.classList.contains('open');
			menuService.closeAll();
			if (!isOpen) {
				menu.classList.add('open');
				button.setAttribute('aria-expanded', 'true');
			}
		});
	}
}
