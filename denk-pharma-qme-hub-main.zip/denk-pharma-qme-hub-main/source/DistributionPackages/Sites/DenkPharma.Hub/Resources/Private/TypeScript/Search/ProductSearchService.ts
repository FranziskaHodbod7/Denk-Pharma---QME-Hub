import { TERM_FILTER_KEY } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/types"
import { AbstractSearchService } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/AbstractSearchService"
import { TermFilterType } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/TermFilterType"
import { ArrayMatchFilterType } from "@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/ArrayMatchFilterType"
import { LocalStorageArrayMatchFilterType } from "./LocalStorageArrayMatchFilterType"

export class ProductSearchService extends AbstractSearchService {
    readonly filterTypes = {
        fieldOfInterest: new LocalStorageArrayMatchFilterType('dp_foi'),
        medications: new ArrayMatchFilterType(),
        productType: new ArrayMatchFilterType(),
        [TERM_FILTER_KEY]: new TermFilterType(),
    }
}
