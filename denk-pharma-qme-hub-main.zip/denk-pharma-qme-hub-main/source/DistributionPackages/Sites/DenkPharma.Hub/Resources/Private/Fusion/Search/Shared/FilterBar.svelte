<script lang="ts">
	import { ViewContainer, type SearchFilterDefinition, type SearchFilterItem } from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/types'
	import { Query } from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/TypeScript/Search/Query'
	import { TranslationService } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import type { Translations } from '@packages/Application/FormatD.Flow.FrontendTranslations/Resources/Private/TypeScript/FrontendTranslations'
	import GenericFilterBar from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/FilterBar.svelte'
	import IntersectionSentinel from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Utils/IntersectionSentinel.svelte'
	import ResultsCount from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Display/ResultsCount.svelte'
	import FilterSelect from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Controls/Select.svelte'
	import SearchInput from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Controls/SearchInput.svelte'
	import ResetButton from '@packages/Application/FormatD.Neos.Search.Svelte/Resources/Private/Svelte/Search/Controls/ResetButton.svelte'
	import FilterBarCollapsedTrigger from './FilterBarCollapsedTrigger.svelte'

	interface Props {
		filterDefinitions: SearchFilterDefinition[]
		filterItems: SearchFilterItem[]
		query: Query
		totalCount: number
		translations: Translations
		onquerychange: (q: Query) => void
		hideEmptyFilters?: boolean
		stickyEnabledOnTotalCount?: number
		collapseBreakpoint?: string
	}

	let {
		filterDefinitions,
		filterItems,
		query,
		totalCount,
		translations,
		onquerychange,
		hideEmptyFilters = true,
		stickyEnabledOnTotalCount = 2,
		collapseBreakpoint = '(min-width: 768px)'
	}: Props = $props()

	const t = $derived(new TranslationService(translations))
	const resultsLabel = $derived(
		totalCount === 1
			? t.translate('search.filterBar.resultSingular')
			: t.translate('search.filterBar.resultPlural')
	)

	const stickyEnabled = $derived(totalCount > stickyEnabledOnTotalCount)
	const activeFilterCount = $derived(
		filterItems.filter((fi) => fi.active && !fi.disabled).length + (query.term ? 1 : 0)
	)

	let isSticky = $state(false)
	let isOverlayOpen = $state(false)
	let isDesktop = $state(false)

	$effect(() => {
		const mq = window.matchMedia(collapseBreakpoint)
		isDesktop = mq.matches
		const handler = (e: MediaQueryListEvent) => {
			isDesktop = e.matches
			if (isDesktop) isOverlayOpen = false
		}
		mq.addEventListener('change', handler)
		return () => mq.removeEventListener('change', handler)
	})

	$effect(() => {
		if (!stickyEnabled) {
			isSticky = false
			isOverlayOpen = false
		}
	})

	const filtersHidden = $derived(isSticky && !isOverlayOpen && !isDesktop)

	const filterBarClass = $derived([
		stickyEnabled ? 'search-filter-bar--sticky-enabled' : '',
		isSticky ? 'search-filter-bar--sticky' : '',
		isSticky && isOverlayOpen ? 'search-filter-bar--overlay-open' : '',
	].filter(Boolean).join(' '))

	function toggleOverlay() {
		if (isSticky && !isDesktop) isOverlayOpen = !isOverlayOpen
	}

	function handleReset() {
		onquerychange(Query.empty())
		isOverlayOpen = false
	}
</script>

<IntersectionSentinel
	class="search-filter-sentinel"
	onenter={() => { isSticky = false; isOverlayOpen = false }}
	onleave={() => { if (stickyEnabled) isSticky = true }}
/>

<div class="search-filter-bar {filterBarClass}">
<GenericFilterBar
	{filterDefinitions}
	{filterItems}
	{query}
	{totalCount}
	{onquerychange}
>
	{#snippet controls({ filterDefinitions, query, getOptionsFor, getSelectedFor, activeFilterCount: ctxFilterCount, onfilterchange, ontermchange })}
		<div class="search-filter-bar__inner">
			<FilterBarCollapsedTrigger
				{activeFilterCount}
				{isOverlayOpen}
				{totalCount}
				{resultsLabel}
				filterLabel={t.translate('search.filterBar.filterLabel')}
				resetLabel={t.translate('search.filterBar.resetFilters')}
				ontoggle={toggleOverlay}
				onreset={handleReset}
			/>

			<div class="search-filter-bar__filters" aria-hidden={filtersHidden}>
				<div class="search-filter-bar__controls">
					{#each filterDefinitions as definition (definition.key)}
						{#if definition.key === 'query'}
							<div class="search-filter-bar__search-wrapper">
								<SearchInput
									value={query.term ?? ''}
									onchange={ontermchange}
									placeholder={t.translate('search.filterBar.searchPlaceholder')}
								/>
							</div>
						{:else}
							{@const handleChange = (values: string[]) => onfilterchange(definition.key, values)}
							<FilterSelect
								label={ViewContainer.findFirstLabelView(definition.view)?.text ?? ''}
								filterKey={definition.key}
								options={getOptionsFor(definition.key)}
								selectedValues={getSelectedFor(definition.key)}
								onchange={handleChange}
								hideWhenEmpty={hideEmptyFilters}
							/>
						{/if}
					{/each}
				</div>
				<div class="search-filter-bar__sub-controls">
					<div class="reset-btn-wrapper">
						{#if ctxFilterCount > 0}
							<ResetButton label={t.translate('search.filterBar.resetFilters')} onreset={handleReset} />
						{/if}
					</div>
					<ResultsCount count={totalCount} label={resultsLabel} />
				</div>
			</div>
		</div>
	{/snippet}
</GenericFilterBar>
</div>