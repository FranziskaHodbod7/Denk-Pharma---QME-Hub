const mobileNav = document.querySelector('.header--nav');
if (mobileNav) {
    const update = () => {
        document.documentElement.style.setProperty('--mobile-nav-height', `${mobileNav.getBoundingClientRect().height}px`);
    };
    update();
    new ResizeObserver(update).observe(mobileNav);
}
