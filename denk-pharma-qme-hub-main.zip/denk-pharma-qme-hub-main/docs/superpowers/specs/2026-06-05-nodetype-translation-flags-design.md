# NodeType Translation Flags — Design Spec

**Date:** 2026-06-05
**Topic:** Extending automatic translation coverage via `options.automaticTranslation` flags across NodeTypes

---

## Overview

`FormatD.Neos.FoundTranslation` auto-translates `string` properties that are either `inlineEditable: true` or have `options.automaticTranslation: true`. A number of visitor-facing string properties currently fall through this net. This spec adds the missing flags (opt-in `true` and opt-out `false`) across the relevant NodeTypes, and also adds explicit opt-outs for properties that are `inlineEditable: true` but should not be translated (contact details, numeric values).

---

## Scope

### Not in scope

- Non-string property types (arrays, JSON, references, booleans)
- `Neos.Form.Builder:EmailFinisher.subject` (contains template placeholders, risky for DeepL)
- `FormatD.DesignSystem.Components.Structural:Content.Section.title` (editor-only labeling, not rendered to visitors)

---

## Approach

**Rule:** config lives closest to where the property is defined, respecting package ownership.

- **Owned packages** (`DenkPharma.*`, `DenkPharma.Hub`, `FormatD.VIMP`): flags added directly to the property's own YAML file.
- **FDDS packages** (`source/DistributionPackages/FDDS`): treated as third-party (will be extracted to a separate repo). Overrides go into `DenkPharma.Design/NodeTypes/`, following the existing override pattern there.
- **Truly third-party** (`Neos.*`, `Neos.Form.Builder`): overrides go into `FormatD.Neos.FoundTranslation/Configuration/NodeTypes.yaml`, following the existing `Neos.Neos:Document` pattern.

---

## Changes

### 1. Owned packages — edit in-place

**`DenkPharma.Product/NodeTypes/Abstract/Product.yaml`**
- `title` → `options.automaticTranslation: true`
- `shortDescription` → `options.automaticTranslation: true`

**`DenkPharma.Product/NodeTypes/Abstract/Formulation.yaml`**
- `applicationRecommendation` → `options.automaticTranslation: true`

**`DenkPharma.Product/NodeTypes/Content/ProductAlerts.yaml`**
- `regionalAvailabilityAlert` → `options.automaticTranslation: true`
- `disclaimerAlert` → `options.automaticTranslation: true`

**`DenkPharma.Hub/NodeTypes/Mixin/NavigationTeaser.yaml`**
- `navigationTeaserTitle` → `options.automaticTranslation: true`
- `navigationTeaserText` → `options.automaticTranslation: true`
- `navigationTeaserImageAlt` → `options.automaticTranslation: true`

**`FormatD.VIMP/NodeTypes/Mixin/VimpIframe.yaml`**
- `alternativeVideoTitle` → `options.automaticTranslation: true`

---

### 2. FDDS overrides — `DenkPharma.Design/NodeTypes/FormatD.DesignSystem.Components.Cards/Content/`

**`ContactCard.yaml`** (new file)
```yaml
'FormatD.DesignSystem.Components.Cards:Content.ContactCard':
  properties:
    phone:
      options:
        automaticTranslation: false
    mobile:
      options:
        automaticTranslation: false
    email:
      options:
        automaticTranslation: false
    fax:
      options:
        automaticTranslation: false
    web:
      options:
        automaticTranslation: false
```

**`NumberCounter.yaml`** (new file)
```yaml
'FormatD.DesignSystem.Components.Cards:Content.NumberCounter':
  properties:
    number:
      options:
        automaticTranslation: false
```

---

### 3. Third-party overrides — `FormatD.Neos.FoundTranslation/Configuration/NodeTypes.yaml`

Append the following NodeType blocks:

| NodeType | Property | Value |
|---|---|---|
| `Neos.NodeTypes.BaseMixins:ImageMixin` | `alternativeText` | `true` |
| `Neos.NodeTypes.BaseMixins:ImageMixin` | `title` | `true` |
| `Neos.Seo:OpenGraphMixin` | `openGraphTitle` | `true` |
| `Neos.Seo:OpenGraphMixin` | `openGraphDescription` | `true` |
| `Neos.Form.Builder:LabelMixin` | `label` | `true` |
| `Neos.Form.Builder:PlaceholderMixin` | `placeholder` | `true` |
| `Neos.Form.Builder:NodeBasedForm` | `submitLabel` | `true` |
| `Neos.Form.Builder:SelectOption` | `label` | `true` |
| `Neos.Form.Builder:StaticText` | `text` | `true` |
| `Neos.Form.Builder:ConfirmationFinisher` | `message` | `true` |

---

## Notes

- `ImageMixin.title` renders as the HTML `title` attribute (visible tooltip). Included as `true`; remove if editors use this field for internal notes rather than visitor-facing text.
- The `unit` property on `NumberCounter` is `inlineEditable: true` and thus currently auto-translated. This is intentional — units like "mg" or "Stück" may legitimately differ by language.
- `assetText` on `ContactCard` is `inlineEditable: true` and is left as-is (translatable by default) since it is free-form display text.
