# DesignSystem 

## General Idea

The DesignSystem splits its Presentation from the Integration & Function.


Templates are meant to be copied into the customer project. 
Components and there packages are imported into the customer project.

If there is a deviation between a design system package and its meant-to-be customer implementation, a customer-specific package SHOULD be used instead of extending/overwriting an existing one.


### Template

```
FormatD.DesignSystem:Template.Small
FormatD.DesignSystem:Template.Medium
FormatD.DesignSystem:Template.Large
FormatD.DesignSystem:Template.Platform
// ...
```

### Components

```
FormatD.DesignSystem:Components.Text
FormatD.DesignSystem:Components.Structural
FormatD.DesignSystem:Components.Slider
FormatD.DesignSystem:Components.Tab
FormatD.DesignSystem:Components.Media
// ...
```

### Packages

```
FormatD.DesignSystem:404
FormatD.DesignSystem:Site
// ...
```


## Example

### Vendor

#### Library

Packages under `Vendor` or `FormatD` namespace. 

```
DistributionPackages/Library/**FormatD:Component.VIMP**
```

#### Design & Components

In **Vendor.Design** are all the base presentational and styling things for all Vendor sites.

Everything in **Vendor.Design** is either styling and/or has overrides of an existing `FormatD.DesignSystem:Components.` packages.

Every other package in `/Design/` is a new package that replaces an existing `FormatD.DesignSystem:Components.` package.
```
DistributionPackages/Design/**Vendor.Design** # <-- Design definition and FDDS overrides

DistributionPackages/Design/**Vendor:Design.Component.Slider** # <- instead of FormatD.DesignSystem:Components.Slider
DistributionPackages/Design/**Vendor:Design.Component.Tab** # <- instead of FormatD.DesignSystem:Components.Tab
```

#### Components

Every package is a completely new package not related to the `FormatD.DesignSystem:Components.` packages.

```
DistributionPackages/Component/**Vendor:Component.PriceCalculator** # <- completely new and Vendor specific
```

#### Packages

```
DistributionPackages/Packages/**Vendor:Products** 
```

#### Sites

```
DistributionPackages/Sites/**Vendor.Hub**
DistributionPackages/Sites/**Vendor.Website**
```