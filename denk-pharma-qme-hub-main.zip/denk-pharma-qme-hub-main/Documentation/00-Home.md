<h1 align="left">
  <br />
  <img src="./Cover.svg" alt="Denk Pharma - QME Hub - Logo" width="25%">
  <br />
</h1>
    
[Denk Pharma - QME Hub](https://sammlung-goetz.de) mit Neos CMS.

