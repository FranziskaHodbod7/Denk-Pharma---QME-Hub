# Neos 8.4 vs. Neos 9.1 – Projekt-Setup

Oct 5, 2026 · @Petra Weinmüller

Neos 9 ersetzt das alte Content Repository (NodeData-Tabelle) durch ein Event-sourced Content Repository. Deshalb ändern sich Dimensionen, CLI, Node-APIs und Rechte grundlegend. Basis: DENK PHARMA QME Hub (Neos 9.1.4).

## Auf einen Blick

### Geändert

Gibt es weiterhin, funktioniert oder konfiguriert sich aber anders.

| Thema | Neos 8.4 | Neos 9.1 | Was beachten |
| --- | --- | --- | --- |
| Dimensionen | `Neos.ContentRepository.contentDimensions` mit Presets + Fallback-Listen | `Neos.ContentRepositoryRegistry.contentRepositories.default.contentDimensions` mit `values` + `specializations` | Fallback ergibt sich aus der Hierarchie, nicht aus Preset-Listen |
| URL-Segment je Sprache | `uriSegment` im Preset | Pro Site: `Neos.Neos.sites.<site>.contentDimensions.resolver` | Resolver (z. B. `UriPathResolverFactory`) + `defaultDimensionSpacePoint` pflegen |
| Neue Sprache nachträglich | Config ergänzen, fertig | Config + Node-Migration (`nodemigration:execute`) | Ohne Migration keine Nodes in der neuen Dimension |
| Root-Page (Site-Node) | Bis 8.3 ein normaler Page-Typ (z. B. `Neos.Neos:Document`); seit 8.4 eigener Typ `Neos.Neos:Site` als Vorbereitung auf 9 | Pflicht: Site-NodeType muss von `Neos.Neos:Site` erben; nur dieser Typ ist unter dem Root `Neos.Neos:Sites` erlaubt | Eigenen Site-Typ anlegen und nicht als normale Page verwenden; beim Upgrade alte Root-Pages umstellen |
| Live veröffentlichen | Rolle `Neos.Neos:Editor` | COLLABORATOR-Rolle auf `live`, per Default über `Neos.Neos:LivePublisher` | Eigene Editor-Rollen um `LivePublisher` erweitern |
| Node-Rechte (Backend + Frontend) | `ReadNodePrivilege` / `EditNodePrivilege` mit Eel-Matchern (`isDescendantNodeOf`, `nodeIsOfType` …) | `ReadNodePrivilege` / `EditNodePrivilege` aus `Neos.Neos`, Matcher = Subtree Tag | `ReadNodePrivilege` gilt auch im Backend |
| Geschützte Seiten (Frontend) | `ReadNodePrivilege` mit Pfad- oder NodeType-Matcher | Subtree Tag auf der Seite (vererbt sich) + `ReadNodePrivilege` auf den Tag | Ohne Recht 404 statt 403; Redakteuren das Recht ebenfalls geben |
| Zeitgesteuerte Sichtbarkeit | Im Core | Zusatzpaket `neos/timeable-node-visibility` | Cronjob `timeablenodevisibility:execute` auf jedem System einrichten |
| Fluid-Templates | Gleichwertig zu Fusion, Node-ViewHelpers mit `NodeInterface` | FluidAdaptor noch vorhanden, aber keine Code-Migration für Fluid mit Nodes; nötige APIs evtl. nicht vorhanden | Eigene Templates (Plugins, Module, Mails) nach Fusion/AFX umziehen |

Unverändert: Benutzer und Login (Flow Accounts, Rollen in der Policy.yaml, eigener Auth-Provider fürs Frontend).

### Entfallen

Gibt es in Neos 9 nicht mehr.

| Was | Ersatz in Neos 9.1 | Was beachten |
| --- | --- | --- |
| NodeData-Tabelle, direkt änderbar | Event Store + Projektionen (siehe „Neu“) | Nie in DB-Tabellen schreiben; Änderungen nur über Commands |
| `NodeInterface`, ContextPath, `node.context` | `Node` (read-only), `NodeAddress`, Subgraph, `renderingMode` | Viele 3rd-Party-Pakete brauchen 9er-Versionen |
| `$node->setProperty()` & Co. | Commands auf das Content Repository (`SetNodeProperties`, `CreateNodeVariant` …) | Siehe „Fusion, Eel & PHP“ |
| `_hidden` | Subtree Tag `disabled` | Sichtbar nur mit Privileg `ReadDisabledNodes` |
| Sites.xml (`site:import` / `site:export`) | `site:importAll` / `site:exportAll` (Ordner mit Events + Assets) | Legacy-Import nur über `neos/contentrepository-legacynodemigration` |
| `node:repair`, `node:migrate`, `site:prune` | `structureadjustments:*`, `nodemigration:*`, `site:pruneAll` | Siehe „Setup & Betrieb per CLI“ |
| `CreateNodePrivilege`, `RemoveNodePrivilege`, `EditNodePropertyPrivilege`, `NodeTreePrivilege`; Eel-Matcher nach Pfad, NodeType, Dimension | `ReadNodePrivilege` / `EditNodePrivilege` auf Subtree Tags; NodeType-Constraints | Rechte nach NodeType oder Property gibt es nicht mehr |

### Neu

Gibt es erst seit Neos 9.

| Was | Wofür | Was beachten |
| --- | --- | --- |
| Event Store + Projektionen (Content Graph) | Speichert alle Änderungen als Events; Lese-Tabellen werden daraus erzeugt | Einrichten per `cr:setup`; `flow:cache:flush` setzt Projektionen nicht zurück |
| `DocumentUriPathProjection` | URLs der Dokumente | Bei kaputten URLs: `subscription:replay Neos.Neos:DocumentUriPathProjection` |
| Subtree Tags | Sichtbarkeit und Rechte, vererben sich auf alle Kind-Nodes | Eigene Tags per `FormatD.NodeTypeSubtreeTag` |
| Workspace-Rollen `VIEWER` / `COLLABORATOR` / `MANAGER` | Rechte pro Workspace, vergeben per `workspace:assignRole` | `workspace:createRoot` legt Workspaces ohne Rollen an |
| `moveNodeStrategy` je NodeType | Steuert, was beim Verschieben mit den Sprachvarianten passiert | Default prüfen (wir: `gatherSpecializations` für Sections) |
| `Neos.Caching.entryIdentifierForNode()` | Workspace und Dimension in Cache-Identifier aufnehmen | Siehe „Caching“ |

## Sprachen / Dimensionen anlegen

In 9.1 ist die Dimension auf zwei Stellen verteilt: Die Werte und Fallbacks gehören zum Content Repository, die URL-Zuordnung gehört zur Site.

**Neos 8.4** – alles an einer Stelle, Fallback als Preset-Liste:

```yaml
Neos:
  ContentRepository:
    contentDimensions:
      language:
        default: en_GB
        defaultPreset: en
        presets:
          en: { label: EN, values: [en_GB], uriSegment: en }
          fr: { label: FR, values: [fr_FR, en_GB], uriSegment: fr }
```

**Neos 9.1** – so im QME Hub (`DenkPharma.Hub/Configuration/Settings.Neos.ContentRepositoryRegistry.yaml`):

```yaml
Neos:
  ContentRepositoryRegistry:
    contentRepositories:
      default:
        contentDimensions:
          language:
            values:
              en_GB:
                label: EN
                specializations:   # fallen auf en_GB zurück
                  fr_FR: { label: FR }
                  es_ES: { label: ES }
```

URL-Mapping pro Site (`Settings.Neos.Neos.Site.yaml`):

```yaml
Neos:
  Neos:
    sites:
      '*':
        contentDimensions:
          defaultDimensionSpacePoint: { language: en_GB }
          resolver:
            factoryClassName: Neos\Neos\FrontendRouting\DimensionResolution\Resolver\UriPathResolverFactory
            options:
              segments:
                - dimensionIdentifier: language
                  dimensionValueMapping: { en_GB: en, fr_FR: fr, es_ES: es }
```

Was beachten:

- Fallback heißt jetzt *Shine-through* über `specializations`. Ein Node in `fr_FR` ohne eigene Variante zeigt den `en_GB`-Inhalt. Eine echte Übersetzung entsteht erst durch `CreateNodeVariant`.
- Eine neue Sprache nachträglich hinzufügen: Config ergänzen, dann eine Node-Migration mit `AddDimensionShineThrough` oder `MoveDimensionSpacePoint` per `./flow nodemigration:execute`. Alternativ Varianten mit `./flow content:createVariantsRecursively` erzeugen.
- Dimensionen umbenennen oder entfernen geht nur per Node-Migration; danach `./flow structureadjustments:detect`.
- Fallback-Kette und URL-Mapping sind entkoppelt: Ein Wert ohne Eintrag in `dimensionValueMapping` ist im Frontend nicht erreichbar.
- Eigener Code darf Sprachen nicht aus dem URL-Pfad parsen. Die Dimension kommt aus der aufgelösten `NodeAddress` (siehe `OnboardingRedirectMiddleware`).
- Doku: [Content Dimensions in Neos 9](https://docs.neos.io/guide/content-repository/multiple-content-repositories-v9#configuring-content-dimensions), [Site-Konfiguration](https://docs.neos.io/guide/content-repository/site-configuration#site-configuration-in-settings-yaml)


## Root-Page als eigener NodeType

Die Root-Page einer Site ist seit Neos 8.4 ein eigener NodeType, `Neos.Neos:Site`. In 8.3 und davor war sie ein normaler Page-Typ. In 9.1 ist das Pflicht: Unter dem Root-Node `Neos.Neos:Sites` erlaubt Neos nur Typen, die von `Neos.Neos:Site` erben (`Neos.Neos/NodeTypes/Root/Sites.yaml`).

So im QME Hub (`DenkPharma.Hub/NodeTypes/Document/Site.yaml`):

```yaml
'DenkPharma.Hub:Site':
  superTypes:
    'Neos.Neos:Site': true
  constraints:
    nodeTypes:
      'DenkPharma.Hub:Site': false
```

Was beachten:

- `Neos.Neos:Site` ist abstrakt und erbt von `Neos.Neos:Document`. Ein eigener, konkreter Site-Typ pro Projekt ist nötig.
- Der Site-Typ soll nicht zusätzlich als normale Seite im Baum verwendbar sein. Die Constraint `'DenkPharma.Hub:Site': false` verhindert das.
- `uriPathSegment` ist beim Site-Node ausgeblendet. Die Startseite einer Sprache hängt am Dimensions-Resolver, nicht an einem Pfadsegment.
- Upgrade von 8.3 oder älter: Den NodeType der bestehenden Root-Page vor der Migration nach 9 auf einen Typ mit `Neos.Neos:Site` umstellen.

## Setup & Betrieb per CLI

Neben `doctrine:migrate` braucht ein 9er-Projekt eigene CR-Befehle. Sie gehören in Setup, Deploy und die Projekt-README.

| Aufgabe | Neos 8.4 | Neos 9.1 |
| --- | --- | --- |
| CR-Tabellen anlegen | – (nur `doctrine:migrate`) | `./flow cr:setup` (+ `cr:status`) |
| Site anlegen | `site:create` | `site:create` (legt Root-Workspace und Site-Node per Command an) |
| Inhalte importieren / exportieren | `site:import` / `site:export` (Sites.xml) | `site:importAll` / `site:exportAll` (Ordner mit Events + Assets) |
| Alle Sites löschen | `site:prune` | `site:pruneAll` |
| Projektionen neu aufbauen | – | `subscription:replay <Name>` / `subscription:replayAll` |
| Struktur prüfen | `node:repair` | `structureadjustments:detect` / `structureadjustments:fix` |
| Node-Migration | `node:migrate` | `nodemigration:execute` / `nodemigration:list` / `nodemigration:kickstart` |
| Workspaces | `workspace:*` (einfach) | `workspace:createRoot`, `createShared`, `assignRole`, `rebaseOutdated` … |
| Aufräumen | – | `contentstream:removeDangling`, `contentstream:pruneRemovedFromEventStream` |

Was beachten:

- Bei kaputten URLs nach Import oder Deploy: `./flow subscription:replay Neos.Neos:DocumentUriPathProjection`. Das steht bereits in unserer README.
- `flow:cache:flush` setzt keine Projektionen zurück. Das ist ein häufiger Denkfehler aus 8.4.
- Importe per eigenem Command schreiben Commands in den Live-Workspace, z. B. `CreateNodeAggregateWithNode` im ProductImport. Direkte SQL-Updates sind tabu.
- Zeitgesteuerte Sichtbarkeit braucht einen Cronjob: `timeablenodevisibility:execute`.
- Upgrade 8.4 → 9: eigenes Migrationspaket (`neos/contentrepository-legacynodemigration`) und Export im Legacy-Format. Kein In-Place-Upgrade der Datenbank.

## Fusion, Eel & PHP

Die größten Umbauten im Code entstehen, weil Nodes in 9 unveränderliche Lese-Objekte sind. Änderungen laufen über Commands.

| Neos 8.4 | Neos 9.1 | Beispiel im QME Hub |
| --- | --- | --- |
| `node.context.inBackend` | `renderingMode.isEdit` / `renderingMode.isPreview` | FooterNav |
| `q(node).property('x')` | `node.properties.x` (bzw. `q(node).property()` nur noch eingeschränkt) | Refactoring |
| `node.identifier` / ContextPath | `node.aggregateId` / `NodeAddress` | – |
| `NodeAddress` als Objekt in Redirect-Argumenten | `NodeAddress::fromNode($n)->toJson()` | Vokabular umbenennen |
| `$node->getNodeType()->getName() === '…'` | `$node->nodeTypeName->equals(NodeTypeName::fromString('…'))` | TaxonomyHelper |
| `$node->getParent()`, `getChildNodes()` | `ContentSubgraph` + `findParentNode`, `findChildNodes`, `findAncestorNodes` (mit Filtern) | Search-Controller |
| `$node->setProperty()` | `SetNodeProperties`-Command auf das Content Repository | Importer |
| Neue Sprachvariante implizit | `CreateNodeVariant` explizit | TaxonomyReferenceController |

Was beachten:

- Property-Typen werden serialisiert. `float`/`int` im NodeType müssen zum gespeicherten Wert passen, sonst schlägt Kopieren fehl. Wir haben einen eigenen `ScalarNormalizer` registriert.
- Content-Element-Wrapping für eigene Markup-Blöcke nicht händisch mit `data-__neos-node-contextpath` nachbauen, sondern `ContentElementWrappingService` nutzen (offenes TODO).
- Eigene UI-Plugins, die Nodes ändern, müssen die UI über die Änderung informieren. Sonst zeigt der Publish-Button nichts an.
- 3rd-Party-Pakete auf 9-Kompatibilität prüfen. Im Projekt: Patch für `moc/imageoptimizer` und `flowpack/content-security-policy`; eigener Mailer-Fork.
- `Neos.Ui.nextVersionPreviewBehavior: true` setzen, sonst Fehler in der Vorschau.

### Fluid-Templates ablösen

Fluid und der FluidAdaptor sind in Neos 9.1 noch enthalten. Neos.Neos hängt weiter von `neos/fluid-adaptor` ab, und Teile des Backends rendern noch mit Fluid. Fluid-Templates, die mit Nodes arbeiten, sind in 9 aber eine Sackgasse:

- Für Fusion gibt es automatische Code-Migrationen, für Fluid nicht. Templates mit Nodes müssen von Hand umgebaut werden.
- Laut Upgrade-Guide bringt Neos 9 nicht unbedingt die nötigen APIs für eine Fluid-Integration mit ([Legacy Fluid Templates with Nodes](https://docs.neos.io/api/upgrade-instructions/version-9-x/upgrade-instructions-8-3-9-0)).
- Deshalb eigene Templates (Plugins, Backend-Module, Mails) gleich nach Fusion/AFX umziehen.

So im QME Hub bei den Mails:

- **System-Mails** (Registrierung, Passwort-Reset) sind Fusion/AFX-Overrides der Prototypen `FormatD.UserManagementPlugin:Notification.*` (`DenkPharma.Hub/Resources/Private/Fusion/Overrides/FormatD.UserManagementPlugin/Notification/`). Die Texte kommen aus den Übersetzungsdateien.
- **Formular-Mails** (Form.Builder) sind Seiten vom Typ `FormatD.Mailer:Document.Email` im E-Mail-Ordner (`DenkPharma.Hub:Document.EmailFolder`). Redakteure pflegen sie im Backend über die Bereiche `header`, `main` und `footer`. Gerendert werden sie per Fusion und MJML.

`DenkPharma.Hub/.../Notification/PasswordReset.fusion` (gekürzt):

```fusion
prototype(FormatD.UserManagementPlugin:Notification.PasswordReset) {
    subject = ${Translation.translate('DenkPharma.Hub:NodeTypes.Registration:email.passwordReset.subject')}

    renderer >
    renderer = afx`
        <FormatD.UserManagementPlugin:Notification.EMail baseUri={props.baseUri}>
            <FormatD.UserManagementPlugin:Notification.Partial.Salutation user={props.user} />
            <p>{Translation.translate('DenkPharma.Hub:NodeTypes.Registration:email.passwordReset.text')}</p>
            <FormatD.UserManagementPlugin:Notification.Partial.ResetLink passwordResetToken={props.passwordResetToken} configurationSet={props.configurationSet} />
        </FormatD.UserManagementPlugin:Notification.EMail>
    `
}
```

## Benutzer, Rollen & Rechte

Accounts, Rollen und Login laufen weiter über Flow Security. Neu sind zwei Dinge: Rechte auf Nodes hängen an Subtree Tags, und Rechte auf Workspaces werden pro Workspace vergeben.

| Thema | Neos 8.4 | Neos 9.1 |
| --- | --- | --- |
| Node-Privilegien | `Read`-, `Edit`-, `Create`-, `Remove`-, `EditNodeProperty`- und `NodeTreePrivilege` mit Eel-Matchern (`isDescendantNodeOf("…")`, `nodeIsOfType("…")`, `isInDimensionPreset("…")`) | Nur `Neos\Neos\Security\Authorization\Privilege\ReadNodePrivilege` und `EditNodePrivilege`; Matcher ist der Name eines Subtree Tags (optional `<crId>:<tag>`) |
| Ausgeblendete Nodes | `_hidden`, im Backend über den Context sichtbar | Subtree Tag `disabled`; sichtbar nur mit Privileg `Neos.Neos:ContentRepository.ReadDisabledNodes` (hat `Neos.Neos:AbstractEditor`) |
| Workspace-Rechte | Workspace-Owner; `RestrictedEditor` vs. `Editor` | Rollen `VIEWER`, `COLLABORATOR`, `MANAGER` pro Workspace, vergeben an User oder Gruppe (Flow-Rolle), gespeichert in der DB |
| Live veröffentlichen | Rolle `Neos.Neos:Editor` | COLLABORATOR auf `live`; per Default hat das `Neos.Neos:LivePublisher` |
| Frontend-Login | Eigener Flow-Authentication-Provider | unverändert |
| Geschützte Seiten | `ReadNodePrivilege` mit Pfad- oder NodeType-Matcher | Subtree Tag auf der Seite + `ReadNodePrivilege` auf den Tag |

### Backend-User

Standard-Rollenzuweisung der Workspaces im Core (`WorkspaceRoleAssignments`):

| Workspace | Zuweisung |
| --- | --- |
| `live` | `Neos.Neos:LivePublisher` → COLLABORATOR, `Neos.Flow:Everybody` → VIEWER |
| Shared Workspace | Ersteller → MANAGER, `Neos.Neos:AbstractEditor` → COLLABORATOR |
| Persönlicher Workspace | Besitzer → MANAGER |

Was beachten:

- `Neos.Neos:Editor` besteht aus `AbstractEditor` + `LivePublisher`. `Neos.Neos:RestrictedEditor` hat kein `LivePublisher` und darf nicht nach live veröffentlichen.
- Eigene Editor-Rollen dürfen erst mit `Neos.Neos:LivePublisher` als `parentRole` nach live veröffentlichen (z. B. `DenkPharma:TaxonomyManagerEditor`).
- Workspace-Rechte werden per `./flow workspace:assignRole <workspace> <subject> <role>` vergeben (`--type user` für einzelne User), nicht in der Policy.yaml.
- `./flow workspace:createRoot` legt einen Workspace **ohne** Rollen an. Dann haben nur Administratoren Zugriff, und das Frontend bleibt leer. Die Standard-Zuweisung für `live` setzen nur `site:create` und `site:importAll`. Bei manuell angelegtem Live-Workspace: `./flow workspace:assignRole live Neos.Flow:Everybody viewer` und `./flow workspace:assignRole live Neos.Neos:LivePublisher collaborator`.
- Rechte nach NodeType oder Property („Redakteur darf Typ X nicht anlegen“) gibt es nicht mehr als Privileg. Einschränkungen laufen über Subtree Tags (`EditNodePrivilege`) oder über NodeType-Constraints.
- `ReadNodePrivilege` gilt auch im Backend. Redakteure brauchen deshalb einen GRANT auf geschützte Tags, sonst fehlen die Seiten im Seitenbaum.

### Frontend-User

So im QME Hub:

- Login über den Provider `FormatD.UserManagementPlugin:Login` (`PersistedUsernamePasswordProvider`, eigenes Request-Pattern für das Frontend), Rolle `DenkPharma.Hub:FrontendUser`.
- Geschützte Seiten bekommen über das Mixin `DenkPharma.Hub:Mixin.Restricted` und `FormatD.NodeTypeSubtreeTag` den Tag `denk_pharma_hub-restricted`.
- Controller-Aktionen (Account, Bookmarks) werden wie bisher per `MethodPrivilege` freigegeben.

`DenkPharma.Hub/Configuration/Policy.yaml`:

```yaml
privilegeTargets:
  'Neos\Neos\Security\Authorization\Privilege\ReadNodePrivilege':
    'DenkPharma.Hub:RestrictedNode':
      matcher: 'denk_pharma_hub-restricted'

roles:
  'Neos.Neos:AbstractEditor':
    privileges:
      - privilegeTarget: 'DenkPharma.Hub:RestrictedNode'
        permission: GRANT
  'DenkPharma.Hub:FrontendAbstractUser':
    abstract: true
    privileges:
      - privilegeTarget: 'DenkPharma.Hub:RestrictedNode'
        permission: GRANT
  'DenkPharma.Hub:FrontendUser':
    parentRoles: ['DenkPharma.Hub:FrontendAbstractUser']
```

Was beachten:

- Ein Subtree Tag vererbt sich automatisch auf alle Kind-Nodes. Ein Matcher auf Pfade wie `isDescendantNodeOf` ist nicht nötig.
- Ohne Recht nimmt Neos den getaggten Node komplett aus dem Subgraph heraus. Es gibt kein 403: Die Seite liefert 404, fehlt in Menüs und in Abfragen wie `findChildNodes` oder der Suche. Einen Redirect zum Login muss man selbst bauen.
- Frontend-User brauchen keine Workspace-Rolle. Sie lesen über `Neos.Flow:Everybody` → VIEWER auf `live`.

## Caching

In Neos 8 enthielt der ContextPath eines Nodes Workspace und Dimension. `${node}` im `entryIdentifier` reichte deshalb aus. In 9 ist ein Node nur noch über `aggregateId` + Subgraph eindeutig. Workspace und Dimension müssen ausdrücklich in Identifier und Tags.

### Cache-Einträge dimensionsabhängig machen

So im QME Hub (`DenkPharma.Hub/Resources/Private/Fusion/Root.fusion`, Such-JSON):

```fusion
@cache {
    mode = "cached"
    entryIdentifier {
        fixed = "search__json"
        documentNode = ${Neos.Caching.entryIdentifierForNode(documentNode)}
    }
}
```

Was beachten:

- `Neos.Caching.entryIdentifierForNode()` ist in 9 neu. Der Helper nimmt Workspace und Dimension des Nodes in den Identifier auf.
- Ein Identifier nur mit `fixed` liefert die Sprache, die zuerst gerendert wurde. Genau so lieferte die Suche Ergebnisse in der falschen Sprache.
- Gilt für jedes `@cache` mit eigenem `entryIdentifier`, z. B. Header, Footer und Card-Menüs.

### Cache-Tags für referenzierte Nodes

So im QME Hub (`DenkPharma.Product/NodeTypes/Document/Product.fusion`):

```fusion
@cache {
    entryTags {
        descendants = ${Neos.Caching.descendantOfTag(documentNode)}
        medications = ${Neos.Caching.nodeTag(q(documentNode).referenceNodes("medications").get())}
        studies = ${Neos.Caching.nodeTag(q(documentNode).referenceNodes("studies").get())}
        accumulatedTaxonomies = ${Neos.Caching.nodeTag(DenkPharma.Product.Caching.accumulatedTaxonomiesTags(documentNode))}
    }
}
```

Was beachten:

- Ändert sich ein referenzierter Node, z. B. eine Taxonomie, wird die Seite nur neu gerendert, wenn sie dessen `nodeTag` trägt. Sonst bleiben Detailseiten veraltet.
- Liegen die Referenzen tiefer im Baum, muss man sie selbst einsammeln. Der Helper `DenkPharma\Product\Eel\CachingHelper::accumulatedTaxonomiesTags()` läuft dazu per `findChildNodes` und `findReferences` über Darreichungen, Formulierungen und Wirkstoffe.
- Für Listen, die sich bei jeder Änderung eines bestimmten Typs ändern, eignet sich `nodeTypeTag`. So in `Root.fusion` für die Such-Datensätze:

```fusion
entryTags.relevantNodeTypes = ${Neos.Caching.nodeTypeTag(DenkPharma.Product.Caching.cacheRelevantNodeTypes(), documentNode)}
```

### Benutzerbezogene Bereiche

So im QME Hub (`DenkPharma.Hub/Resources/Private/Fusion/Component/DefaultHeader.fusion`, Account-Menü):

```fusion
<DenkPharma.Hub:Molecule.AccountMenu
    @if.isAuthenticated={Security.isAuthenticated()}
    userName={DenkPharma.User.Current.displayName()}
    @cache.mode="uncached"
    @cache.context.1="node"
    @cache.context.2="documentNode"
    @cache.context.3="site"
/>
```

Was beachten:

- Username, Bookmarks und andere Daten pro User `uncached` rendern, wenn kein sauberer User-Tag möglich ist. Genauso funktioniert der `BookmarkSlider` (`DenkPharma.Bookmarks`).
- Bei `uncached` alle Context-Variablen, die der Teil braucht, unter `@cache.context` auflisten. Sonst fehlen sie beim Nachrendern.
