workspace "Denk Pharma - QME Hub" {
    !docs "."

    model {
        properties {
            "structurizr.groupSeparator" "/"
        }

        archetypes {
            vueApplication = component {
                technology "Vue"
            }

            jsonProvider = component {
                technology "Fusion"
            }

            content = component {
                technology "Fusion"
                tags "FusionComponent"
            }

            service = component {
                technology "PHP Service"
            }

            controller = component {
                technology "Flow Controller"
            }

            moduleController = component {
                technology "Neos Module Controller"
            }

            eelHelper = component {
                technology "EEL Helper"
            }

            domainModel = component {
                technology "Domain Model"
            }

            repository = component {
                technology "Flow Repository"
            }

            middleware = component {
                technology "HTTP Middleware"
            }

            valueObject = component {
                technology "Value Object"
            }
        }


    }

    views {
        properties {
            "generatr.style.colors.primary" "#FFED00"
            "generatr.style.colors.secondary" "#000000"

            "generatr.style.customStylesheet" "main.css"
            "generatr.site.nestGroups" "true"
            "generatr.markdown.flexmark.extensions" "Abbreviation,Admonition,AnchorLink,Attributes,Autolink,Definition,Emoji,Footnotes,GfmTaskList,GitLab,MediaTags,Tables,TableOfContents,Typographic"
            "generatr.site.theme" "light"
        }

        styles {
            element "Database" {
                shape cylinder
            }
        }

    }
}
