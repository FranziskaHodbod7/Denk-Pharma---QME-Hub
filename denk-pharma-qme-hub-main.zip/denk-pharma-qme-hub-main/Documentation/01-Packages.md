# Packages

## DesignSystem

Until the new DesignSystem is released every package resides here as an Distribution Package.

> `FDDS` stands for FormatD Design System

### Template

The **FormatD.DesignSystem:Template.Current** are the current FormatD DesignSystem presentational and styling parts 

```
DistributionPackages/FDDS/Template/**FormatD.DesignSystem:Template.Current**
```

### Components

```
DistributionPackages/FDDS/Components/**FormatD.DesignSystem:Components.Text**
DistributionPackages/FDDS/Components/**FormatD.DesignSystem:Components.Structural**
DistributionPackages/FDDS/Components/**FormatD.DesignSystem:Components.Slider**
DistributionPackages/FDDS/Components/**FormatD.DesignSystem:Components.Tab**
DistributionPackages/FDDS/Components/**FormatD.DesignSystem:Components.Media**
```

## DenkPharma

### Library

Packages under `DenkPharma` or `FormatD` namespace. Might be released publicly in the future

```
DistributionPackages/Library/**FormatD:Component.VIMP**
```

### Design & Components

In **DenkPharma.Design** are all the base presentational and styling things for all DenkPharma sites.

Everything in **DenkPharma.Design** is either styling and/or has overrides of an existing `FormatD.DesignSystem:Components.` packages.

Every other package in `/Design/` is a new package that replaces an existing `FormatD.DesignSystem:Components.` package.
```
DistributionPackages/Design/**DenkPharma.Design** # <-- Design definition and FDDS overrides

DistributionPackages/Design/**DenkPharma:Design.Component.Slider** # <- instead of FormatD.DesignSystem:Components.Slider
DistributionPackages/Design/**DenkPharma:Design.Component.Tab** # <- instead of FormatD.DesignSystem:Components.Tab
```

### Components

Every package is a completely new package not related to the `FormatD.DesignSystem:Components.` packages.

```
DistributionPackages/Component/**DenkPharma:Component.PriceCalculator** # <- completely new and DenkPharma specific
```

### Packages

```
DistributionPackages/Packages/**DenkPharma:Products** 
```

### Sites

```
DistributionPackages/Sites/**DenkPharma.Hub**
DistributionPackages/Sites/**DenkPharma.Website**
```