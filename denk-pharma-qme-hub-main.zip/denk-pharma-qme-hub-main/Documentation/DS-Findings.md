# FormatD.DesignSystem — Package Findings

> Created as part of Step 1 of the DesignSystem Refactoring Plan.
> Source: `source/Packages/Application/FormatD.DesignSystem/`

---

## Package Metadata

- **Composer Name:** `formatd/designsystem`
- **Neos Compatibility:** ^9.0
- **NPM Name:** `formatd-designsystem` (v1.0.2)

### PHP Dependencies
- `neos/neos` ^9.0
- `formatd/componentloader` ~1.0
- `sitegeist/kaleidoscope` ~7.1.0
- `sitegeist/monocle` ^7.11
- `neos/form-builder` ^3.0 + `neos/form-fusionrenderer` ^2.3
- `moc/imageoptimizer` ~4.0 (with patch)
- `cocur/slugify` ^4.6

### Frontend Dependencies
- `swiper` ^11.0.5 (Slider, Gallery)
- `plyr` ~3.8.0 (Video)
- `handorgel` ^1.0.0 (Accordion)
- `shariff` ^3.2.1 (ShareBar)

---

## Overall Scale

| Area | Count |
|------|-------|
| Node Types | 86 YAML files |
| Fusion Files | 121 files |
| PHP Classes | 24 files |
| TypeScript/JS Files | 29 files |
| SCSS Files | 96 files |
| SVG Icons | 144 (72 external + 72 embedded) |
| Configuration Files | 11 YAML files |

---

## Node Types

### Content (30 types)

| Node Type | File | Key Dependencies/Mixins |
|-----------|------|------------------------|
| `Content.Accordion` | Accordion.yaml | ContentCollection, InspectorTitle |
| `Content.Alert` | Alert.yaml | OptionsGroup |
| `Content.Button` | Button.yaml | NodeLink |
| `Content.ButtonArea` | ButtonArea.yaml | ContentCollection |
| `Content.Columns` (abstract) | Columns.yaml | — |
| `Content.Column` | Columns.yaml | — |
| `Content.TwoColumns` | Columns.yaml | Columns mixin |
| `Content.ThreeColumns` | Columns.yaml | Columns mixin |
| `Content.FourColumns` | Columns.yaml | Columns mixin |
| `Content.ContactCard` | ContactCard.yaml | PositionedImageMixin |
| `Content.ContentNavigation` | ContentNavigation.yaml | OptionsGroup, FilterTab |
| `Content.CookieSettingsLink` | CookieSettingsLink.yaml | OptionsGroup |
| `Content.DownloadCard` | DownloadCard.yaml | LinkMixin |
| `Content.Gallery` | Gallery.yaml | ContentCollection |
| `Content.Headline` | Headline.yaml | InlineTitle |
| `Content.HeroSegment` | HeroSegment.yaml | PositionedImageMixin, OverlayOpacity |
| `Content.IconCard` | IconCard.yaml | InlineText |
| `Content.IconLink` | IconLink.yaml | NodeLink |
| `Content.Image` | Image.yaml | ImageMixin |
| `Content.ImageArea` | ImageArea.yaml | — |
| `Content.ImageCard` | ImageCard.yaml | InlineText |
| `Content.NumberCounter` | NumberCounter.yaml | — |
| `Content.Quote` | Quote.yaml | — |
| `Content.ScrollToTop` | ScrollToTop.yaml | — |
| `Content.Section` | Section.yaml | ContentCollection |
| `Content.Slider` | Slider.yaml | — (swiper-based) |
| `Content.Tab` | Tab.yaml | (child of TabArea) |
| `Content.TabArea` | TabArea.yaml | ContentCollection |
| `Content.Table` | Table.yaml | — |
| `Content.Text` | Text.yaml | — |
| `Content.TextWithImageContent` | TextWithImageContent.yaml | — |
| `Content.TextWithImageTeaser` | TextWithImageTeaser.yaml | PositionedImageMixin |
| `Content.Video` | Video.yaml | Video mixin |

**Form:**
- `CountrySelect` (Neos.Form.Builder override)

### Documents (3 types)

| Node Type | File | Notes |
|-----------|------|-------|
| `Document.Site` | Site.yaml | Root site node |
| `Document.AbstractPage` | AbstractPage.yaml | Full HTML doc structure (head/body/footer) |
| `Document.Page` | Page.yaml | Extends AbstractPage |

### Mixins (20)

| Mixin | Purpose |
|-------|---------|
| `Mixin.ContentSection` | Single content area |
| `Mixin.ContentSections` | Multiple content areas |
| `Mixin.FilterGroup` | Filter properties |
| `Mixin.FilterTab` | Tab-based filtering |
| `Mixin.HorizontalPosition` | Left/center/right alignment |
| `Mixin.Icon` | Icon selection |
| `Mixin.ImageOverlay` | Image overlay properties |
| `Mixin.InlineText` | Small text content |
| `Mixin.InlineTitle` | Small title content |
| `Mixin.InspectorTitle` | Label in editor |
| `Mixin.Link` | Link target |
| `Mixin.NodeLink` | Neos node link |
| `Mixin.OptionsGroup` | Options/settings panel |
| `Mixin.OverlayOpacity` | Overlay transparency |
| `Mixin.PositionedImageMixin` | Image + positioning |
| `Mixin.RelationsGroup` | Related content |
| `Mixin.RelationsTab` | Relations inspector tab |
| `Mixin.TextStyles` | Text formatting options |
| `Mixin.VerticalPosition` | Top/center/bottom alignment |
| `Mixin.Video` | Video source properties |

### Form Builder Overrides (6)
Customizations of `Neos.Form.Builder` elements:
- `SingleLineText`, `SingleSelectRadiobuttons`, `FileUpload`
- `Section`, `SelectOption`, `NodeBasedForm`

**Disabled via Abstractions.yaml:** Password, DatePicker, MultipleSelect variants, EmailFinisher

### Framework Overrides (3 files)
- `Neos.NodeTypes.BaseMixins/ImageMixin.yaml`
- `Neos.NodeTypes.ContentReferences/ContentReferences.yaml`
- `Neos.NodeTypes.Html/Html.yaml`

---

## Fusion Architecture

### Atomic Design Pattern

```
Atoms (4)
└── Molecules (37+)
    └── Organisms (6)
        └── Content NodeType Prototypes (34) ← map to Molecules/Organisms
```

### Atoms (4)
- `Atom.Headline`, `Atom.Icon`, `Atom.ScrollDown`, `Atom.Text`

### Molecules (37+)
**Structure/Layout:** Section, Column, Columns, ButtonArea
**Navigation:** ExpandableNavigation, Footer
**Containers:** Accordion, TabArea, Tab, TabTitle
**Cards:** ContactCard, DownloadCard, IconCard, ImageCard, IconLink, Pill, Quote
**Media:** Image, ImageArea, Picture, Video, NumberCounter
**Interactive:** ScrollToTop, ShareBar, ToggleSwitch, Button
**Hero:** HeroSegment
**Text:** (via Atom.Text + Atom.Headline)
**Tracking:** GoogleTagManager, GoogleTagManagerNoScript, NoScript
**GDPR:** CookieSettingsLink

### Organisms (6)
- `Organism.AnchorNavigation`, `Organism.DefaultHeader`, `Organism.DimensionsMenu`
- `Organism.Slider`, `Organism.Gallery`

### Utility Components (12)
`/Resources/Private/Fusion/Components/`:
- Navigation: `MainNavigation`, `MainNavigationItemAggregator`, `MenuItems`, `MenuLink`
- Content nav: `ContentNavigation`, `ContentNavigationIconCardRenderer`, `ContentNavigationImageCardRenderer`, `ContentNavigationItemRenderer`
- Aggregators: `AnchorNavigationItems`, `FooterItemAggregator`
- Icons: `FrontendIcons`
- Misc: `ContactCardFooterItem`

### Containers (4 — feature-enabling wrappers)
`/Resources/Private/Fusion/Container/`:
- `AjaxFormEnabled` + AjaxFormEnabled.ts
- `LoadMoreEnabled` + LoadMoreEnabled.ts
- `ModalEnabled` + ModalEnabled.ts
- `NeosCollectionContainer`

### Framework Overrides (16)
`/Resources/Private/Fusion/Overrides/`:
- Neos.Form.Builder: `CountrySelect`, `NodeBasedForm`
- Neos.Form.FusionRenderer: `Form`, `Page`, `Section`, `FormElement`, `FormNavigation`, `Checkbox`, `FileUpload`, `MultiLineText`, `SingleLineText`, `SingleSelectDropdown`, `SingleSelectRadiobuttons`, `StaticText`
- Sitegeist.Monocle: `Preview.Page`

---

## PHP Classes

### EEL Helpers (11)
Accessible in Fusion via `${HelperName.method()}`:
`ArrayHelper`, `AssetHelper`, `CountryHelper`, `DebugHelper`, `EscapeHelper`, `IconHelper`, `JavaScriptHelper`, `StringHelper`, `SvgHelper`, `UriHelper`, `UtilityHelper`

### DataSources (7)
Populate inspector dropdowns:
`AbstractSettingsDataSource`, `ContentSectionsDataSource`, `CountryDataSource`, `GalleryPresetsDataSource`, `IconDataSource`, `SliderPresetsDataSource`, `TabAreaPresetsDataSource`

### Services (3)
`CountryService`, `IconService`, `HashedResourceUriService` (cache-busting)

### Aspects (1)
`BackendFeedbackCollectionAugmentationAspect` (AOP)

---

## Frontend / JavaScript

### Core (6 TS files in `/Resources/Private/JavaScript/`)
`DesignSystem.ts`, `ModalManager.ts`, `LoadMoreEnabled.ts`, `Logger.ts`, `DataLayerPopulator.ts`, `VideoCookieHintHandlingService.ts`

### ComponentLoader Framework (4 TS files)
`AbstractComponentManager.ts`, `LegacyComponentManager.ts`, `Events.ts`, `ComponentManagerEvents.ts`

### Component-specific TS (co-located with Fusion files)
- Molecules: Accordion, ExpandableNavigation, HeroSegment, NumberCounter, ScrollToTop, ShareBar, Video, CookieConsent
- Organisms: AnchorNavigation, DefaultHeader, DimensionsMenu, Slider
- Containers: AjaxFormEnabled, LoadMoreEnabled, ModalEnabled

---

## Icons & Assets

### Icon System (Dual Mode)
- **External:** `Resources/Public/Icons/external/*.svg` — served as files (72 icons)
- **Embedded:** `Resources/Public/Icons/embedded/*.svg` — inlined as SVG (72 icons)

**Icon categories:** Social, Navigation, Communication, UI, Media, Documents, Business, Location

### Internal Images (10)
Video controls, modal controls, fallback image, notifications — `Resources/Public/InternalImages/`

---

## Configuration Highlights

### Component Presets (Settings.yaml)
**Slider:** default, offsetBefore, offsetAfter, cardLayout-default, cardLayout-grid, gallery-default, gallery-with-pagination, gallery-full-width
**Tab Area:** default, vertical-tabs

### Caches
`FormatD_DesignSystem_Service_HashedResourceUriCache` — for resource URL cache-busting

### Translations
`de/Main.xlf`, `en/Main.xlf`

---

## Natural Refactoring Boundaries

Based on functional domains, the following groupings emerge:


| Domain                 | Content Types                                                 | Molecules / Atoms                                                                                          | Organisms                                                                  | JS Dependencies         |
|------------------------|---------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|-------------------------|
| **Text**               | Headline, Text, Quote, Button, ButtonArea, IconLink           | Atom.Headline, Atom.Text, Molecule.Quote, Molecule.Button, Molecule.ButtonArea, Molecule.IconLink          | —                                                                          | —                       |
| **Structural**         | Section, TwoColumns, ThreeColumns, FourColumns, Column        | Molecule.Section, Molecule.Column, Molecule.Columns                                                        | —                                                                          | —                       |
| **Teaser**             | TextWithImageContent, TextWithImageTeaser                     | Molecule.TextWithImageContent, Molecule.TextWithImageTeaser                                                | —                                                                          | —                       |
| **Cards**              | IconCard, ImageCard, ContactCard, DownloadCard, NumberCounter | Molecule.ContactCard, Molecule.DownloadCard, Molecule.IconCard, Molecule.ImageCard, Molecule.NumberCounter | —                                                                          | —                       |
| **Media**              | Image, ImageArea                                              | Molecule.Image, Molecule.ImageArea, Molecule.Picture                                                       | -                                                                          | Swiper                  |
| **Video**              | Video                                                         | Molecule.Video                                                                                             | —                                                                          | Plyr, VideoCookieHint   |
| **Slider**             | Slider, Gallery                                               | —                                                                                                          | Organism.Slider, Organism.Gallery                                                          | Swiper                  |
| **Content Panels**     | Tab, TabArea, Accordion                                       | Molecule.Tab, Molecule.TabTitle, Molecule.Accordion                                                        | —                                                                          | Swiper, Handorgel       |
| **Navigation**         | ContentNavigation                                             | Molecule.ExpandableNavigation, Molecule.Footer                                                             | Organism.DefaultHeader, Organism.AnchorNavigation, Organism.DimensionsMenu | —                       |
| **Form**               | Form Builder overrides, CountrySelect                         | AjaxFormEnabled                                                                                            | —                                                                          | —                       |
| **Load More**          | —                                                             | LoadMoreEnabled                                                                                            | —                                                                          | —                       |
| **Tracking & Consent** | —                                                             | Molecule.GoogleTagManager, Molecule.GoogleTagManagerNoScript, Molecule.CookieSettingsLink                  | —                                                                          | DataLayerPopulator      |
| **Base / Core**        | All Mixins, Document types, Site, ScrollToTop, Alert          | Atom.Icon, Molecule.NoScript, Molecule.Pill, Atom.ScrollDown, Molecule.ScrollTop, Molecule.Alert           | —                                                                          | ComponentLoader, Logger |
| **Modal**              | -                                                             | ModalEnabled                                                                                               | -----------                                                                | ComponentLoader         |
| **Hero**               | HeroSegment                                                   | Molecule.HeroSegment                                                                                       | -----------                                                                | ComponentLoader         |
| **Social**             | -                                                             | Molecule.ShareBar                                                                                          | -----------                                                                | ComponentLoader         |


