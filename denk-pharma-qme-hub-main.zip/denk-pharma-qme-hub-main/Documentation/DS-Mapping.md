# DesignSystem — Component-Level Mapping

> Step 2 des DesignSystem Refactoring Plans.
> Basis: `DS-Findings.md` (Groupings-Tabelle) + `Documentation/01-Packages.md` (Zielstruktur).
>
> **Bitte reviewen und anpassen, bevor Step 3 beginnt.**

---

## Ziel-Pakete Übersicht

| Target Package | Ordner | Kurzinhalt |
|---------------|--------|------------|
| `FormatD.DesignSystem` | `FDDS/Base/` | Basis: Mixins, Documents, EEL-Helpers, Services, Core-JS |
| `FormatD.DesignSystem:Template.Current` | `FDDS/Template/` | Document-Typen, AbstractPage, Site, Page |
| `FormatD.DesignSystem:Components.Text` | `FDDS/Components/` | Text, Headline, Quote, Button, ButtonArea, IconLink |
| `FormatD.DesignSystem:Components.Structural` | `FDDS/Components/` | Section, Columns |
| `FormatD.DesignSystem:Components.Teaser` | `FDDS/Components/` | TextWithImageContent, TextWithImageTeaser |
| `FormatD.DesignSystem:Components.Cards` | `FDDS/Components/` | IconCard, ImageCard, ContactCard, DownloadCard, NumberCounter |
| `FormatD.DesignSystem:Components.Hero` | `FDDS/Components/` | HeroSegment |
| `FormatD.DesignSystem:Components.Media` | `FDDS/Components/` | Image, ImageArea |
| `FormatD.DesignSystem:Components.Video` | `FDDS/Components/` | Video |
| `FormatD.DesignSystem:Components.Slider` | `FDDS/Components/` | Slider, Gallery |
| `FormatD.DesignSystem:Components.ContentPanels` | `FDDS/Components/` | Tab, TabArea, Accordion |
| `FormatD.DesignSystem:Components.Navigation` | `FDDS/Components/` | ContentNavigation + Navigation-Organisms |
| `FormatD.DesignSystem:Components.Form` | `FDDS/Components/` | Form Builder Overrides, CountrySelect |
| `FormatD.DesignSystem:Components.LoadMore` | `FDDS/Components/` | LoadMoreEnabled Container |
| `FormatD.DesignSystem:Components.Modal` | `FDDS/Components/` | ModalEnabled Container |
| `FormatD.DesignSystem:Components.Social` | `FDDS/Components/` | ShareBar |
| `FormatD.DesignSystem:Components.TrackingConsent` | `FDDS/Components/` | GTM, CookieSettingsLink, NoScript |

---

## Detailliertes Mapping

### `FormatD.DesignSystem` — Base / Core

Verbleibt als Basis-Paket. Alle anderen Pakete dependieren darauf.

**Node Types**
- `NodeTypes/Mixin/` — alle 20 Mixins (vollständig)
- `NodeTypes/NodeTypes.Abstractions.yaml`
- `NodeTypes/NodeTypes.Constraints.yaml`
- `NodeTypes/Neos.NodeTypes.BaseMixins/ImageMixin.yaml` (Override)
- `NodeTypes/Neos.NodeTypes.ContentReferences/ContentReferences.yaml` (Override)
- `NodeTypes/Neos.NodeTypes.Html/Html.yaml` (Override)
- `NodeTypes/Content/Alert.yaml` + `Alert.fusion`
- `NodeTypes/Content/ScrollToTop.yaml` + `ScrollToTop.fusion`

**Fusion**
- `Resources/Private/Fusion/Root.fusion`
- `Resources/Private/Fusion/JsEnabledComponent.fusion`
- `Resources/Private/Fusion/Helper/Json.fusion`
- `Resources/Private/Fusion/Presentation/Atom/Atom.Icon.*` *(shared — wird als Dependency in Cards, Navigation etc. genutzt)*
- `Resources/Private/Fusion/Presentation/Molecule/Molecule.Pill.*`
- `Resources/Private/Fusion/Presentation/Molecule/Molecule.Alert.*`
- `Resources/Private/Fusion/Presentation/Molecule/Molecule.ScrollToTop.*` (+ `ScrollToTop.ts`)

**PHP Classes**
- `Classes/Package.php`
- `Classes/Exception.php`
- `Classes/Aspect/BackendFeedbackCollectionAugmentationAspect.php`
- `Classes/Service/HashedResourceUriService.php`
- `Classes/Service/IconService.php`
- `Classes/Eel/Helper/ArrayHelper.php`
- `Classes/Eel/Helper/AssetHelper.php`
- `Classes/Eel/Helper/DebugHelper.php`
- `Classes/Eel/Helper/EscapeHelper.php`
- `Classes/Eel/Helper/IconHelper.php`
- `Classes/Eel/Helper/JavaScriptHelper.php`
- `Classes/Eel/Helper/StringHelper.php`
- `Classes/Eel/Helper/SvgHelper.php`
- `Classes/Eel/Helper/UriHelper.php`
- `Classes/Eel/Helper/UtilityHelper.php`
- `Classes/DataSource/AbstractSettingsDataSource.php`
- `Classes/DataSource/ContentSectionsDataSource.php`
- `Classes/DataSource/IconDataSource.php`

**Frontend Assets**
- `Resources/Public/Icons/` (vollständig — 144 SVGs)
- `Resources/Public/InternalImages/` (vollständig)
- `Resources/Private/JavaScript/ComponentLoader/` (4 TS-Files)
- `Resources/Private/JavaScript/DesignSystem.ts`
- `Resources/Private/JavaScript/Logger.ts`
- `Resources/Private/Fusion/ComponentLoader.ts`
- `Resources/Private/Fusion/DesignSystemDefaultImports.ts`
- `Resources/Private/Fusion/Variables.scss`
- `Resources/Private/Fusion/Tailwind.scss`
- `Resources/Private/Fusion/DesignSystem.scss`
- `Resources/Private/Vue/Plugins/Icons.js`

**Configuration**
- `Configuration/Settings.yaml`
- `Configuration/Settings.Neos.Flow.yaml`
- `Configuration/Settings.Neos.Neos.yaml`
- `Configuration/Settings.Neos.Fusion.yaml`
- `Configuration/Settings.Neos.Media.yaml`
- `Configuration/Settings.MOC.ImageOptimizer.yaml`
- `Configuration/Settings.Sitegeist.Monocle.yaml`
- `Configuration/Objects.yaml`
- `Configuration/Policy.Backend.yaml`
- `Configuration/Caches.yaml`

**Translations**
- `Resources/Private/Translations/de/Main.xlf`
- `Resources/Private/Translations/en/Main.xlf`

**Composer Dependencies**
- `neos/neos`, `formatd/componentloader`, `sitegeist/kaleidoscope`, `sitegeist/monocle`, `moc/imageoptimizer`, `cocur/slugify`

---

### `FormatD.DesignSystem:Template.Current`

**Node Types**
- `NodeTypes/Document/Site.yaml`
- `NodeTypes/Document/AbstractPage.yaml`
- `NodeTypes/Document/Page.yaml`

**Fusion**
- `NodeTypes/Document/AbstractPage.fusion`
- `NodeTypes/Document/Page.fusion`
- `Resources/Private/Fusion/Overrides/Sitegeist.Monocle/Preview.Page.fusion`
- `Resources/Private/Fusion/Components/FrontendIcons.fusion`

---

### `FormatD.DesignSystem:Components.Text`

**Node Types**
- `NodeTypes/Content/Headline.yaml` + `Headline.fusion`
- `NodeTypes/Content/Text.yaml` + `Text.fusion`
- `NodeTypes/Content/Quote.yaml` + `Quote.fusion`
- `NodeTypes/Content/Button.yaml` + `Button.fusion`
- `NodeTypes/Content/ButtonArea.yaml` + `ButtonArea.fusion`
- `NodeTypes/Content/IconLink.yaml` + `IconLink.fusion`
- `NodeTypes/Content/Table.yaml` + `Table.fusion`

**Fusion / Presentation**
- `Presentation/Atom/Atom.Headline.*` (fusion, scss, themed.scss)
- `Presentation/Atom/Atom.Text.*`
- `Presentation/Molecule/Molecule.Quote.*`
- `Presentation/Molecule/Molecule.Button.*`
- `Presentation/Molecule/Molecule.ButtonArea.*`
- `Presentation/Molecule/Molecule.IconLink.*`
- `Presentation/Molecule/Molecule.Table.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Structural`

**Node Types**
- `NodeTypes/Content/Section.yaml` + `Section.fusion`
- `NodeTypes/Content/Columns.yaml` + `Columns.fusion` (enthält abstract Columns, Column, TwoColumns, ThreeColumns, FourColumns)

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.Section.*`
- `Presentation/Molecule/Molecule.Column.*`
- `Presentation/Molecule/Molecule.Columns.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Teaser`

**Node Types**
- `NodeTypes/Content/TextWithImageContent.yaml` + `TextWithImageContent.fusion`
- `NodeTypes/Content/TextWithImageTeaser.yaml` + `TextWithImageTeaser.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.TextWithImageContent.*`
- `Presentation/Molecule/Molecule.TextWithImageTeaser.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base), `sitegeist/kaleidoscope`

---

### `FormatD.DesignSystem:Components.Cards`

**Node Types**
- `NodeTypes/Content/IconCard.yaml` + `IconCard.fusion`
- `NodeTypes/Content/ImageCard.yaml` + `ImageCard.fusion`
- `NodeTypes/Content/ContactCard.yaml` + `ContactCard.fusion`
- `NodeTypes/Content/DownloadCard.yaml` + `DownloadCard.fusion`
- `NodeTypes/Content/NumberCounter.yaml` + `NumberCounter.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.ContactCard.*`
- `Presentation/Molecule/Molecule.DownloadCard.*`
- `Presentation/Molecule/Molecule.IconCard.*`
- `Presentation/Molecule/Molecule.ImageCard.*`
- `Presentation/Molecule/Molecule.NumberCounter.*` (+ `NumberCounter.ts`)
- `Presentation/Molecule/Molecule.Pill.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base), `sitegeist/kaleidoscope`

---

### `FormatD.DesignSystem:Components.Hero`

**Node Types**
- `NodeTypes/Content/HeroSegment.yaml` + `HeroSegment.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.HeroSegment.*` (+ `HeroSegment.ts`)
- `Presentation/Atom/Atom.ScrollDown.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base), `sitegeist/kaleidoscope`, `FormatD.DesignSystem:Components.Video`

---

### `FormatD.DesignSystem:Components.Media`

**Node Types**
- `NodeTypes/Content/Image.yaml` + `Image.fusion`
- `NodeTypes/Content/ImageArea.yaml` + `ImageArea.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.Image.*`
- `Presentation/Molecule/Molecule.ImageArea.*`
- `Presentation/Molecule/Molecule.Picture.*`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base), `sitegeist/kaleidoscope`, `moc/imageoptimizer`

---

### `FormatD.DesignSystem:Components.Video`

**Node Types**
- `NodeTypes/Content/Video.yaml` + `Video.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.Video.*` (+ `Video.ts`, `CookieConsent.ts`)

**Frontend Dependencies**
- `plyr` ~3.8.0

**JS**
- `Resources/Private/JavaScript/VideoCookieHintHandlingService.ts`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Slider`

**Node Types**
- `NodeTypes/Content/Slider.yaml` + `Slider.fusion`
- `NodeTypes/Content/Gallery.yaml` + `Gallery.fusion`

**Fusion / Presentation**
- `Presentation/Organism/Organism.Slider.*` (+ `Slider.ts`)
- `Presentation/Organism/Organism.Gallery.*`

**PHP Classes**
- `Classes/DataSource/SliderPresetsDataSource.php`
- `Classes/DataSource/GalleryPresetsDataSource.php`

**Frontend Dependencies**
- `swiper` ^11.0.5

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.ContentPanels`

**Node Types**
- `NodeTypes/Content/TabArea.yaml` + `TabArea.fusion`
- `NodeTypes/Content/Tab.yaml` + `Tab.fusion`
- `NodeTypes/Content/Accordion.yaml` + `Accordion.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.TabArea.*`
- `Presentation/Molecule/Molecule.Tab.*`
- `Presentation/Molecule/Molecule.TabTitle.*`
- `Presentation/Molecule/Molecule.Accordion.*` (+ `Accordion.ts`)

**PHP Classes**
- `Classes/DataSource/TabAreaPresetsDataSource.php`

**Frontend Dependencies**
- `handorgel` ^1.0.0
- `swiper` (ggf. für Tab-Sliding auf Mobile)

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Navigation`

**Node Types**
- `NodeTypes/Content/ContentNavigation.yaml` + `ContentNavigation.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.ExpandableNavigation.*` (+ `ExpandableNavigation.ts`)
- `Presentation/Molecule/Molecule.Footer.*`
- `Presentation/Organism/Organism.DefaultHeader.*` (+ `DefaultHeader.ts`)
- `Presentation/Organism/Organism.AnchorNavigation.*` (+ `AnchorNavigation.ts`)
- `Presentation/Organism/Organism.DimensionsMenu.*` (+ `DimensionsMenu.ts`)

**Fusion / Components**
- `Components/MainNavigation.fusion`
- `Components/MainNavigationItemAggregator.fusion`
- `Components/MenuItems.fusion`
- `Components/MenuLink.fusion`
- `Components/AnchorNavigationItems.fusion`
- `Components/FooterItemAggregator.fusion`
- `Components/ContentNavigation.fusion`
- `Components/ContentNavigationIconCardRenderer.fusion`
- `Components/ContentNavigationImageCardRenderer.fusion`
- `Components/ContentNavigationItemRenderer.fusion`
- `Components/ContactCardFooterItem.fusion`

**Fusion / Container**
- `Container/NeosCollectionContainer.fusion`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Form`

**Node Types**
- `NodeTypes/Neos.Form.Builder/` (alle 6 Overrides)
- `NodeTypes/Content/` — CountrySelect (als Form.Builder Content-Type)

**Fusion / Overrides**
- `Overrides/Neos.Form.Builder/CountrySelect.fusion`
- `Overrides/Neos.Form.Builder/NodeBasedForm.fusion`
- `Overrides/Neos.Form.FusionRenderer/Form.fusion`
- `Overrides/Neos.Form.FusionRenderer/Page.fusion`
- `Overrides/Neos.Form.FusionRenderer/Section.fusion`
- `Overrides/Neos.Form.FusionRenderer/FormElement.fusion`
- `Overrides/Neos.Form.FusionRenderer/FormNavigation.fusion`
- `Overrides/Neos.Form.FusionRenderer/Checkbox.fusion`
- `Overrides/Neos.Form.FusionRenderer/FileUpload.fusion`
- `Overrides/Neos.Form.FusionRenderer/MultiLineText.fusion`
- `Overrides/Neos.Form.FusionRenderer/SingleLineText.fusion`
- `Overrides/Neos.Form.FusionRenderer/SingleSelectDropdown.fusion`
- `Overrides/Neos.Form.FusionRenderer/SingleSelectRadiobuttons.fusion`
- `Overrides/Neos.Form.FusionRenderer/StaticText.fusion`

**Fusion / Container**
- `Container/AjaxFormEnabled.fusion` + `AjaxFormEnabled.ts` + `AjaxFormEnabled.scss`

**PHP Classes**
- `Classes/DataSource/CountryDataSource.php`
- `Classes/Service/CountryService.php`
- `Classes/Eel/Helper/CountryHelper.php`

**Configuration**
- `Configuration/Settings.Neos.Form.yaml`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base), `neos/form-builder`, `neos/form-fusionrenderer`, `cocur/slugify`

---

### `FormatD.DesignSystem:Components.LoadMore`

**Fusion / Container**
- `Container/LoadMoreEnabled.fusion` + `LoadMoreEnabled.ts` + `LoadMoreEnabled.scss`

**JS**
- `Resources/Private/JavaScript/LoadMoreEnabled.ts`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Modal`

**Fusion / Container**
- `Container/ModalEnabled.fusion` + `ModalEnabled.ts` + `ModalEnabled.scss`

**JS**
- `Resources/Private/JavaScript/ModalManager.ts`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.Social`

**Node Types**
- *(kein eigener Content-Typ — ShareBar wird programmatisch eingebunden)*

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.ShareBar.*` (+ `ShareBar.ts`)
- `Presentation/Molecule/Molecule.ToggleSwitch.*`

**Frontend Dependencies**
- `shariff` ^3.2.1

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

### `FormatD.DesignSystem:Components.TrackingConsent`

**Node Types**
- `NodeTypes/Content/CookieSettingsLink.yaml` + `CookieSettingsLink.fusion`

**Fusion / Presentation**
- `Presentation/Molecule/Molecule.GoogleTagManager.*`
- `Presentation/Molecule/Molecule.GoogleTagManagerNoScript.*`
- `Presentation/Molecule/Molecule.NoScript.*`
- `Presentation/Molecule/Molecule.CookieSettingsLink.*`

**JS**
- `Resources/Private/JavaScript/DataLayerPopulator.ts`

**Composer Dependencies**
- `FormatD.DesignSystem` (Base)

---

## Getroffene Entscheidungen

| Thema | Entscheidung |
|-------|-------------|
| **Alert** | In `Base` — Content-Typ + Molecule bleiben im Basis-Paket |
| **ScrollToTop** | In `Base` — Content-Typ + Molecule bleiben im Basis-Paket |
| **Table** | In `Components.Text` — gehört thematisch zu Text-Inhalten |
| **Atom.Icon** | In `Base` — shared utility, andere Pakete dependieren auf Base |
| **IconDataSource** | In `Base` — wird von mehreren Paketen genutzt, Dependency via Base |
| **ContentSectionsDataSource** | In `Base` — wird von mehreren Paketen genutzt, Dependency via Base |
| **Hero → Video** | `Components.Hero` hat explizite Composer-Dependency auf `Components.Video` |
| **Translations** | In `Base` — eine gemeinsame Translation-Datei, kein Aufteilen pro Paket |